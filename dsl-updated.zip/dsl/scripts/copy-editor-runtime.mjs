import { mkdir, copyFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
await mkdir('public/vendor/grapesjs', { recursive: true });
for (const [src, dest] of [['grapesjs/dist/grapes.min.js', 'grapes.min.js'], ['grapesjs/dist/css/grapes.min.css', 'grapes.min.css']]) {
  await copyFile(require.resolve(src), `public/vendor/grapesjs/${dest}`);
}

await mkdir("public/vendor/chartjs", { recursive: true });
await copyFile(join(dirname(require.resolve("chart.js")), "chart.umd.js"), "public/vendor/chartjs/chart.umd.js");
