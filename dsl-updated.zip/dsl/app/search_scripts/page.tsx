'use client';

import { FilterTwoIcon } from '@/public/icons/FilterTwo.icon';
import { SearchIcon } from '@/public/icons/Search.icon';
import { scripts } from '@/src/components/AllModals/SearchModal/constants';
import { SearchScriptFilterModal } from '@/src/components/AllModals/SearchScriptFilterModal/SearchScriptFilterModal';
import CodeMirrorScriptComponent from '@/src/components/CodeMirror/CodeMirrorScriptComponent';
import { Filter } from '@/src/components/Header/interfaces';
import { FilterButton, input } from '@/src/components/Header/style';
import { Button, Stack, TextField, Typography } from '@mui/material';
import { useState } from 'react';

export default function SearchScript(): JSX.Element {
  const [openModal, setOpenModal] = useState<boolean>(false);
  const [searchValue, setSearchValue] = useState('');
  const [filter, setFilter] = useState<Filter[]>(scripts);
  const [jsContent, setJsContent] = useState<string>('');

  const handleClose = () => {
    setOpenModal(false);
  };

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value.toLowerCase();
    setSearchValue(value);
    const filteredByName = scripts.filter((item) => {
      return item.name.toLowerCase().includes(value);
    });

    if (filteredByName.length > 0) {
      setFilter(filteredByName);
    } else {
      const filteredByScript = scripts.filter((item) => {
        return item.script.toLowerCase().includes(value);
      });
      setFilter(filteredByScript);
    }
  };

  return (
    <>
      <SearchScriptFilterModal
        open={openModal}
        handleClose={handleClose}
      />

      <Stack
        direction={'row'}
        sx={{
          justifyContent: 'start',
          alignItems: 'center',
          padding: '42px 0 40px 24px'
        }}
      >
        <Typography
          sx={{
            fontFamily: 'Montserrat',
            fontSize: '32px',
            fontWeight: '500',
            color: '#FFF'
          }}
        >
          Search
        </Typography>
      </Stack>
      <Stack
        direction={'column'}
        sx={{
          padding: '0 24px',
          alignItems: 'start',
          justifyContent: 'start',
          gap: '24px'
        }}
      >
        <Stack
          direction={'row'}
          sx={{
            justifyContent: 'center',
            alignItems: 'center',
            gap: '14px'
          }}
        >
          <Stack
            direction={'row'}
            sx={{
              width: '550px',
              height: '34px',
              justifyContent: 'start',
              alignItems: 'center',
              boxSizing: 'border-box',
              gap: '8px',
              '&:hover': {
                height: '32px',
                border: '1px solid #4170FF',
                backgroundColor: 'rgba(255, 255, 255, 0.15)'
              },
              '&:active': {
                height: '32px',
                border: '1px solid #4170FF',
                backgroundColor: 'rgba(255, 255, 255, 0.15)'
              },
              borderRadius: '4px',
              background: 'rgba(255, 255, 255, 0.10)',
              paddingLeft: '18px'
            }}
          >
            <SearchIcon />
            <TextField
              variant='standard'
              placeholder='Search'
              InputProps={input}
              name='xyz123'
              id='xyz123'
              autoComplete='xyz123'
              value={searchValue}
              onChange={handleInputChange}
            />
          </Stack>
          <FilterButton
            disableTouchRipple={true}
            onClick={() => {
              setOpenModal(true);
            }}
          >
            <FilterTwoIcon />
          </FilterButton>
        </Stack>
        <Stack
          direction={'column'}
          sx={{
            justifyContent: 'start',
            alignItems: 'start',
            gap: '24px',
            overflowY: 'auto',
            '::-webkit-scrollbar': {
              display: 'none'
            },
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
            width: '100%',
            maxHeight: 'calc(100vh - 294px)'
          }}
        >
          {filter?.map((item, index) => (
            <Stack
              direction={'column'}
              sx={{
                alignItems: 'start',
                justifyContent: 'center',
                width: '100%',
                gap: '4px'
              }}
              key={index}
            >
              <Stack
                direction={'row'}
                sx={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  gap: '20px'
                }}
              >
                <Typography
                  sx={{
                    fontFamily: 'Montserrat',
                    fontSize: '16px',
                    fontWeight: '500',
                    color: '#FFF'
                  }}
                >
                  Default processing for Infogreffe (Opendata)
                </Typography>
                <Button
                  sx={{
                    width: '150px',
                    height: '34px',
                    borderRadius: '4px',
                    backgroundColor: '#4170FF',
                    fontFamily: 'Montserrat',
                    fontSize: '14px',
                    fontWeight: 500,
                    color: '#FFF',
                    '&:hover': {
                      backgroundColor: '#547FFF'
                    },
                    '&:active': {
                      backgroundColor: '#6188FF'
                    },
                    textTransform: 'initial'
                  }}
                >
                  Open Full Script
                </Button>
              </Stack>
              <Stack
                sx={{
                  width: '100%',
                  height: '300px',
                  backgroundColor: '#10161C80',
                  borderRadius: '6px',
                  overflow: 'hidden'
                }}
              >
                <CodeMirrorScriptComponent
                  jsContent={jsContent}
                  setJsContent={setJsContent}
                  usingInSearchScripts
                />
              </Stack>
            </Stack>
          ))}
        </Stack>
      </Stack>
    </>
  );
}
