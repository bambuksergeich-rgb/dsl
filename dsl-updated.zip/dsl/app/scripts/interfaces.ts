export interface Data {
  name: string;
  state: string;
  startedDate: string;
  completedDate: string;
  modifiedDate: string;
  modifiedBy: string;
  strarted: boolean;
}
