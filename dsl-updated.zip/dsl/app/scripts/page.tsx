'use client';

import PageSubHeader from '@/src/components/AllSubHeaders/PageSubHeader/PageSubHeader';
import { useEffect, useState } from 'react';
import { ScriptsTable } from '@/src/components/AllTables/ScriptsTable/ScriptsTable';
import { Pagination } from '@/src/components/Pagination/Pagination';
import { Loading } from '@/src/components/Loading/Loading';
import { RooteState, store } from '@/src/store/store';
import { getScripts } from '@/src/store/actions/getScripts';
import { ScriptInterface, ScriptsData } from '@/src/store/counter/scriptsSlice';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { useSearchParams } from 'next/navigation';
import { Stack } from '@mui/material';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { getGroupsAction } from '@/src/store/actions/getGroupsAction';
import { NoData } from '@/src/components/NoData/NoData';
import { fetchApiKey } from '@/src/requests/getApiKey';
import { useWebSocketStatus } from '@/src/hooks/useGetStatusScriptsWS';

export default function Scripts(): JSX.Element {
  const [scriptsPageData, setScriptsPageData] = useState<
    ScriptInterface[] | null
  >(null);
  const [filter, setFilter] = useState<string>('');
  const [filteredData, setFilteredData] = useState<ScriptInterface[] | []>([]);
  const [departmentId, setDepartmentId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [apiKey, setApiKey] = useState<string | null>(null);

  const searchParams = useSearchParams();
  const instances = useSelector(
    (state: RooteState) => state.instances.instances
  );

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getGroupsAction(departmentId, 'SCRIPT'));
    }
  }, [departmentId]);

  useEffect(() => {
    const fetchApiKeyAsync = async () => {
      const fetchedApiKey = await fetchApiKey();
      setApiKey(fetchedApiKey);
    };

    fetchApiKeyAsync();
  }, []);

  useWebSocketStatus(departmentId || null, apiKey, null, null);

  const groups = useSelector((state: State) => state.groups);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getScripts(1, departmentId, filter, setLoading));
    }
  }, [departmentId, filter]);

  const scriptsReduxData: ScriptsData = useSelector(
    (state: State) => state.scripts
  );

  useEffect(() => {
    setFilteredData(scriptsReduxData.content);
  }, [scriptsReduxData.content]);

  useEffect(() => {
    setScriptsPageData(scriptsReduxData.content);
  }, [filteredData]);

  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    if (departmentId) {
      store.dispatch(getScripts(value, departmentId, filter));
      setFilteredData(scriptsReduxData.content);
    }
  };

  if (!departmentId) {
    return <Loading />;
  }
  return (
    <Stack sx={{ height: 'calc(100vh - 81px)' }}>
      <PageSubHeader
        pageName='Scripts'
        filter={filter}
        setFilter={setFilter}
        customPadding='42px 40px 0px 40px'
        createUrl={`/create_script?departmentId=${departmentId}`}
        groups={groups}
      />
      <Stack
        sx={{
          flexDirection: 'column',
          alignItems: 'start',
          gap: '4px',
          padding: '0 40px',
          marginBottom: '24px',
          width: 'calc(100% - 80px)'
        }}
      >
        <TypographyMontserrat500>{`Updated at: ${'16:20:29'}`}</TypographyMontserrat500>
      </Stack>
      {!loading ? (
        scriptsReduxData?.content?.length > 0 ? (
          <>
            <ScriptsTable
              departmentId={departmentId}
              scriptsPageData={scriptsPageData}
            />
            <Pagination
              totalElements={scriptsReduxData.totalElements}
              handleChange={handleChange}
            />
          </>
        ) : (
          <NoData />
        )
      ) : null}
    </Stack>
  );
}
