import { Typography } from '@mui/material';
import { styled } from '@mui/system';

export const style = {};

export const Text = styled(Typography)(({}) => ({
  fontFamily: 'Montserrat',
  fontSize: '16px',
  fontWeight: '500',
  color: '#D3D6E7'
}));
