'use client';

import { EmployeeBody } from '@/src/components/Employee/EmployeeBody';
import { EmployeeHeader } from '@/src/components/Employee/EmployeeHeader';
import { EmployeeSearchBar } from '@/src/components/Employee/EmployeeSearchBar';
import { useEffect, useState } from 'react';
import dayjs from 'dayjs';
import updateLocale from 'dayjs/plugin/updateLocale';
import { store } from '@/src/store/store';
import { getCompany } from '@/src/store/actions/getCompany';
import { Company } from '@/src/store/counter/companySlice';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { useSearchParams } from 'next/navigation';
import { getRoles } from '@/src/store/actions/getRoles';

export default function Employee(): JSX.Element {
  const [searchValue, setSearchValue] = useState('');

  const [departmentId, setDepartmentId] = useState<string>('');

  const searchParams = useSearchParams();

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getRoles(departmentId));
    }
  }, [departmentId]);

  useEffect(() => {
    store.dispatch(getCompany(false));
  }, []);

  const company: Company = useSelector((state: State) => state.company);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(event.target.value);
  };

  dayjs.extend(updateLocale);
  dayjs.updateLocale('en', {
    weekStart: 1
  });

  return (
    <>
      <EmployeeHeader companyName={company.name} />
      <EmployeeSearchBar
        value={searchValue}
        handleChange={handleInputChange}
      />
      <EmployeeBody searchValue={searchValue} />
    </>
  );
}
