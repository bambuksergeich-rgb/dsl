'use client';

import { useActiveGrapesEditor } from '@/src/editor/useActiveGrapesEditor';

/**
 * Backward-compatible hook for legacy consumers.
 * Returns the currently active registered GrapesJS editor without polling window.
 */
export const useGrapesJSEditor = () => useActiveGrapesEditor();
