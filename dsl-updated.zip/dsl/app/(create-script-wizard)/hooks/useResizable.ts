import { useEffect, useRef } from "react";

export const useResizable = (
	handlerRef: React.RefObject<HTMLDivElement>,
	leftSideRef: React.RefObject<HTMLDivElement>,
	rightSideRef: React.RefObject<HTMLDivElement>,
	handlerContainerRef: React.RefObject<HTMLDivElement>
) => {
	const dragAndResize = (event: MouseEvent) => {
		const startX = event.x;
		const lastLeftSideWidth = leftSideRef.current!.clientWidth;
		const lastRightSideWidth = rightSideRef.current!.clientWidth;
		handlerContainerRef.current!.style.width = "200px";
		handlerContainerRef.current!.style.left = "-110px";

		const onMouseMove = (mouseMoveEvent: MouseEvent) => {
			const deltaX = mouseMoveEvent.x - startX;
			leftSideRef.current!.style.width = `${lastLeftSideWidth + deltaX}px`;
			rightSideRef.current!.style.width = `${lastRightSideWidth - deltaX}px`;
		};

		const onMouseUp = () => {
			handlerContainerRef.current!.style.width = "20px";
			handlerContainerRef.current!.style.left = "-20px";
			document.body.removeEventListener("mousemove", onMouseMove);
			document.body.removeEventListener("mouseup", onMouseUp);
		};

		document.body.addEventListener("mousemove", onMouseMove);
		document.body.addEventListener("mouseup", onMouseUp);
	};

	useEffect(() => {
		const handler = handlerRef.current;
		handler?.addEventListener("mousedown", dragAndResize);
		return () => handler?.removeEventListener("mousedown", dragAndResize);
	}, [handlerRef]);
};
