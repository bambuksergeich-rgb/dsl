import React from 'react';

const VerticalSeparatorIcon = () => {
  return (
    <svg width="1" height="24" viewBox="0 0 1 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="1" height="24" rx="0.5" fill="#8996A2" />
    </svg>
  );
};

export default VerticalSeparatorIcon;
