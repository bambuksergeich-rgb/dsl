// icons/Chevron.icon.tsx
import React from "react";

interface ChevronIconProps {
	style?: React.CSSProperties;
	className?: string;
}

export const ChevronIcon: React.FC<ChevronIconProps> = ({
	style,
	className,
}) => {
	return (
		<svg
			width="16"
			height="16"
			viewBox="0 0 24 24"
			fill="none"
			stroke="currentColor"
			strokeWidth="2"
			strokeLinecap="round"
			strokeLinejoin="round"
			style={style}
			className={className}
		>
			<polyline points="6 9 12 15 18 9" />
		</svg>
	);
};
