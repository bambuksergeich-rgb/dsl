import React from "react";

const EyeIcon: React.FC<
	React.SVGProps<SVGSVGElement> & { isHidden?: boolean }
> = ({ isHidden, ...props }) => (
	<svg
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="currentColor"
		{...props}
	>
		{isHidden ? (
			<>
				<path
					d="M2 8S4 4 8 4s6 4 6 4-2 4-6 4-6-4-6-4z"
					stroke="currentColor"
					strokeWidth="1"
					fill="none"
				/>
				<path d="M2 14L14 2" stroke="currentColor" strokeWidth="1" />
			</>
		) : (
			<>
				<path
					d="M2 8S4 4 8 4s6 4 6 4-2 4-6 4-6-4-6-4z"
					stroke="currentColor"
					strokeWidth="1"
					fill="none"
				/>
				<circle
					cx="8"
					cy="8"
					r="2"
					stroke="currentColor"
					strokeWidth="1"
					fill="none"
				/>
			</>
		)}
	</svg>
);

export default EyeIcon;
