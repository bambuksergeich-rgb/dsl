import React from "react";

const InputIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
	<svg
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="currentColor"
		{...props}
	>
		<rect
			x="2"
			y="6"
			width="12"
			height="4"
			stroke="currentColor"
			strokeWidth="1"
			fill="none"
		/>
		<line x1="4" y1="8" x2="6" y2="8" stroke="currentColor" strokeWidth="1" />
	</svg>
);

export default InputIcon;
