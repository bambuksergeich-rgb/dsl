export const ThreeDotsMini = () => {
  return (
    <svg
      xmlns='http://www.w3.org/2000/svg'
      width='11'
      height='2'
      viewBox='0 0 11 2'
      fill='none'
    >
      <path
        d='M5 1H5.01M1 1H1.01M9 1H9.01'
        stroke='white'
        strokeWidth='2'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
};
