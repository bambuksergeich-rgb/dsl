import React from "react";

const CheckboxIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
	<svg
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="currentColor"
		{...props}
	>
		<rect
			x="4"
			y="4"
			width="8"
			height="8"
			stroke="currentColor"
			strokeWidth="1"
			fill="none"
		/>
		<path
			d="M6 8L8 10L10 6"
			stroke="currentColor"
			strokeWidth="1"
			fill="none"
		/>
	</svg>
);

export default CheckboxIcon;
