import React from "react";

const TextareaIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
	<svg
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="currentColor"
		{...props}
	>
		<rect
			x="2"
			y="4"
			width="12"
			height="8"
			stroke="currentColor"
			strokeWidth="1"
			fill="none"
		/>
		<line x1="4" y1="6" x2="12" y2="6" stroke="currentColor" strokeWidth="1" />
		<line
			x1="4"
			y1="10"
			x2="12"
			y2="10"
			stroke="currentColor"
			strokeWidth="1"
		/>
	</svg>
);

export default TextareaIcon;
