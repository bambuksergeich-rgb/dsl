import React from "react";

const ImageIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
	<svg
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="currentColor"
		{...props}
	>
		<rect
			x="2"
			y="2"
			width="12"
			height="12"
			stroke="currentColor"
			strokeWidth="1"
			fill="none"
		/>
		<path
			d="M2 11L6 7L10 11L14 7"
			stroke="currentColor"
			strokeWidth="1"
			fill="none"
		/>
	</svg>
);

export default ImageIcon;
