import React from "react";

const LinkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
	<svg
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="currentColor"
		{...props}
	>
		<path
			d="M4 12L12 4M8 4H12V8M4 8V12H8"
			stroke="currentColor"
			strokeWidth="1"
			fill="none"
		/>
	</svg>
);

export default LinkIcon;
