import React from "react";

const ButtonIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
	<svg
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="currentColor"
		{...props}
	>
		<rect
			x="4"
			y="6"
			width="8"
			height="4"
			rx="1"
			stroke="currentColor"
			strokeWidth="1"
			fill="none"
		/>
	</svg>
);

export default ButtonIcon;
