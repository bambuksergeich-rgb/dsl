import { ComponentConfig } from '../elements';

const LOGIN_USER_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIj4KPGNpcmNsZSBjeD0iMTIiIGN5PSI4IiByPSI0IiBzdHJva2U9IiNGRkZGRkYiIHN0cm9rZS13aWR0aD0iMS43Ii8+CjxwYXRoIGQ9Ik00LjUgMjFjLjgtNSAzLjMtNy41IDcuNS03LjVzNi43IDIuNSA3LjUgNy41IiBzdHJva2U9IiNGRkZGRkYiIHN0cm9rZS13aWR0aD0iMS43IiBzdHJva2UtbGluZWNhcD0icm91bmQiLz4KPC9zdmc+';

export const Login: ComponentConfig = {
  id: 'login',
  type: 'login',
  label: 'Login',
  category: 'Inputs',
  content: {
    tagName: 'div',
    attributes: {
      class: 'login-control',
      'data-value': '',
      'data-invalid': 'false'
    },
    selectable: true,
    hoverable: true,
    components: [
      {
        tagName: 'div',
        attributes: { class: 'login-input-wrapper' },
        selectable: false,
        draggable: false,
        hoverable: false,
        components: [
          {
            tagName: 'input',
            attributes: {
              type: 'text',
              class: 'login-input',
              placeholder: 'Enter text',
              autocomplete: 'username'
            },
            draggable: false,
            selectable: false,
            hoverable: false
          },
          {
            tagName: 'span',
            attributes: { class: 'login-icon' },
            draggable: false,
            selectable: false,
            hoverable: false,
            components: [
              {
                tagName: 'img',
                attributes: {
                  class: 'login-icon-image',
                  src: LOGIN_USER_ICON,
                  alt: ''
                },
                draggable: false,
                selectable: false,
                hoverable: false
              }
            ]
          }
        ]
      },
      {
        tagName: 'div',
        attributes: { class: 'login-error-message' },
        content: 'Not right login',
        draggable: false,
        selectable: false,
        hoverable: false
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="3" y="5" width="18" height="14" rx="2" stroke="white" stroke-width="1.5"/>
    <circle cx="12" cy="10" r="2.5" stroke="white" stroke-width="1.5"/>
    <path d="M7.5 17c.5-2.5 2-3.8 4.5-3.8s4 1.3 4.5 3.8" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
  </svg>`,
  traits: [
    {
      id: 'showIcon',
      name: 'showIcon',
      label: 'Show Icon',
      type: 'checkbox',
      changeProp: true,
      value: true
    },
    {
      id: 'placeholder',
      name: 'placeholder',
      label: 'Placeholder',
      type: 'text',
      placeholder: 'Enter text',
      changeProp: true,
      value: 'Enter text'
    },
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'Image',
      type: 'select-icon',
      changeProp: true,
      value: ''
    }
  ],
  styles: `
/* Standard single-line control height from the editor design. */
.login-input-wrapper .login-input { height: 34px !important; min-height: 34px !important; max-height: 34px !important; line-height: 20px !important; }
[data-draft-id].login-input-wrapper, .login-input-wrapper { height: 34px !important; min-height: 34px !important; max-height: 34px !important; }

    .login-control {
      position: relative;
      display: inline-flex;
      flex-direction: column;
      align-items: stretch;
      width: 320px;
      min-width: 220px;
      min-height: 48px;
      height: auto;
      padding: 0;
      margin: 0;
      overflow: visible;
      box-sizing: border-box;
      background: transparent;
      border: 0;
      box-shadow: none;
      font-family: Montserrat, Arial, sans-serif;
    }
    .login-input-wrapper {
      position: relative;
      width: 100%;
      height: 48px;
      min-height: 48px;
      box-sizing: border-box;
    }
    .login-input {
      display: block;
      width: 100%;
      height: 48px !important;
      min-height: 48px !important;
      padding: 0 48px 0 16px;
      border: 1px solid transparent;
      border-radius: 4px;
      outline: none;
      box-shadow: none;
      background: #5B5D5F;
      color: #FFFFFF;
      font: 400 16px/48px Montserrat, Arial, sans-serif;
      box-sizing: border-box;
    }
    .login-input::placeholder { color: rgba(255,255,255,.66); }
    .login-input:focus {
      outline: none;
      box-shadow: none;
      border-color: rgba(255,255,255,.28);
    }
    .login-icon {
      position: absolute;
      top: 50%;
      right: 14px;
      transform: translateY(-50%);
      width: 26px;
      height: 26px;
      display: none;
      align-items: center;
      justify-content: center;
      pointer-events: none;
    }
    .login-icon-image {
      display: block;
      width: 24px;
      height: 24px;
      object-fit: contain;
      pointer-events: none;
    }
    .login-error-message {
      display: none;
      margin-top: 10px;
      color: #FF273B;
      font: 500 14px/18px Montserrat, Arial, sans-serif;
      text-align: center;
    }
    .login-control[data-invalid='true'] .login-input {
      border-color: #FF273B;
    }
    .login-control[data-invalid='true'] .login-error-message {
      display: block;
    }
  `,
  script: `
    (function () {
      if (!model || !model.getEl || !model.getEl()) return;

      var root = model.getEl();
      var input = root.querySelector('.login-input');
      var icon = root.querySelector('.login-icon');
      var iconImage = root.querySelector('.login-icon-image');
      var defaultIcon = '${LOGIN_USER_ICON}';

      function traitValue(name, fallback) {
        var trait = model.getTrait && model.getTrait(name);
        var value = trait && trait.getValue ? trait.getValue() : undefined;
        return value === undefined || value === null || value === '' ? fallback : value;
      }

      function asBool(value) {
        return value === true || value === 'true' || value === 1 || value === '1';
      }

      function render() {
        if (!input) return;
        var attrs = model.getAttributes ? model.getAttributes() : {};
        var placeholder = String(traitValue('placeholder', 'Enter text'));
        var showIcon = asBool(traitValue('showIcon', true));
        var selectedImage = String(traitValue('selectImage', '') || '');
        var src = selectedImage || defaultIcon;
        var currentValue = attrs['data-value'];

        input.placeholder = placeholder;
        if (currentValue != null && input.value !== String(currentValue)) {
          input.value = String(currentValue);
        }

        if (icon) icon.style.display = showIcon ? 'inline-flex' : 'none';
        input.style.paddingRight = showIcon ? '52px' : '16px';
        input.setAttribute('aria-invalid', attrs['data-invalid'] === 'true' ? 'true' : 'false');
        if (iconImage && src && iconImage.getAttribute('src') !== src) {
          iconImage.setAttribute('src', src);
        }

        var inputComponent = model.find && model.find('.login-input')[0];
        if (inputComponent && inputComponent.getAttributes) {
          var inputAttrs = inputComponent.getAttributes();
          if (inputAttrs.placeholder !== placeholder) {
            inputComponent.addAttributes({ placeholder: placeholder });
          }
        }
        var iconComponent = model.find && model.find('.login-icon-image')[0];
        if (iconComponent && iconComponent.getAttributes) {
          var iconAttrs = iconComponent.getAttributes();
          if (iconAttrs.src !== src) iconComponent.addAttributes({ src: src });
        }
      }

      if (input) {
        input.oninput = function (event) {
          event.stopPropagation();
          model.addAttributes({ 'data-value': input.value });
        };
      }

      if (model.__stage15LoginCleanup) model.__stage15LoginCleanup();
      var onUpdate = function () { render(); };
      model.on('change:traits', onUpdate);
      model.on('change:showIcon', onUpdate);
      model.on('change:placeholder', onUpdate);
      model.on('change:selectImage', onUpdate);
      model.on('change:attributes', onUpdate);
      model.on('active', onUpdate);
      model.__stage15LoginCleanup = function () {
        model.off('change:traits', onUpdate);
        model.off('change:showIcon', onUpdate);
        model.off('change:placeholder', onUpdate);
        model.off('change:selectImage', onUpdate);
        model.off('change:attributes', onUpdate);
        model.off('active', onUpdate);
      };

      render();
    })();
  `
};
