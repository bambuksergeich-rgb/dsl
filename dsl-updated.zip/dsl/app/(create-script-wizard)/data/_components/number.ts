import { ComponentConfig } from '../elements';

export const Number: ComponentConfig = {
  id: 'number-input',
  type: 'Number',
  label: 'Number',
  category: 'Inputs',
  content: {
    tagName: 'div',
    attributes: {
      class: 'mui-number-input-wrapper'
    },
    components: [
      {
        tagName: 'input',
        attributes: {
          type: 'number',
          placeholder: 'Enter...',
          class: 'mui-number-input',
          'data-component-id': 'number-input',
          autocomplete: 'off'
        },
        draggable: false,
        droppable: false,
        editable: true,
        selectable: true
      },
      {
        tagName: 'button',
        attributes: {
          class: 'mui-number-arrow mui-number-arrow-up',
          type: 'button',
          tabindex: '-1'
        },
        draggable: false,
        content: `<svg width="10" height="10" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="pointer-events: none;"><path d="M8.5 7L6 4.5L3.5 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`
      },
      {
        tagName: 'button',
        attributes: {
          class: 'mui-number-arrow mui-number-arrow-down',
          type: 'button',
          tabindex: '-1'
        },
        draggable: false,
        content: `<svg width="10" height="10" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="pointer-events: none;"><path d="M3.5 5L6 7.5L8.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 9L12 5L16 9M16 15L12 19L8 15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`,
  traits: [
    {
      id: 'value',
      name: 'value',
      type: 'number',
      label: 'Default value',
      placeholder: 'Enter value',
      changeProp: true,
      value: 0
    },
    {
      id: 'min',
      name: 'min',
      type: 'text',
      label: 'Min value',
      placeholder: 'Enter value',
      changeProp: true,
      value: ''
    },
    {
      id: 'max',
      name: 'max',
      type: 'text',
      label: 'Max value',
      placeholder: 'Enter value',
      changeProp: true,
      value: ''
    },
    {
      id: 'step',
      name: 'step',
      type: 'text',
      label: 'Step',
      placeholder: 'Enter step',
      changeProp: true,
      value: ''
    },
    {
      id: 'placeholder',
      name: 'placeholder',
      type: 'text',
      label: 'Text Mask',
      placeholder: 'Enter step',
      changeProp: true,
      value: ''
    }
  ],
  styles: `
/* Standard single-line control height from the editor design. */
[data-draft-id].mui-number-input-wrapper, .mui-number-input-wrapper { height: 34px !important; min-height: 34px !important; max-height: 34px !important; }

    /* Обертка - хранитель переменных */
.mui-number-input-wrapper {
  position: relative;
  display: inline-block;
  width: var(--input-width, 140px);
  height: var(--input-height, 34px);
  min-width: 80px;
  min-height: 30px;
  box-sizing: border-box;

  /* Дефолтные значения переменных */
  --input-width: 140px;
  --input-height: 34px;
  --bw: 1px;
  --bc: transparent;
  --bg: rgba(255, 255, 255, 0.1);
  --color: #ffffff;
  --fs: 16px;
}

.mui-number-input {
  display: block;
  width: 100%;
  height: 100%;

  /* Добавляем поддержку min/max ограничений */
  min-width: var(--min-w, auto);
  max-width: var(--max-w, none);
  min-height: var(--min-h, auto);
  max-height: var(--max-h, none);

  padding: 6px 34px 6px 12px;
  box-sizing: border-box;

  background-color: var(--bg, rgba(255, 255, 255, 0.1));
  color: var(--color, #ffffff);

  /* === ХАК ДЛЯ ПАРСЕРА GRAPESJS === */
  border-style: solid;
  border-top-width: var(--bw, 0px);
  border-right-width: var(--bw, 0px);
  border-bottom-width: var(--bw, 0px);
  border-left-width: var(--bw, 0px);

  border-top-color: var(--bc, transparent);
  border-right-color: var(--bc, transparent);
  border-bottom-color: var(--bc, transparent);
  border-left-color: var(--bc, transparent);
  /* ============================== */

  border-radius: 4px;
  font-size: var(--fs, 16px);
  font-family: 'Montserrat', sans-serif;

  -moz-appearance: textfield;
  appearance: none;
}

.mui-number-input:focus {
  outline: none;
  /* При фокусе дублируем границы явно для надежности */
  border-width: var(--bw, 1px);
  border-color: var(--bc, transparent);
  box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.1);
}

.mui-number-input::-webkit-inner-spin-button,
.mui-number-input::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

.mui-number-arrow {
  position: absolute;
  right: 2px;
  width: 26px;
  height: 50%;
  background: transparent;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: var(--color, #ffffff);
  opacity: 0.7;
  z-index: 10;
}

.mui-number-arrow:hover {
  opacity: 1;
  background-color: rgba(255,255,255,0.1);
  border-radius: 2px;
}

.mui-number-arrow-up { top: 0; }
.mui-number-arrow-down { bottom: 0; }

.mui-number-arrow svg { pointer-events: none; }

    `,
  styleConfig: {
    target: '.mui-number-input-wrapper',
    sectors: [
      {
        id: 'style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'background-color',
            name: 'Background Color',
            property: '--bg',
            type: 'color',
            default: 'rgba(255, 255, 255, 0.1)'
          },
          {
            id: 'border-color',
            name: 'Border Color',
            property: '--bc',
            type: 'color',
            default: 'transparent'
          },
          {
            id: 'border-width',
            name: 'Border Width',
            property: '--bw',
            type: 'number',
            default: 1,
            units: ['px']
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: '--input-width',
            type: 'number',
            default: 140,
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: '--input-height',
            type: 'number',
            default: 34,
            units: ['px']
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: '--min-w',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: '--min-h',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: '--max-w',
            type: 'number',
            units: ['px', '%'],
            default: 'none'
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: '--max-h',
            type: 'number',
            units: ['px', '%'],
            default: 'none'
          }
        ]
      },
      {
        id: 'text',
        name: 'Number Text',
        open: true,
        properties: [
          {
            id: 'color',
            name: 'Text Color',
            property: '--color',
            type: 'color',
            default: '#FFFFFF'
          },
          {
            id: 'font-size',
            name: 'Font Size',
            property: '--fs',
            type: 'number',
            default: 16,
            units: ['px']
          }
        ]
      }
    ]
  },
  script: `
function updateNumberInput(model) {
  if (!model || !model.getEl()) return;

  const wrapper = model.getEl();
  const input = wrapper.querySelector('.mui-number-input');
  if (!input) return;

  const getTraitValue = (name, fallback = '') => {
    const trait = model.getTrait && model.getTrait(name);
    const value = trait && trait.getValue ? trait.getValue() : undefined;
    return value === undefined || value === null ? fallback : value;
  };

  const toNumber = (raw) => {
    if (raw === '' || raw === undefined || raw === null) return null;
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? parsed : null;
  };

  const clamp = (value, min, max) => {
    let next = value;
    if (min !== null && next < min) next = min;
    if (max !== null && next > max) next = max;
    return next;
  };

  const stepValue = toNumber(getTraitValue('step', 1));
  const step = stepValue && stepValue > 0 ? stepValue : 1;
  const min = toNumber(getTraitValue('min', ''));
  const max = toNumber(getTraitValue('max', ''));
  const placeholderValue = String(getTraitValue('placeholder', '')).trim();
  const placeholder = placeholderValue || 'Enter...';
  const rawValue = getTraitValue('value', 0);
  const numericValue = toNumber(rawValue);

  const setOrRemove = (element, attr, value) => {
    if (value === undefined || value === null || value === '') {
      element.removeAttribute(attr);
    } else {
      element.setAttribute(attr, String(value));
    }
  };

  if (numericValue !== null && document.activeElement !== input) {
    input.value = String(clamp(numericValue, min, max));
  }
  setOrRemove(input, 'min', min);
  setOrRemove(input, 'max', max);
  setOrRemove(input, 'step', step);
  setOrRemove(input, 'placeholder', placeholder);

  const inputComp = model.find && model.find('input.mui-number-input')[0];
  if (inputComp) {
    const attrs = {
      type: 'number',
      placeholder,
      step: String(step)
    };
    if (min !== null) attrs.min = String(min);
    if (max !== null) attrs.max = String(max);
    if (numericValue !== null) attrs.value = String(clamp(numericValue, min, max));
    inputComp.addAttributes(attrs);
  }

  const persistValue = (nextValue) => {
    const numeric = toNumber(nextValue);
    if (numeric === null) return;
    const clamped = clamp(numeric, min, max);
    const current = toNumber(getTraitValue('value', 0));
    input.value = String(clamped);
    model.addAttributes && model.addAttributes({ 'data-value': String(clamped) });
    if (current !== clamped) {
      const trait = model.getTrait && model.getTrait('value');
      trait && trait.setValue && trait.setValue(clamped);
    }
  };

  const changeByStep = (direction) => {
    const current = toNumber(input.value);
    const base = current !== null ? current : (min !== null ? min : 0);
    const precision = Math.min(10, Math.max(0, (String(step).split('.')[1] || '').length));
    const factor = Math.pow(10, precision);
    const next = Math.round((base + direction * step) * factor) / factor;
    persistValue(next);
  };

  input.oninput = (event) => {
    const next = event && event.target ? event.target.value : input.value;
    if (next === '' || next === '-' || next === '.') return;
    persistValue(next);
  };
  input.onchange = () => {
    if (input.value === '') {
      const fallback = min !== null ? min : 0;
      persistValue(fallback);
      return;
    }
    persistValue(input.value);
  };

  const upArrow = wrapper.querySelector('.mui-number-arrow-up');
  const downArrow = wrapper.querySelector('.mui-number-arrow-down');

  const bindArrow = (button, direction) => {
    if (!button) return;
    button.onpointerdown = (event) => {
      event.stopPropagation();
    };
    button.onmousedown = (event) => {
      event.stopPropagation();
    };
    button.onclick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      changeByStep(direction);
    };
  };

  bindArrow(upArrow, 1);
  bindArrow(downArrow, -1);
}

updateNumberInput(model);
if (model.__numberInputUpdate && model.off) model.off('change:value change:min change:max change:step change:placeholder', model.__numberInputUpdate);
model.__numberInputUpdate = () => updateNumberInput(model);
model.on && model.on('change:value change:min change:max change:step change:placeholder', model.__numberInputUpdate);
`
};
