export type FileControlMode = 'download' | 'upload';

export const FILE_CONTROL_EVENT_NAME = 'gjs:file-control';

export const FILE_CONTROL_STYLES = `
.file-control {
  width: 100%;
  height: 100%;
  min-width: 220px;
  min-height: 54px;
  max-width: 100%;
  box-sizing: border-box;
  position: relative;
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 0;
  border: 0;
  border-radius: 0;
  background: transparent;
  color: #fff;
  font-family: Montserrat, Arial, sans-serif;
  overflow: hidden;
}
.file-control__input {
  position: absolute !important;
  width: 1px !important;
  height: 1px !important;
  margin: 0 !important;
  padding: 0 !important;
  opacity: 0 !important;
  pointer-events: none !important;
  overflow: hidden !important;
  clip-path: inset(50%) !important;
}
.file-control__empty {
  min-height: 40px;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.file-control--upload {
  min-width: 180px;
  min-height: 56px;
  align-items: stretch;
}
.file-control--upload .file-control__empty {
  width: 100%;
  min-height: 54px;
}
.file-control--upload .file-control__list {
  max-width: none;
  flex-basis: auto;
  gap: 4px;
}
.file-control--upload .file-control__item {
  min-height: 54px;
  padding: 6px 8px;
  gap: 9px;
  background: rgba(67, 68, 73, .98);
}
.file-control--upload .file-control__item:hover {
  background: rgba(76, 78, 84, .98);
}
.file-control--upload .file-control__icon {
  width: 34px;
  height: 40px;
  flex-basis: 34px;
}
.file-control--upload .file-control__icon svg {
  width: 32px;
  height: 38px;
}
.file-control--upload .file-control__name {
  font-size: 13px;
  line-height: 17px;
}
.file-control--upload .file-control__size {
  margin-top: 1px;
}
.file-control--upload .file-control__add-row {
  display: none !important;
}
.file-control--upload .file-control__preview {
  display: none !important;
}
.file-control--upload .file-control__remove {
  opacity: 0;
  transition: opacity .15s ease;
}
.file-control--upload .file-control__item:hover .file-control__remove,
.file-control--upload .file-control__item:focus-within .file-control__remove {
  opacity: 1;
}
.file-control__choose,
.file-control__add,
.file-control__action {
  appearance: none;
  border: 1px solid rgba(255,255,255,.2);
  border-radius: 4px;
  background: rgba(58,60,67,.9);
  color: #fff;
  cursor: pointer;
  font-family: inherit;
  box-sizing: border-box;
}
.file-control__choose {
  min-width: 126px;
  height: 36px;
  padding: 0 14px;
  font-size: 13px;
  font-weight: 500;
  white-space: nowrap;
}
.file-control__choose:hover,
.file-control__add:hover,
.file-control__action:hover { background: rgba(78,81,90,.95); }
.file-control__list {
  min-width: 0;
  max-width: 340px;
  max-height: 100%;
  flex: 1 1 300px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  overflow-x: hidden;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: rgba(126, 139, 164, 0.72) transparent;
}
.file-control__list::-webkit-scrollbar { width: 5px; height: 5px; }
.file-control__list::-webkit-scrollbar-track { background: transparent; }
.file-control__list::-webkit-scrollbar-thumb {
  border-radius: 999px;
  background: rgba(126, 139, 164, 0.72);
}
.file-control__list::-webkit-scrollbar-thumb:hover {
  background: rgba(151, 164, 190, 0.9);
}
.file-control__item {
  width: 100%;
  min-width: 0;
  min-height: 56px;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 7px 9px;
  border: 0;
  border-radius: 4px;
  background: rgba(66,68,74,.96);
  box-sizing: border-box;
  cursor: pointer;
  transition: background-color .15s ease;
}
.file-control__item:hover { background: rgba(75,78,85,.98); }
.file-control__icon {
  width: 38px;
  height: 42px;
  flex: 0 0 38px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.file-control__icon svg {
  width: 34px;
  height: 40px;
  display: block;
}
.file-control__meta { min-width: 0; flex: 1 1 auto; }
.file-control__name {
  display: block;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  line-height: 18px;
}
.file-control__size {
  display: block;
  min-height: 14px;
  margin-top: 2px;
  color: rgba(255,255,255,.68);
  font-size: 11px;
  line-height: 14px;
}
.file-control__actions {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 0 0 auto;
}
.file-control__action {
  width: 28px;
  height: 28px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border-color: transparent;
  font-size: 15px;
  line-height: 1;
}
.file-control__action svg {
  width: 16px;
  height: 16px;
  display: block;
}
.file-control__add-row {
  flex: 0 0 auto;
  display: flex;
  justify-content: flex-start;
  margin-top: 11px;
}
.file-control__add {
  width: 34px;
  min-width: 34px;
  height: 34px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: rgba(66,68,74,.96);
  font-size: 18px;
  line-height: 1;
}
.file-control__pending { opacity: .68; }
.file-control[data-file-readonly="true"] .file-control__choose,
.file-control[data-file-readonly="true"] .file-control__add,
.file-control[data-file-readonly="true"] .file-control__remove { display: none !important; }
`;

export const createFileControlScript = (mode: FileControlMode) => `
(function initializeFileControl(model) {
  if (!model || !model.getEl) return;
  var root = model.getEl();
  if (!root) return;

  var MODE = '${mode}';
  var EVENT_NAME = '${FILE_CONTROL_EVENT_NAME}';
  var input = root.querySelector('.file-control__input');
  var empty = root.querySelector('.file-control__empty');
  var choose = root.querySelector('.file-control__choose');
  var list = root.querySelector('.file-control__list');
  var addRow = root.querySelector('.file-control__add-row');
  var add = root.querySelector('.file-control__add');
  var localUrls = {};
  var appendNextSelection = false;
  var disposers = [];
  var renderDisposers = [];

  if (model.__fileControlCleanup) {
    try { model.__fileControlCleanup(); } catch (err) {}
  }

  function bindInto(bucket, el, type, fn, options) {
    if (!el || !el.addEventListener) return;
    el.addEventListener(type, fn, options);
    bucket.push(function () {
      try { el.removeEventListener(type, fn, options); } catch (err) {}
    });
  }

  function bind(el, type, fn, options) {
    bindInto(disposers, el, type, fn, options);
  }

  function bindRender(el, type, fn, options) {
    bindInto(renderDisposers, el, type, fn, options);
  }

  function cleanupRenderBindings() {
    renderDisposers.forEach(function (dispose) { dispose(); });
    renderDisposers = [];
  }

  function stop(event) {
    if (!event) return;
    event.stopPropagation();
  }

  function safeFiles() {
    var raw = model.get('files');
    if (typeof raw === 'string') {
      try { raw = JSON.parse(raw); } catch (err) { raw = []; }
    }
    return Array.isArray(raw) ? raw.filter(Boolean) : [];
  }

  function isMultiple() {
    var raw = model.get('multiple');
    return raw === true || raw === 'true' || raw === 1 || raw === '1';
  }

  function extension(name) {
    var source = String(name || 'FILE');
    var parts = source.split('.');
    var ext = parts.length > 1 ? parts.pop() : 'FILE';
    return String(ext || 'FILE')
      .replace(/[^a-z0-9]/gi, '')
      .slice(0, 4)
      .toUpperCase() || 'FILE';
  }

  function fileAccent(name, type) {
    var ext = extension(name).toLowerCase();
    var mime = String(type || '').toLowerCase();
    if (ext === 'pdf' || mime.indexOf('pdf') >= 0) return '#E14B4B';
    if (/^(doc|docx|rtf)$/.test(ext) || mime.indexOf('word') >= 0) return '#4A72D8';
    if (/^(xls|xlsx|csv)$/.test(ext) || mime.indexOf('sheet') >= 0 || mime.indexOf('excel') >= 0) return '#3B9B67';
    if (/^(png|jpg|jpeg|gif|webp|svg)$/.test(ext) || mime.indexOf('image/') === 0) return '#8B5BD6';
    if (/^(zip|rar|7z|tar|gz)$/.test(ext)) return '#C78B3B';
    return '#717986';
  }

  function fileIconMarkup(name, type) {
    var ext = extension(name);
    var accent = fileAccent(name, type);
    return '<svg viewBox="0 0 34 40" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M6 1h15l7 7v29a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2Z" fill="#F2F3F5"/>' +
      '<path d="M21 1v7h7" fill="#D6D8DD"/>' +
      '<rect x="2" y="22" width="30" height="11" rx="2" fill="' + accent + '"/>' +
      '<text x="17" y="30" text-anchor="middle" font-family="Arial,sans-serif" font-size="7" font-weight="700" fill="#fff">' + ext + '</text>' +
      '</svg>';
  }

  function formatSize(value) {
    var bytes = Number(value || 0);
    if (!Number.isFinite(bytes) || bytes <= 0) return '';
    if (bytes < 1024) return bytes + ' B';
    var kb = bytes / 1024;
    if (kb < 1024) return (kb < 10 ? kb.toFixed(1) : Math.round(kb)) + ' KB';
    var mb = kb / 1024;
    return (mb < 10 ? mb.toFixed(1) : Math.round(mb)) + ' MB';
  }

  function formatFileTime(file) {
    if (!file) return '';
    var raw = file.updatedAt || file.createdAt || file.uploadedAt || file.timestamp;
    if (!raw) return '';
    var date = new Date(raw);
    if (Number.isNaN(date.getTime())) return '';
    var hours = String(date.getHours()).padStart(2, '0');
    var minutes = String(date.getMinutes()).padStart(2, '0');
    return hours + ':' + minutes;
  }

  function fileSubline(file) {
    if (file && file.pending) return 'Uploading…';
    if (MODE === 'upload') {
      var time = formatFileTime(file);
      if (time) return time;
    }
    return formatSize(file && (file.size || file.contentLength));
  }

  function actionIcon(kind) {
    if (kind === 'download') {
      return '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 3v11m0 0-4-4m4 4 4-4M5 16v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    }
    if (kind === 'preview') {
      return '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M8 16 16 8m0 0H9m7 0v7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
    }
    if (kind === 'remove') {
      return '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="m7 7 10 10M17 7 7 17" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
    }
    return '';
  }

  function emit(action, payload) {
    var ownWindow = root.ownerDocument && root.ownerDocument.defaultView;
    var hostWindow = ownWindow && ownWindow.parent && ownWindow.parent !== ownWindow
      ? ownWindow.parent
      : ownWindow;
    if (!hostWindow || !hostWindow.dispatchEvent) return;
    var EventCtor = hostWindow.CustomEvent || CustomEvent;
    var detail = Object.assign({
      action: action,
      mode: MODE,
      draftId: root.getAttribute('data-draft-id') || model.get('draftId') || '',
      multiple: isMultiple(),
      sourceFrame: ownWindow && ownWindow.frameElement ? ownWindow.frameElement : null
    }, payload || {});
    hostWindow.dispatchEvent(new EventCtor(EVENT_NAME, { detail: detail }));
  }

  function cleanupUnusedLocalUrls(files) {
    var used = {};
    files.forEach(function (file) {
      if (file && file.local && file.url) used[file.url] = true;
    });
    Object.keys(localUrls).forEach(function (url) {
      if (used[url]) return;
      try { URL.revokeObjectURL(url); } catch (err) {}
      delete localUrls[url];
    });
  }

  function localDownload(file) {
    if (!file || !file.local || !file.url) return false;
    try {
      var doc = root.ownerDocument;
      var a = doc.createElement('a');
      a.href = file.url;
      a.download = file.name || 'file';
      a.style.display = 'none';
      (doc.body || doc.documentElement).appendChild(a);
      a.click();
      a.remove();
      return true;
    } catch (err) {
      return false;
    }
  }

  function createAction(iconKind, title, className, onClick) {
    var button = root.ownerDocument.createElement('button');
    button.type = 'button';
    button.className = 'file-control__action ' + (className || '');
    button.innerHTML = actionIcon(iconKind);
    button.title = title;
    button.setAttribute('aria-label', title);
    bindRender(button, 'pointerdown', stop);
    bindRender(button, 'mousedown', stop);
    bindRender(button, 'click', function (event) {
      event.preventDefault();
      event.stopPropagation();
      onClick(event);
    });
    return button;
  }

  function render() {
    if (!list || !empty || !addRow || !input) return;
    cleanupRenderBindings();
    var files = safeFiles();
    cleanupUnusedLocalUrls(files);
    input.multiple = isMultiple();
    empty.style.display = files.length ? 'none' : 'flex';
    // The '+' state is a separate design state from the empty 'Choice a File'
    // state. Even when the native picker itself is single-select, the plus button
    // appends one more file to the control.
    addRow.style.display = MODE === 'download' && files.length ? 'flex' : 'none';
    list.innerHTML = '';

    files.forEach(function (file) {
      var row = root.ownerDocument.createElement('div');
      row.className = 'file-control__item' + (file.pending ? ' file-control__pending' : '');
      row.setAttribute('data-file-id', file.id || '');

      var icon = root.ownerDocument.createElement('span');
      icon.className = 'file-control__icon';
      icon.innerHTML = fileIconMarkup(file.name, file.type);
      icon.setAttribute('aria-label', extension(file.name) + ' file');

      var meta = root.ownerDocument.createElement('span');
      meta.className = 'file-control__meta';
      var name = root.ownerDocument.createElement('span');
      name.className = 'file-control__name';
      name.textContent = file.name || 'File';
      var size = root.ownerDocument.createElement('span');
      size.className = 'file-control__size';
      size.textContent = fileSubline(file);
      meta.appendChild(name);
      meta.appendChild(size);

      var actions = root.ownerDocument.createElement('span');
      actions.className = 'file-control__actions';
      var canRemove = root.getAttribute('data-file-readonly') !== 'true';
      var removeAction = function () {
        return createAction('remove', 'Remove', 'file-control__remove', function () {
          if (file.local) {
            var nextLocal = safeFiles().filter(function (item) { return item !== file; });
            model.set('files', nextLocal);
            render();
            return;
          }
          var next = safeFiles().filter(function (item) {
            return String(item.id || '') !== String(file.id || '');
          });
          model.set('files', next);
          render();
          emit('delete', { file: file });
        });
      };
      if (MODE !== 'upload') {
        actions.appendChild(createAction('preview', 'Open', 'file-control__preview', function () {
          emit('preview', { file: file });
        }));
      } else if (canRemove) {
        // Keep the download affordance at the far right like the design.
        // Remove is an editor-only affordance and appears on hover/focus.
        actions.appendChild(removeAction());
      }
      actions.appendChild(createAction('download', 'Download', 'file-control__download', function () {
        if (!localDownload(file)) emit('download', { file: file });
      }));
      if (MODE !== 'upload' && canRemove) {
        actions.appendChild(removeAction());
      }

      row.tabIndex = 0;
      row.setAttribute('role', 'button');
      row.setAttribute('aria-label', 'Open ' + (file.name || 'file'));
      bindRender(row, 'pointerdown', stop);
      bindRender(row, 'mousedown', stop);
      bindRender(row, 'keydown', function (event) {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        event.preventDefault();
        event.stopPropagation();
        emit('preview', { file: file });
      });
      bindRender(row, 'click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        emit('preview', { file: file });
      });

      row.appendChild(icon);
      row.appendChild(meta);
      row.appendChild(actions);
      list.appendChild(row);
    });
  }

  function openPicker(event, append) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    if (root.getAttribute('data-file-readonly') === 'true') return;
    appendNextSelection = Boolean(append);
    if (input && input.click) input.click();
  }

  function onInputChange(event) {
    var fileList = event && event.target ? event.target.files : null;
    var files = fileList ? Array.prototype.slice.call(fileList) : [];
    if (!files.length) {
      appendNextSelection = false;
      return;
    }
    if (!isMultiple()) files = files.slice(0, 1);
    var append = appendNextSelection;
    appendNextSelection = false;

    var local = files.map(function (file, index) {
      var url = '';
      try {
        url = URL.createObjectURL(file);
        localUrls[url] = true;
      } catch (err) {}
      return {
        id: 'local-' + Date.now() + '-' + index,
        name: file.name,
        size: file.size,
        type: file.type || '',
        path: '',
        url: url,
        local: true,
        pending: true,
        createdAt: new Date().toISOString()
      };
    });

    var current = safeFiles();
    var next = append || isMultiple() ? current.concat(local) : local;
    model.set('files', next);
    render();
    emit('upload', {
      files: files,
      // Explicit false is meaningful: a single-select picker opened from '+'
      // appends one file instead of replacing the existing file.
      replace: !append && !isMultiple()
    });
    try { input.value = ''; } catch (err) {}
  }

  bind(choose, 'pointerdown', stop);
  bind(choose, 'mousedown', stop);
  bind(choose, 'click', function (event) { openPicker(event, false); });
  bind(add, 'pointerdown', stop);
  bind(add, 'mousedown', stop);
  bind(add, 'click', function (event) { openPicker(event, true); });
  bind(input, 'click', stop);
  bind(input, 'change', onInputChange);

  var onFilesChanged = function () { render(); };
  var onMultipleChanged = function () { render(); };
  model.on('change:files', onFilesChanged);
  model.on('change:multiple', onMultipleChanged);

  model.__fileControlCleanup = function () {
    cleanupRenderBindings();
    disposers.forEach(function (dispose) { dispose(); });
    disposers = [];
    try { model.off('change:files', onFilesChanged); } catch (err) {}
    try { model.off('change:multiple', onMultipleChanged); } catch (err) {}
    Object.keys(localUrls).forEach(function (url) {
      try { URL.revokeObjectURL(url); } catch (err) {}
    });
    localUrls = {};
  };

  render();
})(model);
`;
