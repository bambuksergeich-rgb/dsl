import { ComponentConfig } from '../elements';

export const Switch: ComponentConfig = {
  id: 'switch',
  type: 'switch',
  label: 'Switch',
  category: 'Form',
  content: {
    tagName: 'div',
    attributes: {
      class: 'switch-wrapper',
      'data-type': 'Boolean',
      'data-checked': 'false',
      'data-value': 'false'
    },
    components: [
      {
        tagName: 'label',
        attributes: { class: 'switch-control' },
        components: [
          {
            tagName: 'input',
            attributes: {
              type: 'checkbox',
              class: 'switch-input',
              'aria-label': 'Switch'
            },
            draggable: false,
            droppable: false,
            selectable: false
          },
          {
            tagName: 'span',
            attributes: { class: 'switch-slider', 'aria-hidden': 'true' },
            draggable: false,
            droppable: false,
            selectable: false
          }
        ],
        draggable: false,
        droppable: false,
        selectable: false
      }
    ],
    droppable: false,
    selectable: true
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17.25 18C20.5637 18 23.25 15.3137 23.25 12C23.25 8.68629 20.5637 6 17.25 6C13.9363 6 11.25 8.68629 11.25 12C11.25 15.3137 13.9363 18 17.25 18Z" stroke="white" stroke-width="1.5" stroke-linejoin="round"/>
<path d="M17.25 6H6.75C3.43629 6 0.75 8.68629 0.75 12C0.75 15.3137 3.43629 18 6.75 18H17.25C20.5637 18 23.25 15.3137 23.25 12C23.25 8.68629 20.5637 6 17.25 6Z" stroke="white" stroke-width="1.5" stroke-linejoin="round"/>
</svg>`,
  traits: [
    {
      id: 'checked',
      name: 'checked',
      label: 'Checked',
      type: 'checkbox',
      changeProp: true,
      value: false
    },
    {
      id: 'color',
      name: 'color',
      label: 'Color',
      type: 'color',
      changeProp: true,
      value: '#4170FF'
    }
  ],
  styles: `
    .switch-wrapper {
      display: inline-flex;
      align-items: center;
      justify-content: flex-start;
      width: fit-content;
      min-width: 48px;
      min-height: 28px;
      box-sizing: border-box;
      font-family: Montserrat, Arial, sans-serif;
      --switch-color: #4170FF;
    }

    .switch-control {
      position: relative;
      display: inline-block;
      width: 48px;
      height: 28px;
      cursor: pointer;
    }

    .switch-input {
      position: absolute;
      width: 1px;
      height: 1px;
      margin: 0;
      opacity: 0;
      pointer-events: none;
    }

    .switch-slider {
      position: absolute;
      inset: 0;
      border: 1px solid rgba(255,255,255,0.45);
      border-radius: 999px;
      background: rgba(255,255,255,0.18);
      transition: background-color 160ms ease, border-color 160ms ease;
      box-sizing: border-box;
    }

    .switch-slider::before {
      content: '';
      position: absolute;
      width: 20px;
      height: 20px;
      left: 3px;
      top: 3px;
      border-radius: 50%;
      background: #FFFFFF;
      box-shadow: 0 1px 3px rgba(0,0,0,0.35);
      transition: transform 160ms ease;
    }

    .switch-input:checked + .switch-slider {
      border-color: var(--switch-color);
      background: var(--switch-color);
    }

    .switch-input:checked + .switch-slider::before {
      transform: translateX(20px);
    }

    .switch-input:focus-visible + .switch-slider {
      outline: 2px solid rgba(84,127,255,0.75);
      outline-offset: 2px;
    }
  `,
  script: `
function switchBoolValue(raw) {
  if (raw === true || raw === 1 || raw === '1') return true;
  if (typeof raw === 'string') {
    const value = raw.trim().toLowerCase();
    return value === 'true' || value === 'yes' || value === 'checked' || value === 'on';
  }
  return false;
}

function switchTraitValue(model, name, fallback) {
  const trait = model.getTrait && model.getTrait(name);
  const value = trait && trait.getValue ? trait.getValue() : undefined;
  return value === undefined || value === null || value === '' ? fallback : value;
}

function updateSwitch(model) {
  if (!model || !model.getEl || !model.getEl()) return;
  const wrapper = model.getEl();
  const input = wrapper.querySelector('.switch-input');
  if (!input) return;

  const attrs = model.getAttributes ? model.getAttributes() : {};
  const traitChecked = switchTraitValue(model, 'checked', undefined);
  const modelChecked = model.get && model.get('checked');
  const checked = switchBoolValue(
    traitChecked !== undefined
      ? traitChecked
      : modelChecked !== undefined
        ? modelChecked
        : attrs['data-value'] !== undefined
          ? attrs['data-value']
          : attrs['data-checked']
  );
  const color = String(switchTraitValue(model, 'color', '#4170FF'));

  input.checked = checked;
  wrapper.style.setProperty('--switch-color', color);
  wrapper.setAttribute('data-checked', checked ? 'true' : 'false');
  wrapper.setAttribute('data-value', checked ? 'true' : 'false');

  if (!input.__dslSwitchBound) {
    input.__dslSwitchBound = true;
    const control = wrapper.querySelector('.switch-control');

    const commit = function(next) {
      input.checked = !!next;
      const trait = model.getTrait && model.getTrait('checked');
      if (trait && trait.setValue) trait.setValue(!!next);
      model.set && model.set('checked', !!next);
      model.addAttributes && model.addAttributes({
        'data-checked': next ? 'true' : 'false',
        'data-value': next ? 'true' : 'false'
      });
      wrapper.setAttribute('data-checked', next ? 'true' : 'false');
      wrapper.setAttribute('data-value', next ? 'true' : 'false');
    };

    const stopEditorGesture = function(event) { event.stopPropagation(); };
    if (control) {
      control.addEventListener('pointerdown', stopEditorGesture);
      control.addEventListener('mousedown', stopEditorGesture);
      control.addEventListener('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        const next = !input.checked;
        commit(next);
        try {
          const EventCtor = wrapper.ownerDocument?.defaultView?.Event || Event;
          input.dispatchEvent(new EventCtor('input', { bubbles: true }));
          input.dispatchEvent(new EventCtor('change', { bubbles: true }));
        } catch (e) {}
      });
    }
    input.addEventListener('change', function() {
      commit(!!input.checked);
    });
  }
}

if (model && model.getEl && model.getEl()) updateSwitch(model);
if (model.__dslSwitchCleanup) model.__dslSwitchCleanup();
const onSwitchChange = function() { updateSwitch(model); };
model.on('change:traits', onSwitchChange);
model.on('change:attributes', onSwitchChange);
model.on('change:checked', onSwitchChange);
model.__dslSwitchCleanup = function() {
  model.off('change:traits', onSwitchChange);
  model.off('change:attributes', onSwitchChange);
  model.off('change:checked', onSwitchChange);
};
`,
  styleConfig: {
    sectors: []
  }
};
