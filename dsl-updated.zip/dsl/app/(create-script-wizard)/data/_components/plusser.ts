import { ComponentConfig } from '../elements';

export const Plusser: ComponentConfig = {
  id: 'plusser',
  type: 'plusser',
  label: 'Plusser',
  category: 'Form',
  content: {
    tagName: 'div',
    attributes: {
      class: 'plusser-wrapper',
      'data-plusser-state': '',
      'data-plusser-object': '',
      'data-axis': 'Horizontal'
    },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'plusser-config' },
        draggable: false,
        components: [
          {
            tagName: 'label',
            attributes: { class: 'plusser-axis-field' },
            draggable: false,
            components: [
              {
                tagName: 'span',
                attributes: { class: 'plusser-field-label' },
                draggable: false,
                content: 'Axis'
              },
              {
                tagName: 'select',
                attributes: { class: 'plusser-axis', 'aria-label': 'Axis' },
                draggable: false,
                components: [
                  { tagName: 'option', attributes: { value: 'Horizontal' }, content: 'Horizontal' },
                  { tagName: 'option', attributes: { value: 'Vertical' }, content: 'Vertical' }
                ]
              }
            ]
          },
          {
            tagName: 'input',
            attributes: {
              class: 'plusser-index',
              type: 'number',
              value: '0',
              min: '0',
              'aria-label': 'Position'
            },
            draggable: false
          },
          {
            tagName: 'button',
            attributes: {
              class: 'plusser-add',
              type: 'button',
              title: 'Add item',
              'aria-label': 'Add item'
            },
            draggable: false,
            content: '+'
          }
        ]
      },
      {
        tagName: 'div',
        attributes: { class: 'plusser-items' },
        draggable: false
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12 5V19M5 12H19" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
</svg>`,
  traits: [],
  styles: `
    .plusser-wrapper {
      width: 100%;
      min-width: 240px;
      min-height: 150px;
      box-sizing: border-box;
      padding: 14px;
      border-radius: 2px;
      background: #211621;
      color: #ffffff;
      font-family: Montserrat, Arial, sans-serif;
      font-size: 12px;
      overflow: hidden;
    }
    .plusser-config {
      position: relative;
      box-sizing: border-box;
      width: 100%;
      min-height: 104px;
      padding: 14px 48px 14px 14px;
      border: 1px solid rgba(78, 92, 214, 0.38);
      border-radius: 2px;
      background: #342449;
    }
    .plusser-axis-field {
      display: flex;
      flex-direction: column;
      gap: 7px;
      width: 100%;
      min-width: 0;
    }
    .plusser-field-label {
      color: rgba(255,255,255,0.82);
      font-size: 11px;
      line-height: 14px;
    }
    .plusser-axis,
    .plusser-index,
    .plusser-item-name {
      box-sizing: border-box;
      height: 30px;
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 2px;
      background: #4a3c61;
      color: #fff;
      outline: none;
      padding: 0 9px;
      font: inherit;
    }
    .plusser-axis {
      width: 100%;
      color-scheme: dark;
    }
    .plusser-index {
      width: 92px;
      margin-top: 10px;
      padding-right: 4px;
    }
    .plusser-add,
    .plusser-remove {
      border: 0;
      border-radius: 1px;
      background: #4558d9;
      color: white;
      cursor: pointer;
      padding: 0;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-family: 'Montserrat', sans-serif;
    }
    .plusser-add {
      position: absolute;
      top: 8px;
      right: 8px;
      width: 30px;
      height: 30px;
      font-size: 20px;
      line-height: 30px;
    }
    .plusser-remove {
      width: 30px;
      height: 30px;
      font-size: 18px;
      line-height: 30px;
      flex: 0 0 30px;
    }
    .plusser-add:hover,
    .plusser-remove:hover {
      background: #5268ef;
    }
    .plusser-items {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-top: 10px;
    }
    .plusser-item {
      display: grid;
      grid-template-columns: minmax(0, 1fr) 30px;
      gap: 7px;
      align-items: center;
    }
    .plusser-item-control {
      position: relative;
      min-width: 0;
    }
    .plusser-item-name {
      width: 100%;
      min-width: 0;
      padding-right: 28px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .plusser-item-arrow {
      position: absolute;
      right: 9px;
      top: 50%;
      transform: translateY(-52%);
      color: rgba(255,255,255,0.66);
      font-size: 13px;
      line-height: 1;
      pointer-events: none;
    }
    .plusser-empty {
      min-height: 30px;
      display: flex;
      align-items: center;
      color: rgba(255,255,255,0.45);
      font-size: 11px;
    }
    .plusser-wrapper input:focus,
    .plusser-wrapper select:focus {
      border-color: rgba(83, 107, 255, 0.86);
      box-shadow: 0 0 0 1px rgba(83, 107, 255, 0.24);
    }
  `,
  script: `
    const root = model?.getEl?.();
    if (!root) return;

    if (typeof model.__stage17PlusserCleanup === 'function') {
      model.__stage17PlusserCleanup();
    }

    const cleanup = [];
    let dynamicCleanup = [];
    const on = (target, event, handler, options) => {
      if (!target?.addEventListener) return;
      target.addEventListener(event, handler, options);
      cleanup.push(() => target.removeEventListener(event, handler, options));
    };
    const onDynamic = (target, event, handler, options) => {
      if (!target?.addEventListener) return;
      target.addEventListener(event, handler, options);
      dynamicCleanup.push(() => target.removeEventListener(event, handler, options));
    };

    const defaultItem = () => ({
      id: 'param-1',
      label: 'Output|Param|Param1',
      type: 'OUTPUT'
    });

    const normalizeItem = (item, index) => {
      if (!item || typeof item !== 'object') {
        return {
          id: 'param-' + (index + 1),
          label: String(item || 'Param ' + (index + 1)),
          type: 'OUTPUT'
        };
      }
      return {
        ...item,
        id: String(item.id || 'param-' + (index + 1)),
        label: String(item.label || item.name || item.value || 'Param ' + (index + 1)),
        type: String(item.type || 'OUTPUT')
      };
    };

    const normalizeState = (raw) => {
      const source = raw && typeof raw === 'object' ? raw : {};
      const conf = source.conf && typeof source.conf === 'object' ? source.conf : {};
      const axis = String(conf.axis || 'Horizontal') === 'Vertical' ? 'Vertical' : 'Horizontal';
      const indexRaw = Number(conf.index ?? conf.position ?? 0);
      const values = Array.isArray(source.values)
        ? source.values.map(normalizeItem)
        : [defaultItem()];
      return {
        conf: {
          ...conf,
          axis,
          index: Number.isFinite(indexRaw) ? indexRaw : 0
        },
        values
      };
    };

    const readAttributeState = () => {
      const attrs = model.getAttributes?.() || {};
      const raw = attrs['data-plusser-state'];
      if (!raw || typeof raw !== 'string') return null;
      try { return JSON.parse(raw); } catch { return null; }
    };

    let state = normalizeState(model.get?.('plusserState') || readAttributeState());

    const draftId = () => String(model.getAttributes?.()?.['data-draft-id'] || model.getId?.() || 'plusser');

    // Plusser and Basket may live in different GrapesJS iframe documents (for
    // example, different Widget Configuration tabs). Keep a tiny same-origin
    // host registry on the top window so every embedded document can see the
    // same Plusser inventory. If the frame is cross-origin, fall back to its
    // own window and retain the legacy in-document event flow.
    const registryHost = (() => {
      const view = root.ownerDocument?.defaultView;
      try {
        if (view?.top?.document) return view.top;
      } catch {}
      try {
        if (view?.parent?.document) return view.parent;
      } catch {}
      return view;
    })();
    const registryKey = '__dslPlusserRegistryV1';
    const registry = (() => {
      if (!registryHost) return null;
      const current = registryHost[registryKey];
      if (current?.items instanceof Map && current?.listeners instanceof Set) return current;
      const created = { items: new Map(), listeners: new Set() };
      try { registryHost[registryKey] = created; } catch {}
      return created;
    })();

    const publishRegistry = () => {
      if (!registry) return;
      const id = draftId();
      const detail = {
        draftId: id,
        state: JSON.parse(JSON.stringify(state)),
        owner: root
      };
      registry.items.set(id, detail);
      registry.listeners.forEach((listener) => {
        try { listener(detail); } catch {}
      });
    };

    const unregisterRegistry = () => {
      if (!registry) return;
      const id = draftId();
      const current = registry.items.get(id);
      if (current?.owner && current.owner !== root) return;
      registry.items.delete(id);
      const detail = { draftId: id, removed: true, owner: root };
      registry.listeners.forEach((listener) => {
        try { listener(detail); } catch {}
      });
    };

    const emitState = () => {
      publishRegistry();
      try {
        const EventCtor = root.ownerDocument?.defaultView?.CustomEvent || CustomEvent;
        root.ownerDocument?.dispatchEvent(new EventCtor('dsl:plusser:updated', {
          detail: {
            draftId: draftId(),
            state: JSON.parse(JSON.stringify(state))
          }
        }));
      } catch {}
    };

    const persist = (next) => {
      const normalized = normalizeState(next);
      const serialized = JSON.stringify(normalized);
      state = normalized;
      model.set?.('plusserState', normalized, { silent: true });
      const attrs = model.getAttributes?.() || {};
      if (attrs['data-plusser-state'] !== serialized) {
        model.addAttributes?.({
          'data-plusser-state': serialized,
          'data-plusser-object': serialized
        });
      }
      render();
      emitState();
    };

    const stopEditorGesture = (event) => {
      event.stopPropagation();
    };

    const render = () => {
      dynamicCleanup.splice(0).forEach((dispose) => {
        try { dispose(); } catch {}
      });
      const axisSelect = root.querySelector('.plusser-axis');
      const indexInput = root.querySelector('.plusser-index');
      const itemsHost = root.querySelector('.plusser-items');
      if (axisSelect) axisSelect.value = state.conf.axis;
      if (indexInput) indexInput.value = String(state.conf.index ?? 0);
      root.setAttribute('data-axis', state.conf.axis);

      if (!itemsHost) return;
      itemsHost.innerHTML = '';
      if (!state.values.length) {
        const empty = root.ownerDocument.createElement('div');
        empty.className = 'plusser-empty';
        empty.textContent = 'No items';
        itemsHost.appendChild(empty);
        return;
      }

      state.values.forEach((item, itemIndex) => {
        const row = root.ownerDocument.createElement('div');
        row.className = 'plusser-item';

        const control = root.ownerDocument.createElement('div');
        control.className = 'plusser-item-control';

        const field = root.ownerDocument.createElement('input');
        field.className = 'plusser-item-name';
        field.value = item.label;
        field.spellcheck = false;
        field.setAttribute('aria-label', 'Plusser item ' + (itemIndex + 1));

        const arrow = root.ownerDocument.createElement('span');
        arrow.className = 'plusser-item-arrow';
        arrow.setAttribute('aria-hidden', 'true');
        arrow.textContent = '▾';

        control.appendChild(field);
        control.appendChild(arrow);

        const remove = root.ownerDocument.createElement('button');
        remove.className = 'plusser-remove';
        remove.type = 'button';
        remove.title = 'Remove item';
        remove.setAttribute('aria-label', 'Remove item');
        remove.textContent = '×';

        row.appendChild(control);
        row.appendChild(remove);
        itemsHost.appendChild(row);

        ['pointerdown', 'mousedown', 'click'].forEach((name) => onDynamic(field, name, stopEditorGesture));
        ['pointerdown', 'mousedown'].forEach((name) => onDynamic(remove, name, stopEditorGesture));
        onDynamic(field, 'change', (event) => {
          event.stopPropagation();
          const nextValues = state.values.map((entry, idx) =>
            idx === itemIndex ? { ...entry, label: String(field.value || '').trim() || entry.label } : entry
          );
          persist({ ...state, values: nextValues });
        });
        onDynamic(remove, 'click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          persist({ ...state, values: state.values.filter((_, idx) => idx !== itemIndex) });
        });
      });
    };

    const axisSelect = root.querySelector('.plusser-axis');
    const indexInput = root.querySelector('.plusser-index');
    const addButton = root.querySelector('.plusser-add');

    [axisSelect, indexInput, addButton].forEach((target) => {
      ['pointerdown', 'mousedown'].forEach((name) => on(target, name, stopEditorGesture));
    });

    on(axisSelect, 'change', (event) => {
      event.stopPropagation();
      persist({
        ...state,
        conf: { ...state.conf, axis: axisSelect.value === 'Vertical' ? 'Vertical' : 'Horizontal' }
      });
    });

    on(indexInput, 'change', (event) => {
      event.stopPropagation();
      const numeric = Number(indexInput.value);
      persist({
        ...state,
        conf: { ...state.conf, index: Number.isFinite(numeric) ? numeric : 0 }
      });
    });

    on(addButton, 'click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const nextIndex = state.values.length + 1;
      persist({
        ...state,
        values: [
          ...state.values,
          {
            id: 'param-' + Date.now() + '-' + nextIndex,
            label: 'Output|Param|Param' + nextIndex,
            type: 'OUTPUT'
          }
        ]
      });
    });

    const discover = () => emitState();
    const onExternalState = () => {
      state = normalizeState(model.get?.('plusserState') || readAttributeState());
      render();
      emitState();
    };
    on(root.ownerDocument, 'dsl:basket:discover', discover);
    on(root.ownerDocument?.defaultView, 'pagehide', unregisterRegistry);
    model.on?.('change:plusserState', onExternalState);
    cleanup.push(() => model.off?.('change:plusserState', onExternalState));
    cleanup.push(unregisterRegistry);

    model.__stage17PlusserCleanup = () => {
      dynamicCleanup.splice(0).forEach((dispose) => {
        try { dispose(); } catch {}
      });
      cleanup.splice(0).forEach((dispose) => {
        try { dispose(); } catch {}
      });
    };

    model.set?.('plusserState', state, { silent: true });
    const initialSerialized = JSON.stringify(state);
    root.setAttribute('data-plusser-state', initialSerialized);
    root.setAttribute('data-plusser-object', initialSerialized);
    root.setAttribute('data-axis', state.conf.axis);
    render();
    emitState();
  `
};
