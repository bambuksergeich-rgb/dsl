import { ComponentConfig } from '../elements';
import { SingleButtonConfig } from './button';

export const Button: ComponentConfig = {
  id: 'button-group',
  type: 'custom-button',
  label: 'Button',
  category: 'Main',
  block: true,
  content: {
    tagName: 'div',
    attributes: {
      class: 'button-group-container',
      'data-component-type': 'custom-button',
      'data-axis': 'horizontal',
      'data-button-position': 'left',
      'data-header': ''
    },
    components: [
      {
        type: 'custom-button-item',
        attributes: {
          name: 'Button',
          data: 'Button',
          value: 'Button',
          'data-text': 'Button',
          'data-type': 'Boolean',
          'data-table-role': 'true',
          'aria-pressed': 'false',
          'data-value': 'false'
        }
      }
    ]
  },
  styles: `
  ${SingleButtonConfig.styles}

  .button-group-container {
    --button-group-direction: row;
    --button-group-justify: flex-start;
    --button-group-align: center;
    display: flex;
    flex-direction: var(--button-group-direction);
    flex-wrap: wrap;
    justify-content: var(--button-group-justify);
    align-items: var(--button-group-align);
    gap: 8px;
    padding: 0;
    width: fit-content;
    min-width: 72px;
    min-height: 34px;
    box-sizing: border-box;
    overflow: visible;
  }

  .button-group-container.gjs-selected {
    outline: none !important;
  }

  .button-group-container[data-axis="horizontal"] > .component-button {
    flex: 0 0 auto;
  }

  .button-group-container[data-axis="vertical"] > .component-button {
    flex: 0 0 auto;
  }
`,
  script: `
  function normalizeAxis(value) {
    return value === 'vertical' || value === 'column' ? 'vertical' : 'horizontal';
  }

  function normalizePosition(value) {
    return ['left', 'right', 'top', 'bottom'].includes(value) ? value : 'left';
  }

  function updateGroup(model) {
    if (!model || typeof model.getEl !== 'function') return;
    const el = model.getEl();
    if (!el) return;

    const header = model.getTrait('header')?.getValue?.() || '';
    const axis = normalizeAxis(model.getTrait('axis')?.getValue?.());
    const position = normalizePosition(model.getTrait('buttonPosition')?.getValue?.());
    const legacyAlign = model.getTrait('group-align')?.getValue?.();

    let direction = axis === 'vertical' ? 'column' : 'row';
    let justify = 'flex-start';
    let align = 'center';

    if (axis === 'horizontal') {
      if (position === 'right') justify = 'flex-end';
      if (position === 'top') align = 'flex-start';
      if (position === 'bottom') align = 'flex-end';
    } else {
      if (position === 'bottom') justify = 'flex-end';
      if (position === 'left') align = 'flex-start';
      if (position === 'right') align = 'flex-end';
    }

    if (legacyAlign && !model.getTrait('buttonPosition')) {
      justify = legacyAlign === 'center' ? 'center' : legacyAlign;
    }

    el.style.setProperty('--button-group-direction', direction);
    el.style.setProperty('--button-group-justify', justify);
    el.style.setProperty('--button-group-align', align);
    el.style.flexDirection = direction;
    el.style.justifyContent = justify;
    el.style.alignItems = align;

    model.addAttributes({
      'data-header': String(header || ''),
      'data-axis': axis,
      'data-button-position': position,
      'aria-label': String(header || 'Button')
    }, { silent: true });
  }

  if (typeof model !== 'undefined' && model) {
    setTimeout(() => updateGroup(model), 0);
    if (!model.__buttonGroupRuntimeBound) {
      model.__buttonGroupRuntimeBound = true;
      let updateTimeout;
      const debouncedUpdate = () => {
        clearTimeout(updateTimeout);
        updateTimeout = setTimeout(() => updateGroup(model), 10);
      };
      model.on('change:traits', debouncedUpdate);
      model.on('change:attributes', debouncedUpdate);
      model.on('change:style', debouncedUpdate);
      model.on('component:update', debouncedUpdate);
    }
  }
`,
  traits: [
    {
      id: 'header',
      type: 'text',
      name: 'header',
      label: 'Header',
      value: '',
      placeholder: 'Enter text',
      changeProp: true
    },
    {
      id: 'axis',
      type: 'select',
      name: 'axis',
      label: 'Axis',
      value: 'horizontal',
      changeProp: true,
      options: [
        { id: 'horizontal', name: 'Horizontal', value: 'horizontal' },
        { id: 'vertical', name: 'Vertical', value: 'vertical' }
      ]
    },
    {
      id: 'buttonPosition',
      type: 'select',
      name: 'buttonPosition',
      label: 'Button Position',
      value: 'left',
      changeProp: true,
      options: [
        { id: 'left', name: 'Left', value: 'left' },
        { id: 'right', name: 'Right', value: 'right' },
        { id: 'top', name: 'Top', value: 'top' },
        { id: 'bottom', name: 'Bottom', value: 'bottom' }
      ]
    },
    {
      type: 'repeater',
      name: 'buttons-list',
      label: 'Buttons',
      itemId: 'custom-button-item',
      itemLabel: 'text',
      itemIcon: 'selectIcon',
      itemColor: 'color',
      defaultLabel: 'Button',
      defaultColor: '#4170FF'
    }
  ],
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M0 5.33334C0 2.38781 2.38781 0 5.33334 0C8.27885 0 10.6667 2.38781 10.6667 5.33334C10.6667 8.27885 8.27885 10.6667 5.33334 10.6667C2.38781 10.6667 0 8.27885 0 5.33334ZM5.33334 9.33334C3.1242 9.33334 1.33334 7.54248 1.33334 5.33334C1.33334 3.1242 3.1242 1.33334 5.33334 1.33334C7.54248 1.33334 9.33334 3.1242 9.33334 5.33334C9.33334 7.54248 7.54248 9.33334 5.33334 9.33334ZM0 24V13.3334H10.6667V24H0ZM1.33334 22.6666V14.6666H9.33334V22.6666H1.33334ZM24 10.6667L18 0L12 10.6667H24ZM21.7203 9.33334L18 2.71964L14.2797 9.33334H21.7203ZM17.3334 24V19.3334H12.6666V18H17.3334V13.3334H18.6666V18H23.3334V19.3334H18.6666V24H17.3334Z" fill="white"/>
    </svg>`,
  styleConfig: {
    sectors: [
      {
        id: 'flex-children',
        name: 'Flex-Children',
        open: true,
        properties: [
          {
            id: 'flex-order-type',
            name: 'Flex Order Type',
            property: 'order-type', // UI Only
            type: 'radio',
            default: '0',
            options: [
              { id: 'type1', label: 'Type 1', name: '', value: '' },
              { id: 'type2', label: 'Type 2', name: '', value: '' }
            ]
          },
          {
            id: 'order',
            name: 'Order',
            property: '--order',
            type: 'number',
            default: '0'
          },
          {
            id: 'flex-grow-shrink-group',
            name: 'Flex Shrink/Grow',
            type: 'composite',
            property: 'flex-group',
            properties: [
              {
                id: 'flex-basis',
                name: 'Basis',
                property: '--flex-basis',
                type: 'number',
                default: 'auto'
              },
              {
                id: 'flex-shrink',
                name: 'Shrink',
                property: '--flex-shrink',
                type: 'number',
                default: '1'
              },
              {
                id: 'flex-grow',
                name: 'Grow',
                property: '--flex-grow',
                type: 'number',
                default: '0'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align Self',
            property: 'align-self',
            type: 'radio',
            default: 'auto',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'flex-start' },
              { id: 'end', label: 'End', name: '', value: 'flex-end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' }
            ]
          },
          {
            id: 'justify-self',
            name: 'Justify Self',
            property: 'justify-self',
            type: 'radio',
            default: 'start',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'start' },
              { id: 'end', label: 'End', name: '', value: 'end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' },
              { id: 'auto', label: 'Auto', name: '', value: 'auto' }
            ]
          },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: 'justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: 'align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              { id: 'stretch', label: 'Stretch', value: 'stretch', name: '' },
              { id: 'baseline', label: 'Baseline', value: 'baseline', name: '' }
            ]
          }
        ]
      },
      {
        id: 'grid-parent',
        name: 'Grid-Parent',
        open: true,
        properties: [
          {
            id: 'grid-template-columns',
            name: 'Columns',
            property: 'grid-template-columns',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-template-rows',
            name: 'Rows',
            property: 'grid-template-rows',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-column-gap',
            name: 'Gap Column',
            property: 'column-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '10px'
          },
          {
            id: 'grid-row-gap',
            name: 'Gap Row',
            property: 'row-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '10px'
          },
          {
            id: 'justify-items',
            name: 'Justify Items',
            property: 'justify-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'normal',
                label: 'Normal',
                value: 'normal',
                name: ''
              }
            ]
          },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: 'justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: 'align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-grid',
        name: 'Grid-Children',
        open: true,
        properties: [
          {
            id: 'grid-column-start',
            name: 'Start Column',
            property: '--grid-column-start',
            type: 'number',
            default: 'auto',
            units: ['%', 'px', 'rem', 'vw', 'fr']
          },
          {
            id: 'grid-column-end',
            name: 'End Column',
            property: '--grid-column-end',
            type: 'number',
            default: 'auto',
            units: ['%', 'px', 'rem', 'vw', 'fr']
          },
          {
            id: 'grid-row-start',
            name: 'Start Row',
            property: '--grid-row-start',
            type: 'number',
            default: 'auto',
            units: ['%', 'px', 'rem', 'vw', 'fr']
          },
          {
            id: 'grid-row-end',
            name: 'End Row',
            property: '--grid-row-end',
            type: 'number',
            default: 'auto',
            units: ['%', 'px', 'rem', 'vw', 'fr']
          },
          {
            id: 'justify-self',
            name: 'Justify-Self',
            property: '--justify-self',
            type: 'radio',
            default: 'start',
            options: [
              {
                id: 'start',
                label: 'Start',
                name: '',
                value: 'start'
              },
              {
                id: 'end',
                label: 'End',
                name: '',
                value: 'end'
              },
              {
                id: 'stretch',
                label: 'Stretch',
                name: '',
                value: 'stretch'
              },
              {
                id: 'center',
                label: 'Center',
                name: '',
                value: 'center'
              },
              {
                id: 'auto',
                label: 'Auto',
                name: '',
                value: 'auto'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align-Self',
            property: '--align-self',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-position',
        name: 'Position',
        open: true,
        properties: [
          {
            id: 'text-align',
            name: 'Align',
            property: '--text-align',
            type: 'radio',
            default: 'left',
            options: [
              {
                id: 'left',
                label: 'Left',
                name: '',
                value: 'left'
              },
              {
                id: 'center',
                label: 'Center',
                name: '',
                value: 'center'
              },
              {
                id: 'right',
                label: 'Right',
                name: '',
                value: 'right'
              }
            ]
          },
          {
            id: 'position',
            name: 'Position',
            property: '--position',
            type: 'select',
            default: 'relative',
            options: [
              {
                id: 'static',
                label: 'Static',
                name: '',
                value: 'static'
              },
              {
                id: 'relative',
                label: 'Relative',
                name: '',
                value: 'relative'
              },
              {
                id: 'absolute',
                label: 'Absolute',
                name: '',
                value: 'absolute'
              },
              {
                id: 'fixed',
                label: 'Fixed',
                name: '',
                value: 'fixed'
              },
              {
                id: 'sticky',
                label: 'Sticky',
                name: '',
                value: 'sticky'
              }
            ]
          },

          {
            id: 'top',
            name: 'Top',
            property: '--top',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'right',
            name: 'Right',
            property: '--right',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'left',
            name: 'Left',
            property: '--left',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'bottom',
            name: 'Bottom',
            property: '--bottom',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw', 'auto'],
            default: 'auto'
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            units: ['vh', '%', 'px', 'rem', 'auto'],
            default: 'auto'
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw'],
            default: '50px'
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            units: ['%', 'px', 'rem', 'vh'],
            default: '50px'
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw'],
            default: '100%'
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            units: ['%', 'px', 'rem', 'vh'],
            default: '100%'
          },
          {
            id: 'display',
            name: 'Display',
            property: 'display',
            type: 'select',
            default: 'flex',
            options: [
              {
                value: 'block',
                name: 'Block',
                id: 'block'
              },
              {
                value: 'flex',
                name: 'Flex',
                id: 'flex'
              },
              {
                value: 'grid',
                name: 'Grid',
                id: 'grid'
              },
              {
                value: 'inline-block',
                name: 'Inline Block',
                id: 'inline-block'
              }
            ]
          }
        ]
      }
    ]
  }
};
