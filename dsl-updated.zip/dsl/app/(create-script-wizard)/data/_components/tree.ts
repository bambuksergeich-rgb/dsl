import { ComponentConfig } from '../elements';

export const Tree: ComponentConfig = {
  id: 'tree',
  type: 'tree',
  label: 'Tree',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: { class: 'tree-wrapper' },
    components: [
      {
        tagName: 'h2',
        attributes: { class: 'tree-header' },
        content: 'Tree Header',
        droppable: false,
        draggable: false,
        selectable: true
      },
      {
        tagName: 'div',
        attributes: { class: 'tree-container' },
        components: [
          {
            tagName: 'div',
            attributes: { class: 'tree-nav vertical' },
            components: [
              {
                tagName: 'div',
                attributes: { class: 'tab-item active' },
                components: [
                  {
                    tagName: 'div',
                    attributes: { class: 'tab-controls' },
                    components: [
                      {
                        tagName: 'button',
                        attributes: { class: 'toggle-tab' },
                        content:
                          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 6L8 10L12 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                        droppable: false,
                        draggable: false
                      },
                      {
                        tagName: 'button',
                        attributes: {
                          class: 'tab-button',
                          'data-value': 'tab1',
                          title: 'Tab 1'
                        },
                        content: 'Tab 1',
                        droppable: false,
                        draggable: false
                      },
                      {
                        tagName: 'button',
                        attributes: { class: 'menu-tab' },
                        content:
                          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="4" cy="8" r="2" fill="white"/><circle cx="8" cy="8" r="2" fill="white"/><circle cx="12" cy="8" r="2" fill="white"/></svg>',
                        droppable: false,
                        draggable: false
                      },
                      {
                        tagName: 'div',
                        attributes: { class: 'dropdown-menu' },
                        components: [
                          {
                            tagName: 'button',
                            attributes: {
                              class: 'dropdown-item',
                              'data-action': 'add-sub-tab',
                              'data-value': 'tab1'
                            },
                            content: 'Add Sub-Tab',
                            droppable: false,
                            draggable: false
                          },
                          {
                            tagName: 'button',
                            attributes: {
                              class: 'dropdown-item',
                              'data-action': 'remove-tab',
                              'data-value': 'tab1'
                            },
                            content: 'Remove Tab',
                            droppable: false,
                            draggable: false
                          }
                        ],
                        droppable: false,
                        draggable: false
                      }
                    ],
                    droppable: false,
                    draggable: false
                  },
                  {
                    tagName: 'div',
                    attributes: { class: 'sub-nav' },
                    components: [],
                    droppable: false,
                    draggable: false
                  }
                ],
                droppable: false,
                draggable: false
              },
              {
                tagName: 'div',
                attributes: { class: 'tab-item' },
                components: [
                  {
                    tagName: 'div',
                    attributes: { class: 'tab-controls' },
                    components: [
                      {
                        tagName: 'button',
                        attributes: { class: 'toggle-tab' },
                        content:
                          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 6L8 10L12 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                        droppable: false,
                        draggable: false
                      },
                      {
                        tagName: 'button',
                        attributes: {
                          class: 'tab-button last-child',
                          'data-value': 'tab2',
                          title: 'Tab 2'
                        },
                        content: 'Tab 2',
                        droppable: false,
                        draggable: false
                      },
                      {
                        tagName: 'button',
                        attributes: { class: 'menu-tab' },
                        content:
                          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="4" r="2" fill="white"/><circle cx="8" cy="8" r="2" fill="white"/><circle cx="8" cy="12" r="2" fill="white"/></svg>',
                        droppable: false,
                        draggable: false
                      },
                      {
                        tagName: 'div',
                        attributes: { class: 'dropdown-menu' },
                        components: [
                          {
                            tagName: 'button',
                            attributes: {
                              class: 'dropdown-item',
                              'data-action': 'add-tab'
                            },
                            content: 'Add Tab',
                            droppable: false,
                            draggable: false
                          },
                          {
                            tagName: 'button',
                            attributes: {
                              class: 'dropdown-item',
                              'data-action': 'add-sub-tab',
                              'data-value': 'tab2'
                            },
                            content: 'Add Sub-Tab',
                            droppable: false,
                            draggable: false
                          },
                          {
                            tagName: 'button',
                            attributes: {
                              class: 'dropdown-item',
                              'data-action': 'remove-tab',
                              'data-value': 'tab2'
                            },
                            content: 'Remove Tab',
                            droppable: false,
                            draggable: false
                          }
                        ],
                        droppable: false,
                        draggable: false
                      }
                    ],
                    droppable: false,
                    draggable: false
                  },
                  {
                    tagName: 'div',
                    attributes: { class: 'sub-nav' },
                    components: [],
                    droppable: false,
                    draggable: false
                  }
                ],
                droppable: false,
                draggable: false
              }
            ],
            droppable: false,
            draggable: false,
            selectable: false
          },
          {
            tagName: 'div',
            attributes: { class: 'tree-content' },
            components: [
              {
                tagName: 'div',
                attributes: {
                  class: 'tab-pane active',
                  'data-value': 'tab1'
                },
                content: '',
                droppable: true,
                draggable: false,
                selectable: true
              },
              {
                tagName: 'div',
                attributes: { class: 'tab-pane', 'data-value': 'tab2' },
                content: '',
                droppable: true,
                draggable: false,
                selectable: true
              }
            ],
            droppable: true,
            draggable: false,
            selectable: true
          }
        ],
        droppable: false,
        draggable: false,
        selectable: false
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g clip-path="url(#clip0_131_18050)">
  <path d="M9.99935 21.3334H7.33268C7.15587 21.3334 6.9863 21.2631 6.86128 21.1381C6.73625 21.0131 6.66602 20.8435 6.66602 20.6667V18C6.66602 17.8232 6.73625 17.6537 6.86128 17.5286C6.9863 17.4036 7.15587 17.3334 7.33268 17.3334H9.99935C10.1762 17.3334 10.3457 17.4036 10.4708 17.5286C10.5958 17.6537 10.666 17.8232 10.666 18V20.6667C10.666 20.8435 10.5958 21.0131 10.4708 21.1381C10.3457 21.2631 10.1762 21.3334 9.99935 21.3334ZM7.99935 20H9.33268V18.6667H7.99935V20Z" fill="white"/>
  <path d="M10.0007 10.6667H7.33398C7.15717 10.6667 6.9876 10.7369 6.86258 10.8619C6.73756 10.987 6.66732 11.1565 6.66732 11.3333V12.1333H3.86732V8H4.66732C4.84413 8 5.0137 7.92976 5.13872 7.80474C5.26375 7.67971 5.33398 7.51014 5.33398 7.33333V4.66667C5.33398 4.48986 5.26375 4.32029 5.13872 4.19526C5.0137 4.07024 4.84413 4 4.66732 4H2.00065C1.82384 4 1.65427 4.07024 1.52925 4.19526C1.40422 4.32029 1.33398 4.48986 1.33398 4.66667V7.33333C1.33398 7.51014 1.40422 7.67971 1.52925 7.80474C1.65427 7.92976 1.82384 8 2.00065 8H2.80065V19.8667H7.04065C7.1821 19.8667 7.31776 19.8105 7.41777 19.7105C7.51779 19.6104 7.57398 19.4748 7.57398 19.3333C7.57398 19.1919 7.51779 19.0562 7.41777 18.9562C7.31776 18.8562 7.1821 18.8 7.04065 18.8H3.86732V13.2H6.66732V14C6.66732 14.1768 6.73756 14.3464 6.86258 14.4714C6.9876 14.5964 7.15717 14.6667 7.33398 14.6667H10.0007C10.1775 14.6667 10.347 14.5964 10.4721 14.4714C10.5971 14.3464 10.6673 14.1768 10.6673 14V11.3333C10.6673 11.1565 10.5971 10.987 10.4721 10.8619C10.347 10.7369 10.1775 10.6667 10.0007 10.6667ZM2.66732 5.33333H4.00065V6.66667H2.66732V5.33333ZM9.33398 13.3333H8.00065V12H9.33398V13.3333Z" fill="white"/>
  <path d="M22.666 6.00004C22.666 5.82323 22.5958 5.65366 22.4708 5.52864C22.3457 5.40361 22.1762 5.33337 21.9993 5.33337H6.66602V6.66671H21.9993C22.1762 6.66671 22.3457 6.59647 22.4708 6.47145C22.5958 6.34642 22.666 6.17685 22.666 6.00004Z" fill="white"/>
  <path d="M22 12H12V13.3333H22C22.1768 13.3333 22.3464 13.2631 22.4714 13.1381C22.5964 13.013 22.6667 12.8435 22.6667 12.6667C22.6667 12.4899 22.5964 12.3203 22.4714 12.1953C22.3464 12.0702 22.1768 12 22 12Z" fill="white"/>
  <path d="M22 18.6666H12V20H22C22.1768 20 22.3464 19.9297 22.4714 19.8047C22.5964 19.6797 22.6667 19.5101 22.6667 19.3333C22.6667 19.1565 22.5964 18.9869 22.4714 18.8619C22.3464 18.7369 22.1768 18.6666 22 18.6666Z" fill="white"/>
  </g>
  <defs>
  <clipPath id="clip0_131_18050">
  <rect width="24" height="24" fill="white"/>
  </clipPath>
  </defs>
  </svg>
  `,
  traits: [
    {
      id: 'tabs',
      name: 'tabs',
      type: 'list',
      label: 'Tabs',
      changeProp: true,
      value:
        '[{"value":"tab1","label":"Tab 1","components":[],"subTabs":[]},{"value":"tab2","label":"Tab 2","components":[],"subTabs":[]}]'
    },
    {
      id: 'headerText',
      name: 'headerText',
      type: 'text',
      label: 'Header Text',
      changeProp: true,
      value: 'Tree Header'
    }
  ],
  styleConfig: {
    sectors: [
      {
        id: 'Tree Dimension',
        name: 'Tree Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '1172',
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: '800',
            units: ['px', '%']
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            default: '50%',
            units: ['px', '%']
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            default: '100%',
            units: ['px', '%']
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          }
        ]
      },
      {
        id: 'Header Text',
        name: 'Header Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: '24',
            units: ['px']
          },
          {
            id: 'color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  },
  styles: `
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap');

    .tree-wrapper {
      min-width: 758px;
      min-height: 800px;
      width: var(--width, 758px);
      height: var(--height, 800px);
      padding: 16px;
      background-color: var(--bg-color, #10161C80);
      border: 2px solid var(--border-color, #3D3AB8);
      border-radius: 12px;
      display: flex;
      flex-direction: column;
      gap: 12px;
      font-family: 'Montserrat', sans-serif;
    }
    .tree-header {
      margin: 0 0 16px 0;
      font-size: var(--font-size, 24px);
      color: var(--color, #FFFFFF);
      font-weight: 500;
      font-family: 'Montserrat', sans-serif;
      text-align: left;
    }
    .tree-container {
      display: flex;
      flex-direction: row;
      gap: 12px;
      flex: 1;
    }
    .tree-nav {
      display: flex;
      flex-direction: column;
      gap: 8px;
      min-width: 380px;
      max-height: 600px;
      overflow-y: auto;
      scrollbar-width: none;
      background-color: transparent;
      position: relative;
      align-items: flex-start;
    }
    .tree-nav::-webkit-scrollbar {
      display: none;
    }
    .tab-item {
      display: flex;
      flex-direction: column;
      gap: 8px;
      width: 320px;
      position: relative;
    }
    .tab-controls {
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 8px;
    }
    .tab-item.active {
      border-radius: 4px;
      padding: 4px;
    }
    .tab-item.collapsed .sub-nav {
      display: none;
    }
    .tab-item.collapsed .toggle-tab svg {
      transform: rotate(90deg);
    }
    .tab-button {
      padding: 8px 16px;
      border: none;
      cursor: pointer;
      transition: all 0.2s;
      width: calc(100% - 48px); /* 24px (toggle-tab) + 24px (menu-tab) + 8px (1 gap) */
      max-width: 220px;
      text-align: left;
      color: var(--tab-color, #FFFFFF);
      background: transparent;
      font-size: 16px;
      font-family: 'Montserrat', sans-serif;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .tab-button.last-child {
      width: calc(100% - 48px); /* Same as above, no extra buttons */
    }
    .tab-button:hover {
      color: #ffffff;
    }
    .tab-button.active {
      color: #ffffff;
    }
    .toggle-tab {
      width: 24px;
      height: 24px;
      padding: 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      background-color: transparent;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .toggle-tab svg {
      width: 16px;
      height: 16px;
      transition: transform 0.2s;
    }
    .menu-tab {
      width: 24px;
      height: 24px;
      padding: 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      background-color: #3D3AB8;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      position: relative;
    }
    .menu-tab svg {
      width: 16px;
      height: 16px;
    }
    .dropdown-menu {
      display: none;
      position: absolute;
      top: 28px;
      right: 0;
      background-color: #2d2d2d;
      border: 1px solid #3D3AB8;
      border-radius: 4px;
      z-index: 10;
      min-width: 120px;
      flex-direction: column;
      gap: 4px;
      padding: 4px;
    }
    .dropdown-menu.open {
      display: flex;
    }
    .dropdown-item {
      padding: 8px 12px;
      border: none;
      background: transparent;
      color: #ffffff;
      font-size: 14px;
      font-family: 'Montserrat', sans-serif;
      text-align: left;
      cursor: pointer;
      width: 100%;
      border-radius: 2px;
    }
    .dropdown-item:hover {
      background-color: #3D3AB8;
    }
    .sub-nav {
      display: flex;
      flex-direction: column;
      gap: 8px;
      width: 300px;
      margin-left: 20px;
    }
    .tree-content {
      background-color: var(--bg-color, #10161C80);
      padding: 12px;
      border-radius: 4px;
      flex: 1;
      min-height: 400px;
    }
    .tab-pane {
      display: none;
      min-height: 100px;
      padding: 16px;
      border-radius: 4px;
    }
    .tab-pane.active {
      display: block;
    }
    .tab-pane > * {
      width: 100%;
    }
    @media (max-width: 768px) {
      .tree-wrapper {
        min-width: 100%;
        width: 100%;
        max-width: none;
      }
      .tree-container {
        flex-direction: column;
      }
      .tree-nav {
        flex-direction: row;
        min-width: 0;
        max-height: none;
        overflow-x: auto;
        overflow-y: visible;
        margin-bottom: 12px;
      }
      .tab-item {
        flex-direction: column;
        align-items: center;
        width: auto;
      }
      .tab-controls {
        flex-direction: row;
        align-items: center;
        gap: 8px;
      }
      .tab-item.active {
        border: none;
        background-color: transparent;
        padding: 0;
      }
      .tab-button {
        width: auto;
        max-width: 80px;
        text-align: center;
      }
      .tab-button.last-child {
        width: auto;
        max-width: 80px;
      }
      .toggle-tab, .menu-tab {
        width: 20px;
        height: 20px;
      }
      .toggle-tab svg, .menu-tab svg {
        width: 12px;
        height: 12px;
      }
      .dropdown-menu {
        top: 24px;
        right: -10px;
        min-width: 100px;
      }
      .sub-nav {
        display: flex;
        flex-direction: column;
        width: 100%;
        margin-left: 10px;
      }
    }
  `,
  script: `
    function updateTree(model, editor) {
      console.log('updateTree called:', model.changed);
      if (!model || !model.getEl() || !editor) {
        console.error('No model, editor, or wrapper element');
        return;
      }
      const wrapper = model.getEl();
      const traits = model.getTraits();
      try {
        const headerEl = wrapper.querySelector('.tree-header');
        const navEl = wrapper.querySelector('.tree-nav');
        const contentEl = wrapper.querySelector('.tree-content');
        if (headerEl && navEl && contentEl) {
          const tabsTrait = traits.find(t => t.getName() === 'tabs');
          const headerTextTrait = traits.find(t => t.getName() === 'headerText');
          let tabs = [];
          try {
            tabs = tabsTrait?.getValue() ? JSON.parse(tabsTrait.getValue()) : [
              { value: 'tab1', label: 'Tab 1', components: [], subTabs: [] },
              { value: 'tab2', label: 'Tab 2', components: [], subTabs: [] }
            ];
          } catch (e) {
            console.error('Invalid JSON in tabs trait:', e);
          }

          // Обновляем текст заголовка
          headerEl.textContent = headerTextTrait?.getValue() || 'Tree Header';

          // Устанавливаем стили из styleConfig
          const styles = model.getStyle() || {};
          wrapper.style.setProperty('--width', styles.width || '758px');
          wrapper.style.setProperty('--height', styles.height || '800px');
          wrapper.style.setProperty('--bg-color', '#10161C80');
          wrapper.style.setProperty('--border-color', '#3D3AB8');
          headerEl.style.setProperty('--font-size', styles['font-size'] ? \`\${styles['font-size']}px\` : '24px');
          headerEl.style.setProperty('--color', styles.color || '#FFFFFF');

          // Функция для генерации HTML вкладок
          function generateTabHTML(tabs, level = 0) {
            return tabs.map((tab, i) => \`
              <div class="tab-item \${i === 0 && level === 0 ? 'active' : ''} \${tab.subTabs?.length ? '' : 'collapsed'}">
                <div class="tab-controls">
                  <button class="toggle-tab" data-value="\${tab.value}">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M4 6L8 10L12 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </button>
                  <button class="tab-button \${i === tabs.length - 1 ? 'last-child' : ''}" data-value="\${tab.value}" title="\${tab.label}">\${tab.label}</button>
                  <button class="menu-tab">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="4" cy="8" r="2" fill="white"/>
                      <circle cx="8" cy="8" r="2" fill="white"/>
                      <circle cx="12" cy="8" r="2" fill="white"/>
                    </svg>
                  </button>
                  <div class="dropdown-menu">
                    \${i === tabs.length - 1 && level === 0 ? \`
                      <button class="dropdown-item" data-action="add-tab">Add Tab</button>
                    \` : ''}
                    <button class="dropdown-item" data-action="add-sub-tab" data-value="\${tab.value}">Add Sub-Tab</button>
                    <button class="dropdown-item" data-action="remove-tab" data-value="\${tab.value}">Remove Tab</button>
                  </div>
                </div>
                <div class="sub-nav">
                  \${tab.subTabs?.length ? generateTabHTML(tab.subTabs, level + 1) : ''}
                </div>
              </div>
            \`).join('');
          }

          // Обновляем навигацию
          navEl.innerHTML = generateTabHTML(tabs);

          // Обновляем содержимое вкладок
          contentEl.innerHTML = '';
          function generatePanes(tabs) {
            tabs.forEach((tab, i) => {
              const pane = document.createElement('div');
              pane.className = \`tab-pane\${i === 0 && !tab.subTabs?.length ? ' active' : ''}\`;
              pane.setAttribute('data-value', tab.value);
              pane.setAttribute('data-droppable', 'true');
              contentEl.appendChild(pane);
              // Восстанавливаем компоненты
              const paneModel = editor.getWrapper().find(\`.tab-pane[data-value="\${tab.value}"]\`)[0];
              if (paneModel && tab.components && tab.components.length > 0) {
                paneModel.components(tab.components);
              }
              if (tab.subTabs?.length) {
                generatePanes(tab.subTabs);
              }
            });
          }
          generatePanes(tabs);

          // Добавляем обработчики событий для tab-button
          const buttons = navEl.querySelectorAll('.tab-button');
          buttons.forEach(button => {
            button.removeEventListener('click', handleTabClick);
            button.addEventListener('click', handleTabClick);
            function handleTabClick() {
              const items = navEl.querySelectorAll('.tab-item');
              items.forEach(item => item.classList.remove('active'));
              const panes = contentEl.querySelectorAll('.tab-pane');
              panes.forEach(p => p.classList.remove('active'));
              button.closest('.tab-item').classList.add('active');
              const pane = contentEl.querySelector(\`.tab-pane[data-value="\${button.dataset.value}"]\`);
              if (pane) {
                pane.classList.add('active');
                // Разворачиваем родительские вкладки
                let parent = button.closest('.tab-item');
                while (parent && parent.classList.contains('tab-item')) {
                  parent.classList.remove('collapsed');
                  parent.querySelector('.toggle-tab svg')?.style.setProperty('transform', 'rotate(0deg)');
                  parent = parent.parentElement.closest('.tab-item');
                }
                console.log('Tab switched:', button.dataset.value);
              } else {
                console.error('Pane not found for value:', button.dataset.value);
              }
            }
          });

          // Обработчики для toggle-tab
          const toggleButtons = navEl.querySelectorAll('.toggle-tab');
          toggleButtons.forEach(button => {
            button.removeEventListener('click', handleToggleTab);
            button.addEventListener('click', handleToggleTab);
            function handleToggleTab() {
              const tabItem = button.closest('.tab-item');
              if (tabItem) {
                tabItem.classList.toggle('collapsed');
                const svg = button.querySelector('svg');
                if (svg) {
                  svg.style.transform = tabItem.classList.contains('collapsed') ? 'rotate(90deg)' : 'rotate(0deg)';
                }
              }
            }
          });

          // Обработчики для menu-tab
          const menuButtons = navEl.querySelectorAll('.menu-tab');
          menuButtons.forEach(button => {
            button.removeEventListener('click', handleMenuToggle);
            button.addEventListener('click', handleMenuToggle);
            function handleMenuToggle(e) {
              e.stopPropagation();
              const dropdown = button.nextElementSibling;
              if (dropdown && dropdown.classList.contains('dropdown-menu')) {
                const isOpen = dropdown.classList.contains('open');
                // Закрываем все другие открытые меню
                navEl.querySelectorAll('.dropdown-menu.open').forEach(menu => {
                  menu.classList.remove('open');
                });
                // Переключаем текущее меню
                if (!isOpen) {
                  dropdown.classList.add('open');
                }
              }
            }
          });

          // Обработчики для dropdown-item
          const dropdownItems = navEl.querySelectorAll('.dropdown-item');
          dropdownItems.forEach(item => {
            item.removeEventListener('click', handleDropdownAction);
            item.addEventListener('click', handleDropdownAction);
            function handleDropdownAction(e) {
              e.stopPropagation();
              const action = item.dataset.action;
              const tabValue = item.dataset.value;
              if (action === 'add-tab') {
                editor.runCommand('add-tab', { component: model });
              } else if (action === 'add-sub-tab') {
                editor.runCommand('add-sub-tab', { component: model, parentValue: tabValue });
              } else if (action === 'remove-tab') {
                editor.runCommand('remove-tab', { component: model, tabValue: tabValue });
              }
              // Закрываем меню после действия
              item.closest('.dropdown-menu').classList.remove('open');
            }
          });

          // Закрытие меню при клике вне
          document.addEventListener('click', function closeMenu(e) {
            if (!e.target.closest('.menu-tab') && !e.target.closest('.dropdown-menu')) {
              navEl.querySelectorAll('.dropdown-menu.open').forEach(menu => {
                menu.classList.remove('open');
              });
            }
          });

          // Сохраняем компоненты в трейт при изменении содержимого tab-pane
          editor.on('component:add component:remove component:update', (component) => {
            if (component.closest('.tab-pane')) {
              const panes = contentEl.querySelectorAll('.tab-pane');
              function updateTabs(tabs) {
                return tabs.map((tab, i) => ({
                  value: tab.value || \`tab\${i + 1}\`,
                  label: tab.label || \`Tab \${i + 1}\`,
                  components: editor.getWrapper().find(\`.tab-pane[data-value="\${tab.value}"]\`)[0]?.components().toJSON() || [],
                  subTabs: tab.subTabs ? updateTabs(tab.subTabs) : []
                }));
              }
              const updatedTabs = updateTabs(tabs);
              tabsTrait.setValue(JSON.stringify(updatedTabs));
              console.log('Tabs updated with components:', updatedTabs);
            }
          });

          // Перехватываем изменение трейта tabs
          editor.on('trait:change:tabs', () => {
            let tabs = [];
            try {
              tabs = JSON.parse(tabsTrait.getValue() || '[]');
            } catch (e) {
              console.error('Error parsing tabs JSON:', e);
            }
            if (tabs.length > 10) {
              tabs = tabs.slice(0, 10);
              editor.Modal.open({ title: 'Warning', content: 'Maximum 10 tabs allowed.' });
            }
            function ensureUniqueValues(tabs, level = 0) {
              return tabs.map((tab, i) => {
                const existingValues = tabs.slice(0, i).map(t => t.value);
                const newTab = {
                  value: tab.value && !existingValues.includes(tab.value) && !tab.value.startsWith('option') ? tab.value : \`tab\${level}-\${i + 1}-\${Date.now()}\`,
                  label: tab.label && !tab.label.startsWith('option') ? tab.label : \`Tab \${i + 1}\`,
                  components: tab.components || [],
                  subTabs: tab.subTabs ? ensureUniqueValues(tab.subTabs, level + 1) : []
                };
                return newTab;
              });
            }
            tabs = ensureUniqueValues(tabs);
            tabsTrait.setValue(JSON.stringify(tabs));
            updateTree(model, editor);
            console.log('Tabs trait updated:', tabs);
          });

          console.log('Tree updated:', { tabs, headerText: headerTextTrait?.getValue() });
        } else {
          console.error('Missing tree elements');
        }
      } catch (e) {
        console.error('Error updating tree:', e);
      }
    }

    // Команда для добавления вкладки
    editor.Commands.add('add-tab', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component || component.get('type') !== 'tree') {
          editor.Modal.open({ title: 'Error', content: 'Please select a Tree component.' });
          return;
        }
        const tabsTrait = component.getTrait('tabs');
        let tabs = [];
        try {
          tabs = JSON.parse(tabsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing tabs JSON:', e);
        }
        if (tabs.length >= 10) {
          editor.Modal.open({ title: 'Error', content: 'Maximum 10 tabs allowed.' });
          return;
        }
        const newTab = { value: \`tab\${tabs.length + 1}-\${Date.now()}\`, label: \`Tab \${tabs.length + 1}\`, components: [], subTabs: [] };
        tabs.push(newTab);
        tabsTrait.setValue(JSON.stringify(tabs));
        console.log('Tab added:', tabs);
        updateTree(component, editor);
        editor.Modal.open({ title: 'Success', content: 'Tab added successfully!' });
      }
    });

    // Команда для добавления подуровня
    editor.Commands.add('add-sub-tab', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        const parentValue = options.parentValue;
        if (!component || component.get('type') !== 'tree' || !parentValue) {
          editor.Modal.open({ title: 'Error', content: 'Please select a Tree component and specify a parent tab.' });
          return;
        }
        const tabsTrait = component.getTrait('tabs');
        let tabs = [];
        try {
          tabs = JSON.parse(tabsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing tabs JSON:', e);
        }
        function addSubTab(tabs, parentValue) {
          return tabs.map(tab => {
            if (tab.value === parentValue) {
              if (!tab.subTabs) tab.subTabs = [];
              if (tab.subTabs.length >= 10) {
                editor.Modal.open({ title: 'Error', content: 'Maximum 10 sub-tabs allowed.' });
                return tab;
              }
              tab.subTabs.push({ value: \`tab\${tab.subTabs.length + 1}-\${Date.now()}\`, label: \`Sub Tab \${tab.subTabs.length + 1}\`, components: [], subTabs: [] });
            } else if (tab.subTabs) {
              tab.subTabs = addSubTab(tab.subTabs, parentValue);
            }
            return tab;
          });
        }
        tabs = addSubTab(tabs, parentValue);
        tabsTrait.setValue(JSON.stringify(tabs));
        console.log('Sub-tab added:', tabs);
        updateTree(component, editor);
        editor.Modal.open({ title: 'Success', content: 'Sub-tab added successfully!' });
      }
    });

    // Команда для удаления вкладки
    editor.Commands.add('remove-tab', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        const tabValue = options.tabValue;
        if (!component || component.get('type') !== 'tree' || !tabValue) {
          editor.Modal.open({ title: 'Error', content: 'Please select a Tree component and specify a tab to remove.' });
          return;
        }
        const tabsTrait = component.getTrait('tabs');
        let tabs = [];
        try {
          tabs = JSON.parse(tabsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing tabs JSON:', e);
        }
        if (tabs.length <= 1 && !options.parentTabs) {
          editor.Modal.open({ title: 'Error', content: 'At least one tab must remain.' });
          return;
        }
        function removeTab(tabs, tabValue) {
          return tabs.filter(tab => {
            if (tab.value === tabValue) return false;
            if (tab.subTabs) tab.subTabs = removeTab(tab.subTabs, tabValue);
            return true;
          });
        }
        tabs = removeTab(tabs, tabValue);
        // Если удалена активная вкладка, сделать первую вкладку активной
        if (!tabs.some((tab, i) => i === 0 && document.querySelector(\`.tab-item[data-value="\${tab.value}"]\`)?.classList.contains('active'))) {
          tabs[0].active = true;
        }
        tabsTrait.setValue(JSON.stringify(tabs));
        console.log('Tab removed:', tabValue, tabs);
        updateTree(component, editor);
        editor.Modal.open({ title: 'Success', content: 'Tab removed successfully!' });
      }
    });

    if (model && model.getEl()) {
      console.log('Initial updateTree call');
      updateTree(model, editor);
    }
    model.on('change', () => {
      console.log('Model changed:', model.changed);
      updateTree(model, editor);
    });
  `
};
