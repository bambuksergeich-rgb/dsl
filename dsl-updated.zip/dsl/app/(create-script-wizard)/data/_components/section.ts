import { ComponentConfig } from '../elements';

export const Section: ComponentConfig = {
  id: 'section',
  type: 'section',
  label: 'Section',
  category: 'Templates',
  content: {
    tagName: 'div',
    attributes: { class: 'section-wrapper' },
    components: [],
    droppable: false,
    editable: false,
    selectable: true,
    draggable: false
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M21.9699 13.4769H18.2776C17.6776 13.4769 17.1699 12.9692 17.1699 12.3692V11.6308C17.1699 11.0308 17.6776 10.5231 18.2776 10.5231H21.9699C22.5699 10.5231 23.0776 11.0308 23.0776 11.6308V12.3692C23.0776 12.9692 22.5699 13.4769 21.9699 13.4769Z" fill="white"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M13.8469 13.4769H10.1546C9.55457 13.4769 9.04688 12.9692 9.04688 12.3692V11.6308C9.04688 11.0308 9.55457 10.5231 10.1546 10.5231H13.8469C14.4469 10.5231 14.9546 11.0308 14.9546 11.6308V12.3692C14.9546 12.9692 14.4469 13.4769 13.8469 13.4769Z" fill="white"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M5.72383 13.4769H2.03152C1.38537 13.4769 0.923828 12.9692 0.923828 12.3692V11.6308C0.923828 11.0308 1.43152 10.5231 2.03152 10.5231H5.72383C6.32383 10.5231 6.83152 11.0308 6.83152 11.6308V12.3692C6.83152 12.9692 6.32383 13.4769 5.72383 13.4769Z" fill="white"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M20.1235 15.6923H3.87731C3.04654 15.6923 2.40039 16.3384 2.40039 17.1692V20.8615C2.40039 21.6923 3.04654 22.3384 3.87731 22.3384H20.1235C20.9542 22.3384 21.6004 21.6923 21.6004 20.8615V17.1692C21.6004 16.3384 20.9081 15.6923 20.1235 15.6923ZM19.385 19.7538C19.385 19.9384 19.2004 20.123 19.0158 20.123H4.98501C4.80039 20.123 4.61578 19.9384 4.61578 19.7538V18.2769C4.61578 18.0923 4.80039 17.9076 4.98501 17.9076H19.0158C19.2004 17.9076 19.385 18.0923 19.385 18.2769V19.7538Z" fill="white"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M20.1235 1.6615H3.87731C3.04654 1.6615 2.40039 2.30765 2.40039 3.13842V6.83073C2.40039 7.6615 3.04654 8.30765 3.87731 8.30765H20.1235C20.9542 8.30765 21.6004 7.6615 21.6004 6.83073V3.13842C21.6004 2.30765 20.9081 1.6615 20.1235 1.6615ZM19.385 5.72304C19.385 5.90765 19.2004 6.09227 19.0158 6.09227H4.98501C4.80039 6.09227 4.61578 5.90765 4.61578 5.72304V4.24611C4.61578 4.0615 4.80039 3.87688 4.98501 3.87688H19.0158C19.2004 3.87688 19.385 4.0615 19.385 4.24611V5.72304Z" fill="white"/>
  </svg>`,
  traits: [
    {
      id: 'sections-count',
      name: 'sections-count',
      type: 'number',
      label: 'Number of Sections',
      min: 1,
      max: 12,
      value: 1,
      changeProp: true
    },
    {
      id: 'spacing',
      name: 'spacing',
      type: 'number',
      label: 'Gap between sections',
      min: 0,
      max: 32,
      value: 8,
      changeProp: true
    },
    {
      id: 'default-height',
      name: 'default-height',
      type: 'number',
      label: 'Default Section Height',
      min: 50,
      max: 800,
      value: 200,
      changeProp: true
    },
    {
      id: 'collapsible',
      name: 'collapsible',
      type: 'switch',
      label: 'Collapsible Sections',
      value: true,
      changeProp: true
    }
  ],
  styles: `
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap');
    .section-wrapper {
      display: flex;
      flex-direction: column;
      gap: var(--section-gap, 8px);
      padding: 16px;
      background-color: transparent !important;
      overflow-y: auto;
      width: 100%;
      box-sizing: border-box;
      position: relative;
      font-family: Montserrat;
    }

    .section-inner {
      display: flex;
      flex-direction: column;
      border: 1px solid #3D3AB8;
      border-radius: 6px;
      overflow: hidden;
      background: transparent;
      transition: all 0.3s ease;
    }

    .section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      background-color: #3D3AB8;
      cursor: pointer;
      user-select: none;
      min-height: 44px;
      box-sizing: border-box;
      transition: background-color 0.2s ease;
    }

    .section-header:hover {
      background-color: #2A2880;
    }

    .section-title {
      font-size: 16px;
      font-weight: 500;
      color: #FFFFFF;
      pointer-events: none;
    }

    .section-toggle {
      cursor: pointer;
      transition: transform 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .section-toggle.collapsed {
      transform: rotate(-90deg);
    }

    .section-content {
      display: flex;
      flex-direction: column;
      padding: 16px;
      background-color: var(--bg-color, #3D3AB899);
      min-height: 50px;
      position: relative;
      width: 100%;
      box-sizing: border-box;
      overflow: auto;
      transition: height 0.3s ease;
    }

    .section-content.collapsed {
      display: none !important;
    }

    /* Стили для ресайзеров */
    .section-content .gjs-resizer {
      background-color: #4170FF !important;
      border: 2px solid #FFFFFF !important;
      z-index: 1000 !important;
      width: 12px !important;
      height: 12px !important;
      border-radius: 50% !important;
      box-shadow: 0 2px 4px rgba(0,0,0,0.3) !important;
    }

    .section-content .gjs-resizer-bc {
      bottom: -6px !important;
      left: 50% !important;
      transform: translateX(-50%) !important;
      cursor: ns-resize !important;
    }

    /* Убедимся, что контент внутри секции можно редактировать */
    .section-content [data-gjs-type] {
      pointer-events: all !important;
    }

    .section-content [data-gjs-droppable="true"] {
      min-height: 20px;
    }

    /* Tablet (≤ 992px) */
    @media (max-width: 992px) {
      .section-wrapper {
        padding: 12px;
        gap: 6px;
      }
      .section-header {
        padding: 10px 14px;
      }
      .section-title {
        font-size: 15px;
      }
      .section-content {
        padding: 14px;
      }
    }

    /* Mobile (≤ 768px) */
    @media (max-width: 768px) {
      .section-wrapper {
        padding: 8px;
        gap: 4px;
      }
      .section-header {
        padding: 8px 12px;
      }
      .section-title {
        font-size: 14px;
      }
      .section-content {
        padding: 12px;
      }
      .section-toggle svg {
        width: 14px;
        height: 14px;
      }
    }`,
  script: `
let sectionCounter = 0;
let isResizing = false;

function updateSection(model) {
  if (isResizing) return;
  
  const wrapper = model.getEl();
  if (!wrapper) return;
  
  // Получаем значения трейтов
  const sectionsCount = parseInt(model.getTrait('sections-count')?.getValue() || '1', 10);
  const spacing = parseInt(model.getTrait('spacing')?.getValue() || '8', 10);
  const defaultHeight = parseInt(model.getTrait('default-height')?.getValue() || '200', 10);
  const collapsible = model.getTrait('collapsible')?.getValue() !== false;

  // Устанавливаем gap для wrapper
  wrapper.style.setProperty('--section-gap', spacing + 'px');

  // Обновляем секции
  updateSections(model, sectionsCount, defaultHeight, collapsible);
}

function updateSections(model, targetCount, defaultHeight, collapsible) {
  const currentSections = model.find('.section-inner');
  const currentCount = currentSections.length;

  if (targetCount > currentCount) {
    addSections(model, targetCount - currentCount, defaultHeight, collapsible);
  } else if (targetCount < currentCount) {
    removeSections(model, currentCount - targetCount);
  }
  
  // Обновляем существующие секции
  currentSections.forEach((section, index) => {
    updateSectionContent(section, defaultHeight, collapsible, index + 1);
  });
}

function addSections(model, count, defaultHeight, collapsible) {
  for (let i = 0; i < count; i++) {
    sectionCounter++;
    const sectionId = 'section-' + sectionCounter;
    const sectionNumber = model.find('.section-inner').length + 1;
    
    const newSection = model.append({
      tagName: 'section',
      attributes: { 
        class: 'section-inner',
        'data-section-id': sectionId
      },
      components: [
        {
          tagName: 'div',
          attributes: {
            class: 'section-header',
            'data-section-id': sectionId
          },
          content: \`
            <span class="section-title">Section \${sectionNumber}</span>
            <span class="section-toggle">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7 10L12 15L17 10" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </span>
          \`,
          droppable: false,
          selectable: true,
          draggable: false,
          editable: false
        },
        {
          tagName: 'div',
          attributes: {
            class: 'section-content',
            'data-section-id': sectionId
          },
          draggable: false,
          droppable: true,
          editable: true,
          selectable: true,
          resizable: {
            tl: false,
            tr: false,
            cl: false,
            cr: false,
            bl: false,
            br: false,
            tc: false,
            bc: true,
            minDim: 50,
            maxDim: 800,
            updateTarget: (el, rect) => {
              const height = rect.height || rect.h;
              console.log('Resizing section content to height:', height + 'px');

              el.style.height = height + 'px';
              el.style.minHeight = '50px';

              const component = model
                .find('*')
                .find((item) => item.getEl && item.getEl() === el);

              if (component) {
                const styles = {
                  height: height + 'px',
                  'min-height': '50px'
                };

                component.setStyle(styles);
                component.trigger('change:style');

                // Сохраняем кастомную высоту
                component.addAttributes({
                  'data-custom-height': height + 'px'
                });
              }
            }
          }
        }
      ],
      draggable: false,
      droppable: false,
      editable: false,
      selectable: true
    });
    
    // Настраиваем новую секцию
    setTimeout(() => {
      setupSectionBehavior(newSection, sectionId, collapsible);
      updateSectionHeight(newSection, defaultHeight, false);
    }, 50);
  }
}

function removeSections(model, count) {
  const sections = model.find('.section-inner');
  const toRemove = sections.slice(-count);
  toRemove.forEach(section => section.remove());
}

function updateSectionContent(section, defaultHeight, collapsible, sectionNumber) {
  const header = section.find('.section-header')[0];
  const content = section.find('.section-content')[0];
  
  if (header && content) {
    // Обновляем заголовок если нужно
    const titleEl = header.getEl()?.querySelector('.section-title');
    if (titleEl && !titleEl.textContent.includes('Section')) {
      titleEl.textContent = \`Section \${sectionNumber}\`;
    }
    
    // Настраиваем поведение
    setupSectionBehavior(section, section.getAttributes()['data-section-id'], collapsible);
    
    // Обновляем высоту если нет кастомной
    const customHeight = content.getAttributes()['data-custom-height'];
    if (!customHeight) {
      updateSectionHeight(section, defaultHeight, false);
    }
  }
}

function setupSectionBehavior(section, sectionId, collapsible) {
  const header = section.find('.section-header')[0];
  const content = section.find('.section-content')[0];
  
  if (!header || !content) return;

  const headerEl = header.getEl();
  const contentEl = content.getEl();
  const toggleEl = headerEl?.querySelector('.section-toggle');
  
  if (!headerEl || !contentEl || !toggleEl) return;

  // Удаляем старые обработчики
  if (headerEl._clickHandler) {
    headerEl.removeEventListener('click', headerEl._clickHandler);
  }

  if (collapsible) {
    // Показываем toggle и добавляем обработчик
    toggleEl.style.display = 'flex';
    
    headerEl._clickHandler = (e) => {
      e.stopPropagation();
      const isCollapsed = contentEl.classList.contains('collapsed');
      
      contentEl.classList.toggle('collapsed', !isCollapsed);
      toggleEl.classList.toggle('collapsed', !isCollapsed);
      
      console.log(\`Section \${sectionId} \${!isCollapsed ? 'collapsed' : 'expanded'}\`);
    };
    
    headerEl.addEventListener('click', headerEl._clickHandler);
    headerEl.style.cursor = 'pointer';
  } else {
    // Скрываем toggle и убираем обработчик
    toggleEl.style.display = 'none';
    headerEl.style.cursor = 'default';
    contentEl.classList.remove('collapsed');
    toggleEl.classList.remove('collapsed');
  }
}

function updateSectionHeight(section, height, forceSave = true) {
  const content = section.find('.section-content')[0];
  if (!content) return;

  const contentEl = content.getEl();
  if (!contentEl) return;

  const styles = {
    'height': height + 'px',
    'min-height': '50px'
  };

  // Применяем к DOM
  Object.entries(styles).forEach(([prop, value]) => {
    contentEl.style[prop] = value;
  });

  // Сохраняем в модель только если forceSave = true
  if (forceSave) {
    content.setStyle(styles);
  }
}

// Функция для принудительного сохранения высоты при ресайзе
function forceSaveSectionHeight(section) {
  const content = section.find('.section-content')[0];
  if (!content) return;

  const contentEl = content.getEl();
  if (!contentEl) return;

  const computedStyle = window.getComputedStyle(contentEl);
  const height = computedStyle.height;

  if (height) {
    const styles = {
      'height': height,
      'min-height': '50px'
    };

    // Сохраняем в модель
    content.setStyle(styles);
    
    // Сохраняем в атрибуты для надежности
    content.addAttributes({
      'data-custom-height': height
    });

    console.log('Force saved section height:', height);
  }
}

// Инициализация
if (model && model.getEl()) {
  // Устанавливаем начальное значение счетчика
  sectionCounter = model.find('.section-inner').length;
  updateSection(model);
}

// Слушатели изменений трейтов
const traitsToWatch = ['sections-count', 'spacing', 'default-height', 'collapsible'];

traitsToWatch.forEach(traitName => {
  const trait = model.getTrait(traitName);
  if (trait) {
    trait.on('change', () => {
      console.log('Section trait changed:', traitName, trait.getValue());
      setTimeout(() => updateSection(model), 10);
    });
  }
});

// Слушатель для начала ресайза
model.on('component:resize:start', (resizedComponent) => {
  isResizing = true;
  console.log('Section resize started');
});

// Слушатель для завершения ресайза
model.on('component:resize:end', (resizedComponent) => {
  isResizing = false;
  
  if (resizedComponent && resizedComponent.getEl && resizedComponent.getEl().classList.contains('section-content')) {
    console.log('Section resize ended, forcing save...');
    const section = resizedComponent.parent();
    if (section) {
      setTimeout(() => {
        forceSaveSectionHeight(section);
      }, 100);
    }
  }
});

// Слушатель для любых изменений в секциях
model.on('component:update', (updatedComponent) => {
  if (isResizing) return;
  
  if (updatedComponent && updatedComponent.getEl && updatedComponent.getEl().classList.contains('section-content')) {
    console.log('Section content updated, checking styles...');
    const section = updatedComponent.parent();
    if (section) {
      setTimeout(() => {
        forceSaveSectionHeight(section);
      }, 50);
    }
  }
});

// Слушатель изменения самого компонента section
model.on('change:attributes', () => {
  if (isResizing) return;
  setTimeout(() => updateSection(model), 10);
});
`,
  styleConfig: {
    sectors: [
      {
        id: 'section-styles',
        name: 'Section Styles',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            units: ['px', 'rem', 'vw', 'auto'],
            default: '100%'
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            units: ['px', 'rem', 'vw', 'auto'],
            default: '100%'
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            units: ['px', 'rem', 'vh', 'auto'],
            default: 'auto'
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            units: ['px', 'rem', 'vh', 'auto'],
            default: 'auto'
          },
          {
            id: 'padding',
            name: 'Padding',
            property: 'padding',
            type: 'number',
            units: ['px', 'rem'],
            default: 16
          },
          {
            id: 'background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: '#3D3AB899',
            selector: '.section-content'
          },
          {
            id: 'header-bg-color',
            name: 'Header Background',
            property: 'background-color',
            type: 'color',
            default: '#3D3AB8',
            selector: '.section-header'
          },
          {
            id: 'border-color',
            name: 'Border Color',
            property: 'border-color',
            type: 'color',
            default: '#3D3AB8',
            selector: '.section-inner'
          },
          {
            id: 'border-width',
            name: 'Border Width',
            property: 'border-width',
            type: 'number',
            units: ['px'],
            default: 1,
            selector: '.section-inner'
          },
          {
            id: 'border-radius',
            name: 'Border Radius',
            property: 'border-radius',
            type: 'number',
            units: ['px', 'rem'],
            default: 6,
            selector: '.section-inner'
          }
        ]
      }
    ]
  }
};
