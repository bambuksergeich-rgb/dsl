import { ComponentConfig } from '../elements';

export const Drawer: ComponentConfig = {
  id: 'drawer',
  type: 'drawer',
  label: 'Drawer',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: { class: 'drawer-wrapper' },
    components: [
      {
        tagName: 'h2',
        attributes: { class: 'drawer-header' },
        content: 'Drawer Header',
        droppable: false,
        draggable: false,
        selectable: true
      },
      {
        tagName: 'div',
        attributes: { class: 'drawer-container' },
        components: [
          {
            tagName: 'div',
            attributes: { class: 'drawer-nav vertical' },
            components: [
              {
                tagName: 'button',
                attributes: { class: 'burger-menu' },
                content: `<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_132_21324)">
                    <path d="M5 22.5H18.75C19.4375 22.5 20 21.9375 20 21.25C20 20.5625 19.4375 20 18.75 20H5C4.3125 20 3.75 20.5625 3.75 21.25C3.75 21.9375 4.3125 22.5 5 22.5ZM5 16.25H15C15.6875 16.25 16.25 15.6875 16.25 15C16.25 14.3125 15.6875 13.75 15 13.75H5C4.3125 13.75 3.75 14.3125 3.75 15C3.75 15.6875 4.3125 16.25 5 16.25ZM3.75 8.75C3.75 9.4375 4.3125 10 5 10H18.75C19.4375 10 20 9.4375 20 8.75C20 8.0625 19.4375 7.5 18.75 7.5H5C4.3125 7.5 3.75 8.0625 3.75 8.75ZM25.375 18.6L21.775 15L25.375 11.4C25.8625 10.9125 25.8625 10.125 25.375 9.6375C24.8875 9.15 24.1 9.15 23.6125 9.6375L19.125 14.125C18.6375 14.6125 18.6375 15.4 19.125 15.8875L23.6125 20.375C24.1 20.8625 24.8875 20.8625 25.375 20.375C25.85 19.8875 25.8625 19.0875 25.375 18.6Z" fill="white"/>
                  </g>
                  <defs>
                    <clipPath id="clip0_132_21324">
                      <rect width="30" height="30" fill="white"/>
                    </clipPath>
                  </defs>
                </svg>`,
                droppable: false,
                draggable: false
              }
            ],
            droppable: true,
            draggable: false,
            selectable: false
          },
          {
            tagName: 'div',
            attributes: { class: 'drawer-content' },
            components: [],
            droppable: true,
            draggable: false,
            selectable: true
          }
        ],
        droppable: false,
        draggable: false,
        selectable: false
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M3 3H21C21.2652 3 21.5196 3.10536 21.7071 3.29289C21.8946 3.48043 22 3.73478 22 4V20C22 20.2652 21.8946 20.5196 21.7071 20.7071C21.5196 20.8946 21.2652 21 21 21H3C2.73478 21 2.48043 20.8946 2.29289 20.7071C2.10536 20.5196 2 20.2652 2 20V4C2 3.73478 2.10536 3.48043 2.29289 3.29289C2.48043 3.10536 2.73478 3 3 3ZM9 5V19H20V5H9Z" fill="white"/>
  </svg>
  `,
  traits: [
    {
      id: 'headerText',
      name: 'headerText',
      type: 'text',
      label: 'Header Text',
      changeProp: true,
      value: 'Drawer Header'
    },
    {
      id: 'isNavOpen',
      name: 'isNavOpen',
      type: 'checkbox',
      label: 'Navigation Open',
      changeProp: true,
      value: true
    },
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'Burger Icon',
      type: 'select-icon',
      changeProp: true,
      value:
        'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjMiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAyMyAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMiAxNS41SDE1Ljc1QzE2LjQzNzUgMTUuNSAxNyAxNC45Mzc1IDE3IDE0LjI1QzE3IDEzLjU2MjUgMTYuNDM3NSAxMyAxNS43NSAxM0gyQzEuMzEyNSAxMyAwLjc1IDEzLjU2MjUgMC43NSAxNC4yNUMwLjc1IDE0LjkzNzUgMS4zMTI1IDE1LjUgMiAxNS41Wk0yIDkuMjVIMTJDMTIuNjg3NSA5LjI1IDEzLjI1IDguNjg3NSAxMy4yNSA4QzEzLjI1IDcuMzEyNSAxMi42ODc1IDYuNzUgMTIgNi43NUgyQzEuMzEyNSA2Ljc1IDAuNzUgNy4zMTI1IDAuNzUgOEMwLjc1IDguNjg3NSAxLjMxMjUgOS4yNSAyIDkuMjVaTTAuNzUgMS43NUMwLjc1IDIuNDM3NSAxLjMxMjUgMyAyIDNIMTUuNzVDMTYuNDM3NSAzIDE3IDIuNDM3NSAxNyAxLjc1QzE3IDEuMDYyNSAxNi40Mzc1IDAuNSAxNS43NSAwLjVIMkMxLjMxMjUgMC41IDAuNzUgMS4wNjI1IDAuNzUgMS43NVpNMjIuMzc1IDExLjZMMTguNzc1IDhMMjIuMzc1IDQuNEMyMi44NjI1IDMuOTEyNSAyMi44NjI1IDMuMTI1IDIyLjM3NSAyLjYzNzVDMjEuODg3NSAyLjE1IDIxLjEgMi4xNSAyMC42MTI1IDIuNjM3NUwxNi4xMjUgNy4xMjVDMTUuNjM3NSA3LjYxMjUgMTUuNjM3NSA4LjQgMTYuMTI1IDguODg3NUwyMC42MTI1IDEzLjM3NUMyMS4xIDEzLjg2MjUgMjEuODg3NSAxMy44NjI1IDIyLjM3NSAxMy4zNzVDMjIuODUgMTIuODg3NSAyMi44NjI1IDEyLjA4NzUgMjIuMzc1IDExLjZaIiBmaWxsPSJ3aGl0ZSIvPiA8L3N2Zz4='
    }
  ],
  styleConfig: {
    sectors: [
      {
        id: 'Drawer Dimension',
        name: 'Drawer Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '758',
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: '800',
            units: ['px', '%']
          }
        ]
      },
      {
        id: 'Header Text',
        name: 'Header Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: '24',
            units: ['px']
          },
          {
            id: 'color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  },
  styles: `
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap');

    .drawer-wrapper {
      min-width: 758px;
      min-height: 800px;
      width: var(--width, 758px);
      height: var(--height, 800px);
      padding: 16px 0px;
      background-color: var(--bg-color, #10161C80);
      border: 2px solid var(--border-color, #3D3AB8);
      border-radius: 12px;
      display: flex;
      flex-direction: column;
      gap: 0px;
      font-family: 'Montserrat', sans-serif;
      position: relative;
    }
    .drawer-header {
      margin: 0 0 16px 0;
      font-size: var(--font-size, 24px);
      color: var(--color, #FFFFFF);
      font-weight: 500;
      font-family: 'Montserrat', sans-serif;
      text-align: left;
      padding-left: 16px;
    }
    .drawer-container {
      display: flex;
      flex-direction: row;
      gap: 12px;
      flex: 1;
    }
    .drawer-nav {
      display: flex;
      flex-direction: column;
      gap: 8px;
      min-width: 220px;
      max-height: auto;
      overflow-y: auto;
      scrollbar-width: none;
      background-color: transparent;
      position: relative;
      align-items: flex-start;
      transition: transform 0.3s ease, opacity 0.3s ease, width 0.3s ease, min-width 0.3s ease;
    }
    .drawer-nav.collapsed {
      transform: translateX(-100%);
      opacity: 0;
      width: 0;
      min-width: 0;
      overflow: hidden;
      position: relative; /* Добавляем, чтобы позиционирование кнопки работало */
    }
    .drawer-nav::-webkit-scrollbar {
      display: none;
    }
    .burger-menu {
      width: 40px;
      height: 40px;
      padding: 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      background: transparent;
      position: absolute;
      top: 16px;
      right: 16px;
      z-index: 10;
    }
    .drawer-nav.collapsed .burger-menu {
      position: absolute; /* Используем absolute вместо sticky */
      right: -48px; /* Сдвигаем кнопку за пределы скрытого контейнера */
      top: 16px;
      opacity: 1; /* Обеспечиваем видимость кнопки */
      width: 40px;
      height: 40px;
      z-index: 10; /* Убедимся, что кнопка поверх других элементов */
    }
    .burger-menu img, .burger-menu svg {
      width: 30px;
      height: 30px;
    }
    .drawer-content {
      background-color: var(--bg-color, #10161C80);
      padding: 12px;
      border-radius: 4px;
      flex: 1;
      min-height: 400px;
    }
    // @media (max-width: 768px) {
    //   .drawer-wrapper {
    //     min-width: 100%;
    //     width: 100%;
    //     max-width: none;
    //   }
    //   .drawer-container {
    //     flex-direction: column;
    //   }
    //   .drawer-nav {
    //     flex-direction: column;
    //     min-width: 0;
    //     max-height: none;
    //     overflow-x: auto;
    //     overflow-y: visible;
    //     margin-bottom: 12px;
    //     transform: translateX(-100%);
    //     opacity: 0;
    //     width: 0;
    //     min-width: 0;
    //     overflow: hidden;
    //   }
    //   .drawer-nav:not(.collapsed) {
    //     transform: translateX(0);
    //     opacity: 1;
    //     width: auto;
    //     min-width: 120px;
    //   }
    //   .burger-menu {
    //     position: absolute;
    //     top: 16px;
    //     left: 16px;
    //     float: none;
    //   }
    //   .drawer-nav:not(.collapsed) .burger-menu {
    //     left: auto;
    //     right: 16px;
    //   }
    }
  `,
  script: `
// Функция debounce для ограничения частоты вызовов
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function updateDrawer(model) {
  if (!model || !model.getEl()) {
    console.error('No model or wrapper element');
    return;
  }
  const wrapper = model.getEl();
  const traits = model.getTraits();
  try {
    const headerEl = wrapper.querySelector('.drawer-header');
    const navEl = wrapper.querySelector('.drawer-nav');
    const contentEl = wrapper.querySelector('.drawer-content');
    const burgerEl = wrapper.querySelector('.burger-menu');
    if (headerEl && navEl && contentEl && burgerEl) {
      const headerTextTrait = traits.find(t => t.getName() === 'headerText');
      const isNavOpenTrait = traits.find(t => t.getName() === 'isNavOpen');
      const selectImageTrait = traits.find(t => t.getName() === 'selectImage');

      // Обновляем текст заголовка
      headerEl.textContent = headerTextTrait?.getValue() || 'Drawer Header';

      // Обновляем иконку burger-menu
      const selectImage = selectImageTrait?.getValue() || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjMiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAyMyAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMiAxNS41SDE1Ljc1QzE2LjQzNzUgMTUuNSAxNyAxNC45Mzc1IDE3IDE0LjI1QzE3IDEzLjU2MjUgMTYuNDM3NSAxMyAxNS43NSAxM0gyQzEuMzEyNSAxMyAwLjc1IDEzLjU2MjUgMC43NSAxNC4yNUMwLjc1IDE0LjkzNzUgMS4zMTI1IDE1LjUgMiAxNS41Wk0yIDkuMjVIMTJDMTIuNjg3NSA5LjI1IDEzLjI1IDguNjg3NSAxMy4yNSA4QzEzLjI1IDcuMzEyNSAxMi42ODc1IDYuNzUgMTIgNi43NUgyQzEuMzEyNSA2Ljc1IDAuNzUgNy4zMTI1IDAuNzUgOEMwLjc1IDguNjg3NSAxLjMxMjUgOS4yNSAyIDkuMjVaTDAuNzUgMS43NUMwLjc1IDIuNDM3NSAxLjMxMjUgMyAyIDNIMTUuNzVDMTYuNDM3NSAzIDE3IDIuNDM3NSAxNyAxLjc1QzE3IDEuMDYyNSAxNi40Mzc1IDAuNSAxNS43NSAwLjVIMkMxLjMxMjUgMC41IDAuNzUgMS4wNjI1IDAuNzUgMS43NVpNMjIuMzc1IDExLjZMMTguNzc1IDhMMjIuMzc1IDQuNEMyMi44NjI1IDMuOTEyNSAyMi44NjI1IDMuMTI1IDIyLjM3NSAyLjYzNzVDMjEuODg3NSAyLjE1IDIxLjEgMi4xNSAyMC42MTI1IDIuNjM3NUwxNi4xMjUgNy4xMjVDMTUuNjM3NSA3LjYxMjUgMTUuNjM3NSA4LjQgMTYuMTI1IDguODg3NUwyMC42MTI1IDEzLjM3NUMyMS4xIDEzLjg2MjUgMjEuODg3NSAxMy44NjI1IDIyLjM3NSAxMy4zNzVDMjIuODUgMTIuODg3NSAyMi44NjI1IDEyLjA4NzUgMjIuMzc1IDExLjZaIiBmaWxsPSJ3aGl0ZSIvPiA8L3N2Zz4=';
      if (selectImage && typeof selectImage === 'string' && selectImage.startsWith('data:image')) {
        burgerEl.innerHTML = \`<img src="\${selectImage}" class="burger-icon" style="width: 30px; height: 30px;">\`;
      } else {
        console.error('Invalid burger icon source:', selectImage);
      }

      // Обновляем состояние навигации
      const isNavOpen = isNavOpenTrait?.getValue() !== false && isNavOpenTrait?.getValue() !== 'false';
      navEl.classList.toggle('collapsed', !isNavOpen);

      // Устанавливаем стили из styleConfig
      const styles = model.getStyle() || {};
      wrapper.style.setProperty('--width', styles.width || '758px');
      wrapper.style.setProperty('--height', styles.height || '800px');
      wrapper.style.setProperty('--bg-color', '#10161C80');
      wrapper.style.setProperty('--border-color', '#3D3AB8');
      headerEl.style.setProperty('--font-size', styles['font-size'] ? \`\${styles['font-size']}px\` : '24px');
      headerEl.style.setProperty('--color', styles.color || '#FFFFFF');

      // Удаляем старый обработчик клика
      if (burgerEl._clickHandler) {
        burgerEl.removeEventListener('click', burgerEl._clickHandler);
      }
      burgerEl._clickHandler = () => {
        console.log('handleBurgerClick triggered');
        const newNavState = !isNavOpenTrait.getValue();
        isNavOpenTrait.setValue(newNavState, { notify: false }); // Отключаем уведомление о событии
        navEl.classList.toggle('collapsed', !newNavState);
      };
      burgerEl.addEventListener('click', burgerEl._clickHandler);
    } else {
      console.error('Missing drawer elements');
    }
  } catch (e) {
    console.error('Error updating drawer:', e);
  }
}

// Дебансированная версия updateDrawer
const debouncedUpdateDrawer = debounce(updateDrawer, 100);

// Проверяем, что model доступен
if (model && model.getEl()) {
  console.log('Initializing drawer');
  updateDrawer(model);
} else {
  console.error('Model not available in script context');
}

// Обработка изменений модели
model.on('change', () => {
  console.log('Model changed:', model.changed);
  debouncedUpdateDrawer(model);
});
model.on('change:style', () => {
  console.log('Style changed');
  debouncedUpdateDrawer(model);
});
model.on('load', () => {
  console.log('Model loaded');
  updateDrawer(model);
});
`
};
