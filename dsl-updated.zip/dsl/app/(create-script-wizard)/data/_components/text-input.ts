import { ComponentConfig } from '../elements';

export const TextInput: ComponentConfig = {
  id: 'text-input',
  type: 'text-input',
  label: 'Text Input',
  category: 'Main',
  content: {
    tagName: 'div',
    attributes: {
      class: 'text-input-container',
      name: 'Text Input',
      data_type: 'String',
      data: ''
    },
    components: [
      {
        tagName: 'input',
        attributes: {
          type: 'text',
          class: 'text-input',
          placeholder: 'Enter text'
        },
        draggable: false
      },
      {
        tagName: 'button',
        attributes: {
          type: 'button',
          class: 'text-input-toggle'
        },
        draggable: false,
        selectable: false,
        components: [
          {
            tagName: 'img',
            draggable: false,
            selectable: false,
            attributes: {
              class: 'text-input-icon',
              src: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04IDNDOCAyLjQ0NzcyIDguNDQ3NzIgMiA5IDIgSDE1QzE1LjU1MjMgMiAxNiAyLjQ0NzcyIDE2IDNDMTYgMy41NTIyOSAxNS41NTIzIDQgMTUgNEgxM1YyMEgxNUMxNS41NTIzIDIwIDE2IDIwLjQ0NzcgMTYgMjFDMTYgMjEuNTUyMyAxNS41NTIzIDIyIDE1IDIySDlDOC40NDc3MiAyMiA4IDIxLjU1MjMgOCAyMUM4IDIwLjQ0NzcgOC40NDc3MiAyMCA5IDIwSDExVjRIOC40NDc3MiA0IDggMy41NTIyOCA4IDNaTTcuNzg4IDZIOC4wNTUyOSAxMCA5IDcuNDQ3NzIgOSAxN0M5IDcuNTUyMjggOC41NTIyOSA4IDggOEg3LjgzQzYuOTU4OTggOC4wMDExIDYuMzY2ODYgOC4wMDEyIDUuOTA5NDUgOC4wMzg3OUM1LjQ2NDAxIDguMDc1NzggNS4yMzY2MyA4LjE0MjggNS4wNzgwNSA4LjIyNTE3QzQuNzEyNzcgOC40MTQ5MiA0LjQxNDkzIDguNzEyNzYgNC4yMjUxNyA5LjA3ODA1QzQuMTQyOCAxMC4yMzY2MyA0LjA3NTc4IDkuNDY0MDEgNC4wMzg3OSA5LjkwOTQ1QzQuMDAxMiAxMC4zNjY5IDQgMTAuOTU5IDQgMTEuODNWMTIuMTdDNC4wMDExIDEzLjA0MSAxMC4wMDExIDEzLjYzMzEgNC4wMzg3OSAxNC4wOTA1QzQuMDc1NzggMTQuNTM2IDQuMTQyOCAxNC43NjM0IDQuMjI1MTcgMTQuOTIxOUM0LjQxNDkzIDE1LjI4NzIgNC43MTI3NyAxNS41ODUxIDUuMDc4MDUgMTUuNzc0OEM1LjIzNjYzIDE1Ljg1NzIgNS40NjQwMiAxNS45MjQyIDUuOTA5NDUgMTUuOTYxMkM2LjM2Njg2IDE1Ljk5OTIgNi45NTg5OCAxNiA3LjgzIDE2SDhDOC41NTIyOSAxNiA5IDE2LjQ0NzcgOSAxN0M5IDE3LjU1MjMgOC41NTIyOSAxOCA4IDE4SDcuNzg3OThDNi45Njk0NiAxOCA2LjI5MzkzIDE4IDUuNzQzOTMgMTcuOTU0M0M1LjE3MjU4IDE3LjkwNjkgNC42NDc3NCAxNy44MDUgNC4xNTYxIDE3LjU0OTdDMi41NTUzIDE3LjE3MDIgMi44Mjk4NSAxNi41NzQ1IDIuNDUwMzUgMTUuODQzOUMyLjE5NDk2IDE1LjM1MjMgMi4wOTMxIDE0LjgyNzQgMi4wNDU2NSAxNC4yNTYxQzEuOTk5OTggMTMuNzA2MSAxLjk5OTk5IDEzLjAzMDUgMiAxMi4yMTJWMTUuNzg4QzEuOTk5OTkgMTAuOTY5NSAxLjk5OTk4IDEwLjI5MzkgMi4wNDU2NSA5Ljc0MzkzQzIuMDkzMSA5LjE3MjU4IDIuMTk0OTYgOC42NDc3NCAyLjQ1MDM1IDguMTU2MUMyLjgyOTg1IDcuNDI1NTMgMy40MjU1MyA2LjgyOTg1IDQuMTU2MSA2LjQ1MDM1QzQuNjQ3NzQgNi4xOTQ5NiA1LjE3MjU4IDYuMDkzMSA1Ljc0MzkzIDYuMDQ1NjVDNi4yOTM5MyA1Ljk5OTk4IDYuOTY5NDcgNS45OTk5OSA3Ljc4OCA2Wk0xOC4wOTA1IDguMDM4NzlDMTcuNjMzMSA4LjAwMTIgMTcuMDQxIDggMTYuMTcgOEgxNkMxNS40NDc3IDggMTUgNy41NTIyOCAxNSA3QzE1IDYuNDQ3NzIgMTUuNDQ3NyA2IDE2IDZIMTYuMjEyQzE3LjAzMDUgNS45OTk5OSAxNy43MDYxIDUuOTk5OTggMTguMjU2MSA2LjA0NTY1QzE4LjgyNzQgNi4wOTMxIDE5LjM1MjMgNi4xOTQ5NiAxOS44NDM5IDYuNDUwMzVDMjAuNTc0NSA2LjgyOTg1IDIxLjE3MDIgNy40MjU1MyAyMS41NDk3IDguMTU2MUMyMS44MDUgOC42NDc3NCAyMS45MDY5IDkuMTcyNTggMjEuOTU0MyA5Ljc0MzkzQzIyIDEwLjI5MzkgMjIgMTAuOTY5NSAyMiAxMS43ODhWMTIuMjEyQzIyIDEzLjAzMDUgMjIgMTMuNzA2MSAyMS45NTQzIDE0LjI1NjFDMjEuOTA2OSAxNC44Mjc0IDIxLjgwNSAxNS4zNTIzIDIxLjU0OTcgMTUuODQzOUMyMS4xNzAyIDE2LjU3NDUgMjAuNTc0NSAxNy4xNzAyIDE5Ljg0MzkgMTcuNTQ5N0MxOS4zNTIzIDE3LjgwNSAxOC44Mjc0IDE3LjkwNjkgMTguMjU2MSAxNy45NTQzQzE3LjcwNjEgMTggMTcuMDMwNSAxOCAxNi4yMTIgMThIMTZDMTUuNDQ3NyAxOCAxNSAxNy41NTIzIDE1IDE3QzE1IDE2LjQ0NzcgMTUuNDQ3NyAxNiAxNiAxNkgxNi4xN0MxNy4wNDEgMTYgMTcuNjMzMSAxNS45OTkyIDE4LjA5MDUgMTUuOTYxMkMxOC41MzYgMTUuOTI0MiAxOC43NjM0IDE1Ljg1NzIgMTguOTIxOSAxNS43NzQ4QzE5LjI4NzIgMTUuNTg1MSAxOS41ODUxIDE1LjI4NzIgMTkuNzc0OCAxNC45MjE5QzE5Ljg1NzIgMTQuNzYzNCAxOS45MjQyIDE0LjUzNiAxOS45NjEyIDE0LjA5MDVDMTkuOTk5MiAxMy42MzMxIDIwIDEzLjA0MSAyMCAxMi4xN1YxMS44M0MyMCAxMC45NTkgMTkuOTk5MiAxMC4zNjY5IDE5Ljk2MTIgOS45MDk0NUMxOS45MjQyIDkuNDY0MDEgMTkuODU3MiA5LjIzNjYzIDE5Ljc3NDggOS4wNzgwNUMxOS41ODUxIDguNzEyNzcgMTkuMjg3MiA4LjQxNDkyIDE4LjkyMTkgOC4yMjUxN0MxOC43NjM0IDguMTQyOCAxOC41MzYgOC4wNzU3OCAxOC4wOTA1IDguMDM4Nzl6IiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4='
            }
          }
        ]
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M8 3C8 2.44772 8.44772 2 9 2H15C15.5523 2 16 2.44772 16 3C16 3.55229 15.5523 4 15 4H13V20H15C15.5523 20 16 20.4477 16 21C16 21.5523 15.5523 22 15 22H9C8.44772 22 8 21.5523 8 21C8 20.4477 8.44772 20 9 20H11V4H9C8.44772 4 8 3.55228 8 3ZM7.788 6H8C8.55229 6 9 6.44772 9 7C9 7.55228 8.55229 8 8 8H7.83C6.95898 8 6.36686 8.0008 5.90945 8.03879C5.46401 8.07578 5.23663 8.1428 5.07805 8.22517C4.71277 8.41492 4.41493 8.71276 4.22517 9.07805C4.1428 9.23663 4.07578 9.46401 4.03879 9.90945C4.0008 10.3669 4 10.959 4 11.83V12.17C4 13.041 4.0008 13.6331 4.03879 14.0905C4.07578 14.536 4.1428 14.7634 4.22517 14.9219C4.41493 15.2872 4.71277 15.5851 5.07805 15.7748C5.23663 15.8572 5.46402 15.9242 5.90945 15.9612C6.36686 15.9992 6.95898 16 7.83 16H8C8.55229 16 9 16.4477 9 17C9 17.5523 8.55229 18 8 18H7.78798C6.96946 18 6.29393 18 5.74393 17.9543C5.17258 17.9069 4.64774 17.805 4.1561 17.5497C3.42553 17.1702 2.82985 16.5745 2.45035 15.8439C2.19496 15.3523 2.0931 14.8274 2.04565 14.2561C1.99998 13.7061 1.99999 13.0305 2 12.212V11.788C1.99999 10.9695 1.99998 10.2939 2.04565 9.74393C2.0931 9.17258 2.19496 8.64774 2.45035 8.1561C2.82985 7.42553 3.42553 6.82985 4.1561 6.45035C4.64774 6.19496 5.17258 6.0931 5.74393 6.04565C6.29393 5.99998 6.96947 5.99999 7.788 6ZM18.0905 8.03879C17.6331 8.0008 17.041 8 16.17 8H16C15.4477 8 15 7.55228 15 7C15 6.44772 15.4477 6 16 6H16.212C17.0305 5.99999 17.7061 5.99998 18.2561 6.04565C18.8274 6.0931 19.3523 6.19496 19.8439 6.45035C20.5745 6.82985 21.1702 7.42553 21.5497 8.1561C21.805 8.64774 21.9069 9.17258 21.9543 9.74393C22 10.2939 22 10.9695 22 11.788V12.212C22 13.0305 22 13.7061 21.9543 14.2561C21.9069 14.8274 21.805 15.3523 21.5497 15.8439C21.1702 16.5745 20.5745 17.1702 19.8439 17.5497C19.3523 17.805 18.8274 17.9069 18.2561 17.9543C17.7061 18 17.0305 18 16.212 18H16C15.4477 18 15 17.5523 15 17C15 16.4477 15.4477 16 16 16H16.17C17.041 16 17.6331 15.9992 18.0905 15.9612C18.536 15.9242 18.7634 15.8572 18.9219 15.7748C19.2872 15.5851 19.5851 15.2872 19.7748 14.9219C19.8572 14.7634 19.9242 14.536 19.9612 14.0905C19.9992 13.6331 20 13.041 20 12.17V11.83C20 10.959 19.9992 10.3669 19.9612 9.90945C19.9242 9.46401 19.8572 9.23663 19.7748 9.07805C19.5851 8.71277 19.2872 8.41492 18.9219 8.22517C18.7634 8.1428 18.536 8.07578 18.0905 8.03879Z" fill="white"/>
      </svg>
      `,
  traits: [
    // {
    //   id: 'showIcon',
    //   name: 'showIcon',
    //   label: 'Show Icon',
    //   type: 'checkbox',
    //   changeProp: true,
    //   value: true
    // },
    {
      id: 'type',
      name: 'inputType', // Имя свойства модели, которое хранит тип
      label: 'Type',
      type: 'select',
      changeProp: true,
      options: [
        { id: 'text', name: 'Text', value: 'text' },
        { id: 'textarea', name: 'Textarea', value: 'textarea' }
      ],
      value: 'text'
    },
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'Select Icon',
      type: 'select-icon',
      changeProp: true,
      value:
        'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04IDNDOCAyLjQ0NzcyIDguNDQ3NzIgMiA5IDIgSDE1QzE1LjU1MjMgMiAxNiAyLjQ0NzcyIDE2IDNDMTYgMy41NTIyOSAxNS41NTIzIDQgMTUgNEgxM1YyMEgxNUMxNS41NTIzIDIwIDE2IDIwLjQ0NzcgMTYgMjFDMTYgMjEuNTUyMyAxNS41NTIzIDIyIDE1IDIySDlDOC40NDc3MiAyMiA4IDIxLjU1MjMgOCAyMUM4IDIwLjQ0NzcgOC40NDc3MiAyMCA5IDIwSDExVjRIOC40NDc3MiA0IDggMy41NTIyOCA4IDNaTTcuNzg4IDZIOC4wNTUyOSAxMCA5IDcuNDQ3NzIgOSAxN0M5IDcuNTUyMjggOC41NTIyOSA4IDggOEg3LjgzQzYuOTU4OTggOC4wMDExIDYuMzY2ODYgOC4wMDEyIDUuOTA5NDUgOC4wMzg3OUM1LjQ2NDAxIDguMDc1NzggNS4yMzY2MyA4LjE0MjggNS4wNzgwNSA4LjIyNTE3QzQuNzEyNzcgOC40MTQ5MiA0LjQxNDkzIDguNzEyNzYgNC4yMjUxNyA5LjA3ODA1QzQuMTQyOCAxMC4yMzY2MyA0LjA3NTc4IDkuNDY0MDEgNC4wMzg3OSA5LjkwOTQ1QzQuMDAxMiAxMC4zNjY5IDQgMTAuOTU5IDQgMTEuODNWMTIuMTdDNC4wMDExIDEzLjA0MSAxMC4wMDExIDEzLjYzMzEgNC4wMzg3OSAxNC4wOTA1QzQuMDc1NzggMTQuNTM2IDQuMTQyOCAxNC43NjM0IDQuMjI1MTcgMTQuOTIxOUM0LjQxNDkzIDE1LjI4NzIgNC43MTI3NyAxNS41ODUxIDUuMDc4MDUgMTUuNzc0OEM1LjIzNjYzIDE1Ljg1NzIgNS40NjQwMiAxNS45MjQyIDUuOTA5NDUgMTUuOTYxMkM2LjM2Njg2IDE1Ljk5OTIgNi45NTg5OCAxNiA3LjgzIDE2SDhDOC41NTIyOSAxNiA5IDE2LjQ0NzcgOSAxN0M5IDE3LjU1MjMgOC41NTIyOSAxOCA4IDE4SDcuNzg3OThDNi45Njk0NiAxOCA2LjI5MzkzIDE4IDUuNzQzOTMgMTcuOTU0M0M1LjE3MjU4IDE3LjkwNjkgNC42NDc3NCAxNy44MDUgNC4xNTYxIDE3LjU0OTdDMi41NTUzIDE3LjE3MDIgMi44Mjk4NSAxNi41NzQ1IDIuNDUwMzUgMTUuODQzOUMyLjE5NDk2IDE1LjM1MjMgMi4wOTMxIDE0LjgyNzQgMi4wNDU2NSAxNC4yNTYxQzEuOTk5OTggMTMuNzA2MSAxLjk5OTk5IDEzLjAzMDUgMiAxMi4yMTJWMTUuNzg4QzEuOTk5OTkgMTAuOTY5NSAxLjk5OTk4IDEwLjI5MzkgMi4wNDU2NSA5Ljc0MzkzQzIuMDkzMSA5LjE3MjU4IDIuMTk0OTYgOC42NDc3NCAyLjQ1MDM1IDguMTU2MUMyLjgyOTg1IDcuNDI1NTMgMy40MjU1MyA2LjgyOTg1IDQuMTU2MSA2LjQ1MDM1QzQuNjQ3NzQgNi4xOTQ5NiA1LjE3MjU4IDYuMDkzMSA1Ljc0MzkzIDYuMDQ1NjVDNi4yOTM5MyA1Ljk5OTk4IDYuOTY5NDcgNS45OTk5OSA3Ljc4OCA2Wk0xOC4wOTA1IDguMDM4NzlDMTcuNjMzMSA4LjAwMTIgMTcuMDQxIDggMTYuMTcgOEgxNkMxNS40NDc3IDggMTUgNy41NTIyOCAxNSA3QzE1IDYuNDQ3NzIgMTUuNDQ3NyA2IDE2IDZIMTYuMjEyQzE3LjAzMDUgNS45OTk5OSAxNy43MDYxIDUuOTk5OTggMTguMjU2MSA2LjA0NTY1QzE4LjgyNzQgNi4wOTMxIDE5LjM1MjMgNi4xOTQ5NiAxOS44NDM5IDYuNDUwMzVDMjAuNTc0NSA2LjgyOTg1IDIxLjE3MDIgNy40MjU1MyAyMS41NDk3IDguMTU2MUMyMS44MDUgOC42NDc3NCAyMS45MDY5IDkuMTcyNTggMjEuOTU0MyA5Ljc0MzkzQzIyIDEwLjI5MzkgMjIgMTAuOTY5NSAyMiAxMS43ODhWMTIuMjEyQzIyIDEzLjAzMDUgMjIgMTMuNzA2MSAyMS45NTQzIDE0LjI1NjFDMjEuOTA2OSAxNC44Mjc0IDIxLjgwNSAxNS4zNTIzIDIxLjU0OTcgMTUuODQzOUMyMS4xNzAyIDE2LjU3NDUgMjAuNTc0NSAxNy4xNzAyIDE5Ljg0MzkgMTcuNTQ5N0MxOS4zNTIzIDE3LjgwNSAxOC44Mjc0IDE3LjkwNjkgMTguMjU2MSAxNy45NTQzQzE3LjcwNjEgMTggMTcuMDMwNSAxOCAxNi4yMTIgMThIMTZDMTUuNDQ3NyAxOCAxNSAxNy41NTIzIDE1IDE3QzE1IDE2LjQ0NzcgMTUuNDQ3NyAxNiAxNiAxNkgxNi4xN0MxNy4wNDEgMTYgMTcuNjMzMSAxNS45OTkyIDE4LjA5MDUgMTUuOTYxMkMxOC41MzYgMTUuOTI0MiAxOC43NjM0IDE1Ljg1NzIgMTguOTIxOSAxNS43NzQ4QzE5LjI4NzIgMTUuNTg1MSAxOS41ODUxIDE1LjI4NzIgMTkuNzc0OCAxNC45MjE5QzE5Ljg1NzIgMTQuNzYzNCAxOS45MjQyIDE0LjUzNiAxOS45NjEyIDE0LjA5MDVDMTkuOTk5MiAxMy42MzMxIDIwIDEzLjA0MSAyMCAxMi4xN1YxMS44M0MyMCAxMC45NTkgMTkuOTk5MiAxMC4zNjY5IDE5Ljk2MTIgOS45MDk0NUMxOS45MjQyIDkuNDY0MDEgMTkuODU3MiA5LjIzNjYzIDE5Ljc3NDggOS4wNzgwNUMxOS41ODUxIDguNzEyNzcgMTkuMjg3MiA4LjQxNDkyIDE4LjkyMTkgOC4yMjUxN0MxOC43NjM0IDguMTQyOCAxOC41MzYgOC4wNzU3OCAxOC4wOTA1IDguMDM4Nzl6IiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4='
    },
    {
      id: 'placeholder',
      name: 'placeholder',
      label: 'Placeholder',
      type: 'text',
      changeProp: true,
      value: 'Enter text'
    }
  ],
  styles: `
/* Standard single-line control height from the editor design. */
.text-input-container:not(:has(textarea)) .text-input, .text-input-container:not(:has(textarea)) .text-input-toggle { height: 34px !important; min-height: 34px !important; max-height: 34px !important; line-height: 20px !important; }
[data-draft-id].text-input-container:not(:has(textarea)), .text-input-container:not(:has(textarea)) { height: 34px !important; min-height: 34px !important; max-height: 34px !important; }

        /* ... (Ваши стили, как были) ... */
        .text-input-container {
          position: relative;
          display: flex;
          width: fit-content;
          height: auto;
          min-height: 48px;
          overflow: visible;
          --bw: 0px;
          --bc: #3182ce;
          --bg: #FFFFFF1A;
          --color: #FFFFFF;
          --fs: 16px;
        }
.text-input, .text-input-multiline {
    width: var(--input-width, 365px);
    padding: 0 48px 0 16px;
    
    /* ✅ КРИТИЧНО: Используй отдельные свойства как в Password */
    border-style: solid;
    border-top-width: var(--bw, 0px);
    border-right-width: var(--bw, 0px);
    border-bottom-width: var(--bw, 0px);
    border-left-width: var(--bw, 0px);
    
    border-top-color: var(--bc, #3182ce);
    border-right-color: var(--bc, #3182ce);
    border-bottom-color: var(--bc, #3182ce);
    border-left-color: var(--bc, #3182ce);
    
    border-radius: 6px;
    font-size: var(--fs, 16px);
    color: var(--color, #FFFFFF);
    background-color: var(--bg, #FFFFFF1A);
    font-family: 'Montserrat', sans-serif;
    box-sizing: border-box;
    position: relative;
    z-index: 1;
  }
        .text-input { height: var(--input-height, 48px); }
        .text-input-multiline {
          height: 121px;
          min-height: 121px !important;
          padding: 12px 1px 12px 16px;
          resize: vertical;
        }
        .text-input:focus, .text-input-multiline:focus {
          outline: none;
          border-width: var(--bw, 0px);
          border-color: var(--bc, #3182ce);
          box-shadow: 0 0 0 2px rgba(49, 130, 206, 0.2);
        }
        .text-input-toggle {
          position: absolute;
          right: 0;
          top: 0;
          width: 38px;
          height:38px;
          background: none;
          border: none;
          cursor: pointer;
          padding: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 20;
        }
        .text-input-icon { width: 24px; height: 24px; object-fit: contain; pointer-events: none; }
        .text-input-multiline + .text-input-toggle { top: auto; bottom: 0; }
        .text-input-toggle:hover { opacity: 0.8; }
      `,
  script: `
    function updateTextInput(model) {
      if (!model || !model.getEl()) return;

      const container = model.getEl();
      const traits = model.getTraits();

      try {
        // --- 0. СИНХРОНИЗАЦИЯ 'DATA' <-> INPUT VALUE ---
        if (!container._inputListenerAttached) {
            container.addEventListener('input', function(e) {
                const target = e.target;
                if (target && (target.classList.contains('text-input') || target.classList.contains('text-input-multiline'))) {
                    const currentAttrs = model.get('attributes');
                    if (currentAttrs.data !== target.value) {
                        model.set('attributes', { ...currentAttrs, data: target.value });
                    }
                }
            });
            container._inputListenerAttached = true;
        }

        // --- 1. ЧИТАЕМ ТРЕЙТЫ ---
        const placeholder = traits.find(t => t.getName() === 'placeholder')?.getValue() || 'Enter text';
        
        const showIconTrait = traits.find(t => t.getName() === 'showIcon');
        const showIconValue = showIconTrait ? showIconTrait.getValue() : true;
        const showIcon = (showIconValue === false || showIconValue === 'false') ? false : true;

        // --- 2. ПОИСК КОМПОНЕНТА INPUT В МОДЕЛИ ---
        const inputComp = model.find('input.text-input, textarea.text-input-multiline')[0];

        // --- 3. ОБНОВЛЕНИЕ INPUT (DOM + MODEL) ---
        const inputEl = container.querySelector('.text-input, .text-input-multiline');
        if (inputEl) {
          // А. Обновляем визуально (DOM)
          inputEl.placeholder = placeholder; 
          
          const savedData = model.getAttributes()['data'];
          if (savedData && inputEl.value !== savedData) {
              inputEl.value = savedData;
          }
        }

        // Б. [ВАЖНО] Обновляем Модель (чтобы placeholder сохранялся)
        if (inputComp) {
            const currentAttrs = inputComp.getAttributes();
            if (currentAttrs.placeholder !== placeholder) {
                inputComp.addAttributes({ placeholder: placeholder });
            }
        }

        // --- 4. РАБОТА С ИКОНКОЙ ---
        const toggleEl = container.querySelector('.text-input-toggle');
        
        if (toggleEl) {
          toggleEl.style.display = showIcon ? 'flex' : 'none';
          
          if (showIcon) {
               const selectImageTrait = traits.find(t => t.getName() === 'selectImage');
               const defaultIcon = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04IDNDOCAyLjQ0NzcyIDguNDQ3NzIgMiA5IDIgSDE1QzE1LjU1MjMgMiAxNiAyLjQ0NzcyIDE2IDNDMTYgMy41NTIyOSAxNS41NTIzIDQgMTUgNEgxM1YyMEgxNUMxNS41NTIzIDIwIDE2IDIwLjQ0NzcgMTYgMjFDMTYgMjEuNTUyMyAxNS41NTIzIDIyIDE1IDIySDlDOC40NDc3MiAyMiA4IDIxLjU1MjMgOCAyMUM4IDIwLjQ0NzcgOC40NDc3MiAyMCA5IDIwSDExVjRIOC40NDc3MiA0IDggMy41NTIyOCA4IDNaTTcuNzg4IDZIOC4wNTUyOSAxMCA5IDcuNDQ3NzIgOSAxN0M5IDcuNTUyMjggOC41NTIyOSA4IDggOEg3LjgzQzYuOTU4OTggOC4wMDExIDYuMzY2ODYgOC4wMDEyIDUuOTA5NDUgOC4wMzg3OUM1LjQ2NDAxIDguMDc1NzggNS4yMzY2MyA4LjE0MjggNS4wNzgwNSA4LjIyNTE3QzQuNzEyNzcgOC40MTQ5MiA0LjQxNDkzIDguNzEyNzYgNC4yMjUxNyA5LjA3ODA1QzQuMTQyOCAxMC4yMzY2MyA0LjA3NTc4IDkuNDY0MDEgNC4wMzg3OSA5LjkwOTQ1QzQuMDAxMiAxMC4zNjY5IDQgMTAuOTU5IDQgMTEuODNWMTIuMTdDNC4wMDExIDEzLjA0MSAxMC4wMDExIDEzLjYzMzEgNC4wMzg3OSAxNC4wOTA1QzQuMDc1NzggMTQuNTM2IDQuMTQyOCAxNC43NjM0IDQuMjI1MTcgMTQuOTIxOUM0LjQxNDkzIDE1LjI4NzIgNC43MTI3NyAxNS41ODUxIDUuMDc4MDUgMTUuNzc0OEM1LjIzNjYzIDE1Ljg1NzIgNS40NjQwMiAxNS45MjQyIDUuOTA5NDUgMTUuOTYxMkM2LjM2Njg2IDE1Ljk5OTIgNi45NTg5OCAxNiA3LjgzIDE2SDhDOC41NTIyOSAxNiA5IDE2LjQ0NzcgOSAxN0M5IDE3LjU1MjMgOC41NTIyOSAxOCA4IDE4SDcuNzg3OThDNi45Njk0NiAxOCA2LjI5MzkzIDE4IDUuNzQzOTMgMTcuOTU0M0M1LjE3MjU4IDE3LjkwNjkgNC42NDc3NCAxNy44MDUgNC4xNTYxIDE3LjU0OTdDMi41NTUzIDE3LjE3MDIgMi44Mjk4NSAxNi41NzQ1IDIuNDUwMzUgMTUuODQzOUMyLjE5NDk2IDE1LjM1MjMgMi4wOTMxIDE0LjgyNzQgMi4wNDU2NSAxNC4yNTYxQzEuOTk5OTggMTMuNzA2MSAxLjk5OTk5IDEzLjAzMDUgMiAxMi4yMTJWMTUuNzg4QzEuOTk5OTkgMTAuOTY5NSAxLjk5OTk4IDEwLjI5MzkgMi4wNDU2NSA5Ljc0MzkzQzIuMDkzMSA5LjE3MjU4IDIuMTk0OTYgOC42NDc3NCAyLjQ1MDM1IDguMTU2MUMyLjgyOTg1IDcuNDI1NTMgMy40MjU1MyA2LjgyOTg1IDQuMTU2MSA2LjQ1MDM1QzQuNjQ3NzQgNi4xOTQ5NiA1LjE3MjU4IDYuMDkzMSA1Ljc0MzkzIDYuMDQ1NjVDNi4yOTM5MyA1Ljk5OTk4IDYuOTY5NDcgNS45OTk5OSA3Ljc4OCA2Wk0xOC4wOTA1IDguMDM4NzlDMTcuNjMzMSA4LjAwMTIgMTcuMDQxIDggMTYuMTcgOEgxNkMxNS40NDc3IDggMTUgNy41NTIyOCAxNSA3QzE1IDYuNDQ3NzIgMTUuNDQ3NyA2IDE2IDZIMTYuMjEyQzE3LjAzMDUgNS45OTk5OSAxNy43MDYxIDUuOTk5OTggMTguMjU2MSA2LjA0NTY1QzE4LjgyNzQgNi4wOTMxIDE5LjM1MjMgNi4xOTQ5NiAxOS44NDM5IDYuNDUwMzVDMjAuNTc0NSA2LjgyOTg1IDIxLjE3MDIgNy40MjU1MyAyMS41NDk3IDguMTU2MUMyMS44MDUgOC42NDc3NCAyMS45MDY5IDkuMTcyNTggMjEuOTU0MyA5Ljc0MzkzQzIyIDEwLjI5MzkgMjIgMTAuOTY5NSAyMiAxMS43ODhWMTIuMjEyQzIyIDEzLjAzMDUgMjIgMTMuNzA2MSAyMS45NTQzIDE0LjI1NjFDMjEuOTA2OSAxNC44Mjc0IDIxLjgwNSAxNS4zNTIzIDIxLjU0OTcgMTUuODQzOUMyMS4xNzAyIDE2LjU3NDUgMjAuNTc0NSAxNy4xNzAyIDE5Ljg0MzkgMTcuNTQ5N0MxOS4zNTIzIDE3LjgwNSAxOC44Mjc0IDE3LjkwNjkgMTguMjU2MSAxNy45NTQzQzE3LjcwNjEgMTggMTcuMDMwNSAxOCAxNi4yMTIgMThIMTZDMTUuNDQ3NyAxOCAxNSAxNy41NTIzIDE1IDE3QzE1IDE2LjQ0NzcgMTUuNDQ3NyAxNiAxNiAxNkgxNi4xN0MxNy4wNDEgMTYgMTcuNjMzMSAxNS45OTkyIDE4LjA5MDUgMTUuOTYxMkMxOC41MzYgMTUuOTI0MiAxOC43NjM0IDE1Ljg1NzIgMTguOTIxOSAxNS43NzQ4QzE5LjI4NzIgMTUuNTg1MSAxOS41ODUxIDE1LjI4NzIgMTkuNzc0OCAxNC45MjE5QzE5Ljg1NzIgMTQuNzYzNCAxOS45MjQyIDE0LjUzNiAxOS45NjEyIDE0LjA5MDVDMTkuOTk5MiAxMy42MzMxIDIwIDEzLjA0MSAyMCAxMi4xN1YxMS44M0MyMCAxMC45NTkgMTkuOTk5MiAxMC4zNjY5IDE5Ljk2MTIgOS45MDk0NUMxOS45MjQyIDkuNDY0MDEgMTkuODU3MiA5LjIzNjYzIDE5Ljc3NDggOS4wNzgwNUMxOS41ODUxIDguNzEyNzcgMTkuMjg3MiA4LjQxNDkyIDE4LjkyMTkgOC4yMjUxN0MxOC43NjM0IDguMTQyOCAxOC41MzYgOC4wNzU3OCAxOC4wOTA1IDguMDM4Nzl6IiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4=';
               
               let src = selectImageTrait?.getValue();
               if (!src) src = defaultIcon;

               const iconEl = toggleEl.querySelector('.text-input-icon');
               if (iconEl && src && (src.startsWith('data:image') || src.startsWith('http'))) {
                   if (iconEl.getAttribute('src') !== src) {
                      iconEl.src = src;
                   }
               }

               const iconComp = model.find('.text-input-icon')[0];
               if (iconComp) {
                   const currentModelSrc = iconComp.getAttributes()['src'];
                   if (currentModelSrc !== src) {
                       iconComp.addAttributes({ src: src });
                   }
               }
          }

          if (toggleEl._clickHandler) {
              toggleEl.removeEventListener('click', toggleEl._clickHandler);
          }
          toggleEl._clickHandler = function(e) {
              e.preventDefault();
              e.stopPropagation();
              
              const typeTrait = model.getTraits().find(t => t.getName() === 'inputType');
              if (typeTrait) {
                  const currentVal = typeTrait.getValue() || 'text';
                  const nextVal = currentVal === 'text' ? 'textarea' : 'text';
                  typeTrait.setValue(nextVal);
              }
          };
          toggleEl.addEventListener('click', toggleEl._clickHandler);
        }

        // --- 5. СМЕНА ТЕГА (Input <-> Textarea) ---
        const typeTrait = traits.find(t => t.getName() === 'inputType');
        const inputType = typeTrait?.getValue() || 'text';
        
        if (inputComp) {
           const currentTagName = inputComp.get('tagName').toLowerCase();
           const targetTagName = inputType === 'textarea' ? 'textarea' : 'input';
           
           if (currentTagName !== targetTagName) {
               const currentVal = inputComp.getAttributes().value || model.getAttributes()['data'] || '';
               
               inputComp.replaceWith({
                  tagName: targetTagName,
                  attributes: {
                    id: inputComp.getId(),
                    class: inputType === 'textarea' ? 'text-input-multiline' : 'text-input',
                    type: inputType === 'textarea' ? undefined : 'text',
                    placeholder: placeholder // Тут он тоже прокинется при пересоздании
                  },
                  style: inputComp.getStyle()
               });
               setTimeout(() => updateTextInput(model), 0);
           } else {
               const targetClass = inputType === 'textarea' ? 'text-input-multiline' : 'text-input';
               if (inputComp.getAttributes().class !== targetClass) {
                   inputComp.setClass(targetClass);
               }
           }
        }

      } catch (e) {
        console.error('Script Error:', e);
      }
    }

    if (model && model.getEl()) {
      updateTextInput(model);
    }

    if (model.__stage19TextInputCleanup) model.__stage19TextInputCleanup();
    var stage19TextInputTimer = 0;
    var stage19OnTextInputTraits = function() {
      if (stage19TextInputTimer) clearTimeout(stage19TextInputTimer);
      stage19TextInputTimer = setTimeout(function() {
        stage19TextInputTimer = 0;
        updateTextInput(model);
      }, 0);
    };
    var stage19OnTextInputChange = function() { updateTextInput(model); };
    model.on('change:traits', stage19OnTextInputTraits);
    model.on('change:style', stage19OnTextInputChange);
    model.on('change:components', stage19OnTextInputChange);
    model.__stage19TextInputCleanup = function() {
      model.off('change:traits', stage19OnTextInputTraits);
      model.off('change:style', stage19OnTextInputChange);
      model.off('change:components', stage19OnTextInputChange);
      if (stage19TextInputTimer) clearTimeout(stage19TextInputTimer);
      stage19TextInputTimer = 0;
    };
`,
  styleConfig: {
    target: '.text-input-container',
    sectors: [
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: '--input-width',
            type: 'number',
            default: 365,
            units: ['px', '%', 'vw']
          },
          {
            id: 'height',
            name: 'Height',
            property: '--input-height',
            type: 'number',
            default: 48,
            units: ['px', '%', 'vh', 'auto']
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: '--c-min-width',
            type: 'number',
            default: 'fit-content',
            units: ['px', '%', 'vw']
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: '--c-min-height',
            type: 'number',
            default: '48',
            units: ['px', '%', 'vh']
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: '--c-max-width',
            type: 'number',
            default: 365,
            units: ['px', '%', 'vw']
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: '--c-max-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto']
          }
        ]
      },
      {
        id: 'style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'border-color',
            name: 'Border Color',
            property: '--bc',
            type: 'color',
            default: '#3182ce'
          },
          {
            id: 'background-color',
            name: 'Color',
            property: '--bg',
            type: 'color',
            default: '#FFFFFF1A'
          },
          {
            id: 'border-width',
            name: 'Border Width',
            property: '--bw',
            type: 'number',
            default: 0,
            units: ['px']
          }
        ]
      },
      {
        id: 'text',
        name: 'Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: '--fs',
            type: 'number',
            default: 16,
            units: ['px']
          },
          {
            id: 'color',
            name: 'Color',
            property: '--color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  }
};
