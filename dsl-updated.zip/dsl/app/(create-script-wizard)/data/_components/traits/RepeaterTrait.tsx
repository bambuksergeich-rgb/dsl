import React, { useEffect, useState, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { useEditor } from '@grapesjs/react';
import type { Component, Trait } from 'grapesjs';
import { Box, TextField, IconButton } from '@mui/material';
import { IconPickerModal } from '@/src/components/CreateFlowchartBlock/IconPickerModal/IconPickerModal';
import { iconsStore } from '@/src/helpers/getIconsHelper';
import { renderToStaticMarkup } from 'react-dom/server';
import * as AllIcons from '../../../../../public/icons/flowchartBlock';
import ColorElement from '../../../components/ColorElement';

interface RepeaterItem {
  id: string;
  label: string;
  icon: string;
  color: string;
}

export const RepeaterTrait = ({ trait }: { trait: Trait }) => {
  const editor = useEditor();
  const selectedComponent = editor.getSelected();

  const [items, setItems] = useState<RepeaterItem[]>([]);
  const [newItemLabel, setNewItemLabel] = useState('');
  const [newItemIcon, setNewItemIcon] = useState('');
  const [newItemColor, setNewItemColor] = useState('#4170FF');
  const [isIconPickerOpen, setIsIconPickerOpen] = useState(false);
  const [activePickerId, setActivePickerId] = useState<string | null>(null);

  const getTraitConfig = (key: string): unknown =>
    (trait as unknown as { get: (name: string) => unknown }).get(key);

  const childType = String(getTraitConfig('itemId') || 'text');
  const labelTraitName = String(getTraitConfig('itemLabel') || 'text');
  const iconTraitName = String(getTraitConfig('itemIcon') || 'selectIcon');
  const colorTraitName = String(getTraitConfig('itemColor') || 'color');
  const defaultLabel = String(getTraitConfig('defaultLabel') || 'New Item');
  const defaultColor = String(getTraitConfig('defaultColor') || '#4170FF');

  const normalizeColor = (value: unknown) => {
    const color = String(value || '');
    return /^#[0-9a-f]{6}$/i.test(color) ? color : defaultColor;
  };

  const getItemsContainer = useCallback(() => {
    if (!selectedComponent) return null;
    const directChildren = selectedComponent.components();
    const containerWrapper = directChildren.models.find((c) =>
      c.getClasses().includes('button-group-container')
    );
    if (containerWrapper) return containerWrapper;
    return selectedComponent;
  }, [selectedComponent]);

  const getIconDataUrl = (iconName: string) => {
    const iconComponents = AllIcons as unknown as Partial<Record<
      string,
      React.ComponentType
    >>;
    let IconComponent = iconComponents[iconName];

    if (!IconComponent) {
      console.error('❌ Icon not found:', iconName);

      // Попробуем найти альтернативную иконку (например, с цифрой "2")
      const alternativeName = iconName.replace(/Icon$/, '2Icon');
      IconComponent = iconComponents[alternativeName];

      if (IconComponent) {
        console.warn('⚠️ Using alternative icon:', alternativeName);
      } else {
        const firstIcon = Object.keys(AllIcons)[0];
        console.warn('⚠️ Using fallback icon:', firstIcon);
        IconComponent = iconComponents[firstIcon];
      }

      if (!IconComponent) return null;
    }

    try {
      const svgString = renderToStaticMarkup(<IconComponent />);
      // encodeURIComponent is safer than btoa here: an SVG component may
      // contain non-ASCII text/attributes and btoa would throw in that case.
      return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svgString)}`;
    } catch (error) {
      console.error('❌ Error generating icon:', error);
      return null;
    }
  };

  const processIconSelection = (iconId: string): string | null => {
    const iconMeta = iconsStore.find((icon: any) => icon.id === iconId);
    if (!iconMeta) return null;
    return getIconDataUrl(iconMeta.name);
  };

  const syncItems = useCallback(() => {
    const container = getItemsContainer();
    if (!container) return;

    const children = container.components();
    const mapped: RepeaterItem[] = children.models.map((child: Component) => {
      let labelVal = '';

      // 1. Пробуем получить из trait
      const childLabelTrait = child.getTrait(labelTraitName);
      if (childLabelTrait) {
        labelVal = childLabelTrait.getValue();
      }

      // 2. Если trait пустой, пробуем из attributes
      if (!labelVal) {
        labelVal =
          child.get(labelTraitName) ||
          child.getAttributes()[labelTraitName] ||
          '';
      }

      // 3. Если всё ещё пусто, пробуем из content кнопки
      if (!labelVal) {
        const labelComp = child.find('.button-label')?.[0];
        if (labelComp) {
          // Получаем textContent из компонента
          const textNode = labelComp.components().models[0];
          if (textNode) {
            labelVal = textNode.get('content') || '';
          }
        }
      }

      if (!labelVal) {
        labelVal = defaultLabel;

        if (childLabelTrait) {
          childLabelTrait.setValue(labelVal);
        }
      }

      // === ИКОНКА ===
      let iconVal = '';
      const childIconTrait = child.getTrait(iconTraitName);
      if (childIconTrait) {
        iconVal = childIconTrait.getValue();
      }
      if (!iconVal) {
        const imgComp =
          child.findType('image-icon')[0] ||
          child.find('img')[0] ||
          child.find('.button-icon')[0];
        if (imgComp) {
          iconVal = imgComp.getAttributes()['src'] || imgComp.get('src') || '';
        }
      }

      let colorVal = '';
      const childColorTrait = child.getTrait(colorTraitName);
      if (childColorTrait) {
        colorVal = childColorTrait.getValue();
      }
      if (!colorVal) {
        const childStyle = child.getStyle?.() || {};
        colorVal =
          childStyle['--bg'] ||
          child.getAttributes?.()['data-color'] ||
          defaultColor;
      }

      return {
        id: child.getId(),
        label: labelVal,
        icon: iconVal,
        color: normalizeColor(colorVal)
      };
    });

    const filtered =
      childType !== '*'
        ? mapped.filter((_, i) => children.models[i]?.get('type') === childType)
        : mapped;
    setItems(filtered);
  }, [
    getItemsContainer,
    childType,
    labelTraitName,
    iconTraitName,
    colorTraitName,
    defaultLabel,
    defaultColor
  ]);

  useEffect(() => {
    syncItems();
  }, [selectedComponent]);

  const handleLabelChange = (id: string, newVal: string) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, label: newVal } : item))
    );

    updateComponentProperty(id, labelTraitName, newVal);
  };

  // Обновление icon
  const handleIconChange = (id: string, newIconUrl: string) => {

    // Обновляем локальный стейт
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, icon: newIconUrl } : item
      )
    );

    updateComponentProperty(id, iconTraitName, newIconUrl);
  };


  const handleColorChange = (id: string, color: string) => {
    const normalized = normalizeColor(color);
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, color: normalized } : item
      )
    );
    updateComponentProperty(id, colorTraitName, normalized);
  };

  const updateComponentProperty = (
    id: string,
    propName: string,
    value: string
  ) => {

    const container = getItemsContainer();
    if (!container) return;

    const child = container.components().models.find((c) => c.getId() === id);
    if (!child) return;

    // 1. Обновляем трейт (если он есть)
    const childTrait = child.getTrait(propName);
    if (childTrait) {
      childTrait.setValue(value);
    }

    // changeProp traits are mirrored to the component model. Explicitly keep
    // that mirror in sync as well, so nested button items update immediately
    // even when GrapesJS does not emit the trait/model bridge event.
    if (child.get?.(propName) !== value) {
      child.set?.(propName, value);
    }

    // 2. Всегда обновляем атрибут (это то, что слушает наш скрипт в Checkbox через change:attributes)
    child.addAttributes({ [propName]: value });

    // 3. Специальная логика для ИКОНКИ
    if (propName === iconTraitName) {
      const imageComponent =
        child.findType('image-icon')[0] ||
        child.find('.button-icon')[0] ||
        child.find('img')[0];

      if (imageComponent) {
        imageComponent.setAttributes({
          ...imageComponent.getAttributes?.(),
          src: value
        });
        imageComponent.set('src', value);
        imageComponent.view?.render?.();
      }
      child.addAttributes({
        [iconTraitName]: value,
        'data-icon': value
      });
    }

    if (propName === colorTraitName) {
      child.addStyle?.({ '--bg': normalizeColor(value) });
      child.addAttributes({ 'data-color': normalizeColor(value) });
      const childEl = child.getEl?.();
      childEl?.style?.setProperty?.('--bg', normalizeColor(value));
    }

    // 4. Специальная логика для ТЕКСТА (label/text)
    if (propName === labelTraitName) {
      child.addAttributes({
        [labelTraitName]: value,
        name: value,
        value,
        data: value,
        'data-text': value
      });

      // Пытаемся найти вложенный элемент для текста (для кнопок с .button-label)
      const textComp =
        child.find('.button-label')[0] || child.find('.checkbox-label')[0];

      if (textComp) {
        textComp.set('content', value);
        if (textComp.view) textComp.view.render();
      } else {
        // Если вложенного компонента нет, обновляем контент самого элемента
        child.set('content', value);
      }
    }

    // ВАЖНО: Принудительно триггерим событие, чтобы скрипт во фрейме сработал
    child.trigger('change:attributes');
  };

  const handleAdd = () => {
    const container = getItemsContainer();
    if (!container) return;

    const labelToAdd = newItemLabel.trim() || defaultLabel;

    const newComponent = container.append({
      type: childType,
      attributes: {
        [labelTraitName]: labelToAdd,
        name: labelToAdd,
        value: labelToAdd,
        data: labelToAdd,
        'data-text': labelToAdd,
        [iconTraitName]: newItemIcon,
        'data-icon': newItemIcon,
        'data-color': normalizeColor(newItemColor),
        'data-type': 'Boolean',
        'data-table-role': 'true',
        'aria-pressed': 'false',
        'data-value': 'false'
      },
      [labelTraitName]: labelToAdd,
      [iconTraitName]: newItemIcon
    })[0];

    if (newComponent) {
      setTimeout(() => {
        updateComponentProperty(newComponent.getId(), labelTraitName, labelToAdd);
        if (newItemIcon) {
          updateComponentProperty(newComponent.getId(), iconTraitName, newItemIcon);
        }
        updateComponentProperty(
          newComponent.getId(),
          colorTraitName,
          normalizeColor(newItemColor)
        );
      }, 50);
    }

    setTimeout(() => syncItems(), 100);

    setNewItemLabel('');
    setNewItemIcon('');
    setNewItemColor(defaultColor);
  };

  const handleRemove = (id: string) => {
    const container = getItemsContainer();
    if (!container) return;
    const child = container.components().models.find((c) => c.getId() === id);
    if (child) {
      child.remove();

      setTimeout(() => syncItems(), 50);
    }
  };

  const handleIconSelectFromModal = (iconId: string) => {
    const iconSrc = processIconSelection(iconId);
    if (!iconSrc) return;

    if (activePickerId === 'new') {
      setNewItemIcon(iconSrc);
    } else if (activePickerId) {
      handleIconChange(activePickerId, iconSrc);
    }

    setIsIconPickerOpen(false);
    setActivePickerId(null);
  };

  const openIconPicker = (id: string) => {
    setActivePickerId(id);
    setIsIconPickerOpen(true);
  };

  const IconSelectButton = ({
    iconValue,
    onClick
  }: {
    iconValue: string;
    onClick: () => void;
  }) => (
    <button
      type='button'
      onClick={onClick}
      title='Select Icon'
      aria-label='Select icon'
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: '34px',
        height: '34px',
        flexShrink: 0,
        backgroundColor: 'rgba(65, 112, 255, 0.2)',
        border: '1px solid #4170FF',
        borderRadius: '4px',
        cursor: 'pointer',
        padding: '0'
      }}
    >
      {iconValue ? (
        <img
          src={iconValue}
          alt='Icon'
          style={{ width: '20px', height: '20px', objectFit: 'contain' }}
        />
      ) : (
        <svg
          width='20'
          height='20'
          viewBox='0 0 24 24'
          fill='none'
        >
          <path
            d='M4 5C4 4.73478 4.10536 4.48043 4.29289 4.29289C4.48043 4.10536 4.73478 4 5 4H9C9.26522 4 9.51957 4.10536 9.70711 4.29289C9.89464 4.48043 10 4.73478 10 5V9C10 9.2652 9.89464 9.5196 9.70711 9.7071C9.51957 9.8946 9.26522 10 9 10H5C4.73478 10 4.48043 9.8946 4.29289 9.7071C4.10536 9.5196 4 9.2652 4 9V5ZM14 5C14 4.73478 14.1054 4.48043 14.2929 4.29289C14.4804 4.10536 14.7348 4 15 4H19C19.2652 4 19.5196 4.10536 19.7071 4.29289C19.8946 4.48043 20 4.73478 20 5V7C20 7.26522 19.8946 7.51957 19.7071 7.70711C19.5196 7.89464 19.2652 8 19 8H15C14.7348 8 14.4804 7.89464 14.2929 7.70711C14.1054 7.51957 14 7.26522 14 7V5ZM4 16C4 15.7348 4.10536 15.4804 4.29289 15.2929C4.48043 15.1054 4.73478 15 5 15H9C9.26522 15 9.51957 15.1054 9.70711 15.2929C9.89464 15.4804 10 15.7348 10 16V19C10 19.2652 9.89464 19.5196 9.70711 19.7071C9.51957 19.8946 9.26522 20 9 20H5C4.73478 20 4.48043 19.8946 4.29289 19.7071C4.10536 19.5196 4 19.2652 4 19V16ZM14 13C14 13.7348 14.1054 12.4804 14.2929 12.2929C14.4804 12.1054 14.7348 12 15 12H19C19.2652 12 19.5196 12.1054 19.7071 12.2929C19.8946 12.4804 20 12.7348 20 13V19C20 19.2652 19.8946 19.5196 19.7071 19.7071C19.5196 19.8946 19.2652 20 19 20H15C14.7348 20 14.4804 19.8946 14.2929 19.7071C14.1054 19.5196 14 19.2652 14 19V13Z'
            stroke='white'
            strokeWidth='1.5'
          />
        </svg>
      )}
    </button>
  );

  return (
    <>
      <Box
        sx={{
          p: 0,
          width: '100%',
          gap: '8px',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        <Box sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <IconSelectButton
            iconValue={newItemIcon}
            onClick={() => openIconPicker('new')}
          />
          <TextField
            size='small'
            placeholder={defaultLabel}
            value={newItemLabel}
            onChange={(e) => setNewItemLabel(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
            fullWidth
            sx={{
              flex: 1,
              '& .MuiInputBase-root': {
                height: '34px',
                color: '#fff',
                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                borderRadius: '6px',
                border: 'none'
              },
              '& .MuiInputBase-input': {
                height: '34px',
                boxSizing: 'border-box',
                padding: '0 12px',
                fontFamily: 'Montserrat, sans-serif',
                fontSize: '14px'
              },
              '& .MuiOutlinedInput-notchedOutline': {
                border: 'none'
              }
            }}
          />
          <ColorElement
            value={normalizeColor(newItemColor)}
            onChange={setNewItemColor}
            mini
          />
          <IconButton
            type='button'
            onClick={handleAdd}
            aria-label='Add button'
            sx={{
              backgroundColor: '#4170ff',
              width: '34px',
              height: '34px',
              borderRadius: '4px',
              flexShrink: 0,
              '&:hover': { backgroundColor: '#365fd9' }
            }}
          >
            <svg
              width='14'
              height='14'
              viewBox='0 0 14 14'
              fill='none'
            >
              <path
                d='M7 0.75V13.25M13.25 7H0.75'
                stroke='white'
                strokeWidth='1.5'
                strokeLinecap='round'
                strokeLinejoin='round'
              />
            </svg>
          </IconButton>
        </Box>

        <Box
          sx={{ display: 'flex', flexDirection: 'column', gap: '8px', mb: 1 }}
        >
          {items.map((item) => (
            <Box
              key={item.id}
              sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}
            >
              <IconSelectButton
                iconValue={item.icon}
                onClick={() => openIconPicker(item.id)}
              />
              <TextField
                size='small'
                value={item.label}
                onChange={(e) => handleLabelChange(item.id, e.target.value)}
                fullWidth
                sx={{
                  flex: 1,
                  '& .MuiInputBase-root': {
                    height: '34px',
                    color: '#fff',
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    borderRadius: '6px',
                    border: 'none'
                  },
                  '& .MuiInputBase-input': {
                    height: '34px',
                    boxSizing: 'border-box',
                    padding: '0 12px',
                    fontFamily: 'Montserrat, sans-serif',
                    fontSize: '14px'
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    border: 'none'
                  }
                }}
              />
              <ColorElement
                value={normalizeColor(item.color)}
                onChange={(color) => handleColorChange(item.id, color)}
                mini
              />
              <IconButton
                type='button'
                onClick={() => handleRemove(item.id)}
                disabled={items.length <= 1}
                aria-label='Remove button'
                sx={{
                  backgroundColor: '#3D3AB8',
                  width: '34px',
                  height: '34px',
                  borderRadius: '4px',
                  flexShrink: 0,
                  '&:hover': { backgroundColor: '#3D3AB8' },
                  '&:disabled': { backgroundColor: '#3D3AB8', opacity: 0.5 }
                }}
              >
                <svg
                  width='12'
                  height='12'
                  viewBox='0 0 12 12'
                  fill='none'
                >
                  <path
                    fillRule='evenodd'
                    clipRule='evenodd'
                    d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                    fill='white'
                  />
                </svg>
              </IconButton>
            </Box>
          ))}
        </Box>
      </Box>

      {isIconPickerOpen &&
        createPortal(
          <IconPickerModal
            open={isIconPickerOpen}
            onClose={() => {
              setIsIconPickerOpen(false);
              setActivePickerId(null);
            }}
            onSelect={handleIconSelectFromModal}
            selectedId={undefined}
          />,
          document.body
        )}
    </>
  );
};
