import { ComponentConfig } from '../elements';

export const Badge: ComponentConfig = {
  id: 'button-link',
  type: 'button-link',
  label: 'Badge',
  category: 'Content',
  content: {
    tagName: 'a',
    attributes: { class: 'button-link', href: '#' },
    components: [
      {
        tagName: 'img',
        attributes: {
          class: 'button-link-icon',
          src: ''
        },
        draggable: false
      },
      {
        tagName: 'span',
        attributes: { class: 'button-link-text' },
        content: 'Add class'
      },
      {
        tagName: 'span',
        attributes: { class: 'notification-count' },
        content: '14'
      }
    ]
  },
  block: true,
  icon: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.5 10.5L8.0089 12.0089C8.3526 12.3526 8.5245 12.5245 8.7198 12.5822C8.8914 12.6328 9.0749 12.6245 9.2412 12.5585C9.4305 12.4834 9.5861 12.2967 9.8973 11.9232L14 7M14.3287 2.75855C15.0676 2.77963 15.8001 3.07212 16.364 3.636C16.9278 4.19989 17.2203 4.9324 17.2414 5.67121C17.2623 6.40232 17.2727 6.76787 17.2942 6.85296C17.3401 7.0351 17.2867 6.90625 17.383 7.06752C17.428 7.14286 17.6792 7.40876 18.1814 7.94045C18.6889 8.4778 19 9.2026 19 10C19 10.7974 18.6889 11.5222 18.1814 12.0595C17.6792 12.5912 17.428 12.8571 17.383 12.9325C17.2867 13.0937 17.3401 12.9649 17.2942 13.147C17.2727 13.2321 17.2623 13.5977 17.2414 14.3288C17.2203 15.0676 16.9278 15.8001 16.364 16.364C15.8001 16.9279 15.0676 17.2204 14.3287 17.2414C13.5976 17.2623 13.2321 17.2727 13.147 17.2942C12.9649 17.3401 13.0937 17.2868 12.9325 17.3831C12.8571 17.4281 12.5912 17.6792 12.0595 18.1814C11.5222 18.6889 10.7974 19 10 19C9.2026 19 8.4778 18.6889 7.94047 18.1814C7.40874 17.6792 7.14287 17.4281 7.06753 17.3831C6.90626 17.2868 7.0351 17.3401 6.85296 17.2942C6.76788 17.2727 6.40225 17.2623 5.67121 17.2414C4.93238 17.2204 4.19986 16.9279 3.63597 16.364C3.07207 15.8001 2.77959 15.0676 2.75852 14.3287C2.73766 13.5976 2.72724 13.2321 2.70578 13.147C2.65985 12.9649 2.71322 13.0937 2.61691 12.9324C2.57192 12.8571 2.32082 12.5912 1.81862 12.0595C1.31113 11.5222 1 10.7974 1 10C1 9.2026 1.31113 8.4778 1.81862 7.94048C2.32082 7.40876 2.57192 7.14289 2.61691 7.06755C2.71322 6.90628 2.65985 7.03512 2.70578 6.85299C2.72724 6.7679 2.73766 6.40235 2.75852 5.67126C2.77959 4.93243 3.07207 4.1999 3.63597 3.636C4.19986 3.07211 4.93238 2.77963 5.67121 2.75855C6.40232 2.73769 6.76788 2.72727 6.85296 2.70581C7.0351 2.65988 6.90626 2.71325 7.06753 2.61694C7.14287 2.57195 7.40876 2.32082 7.94047 1.81863C8.4778 1.31113 9.2026 1 10 1C10.7974 1 11.5222 1.31114 12.0595 1.81864C12.5913 2.32084 12.8571 2.57194 12.9325 2.61693C13.0937 2.71324 12.9649 2.65988 13.147 2.70581C13.2321 2.72726 13.5976 2.73769 14.3287 2.75855Z" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`,
  traits: [
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'Select Icon',
      type: 'select-icon',
      changeProp: true,
      value: ''
    },
    {
      id: 'badge-value',
      name: 'badge-value',
      label: 'Badge Value',
      type: 'number',
      changeProp: true,
      min: 0,
      value: 14
    },
    {
      id: 'text',
      name: 'text',
      label: 'Text',
      type: 'text',
      changeProp: true,
      value: 'Add class'
    },
    {
      id: 'axis',
      name: 'axis',
      label: 'Axis',
      type: 'select',
      changeProp: true,
      options: [
        { id: 'right', name: 'Right', value: 'right' },
        { id: 'left', name: 'Left', value: 'left' },
        { id: 'top', name: 'Top', value: 'top' },
        { id: 'bottom', name: 'Bottom', value: 'bottom' }
      ],
      value: 'right'
    }
  ],
  styles: `
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap');

.button-link {
  display: inline-flex;
  align-items: center;
  background-color: var(--background-color, #4170FF);
  border-color: var(--border-color, transparent);
  border-style: var(--border-style, none);
  border-width: var(--border-width, 0);
  border-radius: 6px;
  font-size: var(--text-font-size, 16px);
  color: var(--text-color, #ffffff);
  text-decoration: none;
  cursor: pointer;
  transition: background-color 0.2s;
  gap: 8px;
  width: var(--width, auto);
  height: var(--height, auto);
  min-width: var(--min-width, 100px);
  min-height: var(--min-height, 32px);
  max-width: var(--max-width, 200px);
  max-height: var(--max-height, none);
  position: relative; /* Для совместимости с дочерними элементами */
  padding: 0 12px; /* Добавляем отступы для контента */
  font-family: Montserrat;

}
.button-link:hover {
  filter: brightness(1.1);
}

.button-link-text {
  font-size: var(--text-font-size, 16px);
  color: var(--text-color, #ffffff);
}

.button-link-icon {
  width: 16px !important;
  height: 16px !important;
  max-width: 16px !important;
  max-height: 16px !important;
  object-fit: contain;
  display: none;
}
.button-link-icon[src]:not([src=""]) {
  display: inline-block;
}

.notification-count {
  display: inline-flex; /* Flex для центрирования */
  align-items: center; /* Вертикальное центрирование */
  justify-content: center; /* Горизонтальное центрирование */
  width: var(--badge-width, auto); /* Синхронизировано с styleConfig */
  min-width:24px;
  height: var(--badge-height, 24px); /* Синхронизировано с styleConfig */
  margin-left: auto; /* Сдвигаем к правому краю */
  margin-right: 6px; /* Отступ 6px от правого края */
  background-color: var(--badge-color, #3D3AB8);
  color: var(--badge-text-color, #ffffff);
  font-size: var(--badge-font-size, 12px);
  border-radius: 50%;
  text-align: center;
}
.notification-count.visible {
  visibility: visible;
}
.button-link.axis-left {
  flex-direction: row-reverse;
}
.button-link.axis-top {
  flex-direction: column;
  align-items: flex-start;
}
.button-link.axis-bottom {
  flex-direction: column-reverse;
  align-items: flex-start;
}
.button-link.axis-right {
  flex-direction: row;
}
  `,
  script: `
function updateButtonLink(model) {
  console.log('updateButtonLink called:', model.changed);
  const button = model.getEl();
  if (!button) {
    console.error('No button element');
    return;
  }
  const icon = model.getTrait('selectImage')?.getValue() || '';
  const badgeValue = parseInt(model.getTrait('badge-value')?.getValue() || '14');
  const text = model.getTrait('text')?.getValue() || 'Add class';
  const axis = model.getTrait('axis')?.getValue() || 'right';
  
  // Обновление иконки
   const iconEl = model.find('.button-link-icon')[0];
    if (iconEl) {
      if (typeof icon === 'string' && icon.startsWith('data:image')) {
        iconEl.setAttributes({ src: icon });
        console.log('Icon updated with data URL:', icon);
      } else {
        iconEl.setAttributes({ src: '' });
        console.log('Icon cleared');
      }
    } else {
      console.error('Icon element (.button-link-icon) not found');
    }
  
  // Обновление текста
  const textSpan = model.find('.button-link-text')[0];
  if (textSpan) {
    textSpan.set('content', text);
    console.log('Text updated:', text);
  }
  
  // Обновление счетчика
  const countSpan = model.find('.notification-count')[0];
  if (countSpan) {
    countSpan.set('content', badgeValue.toString());
    if (badgeValue > 0) {
      countSpan.addClass('visible');
    } else {
      countSpan.removeClass('visible');
    }
    // Настройка отступов в зависимости от axis
    countSpan.getEl().style.margin = '';
    if (axis === 'right') {
      countSpan.getEl().style.marginLeft = 'auto';
      countSpan.getEl().style.marginRight = '6px';
    } else if (axis === 'left') {
      countSpan.getEl().style.marginRight = 'auto';
      countSpan.getEl().style.marginLeft = '6px';
    } else if (axis === 'top') {
      countSpan.getEl().style.marginBottom = 'auto';
      countSpan.getEl().style.marginTop = '6px';
    } else if (axis === 'bottom') {
      countSpan.getEl().style.marginTop = 'auto';
      countSpan.getEl().style.marginBottom = '6px';
    }
    console.log('Badge value updated:', badgeValue);
  }
  
  // Обновление позиции через Axis
  button.classList.remove('axis-left', 'axis-right', 'axis-top', 'axis-bottom');
  button.classList.add('axis-' + axis);
  console.log('Axis updated:', axis);
  
  // Обновление стилей из styleConfig для .button-link
  const styles = model.getStyle();
  if (styles['background-color']) {
    button.style.setProperty('--background-color', styles['background-color']);
  }
  if (styles['border-color']) {
    button.style.setProperty('--border-color', styles['border-color']);
  }
  if (styles['border-style']) {
    button.style.setProperty('--border-style', styles['border-style']);
  }
  if (styles['border-width']) {
    button.style.setProperty('--border-width', styles['border-width']);
  }
  if (styles['width']) {
    button.style.setProperty('--width', styles['width']);
  }
  if (styles['height']) {
    button.style.setProperty('--height', styles['height']);
  }
  if (styles['min-width']) {
    button.style.setProperty('--min-width', styles['min-width']);
  }
  if (styles['min-height']) {
    button.style.setProperty('--min-height', styles['min-height']);
  }
  if (styles['max-width']) {
    button.style.setProperty('--max-width', styles['max-width']);
  }
  if (styles['max-height']) {
    button.style.setProperty('--max-height', styles['max-height']);
  }
  
  // Обновление стилей текста для .button-link-text
  const textStyles = model.getStyle('.button-link-text') || {};
  if (textStyles['font-size']) {
    button.style.setProperty('--text-font-size', textStyles['font-size']);
  }
  if (textStyles['color']) {
    button.style.setProperty('--text-color', textStyles['color']);
  }
  
  // Обновление стилей баджа для .notification-count
  const badgeStyles = model.getStyle('.notification-count') || {};
  if (countSpan && countSpan.getEl()) {
    if (badgeStyles['background-color']) {
      countSpan.getEl().style.setProperty('--badge-color', badgeStyles['background-color']);
    }
    if (badgeStyles['font-size']) {
      countSpan.getEl().style.setProperty('--badge-font-size', badgeStyles['font-size']);
    }
    if (badgeStyles['color']) {
      countSpan.getEl().style.setProperty('--badge-text-color', badgeStyles['color']);
    }
    if (badgeStyles['width']) {
      countSpan.getEl().style.setProperty('--badge-width', badgeStyles['width']);
    }
    if (badgeStyles['height']) {
      countSpan.getEl().style.setProperty('--badge-height', badgeStyles['height']);
    }
  }
  console.log('Styles updated:', { styles, textStyles, badgeStyles });
}
if (model && model.getEl()) {
  console.log('Initial updateButtonLink call');
  updateButtonLink(model);
}
model.on('change:selectImage change:badge-value change:text change:axis', () => {
  console.log('Trait changed:', model.changed);
  updateButtonLink(model);
});
model.on('style:property:change', () => {
  console.log('Style property changed');
  updateButtonLink(model);
});
`,
  styleConfig: {
    sectors: [
      {
        id: 'style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'button-background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: '#4170FF'
          },
          {
            id: 'notification-count-background-color',
            name: 'Badge Color',
            property: 'background-color',
            type: 'color',
            default: '#3D3AB8',
            selector: '.notification-count'
          },
          {
            id: 'button-border-color',
            name: 'Border Color',
            property: 'border-color',
            type: 'color',
            default: 'transparent'
          },
          {
            id: 'button-border-style',
            name: 'Border Type',
            property: 'border-style',
            type: 'select',
            options: [
              { id: 'solid', name: 'Solid', value: 'solid' },
              { id: 'dashed', name: 'Dashed', value: 'dashed' },
              { id: 'dotted', name: 'Dotted', value: 'dotted' },
              { id: 'none', name: 'None', value: 'none' }
            ],
            default: 'none'
          },
          {
            id: 'button-border-width',
            name: 'Border Width',
            property: 'border-width',
            type: 'number',
            units: ['px'],
            default: 0
          }
        ]
      },
      {
        id: 'badge-dimension',
        name: 'Badge Dimension',
        open: true,
        properties: [
          {
            id: 'notification-count-width',
            name: 'Badge Width',
            property: 'width',
            type: 'number',
            units: ['px'],
            default: 24,
            selector: '.notification-count'
          },
          {
            id: 'notification-count-height',
            name: 'Badge Height',
            property: 'height',
            type: 'number',
            units: ['px'],
            default: 24,
            selector: '.notification-count'
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: false,
        properties: [
          {
            id: 'button-width',
            name: 'Width',
            property: 'width',
            type: 'number',
            units: ['px', '%'],
            default: 238
          },
          {
            id: 'button-height',
            name: 'Height',
            property: 'height',
            type: 'number',
            units: ['px', '%'],
            default: 44
          },
          {
            id: 'button-min-width',
            name: 'Min-Width',
            property: 'min-width',
            type: 'number',
            units: ['px', '%'],
            default: 100
          },
          {
            id: 'button-min-height',
            name: 'Min-Height',
            property: 'min-height',
            type: 'number',
            units: ['px', '%'],
            default: 32
          },
          {
            id: 'button-max-width',
            name: 'Max-Width',
            property: 'max-width',
            type: 'number',
            units: ['px', '%'],
            default: 200
          },
          {
            id: 'button-max-height',
            name: 'Max-Height',
            property: 'max-height',
            type: 'number',
            units: ['px', '%'],
            default: 50
          }
        ]
      },
      {
        id: 'text',
        name: 'Text',
        open: true,
        properties: [
          {
            id: 'text-font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            units: ['px', 'rem'],
            default: 14,
            selector: '.button-link-text'
          },
          {
            id: 'text-color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#ffffff',
            selector: '.button-link-text'
          }
        ]
      },
      {
        id: 'badge-text',
        name: 'Badge Text',
        open: true,
        properties: [
          {
            id: 'badge-font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            units: ['px'],
            default: 12,
            selector: '.notification-count'
          },
          {
            id: 'badge-text-color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#ffffff',
            selector: '.notification-count'
          }
        ]
      }
    ]
  }
};
