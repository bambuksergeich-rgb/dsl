import { ComponentConfig } from '../elements';

const DEFAULT_CIRCLE_IMAGE = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI5NiIgaGVpZ2h0PSI5NiIgdmlld0JveD0iMCAwIDk2IDk2IiBmaWxsPSJub25lIj4KPGNpcmNsZSBjeD0iNDgiIGN5PSI0OCIgcj0iNDQiIGZpbGw9IiMyQTMxM0IiIHN0cm9rZT0iI0ZGRkZGRiIgc3Ryb2tlLW9wYWNpdHk9Ii4zNSIgc3Ryb2tlLXdpZHRoPSIyIi8+CjxjaXJjbGUgY3g9IjQ4IiBjeT0iMzgiIHI9IjE1IiBmaWxsPSIjRkZGRkZGIi8+CjxwYXRoIGQ9Ik0yMyA3OGMzLTE0IDEzLTIyIDI1LTIyczIyIDggMjUgMjIiIGZpbGw9IiNGRkZGRkYiLz4KPC9zdmc+';

export const CircleImage: ComponentConfig = {
  id: 'circle-image',
  type: 'circle-image',
  label: 'Circle Image',
  category: 'Media',
  content: {
    tagName: 'div',
    attributes: {
      class: 'circle-image-wrapper',
      'data-image': DEFAULT_CIRCLE_IMAGE,
      'data-radius': '0'
    },
    selectable: true,
    hoverable: true,
    components: [
      {
        tagName: 'img',
        attributes: {
          class: 'circle-image',
          src: DEFAULT_CIRCLE_IMAGE,
          alt: ''
        },
        draggable: false,
        selectable: false,
        hoverable: false,
        droppable: false
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="10" stroke="white" stroke-width="1.5"/>
    <circle cx="12" cy="9" r="3" fill="white"/>
    <path d="M6.5 19c.8-3.8 2.7-5.7 5.5-5.7s4.7 1.9 5.5 5.7" fill="white"/>
  </svg>`,
  traits: [
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'Select Image',
      type: 'select-icon',
      changeProp: true,
      value: ''
    },
    {
      id: 'radius',
      name: 'radius',
      label: 'Radius',
      type: 'number',
      changeProp: true,
      value: 0,
      min: 0,
      max: 999,
      step: 1
    }
  ],
  styles: `
    .circle-image-wrapper {
      position: relative;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 112px;
      height: 112px;
      min-width: 48px;
      min-height: 48px;
      padding: 0;
      margin: 0;
      overflow: hidden;
      box-sizing: border-box;
      background-color: transparent;
      background-image: url('${DEFAULT_CIRCLE_IMAGE}');
      background-position: center;
      background-repeat: no-repeat;
      background-size: contain;
    }
    .circle-image {
      display: block;
      width: 100%;
      height: 100%;
      min-width: 0;
      min-height: 0;
      object-fit: cover;
      border: 0;
      box-shadow: none;
      pointer-events: none;
      user-select: none;
    }
  `,
  script: `
    (function () {
      if (!model || !model.getEl || !model.getEl()) return;

      var root = model.getEl();
      var img = root.querySelector('.circle-image');
      var fallbackImage = '${DEFAULT_CIRCLE_IMAGE}';

      var failedSrc = '';

      function traitValue(name, fallback) {
        var trait = model.getTrait && model.getTrait(name);
        var value = trait && trait.getValue ? trait.getValue() : undefined;
        if (value === undefined || value === null || value === '') {
          value = model.get ? model.get(name) : undefined;
        }
        return value === undefined || value === null || value === '' ? fallback : value;
      }

      function normaliseRadius(value) {
        var parsed = Number(value);
        return Number.isFinite(parsed) ? Math.max(0, parsed) : 0;
      }

      function normaliseSource(value) {
        var src = String(value || '').trim();
        return !src || src === 'undefined' || src === 'null' ? '' : src;
      }

      function syncImageComponent(src) {
        var imageComponent = model.find && model.find('.circle-image')[0];
        if (!imageComponent || !imageComponent.getAttributes) return;
        var current = imageComponent.getAttributes();
        if (current.src !== src) imageComponent.addAttributes({ src: src });
      }

      function render() {
        if (!img) return;
        var attrs = model.getAttributes ? model.getAttributes() : {};
        var selected = normaliseSource(traitValue('selectImage', ''));
        var stored = normaliseSource(attrs['data-image']);
        var requestedSrc = selected || stored || fallbackImage;
        var src = requestedSrc === failedSrc ? fallbackImage : requestedSrc;
        var radius = normaliseRadius(traitValue('radius', attrs['data-radius'] || 0));

        root.style.borderRadius = radius + 'px';
        root.style.backgroundImage = 'url("' + fallbackImage + '")';
        img.style.borderRadius = radius + 'px';
        if (img.getAttribute('src') !== src) img.setAttribute('src', src);
        syncImageComponent(src);

        model.addAttributes({
          'data-image': src,
          'data-radius': String(radius)
        }, { silent: true });
      }

      if (model.__stage15CircleImageCleanup) model.__stage15CircleImageCleanup();
      var onUpdate = function () { render(); };
      model.on('change:selectImage', onUpdate);
      model.on('change:radius', onUpdate);
      model.on('change:traits', onUpdate);
      model.on('change:attributes', onUpdate);
      model.on('active', onUpdate);
      model.__stage15CircleImageCleanup = function () {
        model.off('change:selectImage', onUpdate);
        model.off('change:radius', onUpdate);
        model.off('change:traits', onUpdate);
        model.off('change:attributes', onUpdate);
        model.off('active', onUpdate);
      };

      if (img) {
        img.onerror = function () {
          var broken = normaliseSource(img.getAttribute('src'));
          if (!broken || broken === fallbackImage) return;
          failedSrc = broken;
          var trait = model.getTrait && model.getTrait('selectImage');
          if (trait && trait.getValue && trait.setValue && normaliseSource(trait.getValue()) === broken) {
            trait.setValue('');
          }
          model.addAttributes({ 'data-image': fallbackImage }, { silent: true });
          img.setAttribute('src', fallbackImage);
          syncImageComponent(fallbackImage);
        };
      }

      render();
    })();
  `
};
