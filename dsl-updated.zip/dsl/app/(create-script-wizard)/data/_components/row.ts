import { getActiveEditor } from '@/src/editor/editorRegistry';
import { ComponentConfig } from '../elements';

export const Row: ComponentConfig = {
  id: 'row',
  type: 'row',
  label: 'Row',
  category: 'Main',
  content: {
    tagName: 'div',
    attributes: {
      class: 'mui-row-wrapper',
      'data-component-id': 'row',
      'data-row-height': '120px'
    },
    components: [
      {
        type: 'column-subcolumn',
        tagName: 'div',
        attributes: {
          class: 'mui-column-subcolumn',
          'data-subcolumn-id': 'subcolumn-1'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 50,
          maxDim: 1200,
          updateTarget: (el, rect) => {
            const width = Number(rect.width ?? rect.w ?? 0);
            const height = Number(rect.height ?? rect.h ?? 0);
            const size = Math.max(width, height);
            const clampedSize = Math.max(50, Math.min(1200, size));

            el.style.width = clampedSize + 'px';
            el.style.height = clampedSize + 'px';
            el.style.minWidth = clampedSize + 'px';
            el.style.minHeight = clampedSize + 'px';
            el.style.aspectRatio = '1/1';

            const editor = getActiveEditor();
            if (editor) {
              const component = editor.getSelected();
              if (component && component.getEl() === el) {
                const styles = {
                  width: clampedSize + 'px',
                  height: clampedSize + 'px',
                  'min-width': clampedSize + 'px',
                  'min-height': clampedSize + 'px',
                  'aspect-ratio': '1/1'
                };

                component.setStyle(styles);
                component.trigger('change:style');

                component.addAttributes({
                  'data-custom-width': clampedSize + 'px',
                  'data-custom-height': clampedSize + 'px'
                });
              }
            }
          }
        }
      },
      {
        type: 'column-subcolumn',
        tagName: 'div',
        attributes: {
          class: 'mui-column-subcolumn',
          'data-subcolumn-id': 'subcolumn-2'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 50,
          maxDim: 1200,
          updateTarget: (el, rect) => {
            const width = Number(rect.width ?? rect.w ?? 0);
            const height = Number(rect.height ?? rect.h ?? 0);
            const size = Math.max(width, height);
            const clampedSize = Math.max(50, Math.min(1200, size));

            console.log('Resizing subcolumn to:', clampedSize + 'px');

            el.style.width = clampedSize + 'px';
            el.style.height = clampedSize + 'px';
            el.style.minWidth = clampedSize + 'px';
            el.style.minHeight = clampedSize + 'px';
            el.style.aspectRatio = '1/1';

            const editor = getActiveEditor();
            if (editor) {
              const component = editor.getSelected();
              if (component && component.getEl() === el) {
                const styles = {
                  width: clampedSize + 'px',
                  height: clampedSize + 'px',
                  'min-width': clampedSize + 'px',
                  'min-height': clampedSize + 'px',
                  'aspect-ratio': '1/1'
                };

                component.setStyle(styles);
                component.trigger('change:style');

                component.addAttributes({
                  'data-custom-width': clampedSize + 'px',
                  'data-custom-height': clampedSize + 'px'
                });
              }
            }
          }
        }
      },
      {
        type: 'column-subcolumn',
        tagName: 'div',
        attributes: {
          class: 'mui-column-subcolumn',
          'data-subcolumn-id': 'subcolumn-3'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 50,
          maxDim: 1200,
          updateTarget: (el, rect) => {
            const width = Number(rect.width ?? rect.w ?? 0);
            const height = Number(rect.height ?? rect.h ?? 0);
            const size = Math.max(width, height);
            const clampedSize = Math.max(50, Math.min(1200, size));

            el.style.width = clampedSize + 'px';
            el.style.height = clampedSize + 'px';
            el.style.minWidth = clampedSize + 'px';
            el.style.minHeight = clampedSize + 'px';
            el.style.aspectRatio = '1/1';

            const editor = getActiveEditor();
            if (editor) {
              const component = editor.getSelected();
              if (component && component.getEl() === el) {
                const styles = {
                  width: clampedSize + 'px',
                  height: clampedSize + 'px',
                  'min-width': clampedSize + 'px',
                  'min-height': clampedSize + 'px',
                  'aspect-ratio': '1/1'
                };

                component.setStyle(styles);
                component.trigger('change:style');

                component.addAttributes({
                  'data-custom-width': clampedSize + 'px',
                  'data-custom-height': clampedSize + 'px'
                });

                console.log('Styles saved to model:', styles);
              }
            }
          }
        }
      },
      {
        type: 'column-subcolumn',
        tagName: 'div',
        attributes: {
          class: 'mui-column-subcolumn',
          'data-subcolumn-id': 'subcolumn-4'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 50,
          maxDim: 1200,
          updateTarget: (el, rect) => {
            const width = Number(rect.width ?? rect.w ?? 0);
            const height = Number(rect.height ?? rect.h ?? 0);
            const size = Math.max(width, height);
            const clampedSize = Math.max(50, Math.min(1200, size));

            el.style.width = clampedSize + 'px';
            el.style.height = clampedSize + 'px';
            el.style.minWidth = clampedSize + 'px';
            el.style.minHeight = clampedSize + 'px';
            el.style.aspectRatio = '1/1';

            const editor = getActiveEditor();
            if (editor) {
              const component = editor.getSelected();
              if (component && component.getEl() === el) {
                const styles = {
                  width: clampedSize + 'px',
                  height: clampedSize + 'px',
                  'min-width': clampedSize + 'px',
                  'min-height': clampedSize + 'px',
                  'aspect-ratio': '1/1'
                };

                component.setStyle(styles);
                component.trigger('change:style');

                component.addAttributes({
                  'data-custom-width': clampedSize + 'px',
                  'data-custom-height': clampedSize + 'px'
                });

                console.log('Styles saved to model:', styles);
              }
            }
          }
        }
      }
    ],
    droppable: true,
    editable: true,
    selectable: true,
    draggable: '.container-wrapper, div',
    resizable: {
      cr: true,
      bc: true,
      minDim: 50,
      maxDim: 2000,
      updateTarget: (el: HTMLElement, rect: any) => {
        el.style.height = `${rect.h}px`;
        el.style.width = `${rect.w}px`;
      }
    }
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path opacity="0.4" d="M10.5 19.9V4.1C10.5 2.6 9.86 2 8.27 2H4.23C2.64 2 2 2.6 2 4.1V19.9C2 21.4 2.64 22 4.23 22H8.27C9.86 22 10.5 21.4 10.5 19.9Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M22 19.9V4.1C22 2.6 21.36 2 19.77 2H15.73C14.14 2 13.5 2.6 13.5 4.1V19.9C13.5 21.4 14.14 22 15.73 22H19.77C21.36 22 22 21.4 22 19.9Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`,
  traits: [
    {
      id: 'subcolumns',
      name: 'subcolumns',
      type: 'number',
      label: 'Number of Cell in Row',
      min: 1,
      max: 12,
      value: 4,
      changeProp: true
    },
    {
      id: 'spacing',
      name: 'spacing',
      type: 'number',
      label: 'Gap',
      min: 0,
      max: 32,
      value: 16,
      changeProp: true,
      units: ['px', '%']
    },
    {
      id: 'scrollable',
      name: 'scrollable',
      type: 'switch',
      label: 'Scrollable',
      value: false,
      changeProp: true
    },
    {
      id: 'minMax',
      name: 'minMax',
      type: 'select',
      label: 'Size',
      options: [
        { id: 'min', name: 'min', value: 'min' },
        { id: 'max', name: 'max', value: 'max' }
      ],
      value: 'min',
      changeProp: true
    },
    {
      id: 'main-axis-alignment',
      name: 'main-axis-alignment',
      type: 'select',
      label: 'Main Axis Alignment',
      options: [
        {
          value: 'flex-start',
          label: 'Start',
          icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 22V2H4V22H2ZM13 17V7H16V17H13ZM7 17V7H10V17H7Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        },
        {
          value: 'flex-end',
          label: 'End',
          icon: `<svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 20V0H14V20H12ZM6 15V5H9V15H6ZM0 15V5H3V15H0Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        },
        {
          value: 'center',
          label: 'Center',
          icon: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 20V15H15V5H18V0H20V20H18ZM0 20V0H2V5H5V15H2V20H0Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        },
        {
          value: 'space-between',
          label: 'Space Between',
          icon: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 20V0H20V20H18ZM0 20V0H2V20H0ZM13 15V5H16V15H13ZM4 15V5H7V15H4Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        },
        {
          value: 'space-around',
          label: 'Space Around',
          icon: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 20V0H20V20H18ZM0 20V0H2V20H0ZM11 15V10V5H14V15H11ZM6 15V10V5H9V10V15H6Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        }
      ],
      value: 'flex-start',
      changeProp: true
    },
    {
      id: 'cross-axis-alignment',
      name: 'cross-axis-alignment',
      type: 'select',
      label: 'Cross Axis Alignment',
      options: [
        {
          value: 'flex-start',
          label: 'Start',
          icon: `<svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 0L20 0V2L0 2V0Z" fill="white"/>
                <path d="M0 17L20 17V19L0 19V17Z" fill="white"/>
                <path d="M9 2L9 7V12H6L6 7V2H9ZM13 2L13 7V12H10V7L10 2H13Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        },
        {
          value: 'center',
          label: 'Center',
          icon: `<svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 19H0L0 17H20V19Z" fill="white"/>
                <path d="M20 2L0 2L0 0L20 0V2Z" fill="white"/>
                <path d="M11 17V12V7H14V12V17H11ZM7 17V12V7H10V12V17H7Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        },
        {
          value: 'flex-end',
          label: 'End',
          icon: `<svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 0L20 0V2L0 2V0Z" fill="white"/>
                <path d="M0 17L20 17V19L0 19V17Z" fill="white"/>
                <path d="M10 2L10 9.5V17H7L7 9.5L7 2H10ZM14 2V9.5L14 17H11V9.5L11 2H14Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        },
        {
          value: 'stretch',
          label: 'Stretch',
          icon: `<svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 0L20 0V2L0 2V0Z" fill="white"/>
                <path d="M0 17L20 17V19L0 19V17Z" fill="white"/>
                <path d="M10 4L10 9.5V15H7L7 9.5L7 4H10ZM14 4L14 9.5V15H11V9.5L11 4H14Z" fill="white"/>
              </svg>`,
          id: '',
          name: ''
        }
      ],
      value: 'stretch',
      changeProp: true
    }
  ],
  styles: `
    .mui-row-wrapper {
      --order: 0;
    --flex-grow: 1;
    --flex-shrink: 1;
    --flex-basis: auto;
    --align-self: stretch;
    --grid-column-start: 1;
    --grid-column-end: 1;
    --grid-row-start: 1;
    --grid-row-end: 1;
    --justify-self: start;
    --text-align: left;
    --position: relative; 
    --top: auto;
    --right: auto;
    --bottom: auto;
    --left: auto;
    --z-index: auto;
    --grid-template-columns: 1fr;
    --grid-template-rows: 1fr;
    --column-gap: 0;
    --row-gap: 0;
    --justify-items: stretch;
    --justify-content: stretch;
    --align-items: stretch;
    --width: 100%;
    --height: 100%;
    --min-width: 50px;
    --min-height: 50px;
    --max-width: 100%;
    --max-height: 100%;
    --display: flex;
    
    order: var(--order);
    flex-grow: var(--flex-grow);
    flex-shrink: var(--flex-shrink);
    flex-basis: var(--flex-basis);
    align-self: var(--align-self);
    
    grid-column-start: var(--grid-column-start);
    grid-column-end: var(--grid-column-end);
    grid-row-start: var(--grid-row-start);
    grid-row-end: var(--grid-row-end);
    justify-self: var(--justify-self);
    justify-items: var(--justify-items);
    justify-content: var(--justify-content);
    align-items: var(--align-items);
    
    text-align: var(--text-align);
    position: var(--position);
    top: var(--top);
    right: var(--right);
    bottom: var(--bottom);
    left: var(--left);
    z-index: var(--z-index);
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        
        /* Размеры и отступы */
        width: auto;
        min-height: 120px;
        padding: 16px;
        box-sizing: border-box;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        overflow-y: hidden; 
        overflow-x: hidden;
        -webkit-overflow-scrolling: touch;
        position: relative;
        z-index: auto;
    }

    .scrollable-row { 
        overflow-x: auto !important; 
        flex-wrap: nowrap !important;
        width: 100% !important; 
        -ms-overflow-style: none !important; 
        scrollbar-width: none !important; 
    }
    
    .scrollable-row::-webkit-scrollbar { 
        display: none !important; 
    }

    .mui-column-subcolumn {
        color: #ffffff;
        padding: 16px;
        border-radius: 4px;
        box-sizing: border-box;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
        transition: transform 0.2s, box-shadow 0.2s;

        flex: 1 1 0; 
        min-width: 50px;
        min-height: 50px;
        
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1;
    }

    .mui-column-subcolumn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4);
    }
    
    .gjs-resizer {
        z-index: 10000 !important;
    }
`,
  script: `
    function updateRow(model) {
        const wrapper = model.getEl();
        if (!wrapper) return;

        // 1. Читаем трейты и стили
        const subcolumns = parseInt(model.getTrait('subcolumns')?.getValue() || '4', 10);
        const spacing = parseInt(model.getTrait('spacing')?.getValue() || '16', 10);
        const scrollable = model.getTrait('scrollable')?.getValue() || false;
        
        // Проверяем как прямую настройку, так и переменную (на случай старых конфигов)
        const style = model.getStyle();
        const display = style.display || style['--display'] || getComputedStyle(wrapper).display;
        const isGrid = display === 'grid';

        // 2. Управление классами и базовыми стилями
        if (isGrid) {
            wrapper.classList.add('mui-row-grid-mode');
            wrapper.classList.remove('scrollable-row');
            
            // Если сетка не задана явно, ставим дефолт
            if (!style['grid-template-columns']) {
                wrapper.style.gridTemplateColumns = \`repeat(\${subcolumns}, 1fr)\`;
            }
            // Gap в Grid
            wrapper.style.gap = spacing + 'px';
            
            // В Grid только обновляем количество, размеры считает CSS
            updateChildCount(model, subcolumns);
            
        } else {
            // Flex режим
            wrapper.classList.remove('mui-row-grid-mode');
            wrapper.style.gap = spacing + 'px'; // Gap во Flex
            
            if (scrollable) {
                wrapper.classList.add('scrollable-row');
                wrapper.style.width = '100%';
                updateChildCount(model, subcolumns);
            } else {
                wrapper.classList.remove('scrollable-row');
                wrapper.style.width = '100%'; // Flex на всю ширину
                // Считаем ширину колонок математически
                updateFlexColumns(model, subcolumns, spacing);
            }
        }
    }

    function updateChildCount(model, count) {
        const currentItems = model.find('.mui-column-subcolumn');
        const diff = count - currentItems.length;
        
        if (diff > 0) {
             for(let i=0; i<diff; i++) {
                 model.append({ 
                    type: 'column-subcolumn', 
                    tagName: 'div', 
                    attributes: { class: 'mui-column-subcolumn' }
                 });
             }
        } else if (diff < 0) {
             const toRemove = currentItems.slice(currentItems.length + diff);
             toRemove.forEach(item => item.remove());
        }
    }

    function updateFlexColumns(model, count, spacing) {
        updateChildCount(model, count);
        const widthCalc = \`calc((100% - \${(count - 1) * spacing}px) / \${count})\`;
        
        model.find('.mui-column-subcolumn').forEach(item => {
             const el = item.getEl();
             // Если нет ручного ресайза, ставим авто-ширину
             if (el && !item.getStyle().width) {
                 el.style.flex = \`0 0 \${widthCalc}\`;
                 el.style.maxWidth = widthCalc;
             }
        });
    }

    if (model.getEl()) setTimeout(() => updateRow(model), 0);

    model.on('change:attributes:data-subcolumns change:attributes:data-spacing change:attributes:data-scrollable', () => updateRow(model));
    
    // Важно: слушаем изменение свойства display
    model.on('change:style:display', () => setTimeout(() => updateRow(model), 10));
`,

  styleConfig: {
    sectors: [
      {
        id: 'flex-children',
        name: 'Flex-Children',
        open: true,
        properties: [
          {
            id: 'flex-order-type',
            name: 'Flex Order Type',
            property: 'order-type', // UI Only
            type: 'radio',
            default: '0',
            options: [
              { id: 'type1', label: 'Type 1', name: '', value: '' },
              { id: 'type2', label: 'Type 2', name: '', value: '' }
            ]
          },
          {
            id: 'order',
            name: 'Order',
            property: '--order',
            type: 'number',
            default: '0'
          },
          {
            id: 'flex-grow-shrink-group',
            name: 'Flex Shrink/Grow',
            type: 'composite',
            property: 'flex-group',
            properties: [
              {
                id: 'flex-basis',
                name: 'Basis',
                property: '--flex-basis',
                type: 'number',
                default: 'auto'
              },
              {
                id: 'flex-shrink',
                name: 'Shrink',
                property: '--flex-shrink',
                type: 'number',
                default: '1'
              },
              {
                id: 'flex-grow',
                name: 'Grow',
                property: '--flex-grow',
                type: 'number',
                default: '0'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align Self',
            property: 'align-self',
            type: 'radio',
            default: 'auto',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'flex-start' },
              { id: 'end', label: 'End', name: '', value: 'flex-end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' }
            ]
          },
          {
            id: 'justify-self',
            name: 'Justify Self',
            property: 'justify-self',
            type: 'radio',
            default: 'start',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'start' },
              { id: 'end', label: 'End', name: '', value: 'end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' },
              { id: 'auto', label: 'Auto', name: '', value: 'auto' }
            ]
          },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: '--justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: '--align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              { id: 'stretch', label: 'Stretch', value: 'stretch', name: '' },
              { id: 'baseline', label: 'Baseline', value: 'baseline', name: '' }
            ]
          }
        ]
      },
      {
        id: 'grid-parent',
        name: 'Grid-Parent',
        open: true,
        properties: [
          {
            id: 'grid-template-columns',
            name: 'Columns',
            property: '--grid-template-columns',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-template-rows',
            name: 'Rows',
            property: '--grid-template-rows',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-column-gap',
            name: 'Gap Column',
            property: '--column-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '0'
          },
          {
            id: 'grid-row-gap',
            name: 'Gap Row',
            property: 'row-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '0'
          },
          {
            id: 'justify-items',
            name: 'Justify Items',
            property: '--justify-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'normal',
                label: 'Normal',
                value: 'normal',
                name: ''
              }
            ]
          },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: '--justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: '--align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-grid',
        name: 'Grid-Children',
        open: true,
        properties: [
          {
            id: 'grid-column-start',
            name: 'Start Column',
            property: '--grid-column-start',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-column-end',
            name: 'End Column',
            property: '--grid-column-end',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-row-start',
            name: 'Start Row',
            property: '--grid-row-start',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-row-end',
            name: 'End Row',
            property: '--grid-row-end',
            type: 'number',
            default: '1'
          },
          {
            id: 'justify-self',
            name: 'Justify-Self',
            property: '--justify-self',
            type: 'radio',
            default: 'start',
            options: [
              {
                id: 'start',
                label: 'Start',
                name: '',
                value: 'start'
              },
              {
                id: 'end',
                label: 'End',
                name: '',
                value: 'end'
              },
              {
                id: 'stretch',
                label: 'Stretch',
                name: '',
                value: 'stretch'
              },
              {
                id: 'center',
                label: 'Center',
                name: '',
                value: 'center'
              },
              {
                id: 'auto',
                label: 'Auto',
                name: '',
                value: 'auto'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align-Self',
            property: '--align-self',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-position',
        name: 'Position',
        open: true,
        properties: [
          {
            id: 'text-align',
            name: 'Align',
            property: '--text-align', // ПЕРЕМЕННАЯ
            type: 'radio',
            default: 'left',
            options: [
              {
                id: 'left',
                label: 'Left',
                value: 'left',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'right',
                label: 'Right',
                value: 'right',
                name: ''
              }
            ]
          },
          {
            id: 'position',
            name: 'Position',
            property: '--position', // ПЕРЕМЕННАЯ
            type: 'select',
            default: 'relative', // Дефолт в CSS
            options: [
              {
                id: 'static',
                label: 'Static',
                value: 'static',
                name: ''
              },
              {
                id: 'relative',
                label: 'Relative',
                value: 'relative',
                name: ''
              },
              {
                id: 'absolute',
                label: 'Absolute',
                value: 'absolute',
                name: ''
              },
              {
                id: 'fixed',
                label: 'Fixed',
                value: 'fixed',
                name: ''
              },
              {
                id: 'sticky',
                label: 'Sticky',
                value: 'sticky',
                name: ''
              }
            ]
          },
          {
            id: 'top',
            name: 'Top',
            property: '--top', // ПЕРЕМЕННАЯ
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'right',
            name: 'Right',
            property: '--right', // ПЕРЕМЕННАЯ
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'left',
            name: 'Left',
            property: '--left', // ПЕРЕМЕННАЯ
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'bottom',
            name: 'Bottom',
            property: '--bottom', // ПЕРЕМЕННАЯ
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'display',
            name: 'Display',
            property: 'display',
            type: 'select',
            default: 'flex',
            options: [
              { value: 'flex', name: 'Flex', id: 'flex' },
              { value: 'grid', name: 'Grid', id: 'grid' },
              { value: 'block', name: 'Block', id: 'block' },
              {
                value: 'inline-block',
                name: 'Inline Block',
                id: 'inline-block'
              }
            ]
          }
        ]
      }
    ]
  }
};
