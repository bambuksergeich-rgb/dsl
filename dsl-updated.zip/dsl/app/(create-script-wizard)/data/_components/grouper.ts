import { ComponentConfig } from '../elements';

export const Grouper: ComponentConfig = {
  id: 'grouper',
  type: 'grouper',
  label: 'Grouper',
  category: 'Containers',
  content: {
    tagName: 'div',
    attributes: { class: 'grouper-wrapper', 'data-type': 'default' },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'grouper-header' },
        content: '<span class="grouper-title">Panel</span>',
        selectable: false,
        draggable: false,
        hoverable: true
      },
      {
        tagName: 'div',
        attributes: { class: 'grouper-content' },
        content: '',
        droppable: true,
        editable: true,
        selectable: false,
        draggable: false
      },
      {
        tagName: 'canvas',
        attributes: { class: 'grouper-canvas' }
      }
    ],
    droppable: false,
    selectable: false,
    draggable: false,
    editable: true
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g clip-path="url(#clip0_131_18220)">
  <path d="M11.9998 5.34002C13.0547 5.34002 13.9098 4.48488 13.9098 3.43002C13.9098 2.37516 13.0547 1.52002 11.9998 1.52002C10.945 1.52002 10.0898 2.37516 10.0898 3.43002C10.0898 4.48488 10.945 5.34002 11.9998 5.34002Z" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
  <path d="M9.14062 8.19997C9.14062 7.44145 9.44195 6.71399 9.9783 6.17764C10.5147 5.64129 11.2421 5.33997 12.0006 5.33997C12.7591 5.33997 13.4866 5.64129 14.023 6.17764C14.5593 6.71399 14.8606 7.44145 14.8606 8.19997" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
  <path d="M19.6405 20.61C20.6953 20.61 21.5505 19.7549 21.5505 18.7C21.5505 17.6452 20.6953 16.79 19.6405 16.79C18.5856 16.79 17.7305 17.6452 17.7305 18.7C17.7305 19.7549 18.5856 20.61 19.6405 20.61Z" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
  <path d="M16.7695 23.48C16.7695 22.7188 17.0719 21.9888 17.6101 21.4506C18.1484 20.9124 18.8784 20.61 19.6395 20.61C20.399 20.6126 21.1264 20.9162 21.6625 21.4541C22.1985 21.9921 22.4995 22.7205 22.4995 23.48" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
  <path d="M4.35922 20.61C5.41408 20.61 6.26922 19.7549 6.26922 18.7C6.26922 17.6452 5.41408 16.79 4.35922 16.79C3.30436 16.79 2.44922 17.6452 2.44922 18.7C2.44922 19.7549 3.30436 20.61 4.35922 20.61Z" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
  <path d="M1.5 23.48C1.5 22.7205 1.801 21.9921 2.33706 21.4541C2.87313 20.9162 3.60056 20.6126 4.36 20.61C5.12117 20.61 5.85117 20.9124 6.3894 21.4506C6.92763 21.9888 7.23 22.7188 7.23 23.48" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
  <path d="M12 9.16003V13.93" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
  <path d="M8.17969 16.8001L11.9997 13.9301L15.8197 16.8001" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
  </g>
  <defs>
  <clipPath id="clip0_131_18220">
  <rect width="24" height="24" fill="white"/>
  </clipPath>
  </defs>
  </svg>
  `,
  traits: [
    {
      id: 'title',
      name: 'title',
      label: 'Title',
      type: 'text',
      changeProp: true,
      value: 'Panel'
    },
    {
      id: 'type',
      name: 'type',
      label: 'Type',
      type: 'select',
      options: [
        { id: 'default', name: 'default', value: 'default' },
        { id: 'alternative', name: 'alternative', value: 'alternative' }
      ],
      value: 'default',
      changeProp: true
    }
  ],
  styles: `
    .grouper-wrapper {
      width: 440px;
      height: 244px;
      position: relative;
      font-family: 'Montserrat', sans-serif;
      transition: height 0.3s ease;
      box-sizing: border-box;
    }
    .grouper-wrapper[data-type="alternative"] {
      height: calc(244px - 2.5px * 2);
    }
    .grouper-header {
      height: 58px;
      display: flex;
      align-items: center;
      padding: 0 16px;
      position: relative;
      z-index: 2;
      transition: height 0.3s ease;
      border-bottom: 2.5px solid #3D3AB8;
    }
    .grouper-wrapper[data-type="alternative"] .grouper-header {
      height: 0;
      padding: 0;
      border: none;
    }
    .grouper-title {
      color: #FFFFFF;
      font-size: 20px;
      font-weight: 500;
      position: absolute;
      top: 16px;
      left: 16px;
      right: 16px;
      z-index: 3;
      transition: all 0.3s ease;
    }
    .grouper-wrapper[data-type="alternative"] .grouper-title {
      top: 0px;
      font-size: 20px;
      left: 12px;
      right: auto;
      padding: 0 4px;
      color: #FFFFFF;
      transform: translateY(-50%);
      background: transparent;
    }
    .grouper-content {
      padding: 16px;
      height: calc(244px - 58px - 2.5px * 2);
      overflow-y: auto;
      display: block;
      transition: height 0.3s ease;
      position: relative;
      z-index: 2;
    }
    .grouper-wrapper[data-type="alternative"] .grouper-content {
      height: calc(244px - 2.5px * 2);
      padding-top: 24px;
    }
    .grouper-canvas {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
    }
  `,
  script: `
    function updateGrouper(model, editor) {
      if (!model || !model.getEl() || !editor) {
        console.error('No model, editor, or wrapper element');
        return;
      }
      const wrapper = model.getEl();
      const titleEl = wrapper.querySelector('.grouper-title');
      const canvas = wrapper.querySelector('.grouper-canvas');
      const ctx = canvas.getContext('2d');
      const traits = model.getTraits();
      
      // Update canvas size
      canvas.width = wrapper.offsetWidth;
      canvas.height = wrapper.offsetHeight;

      // Update title
      const title = traits.find(t => t.getName() === 'title')?.getValue() || 'Panel';
      titleEl.textContent = title;

      // Update type
      const type = traits.find(t => t.getName() === 'type')?.getValue() || 'default';
      wrapper.setAttribute('data-type', type);

      // Draw border
      function drawBorder() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#3D3AB8';
        ctx.lineWidth = 2.5;

        if (type === 'alternative') {
          const titleRect = titleEl.getBoundingClientRect();
          const wrapperRect = wrapper.getBoundingClientRect();
          const labelX = titleRect.left - wrapperRect.left;
          const labelWidth = titleRect.width;

          // Draw rounded border with gap for title
          const radius = 12;
          ctx.beginPath();
          ctx.moveTo(0, radius);
          ctx.arcTo(0, 0, radius, 0, radius);
          ctx.lineTo(labelX, 0);
          ctx.moveTo(labelX + labelWidth, 0);
          ctx.lineTo(canvas.width - radius, 0);
          ctx.arcTo(canvas.width, 0, canvas.width, radius, radius);
          ctx.lineTo(canvas.width, canvas.height - radius);
          ctx.arcTo(canvas.width, canvas.height, canvas.width - radius, canvas.height, radius);
          ctx.lineTo(radius, canvas.height);
          ctx.arcTo(0, canvas.height, 0, canvas.height - radius, radius);
          ctx.lineTo(0, radius);
          ctx.stroke();
        } else {
          // Draw full rounded border for default type
          const radius = 12;
          ctx.beginPath();
          ctx.moveTo(0, radius);
          ctx.arcTo(0, 0, radius, 0, radius);
          ctx.lineTo(canvas.width - radius, 0);
          ctx.arcTo(canvas.width, 0, canvas.width, radius, radius);
          ctx.lineTo(canvas.width, canvas.height - radius);
          ctx.arcTo(canvas.width, canvas.height, canvas.width - radius, canvas.height, radius);
          ctx.lineTo(radius, canvas.height);
          ctx.arcTo(0, canvas.height, 0, canvas.height - radius, radius);
          ctx.closePath();
          ctx.stroke();
        }
      }

      drawBorder();

      // Handle resize
      const resizeObserver = new ResizeObserver(() => {
        canvas.width = wrapper.offsetWidth;
        canvas.height = wrapper.offsetHeight;
        drawBorder();
      });
      resizeObserver.observe(wrapper);

      console.log('Grouper updated:', { title, type });
    }

    if (model && model.getEl()) {
      updateGrouper(model, editor);
    } else {
      console.error('Model or element not available');
    }

    model.on('change:title change:type', () => {
      updateGrouper(model, editor);
    });
  `,
  styleConfig: {
    sectors: [
      {
        id: 'Dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '440',
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: '244',
            units: ['px', '%']
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            default: '0',
            units: ['px', '%']
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            default: '0',
            units: ['px', '%']
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            default: 'none',
            units: ['px', '%']
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            default: 'none',
            units: ['px', '%']
          }
        ]
      }
    ]
  }
};
