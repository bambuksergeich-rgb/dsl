import { ComponentConfig } from '../elements';

export const Tabs: ComponentConfig = {
  id: 'tabs',
  type: 'tabs',
  label: 'Tabs',
  category: 'Main',
  content: {
    tagName: 'div',
    attributes: { class: 'tabs-wrapper' },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'tabs-nav' },
        components: [
          {
            tagName: 'button',
            attributes: { class: 'tab-button active', 'data-tab': 'tab1' },
            content: 'Tab 1',
            droppable: true,
            draggable: false,
            selectable: true
          },
          {
            tagName: 'button',
            attributes: { class: 'tab-button', 'data-tab': 'tab2' },
            content: 'Tab 2',
            droppable: true,
            draggable: false,
            selectable: true
          }
        ],
        droppable: true,
        draggable: false,
        selectable: true
      },
      {
        tagName: 'div',
        attributes: { class: 'tabs-content' },
        components: [
          {
            tagName: 'div',
            attributes: { class: 'tab-pane active', 'data-tab': 'tab1' },
            components: [
              {
                type: 'container',
                tagName: 'div',
                content: 'Content for Tab 1',
                attributes: { class: 'placeholder-text' },
                droppable: true,
                draggable: false,
                selectable: true
              }
            ],
            droppable: true,
            draggable: false
          },
          {
            type: 'container',
            tagName: 'div',
            attributes: { class: 'tab-pane', 'data-tab': 'tab2' },
            components: [
              {
                tagName: 'div',
                content: 'Content for Tab 2',
                attributes: { class: 'placeholder-text' },
                droppable: true,
                draggable: false,
                selectable: true
              }
            ],
            droppable: true,
            draggable: false
          }
        ],
        droppable: false,
        draggable: false
      }
    ]
  },
  block: true,
  icon: '<svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.75 3.5C5.02065 3.5 4.32118 3.78973 3.80546 4.30546C3.28973 4.82118 3 5.52065 3 6.25V18.75C3 19.4793 3.28973 20.1788 3.80546 20.6945C4.32118 21.2103 5.02065 21.5 5.75 21.5H18.25C18.9793 21.5 19.6788 21.2103 20.1945 20.6945C20.7103 20.1788 21 19.4793 21 18.75V6.25C21 5.52065 20.7103 4.82118 20.1945 4.30546C19.6788 3.78973 18.9793 3.5 18.25 3.5H5.75ZM11 5V6.25C11 6.84674 11.2371 7.41903 11.659 7.84099C12.081 8.26295 12.6533 8.5 13.25 8.5H19.5V18.75C19.5 19.44 18.94 20 18.25 20H5.75C5.06 20 4.5 19.44 4.5 18.75V6.25C4.5 5.56 5.06 5 5.75 5H11ZM19.5 7H13.25C13.0511 7 12.8603 6.92098 12.7197 6.78033C12.579 6.63968 12.5 6.44891 12.5 6.25V5H18.25C18.94 5 19.5 5.56 19.5 6.25V7Z" fill="white"/></svg>',
  traits: [
    // {
    //   id: 'tabs-count',
    //   name: 'tabs-count',
    //   type: 'number',
    //   label: 'Number of Tabs',
    //   min: 1,
    //   max: 10,
    //   changeProp: true,
    //   value: 2
    // },
    {
      id: 'tabs',
      name: 'tabs',
      type: 'list',
      label: 'Tabs',
      changeProp: true,
      value: JSON.stringify([
        { id: 'tab1', label: 'Tab 1' },
        { id: 'tab2', label: 'Tab 2' }
      ]),
      default: JSON.stringify([
        { id: 'tab1', label: 'Tab 1' },
        { id: 'tab2', label: 'Tab 2' }
      ])
    },

    {
      id: 'orientation',
      name: 'orientation',
      type: 'select',
      label: 'Type',
      options: [
        { id: 'horizontal', value: 'horizontal', name: 'Horizontal' },
        { id: 'vertical', value: 'vertical', name: 'Vertical' },
        {
          id: 'horizontal-custom',
          value: 'horizontal-custom',
          name: 'Horizontal Custom Tabs'
        },
        {
          id: 'vertical-custom',
          value: 'vertical-custom',
          name: 'Vertical Custom Tabs'
        }
      ],
      value: 'horizontal',
      changeProp: true
    }
  ],
  styleConfig: {
    sectors: [
      {
        id: 'dimension',
        name: 'Tab Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '100%',
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          }
        ]
      },
      {
        id: 'tab-style',
        name: 'Tab Text',
        open: false,
        properties: [
          {
            id: 'tab-font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: '16',
            units: ['px']
          },
          {
            id: 'tab-color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  },
  styles: `
  .tabs-wrapper {
    width: 100%;
    min-height: 300px;
    background-color: #10161C80;
    border: 2px solid #3D3AB8;
    border-radius: 12px;
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    font-family: 'Montserrat', sans-serif;
  }

  /* Горизонтальные и вертикальные вкладки */
  .tabs-wrapper[data-orientation="vertical"],
  .tabs-wrapper[data-orientation="vertical-custom"] {
    flex-direction: row;
  }

  /* Навигация при вертикальной ориентации */
  .tabs-wrapper[data-orientation="vertical"] .tabs-nav,
  .tabs-wrapper[data-orientation="vertical-custom"] .tabs-nav {
    flex-direction: column;
    min-width: 120px;
  }

  .tabs-nav {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    flex-shrink: 0;
    background: transparent;
  }

  .tab-button {
    padding: 8px 16px;
    border: none;
    background: transparent;
    color: #FFFFFF26;
    cursor: pointer;
    border-radius: 4px;
    transition: all 0.3s ease;
    font-family: inherit;
    font-size: 14px;
    white-space: wrap;
    text-align: center;
  }

  .tab-button:hover {
    color: #FFFFFF;
    background: rgba(61, 58, 184, 0.3);
  }

  .tab-button.active {
    color: #FFFFFF;
    background: #3D3AB8;
  }

  /* Стили для Custom Tabs: Horizontal Custom и Vertical Custom */
  .tabs-wrapper[data-orientation="horizontal-custom"],
  .tabs-wrapper[data-orientation="vertical-custom"] {
    border: 2px solid #10161C;
    border-radius:0px;
    padding:0px;
    gap:0px;
  }

  .tabs-wrapper[data-orientation="horizontal-custom"] .tab-button,
  .tabs-wrapper[data-orientation="vertical-custom"] .tab-button {
    background: transparent;
    color: #FFFFFF;
    width: auto;
    height:64px;
    border-radius: 0px;
    border-right: 1px solid #FFFFFF26;
  }

  .tabs-wrapper[data-orientation="horizontal-custom"] .tab-button:last-child {
  border-right: none;
}

  .tabs-wrapper[data-orientation="vertical-custom"] .tab-button {
    border:none;
  }

  .tabs-wrapper[data-orientation="horizontal-custom"] .tab-button.active,
  .tabs-wrapper[data-orientation="vertical-custom"] .tab-button.active {
    background: #10161C;
    color: #FFFFFF;
    width: auto;
    height:64px;
    border-radius: 0px;
    border-right:none;
  }

  .tabs-wrapper[data-orientation="horizontal-custom"] .tab-button:hover,
  .tabs-wrapper[data-orientation="vertical-custom"] .tab-button:hover {
    background: rgba(16, 22, 28, 0.5);
  }

  .tabs-content {
    min-height: 200px;
    background: rgba(16, 22, 28, 0.5);
    border-radius: 8px;
    padding: 16px;
    position: relative;
    flex-grow: 1;
    width: 100%;
  }

  .tab-pane {
    display: none !important; /* Усиление */
    width: 100%;
    height: 100%;
    min-height: 150px;
    border: 2px dashed rgba(61, 58, 184, 0.3);
    border-radius: 4px;
    padding: 8px;
  }

  .tab-pane.active {
    display: block !important; /* Усиление */
  }

   .tabs-wrapper[data-orientation="horizontal-custom"] .tab-pane.active,
  .tabs-wrapper[data-orientation="vertical-custom"] .tab-pane.active {
    background: transparent;
    border-radius: 0px;
    border:none;
  }
    .tabs-wrapper[data-orientation="horizontal-custom"] .tabs-content,
      .tabs-wrapper[data-orientation="vertical-custom"] .tabs-content{
    min-height: 200px;
    background:transparent;
    border-radius: 0px;
    padding: 14px;
    position: relative;
    flex-grow: 1;
    width: 100%;
    border: 1px solid #FFFFFF26;
  }
  .tab-pane:empty::before {
    content: 'Drop components here';
    color: rgba(255, 255, 255, 0.3);
    font-style: italic;
  }

  .placeholder-text {
    color: rgba(255, 255, 255, 0.5);
    font-style: italic;
    padding: 8px;
  }
`,
  script: `
function initTabsAdvanced(model) {
  const wrapper = model.getEl();
  if (!wrapper) {
    setTimeout(() => initTabsAdvanced(model), 100);
    return;
  }

  // ✅ КРИТИЧНО: Очистка trait 'tabs' от переносов строк при изменении
  model.on('change:tabs', () => {
    const tabsValue = model.getTrait('tabs')?.getValue();
    if (typeof tabsValue === 'string') {
      // Очищаем JSON от переносов строк и лишних пробелов
      const cleaned = tabsValue
        .replace(/[\\r\\n\\t\\f\\v]/g, '')     // ✅ ДВОЙНОЕ экранирование!
        .replace(/\\s{2,}/g, ' ')               // ✅ ДВОЙНОЕ экранирование!
        .trim();
      
      // Сохраняем очищенное значение обратно в атрибут
      model.addAttributes({ 'data-tabs': cleaned });
      
      console.log('🧹 [Tabs] Cleaned data-tabs from newlines');
    }
  });

  // --- Остальной код без изменений ---
  
  function switchTab(tabId) {
    if (!tabId) return;
    tabId = String(tabId);

    const allButtons = wrapper.querySelectorAll('.tab-button');
    const allPanes = wrapper.querySelectorAll('.tab-pane');

    allButtons.forEach(btn => {
        if(btn.getAttribute('data-tab') === tabId) {
             btn.classList.add('active');
        } else {
             btn.classList.remove('active');
        }
    });
    
    allPanes.forEach(pane => {
        if(pane.getAttribute('data-tab') === tabId) {
             pane.classList.add('active');
        } else {
             pane.classList.remove('active');
        }
    });
  }

  function getTabsFromTrait() {
    const traits = model.getTraits();
    const tabsTrait = traits.find(t => t.getName() === 'tabs');
    let tabs = [];
    try {
      const tabsValue = tabsTrait?.getValue();
      if (typeof tabsValue === 'string') {
        tabs = JSON.parse(tabsValue);
      } else if (Array.isArray(tabsValue)) {
        tabs = tabsValue;
      }
    } catch (e) {
      console.error('Error parsing tabs trait:', e);
    }
    
    if (!tabs || tabs.length === 0) {
        tabs = [
            { id: 'tab1', label: 'Tab 1' }, 
            { id: 'tab2', label: 'Tab 2' }
        ];
    }
    
    return tabs.map(t => ({
        id: String(t.id || t.value || 'tab-' + Math.random().toString(36).substr(2, 9)),
        label: t.label || t.name || 'Tab'
    }));
  }

  function updateTabs() {
    const tabsData = getTabsFromTrait();
    const navComponent = model.components().at(0);
    const contentComponent = model.components().at(1);
    
    if (!navComponent || !contentComponent) return;

    const navColl = navComponent.components();
    const contentColl = contentComponent.components();

    const newIds = new Set(tabsData.map(t => t.id));

    for (let i = navColl.length - 1; i >= 0; i--) {
      const btn = navColl.at(i);
      const attrs = btn.get('attributes') || {};
      const btnId = String(attrs['data-tab']);
      
      if (!newIds.has(btnId)) {
        console.log('Removing old tab:', btnId);
        navColl.remove(btn);
        
        const paneToRemove = contentColl.filter(p => {
             const pAttrs = p.get('attributes') || {};
             return String(pAttrs['data-tab']) === btnId;
        })[0];
        
        if (paneToRemove) contentColl.remove(paneToRemove);
      }
    }

    tabsData.forEach((tabItem, index) => {
      const existingBtn = navColl.filter(c => {
          const attrs = c.get('attributes') || {};
          return String(attrs['data-tab']) === tabItem.id;
      })[0];

      if (existingBtn) {
        const currentContent = existingBtn.get('content');
        if (currentContent !== tabItem.label) {
          console.log('Updating tab label:', tabItem.id);
          existingBtn.set('content', tabItem.label);
        }
      } else {
        console.log('Creating new tab:', tabItem.id);
        
        navColl.add({
          tagName: 'button',
          attributes: { 
            class: 'tab-button', 
            'data-tab': tabItem.id 
          },
          content: tabItem.label,
          droppable: true,
          draggable: false,
          selectable: true
        }, { at: index });

        contentColl.add({
          tagName: 'div',
          attributes: { 
            class: 'tab-pane', 
            'data-tab': tabItem.id 
          },
          components: [{
            type: 'container',
            tagName: 'div',
            content: 'Content for ' + tabItem.label,
            attributes: { class: 'placeholder-text' },
            droppable: true,
            selectable: true
          }],
          droppable: true,
          draggable: false
        });
      }
    });

    setTimeout(() => {
        const activeInDom = wrapper.querySelector('.tab-button.active');
        if (!activeInDom && tabsData.length > 0) {
            switchTab(tabsData[0].id);
        }
    }, 50);
  }

  wrapper.addEventListener('click', function(e) {
    const tabBtn = e.target.closest('.tab-button');
    if (!tabBtn) return;
    e.stopPropagation(); 
    e.preventDefault();
    switchTab(tabBtn.getAttribute('data-tab'));
  });

  model.on('change:tabs', updateTabs);
  
  model.on('change:orientation', () => {
    const orientation = model.get('orientation') || 'horizontal';
    const wrapper = model.getEl();
    if (!wrapper) return;

    wrapper.classList.remove('vertical', 'horizontal', 'vertical-custom', 'horizontal-custom');

    if (orientation === 'vertical-custom') {
      wrapper.classList.add('vertical-custom');
      wrapper.setAttribute('data-orientation', 'vertical-custom');
    } else if (orientation === 'horizontal-custom') {
      wrapper.classList.add('horizontal-custom');
      wrapper.setAttribute('data-orientation', 'horizontal-custom');
    } else if (orientation === 'vertical') {
      wrapper.classList.add('vertical');
      wrapper.setAttribute('data-orientation', 'vertical');
    } else {
      wrapper.setAttribute('data-orientation', 'horizontal');
    }
  });

  setTimeout(() => {
     const orientation = model.get('orientation') || 'horizontal';
     if (orientation === 'vertical') wrapper.classList.add('vertical');
     
     updateTabs();
  }, 100);
}

if (typeof model !== 'undefined') {
  setTimeout(() => initTabsAdvanced(model), 100);
}
`

  //   script: `
  // function initTabsAdvanced(model) {
  //   const wrapper = model.getEl();
  //   if (!wrapper) {
  //     setTimeout(() => initTabsAdvanced(model), 100);
  //     return;
  //   }

  //   // --- Вспомогательные функции ---

  //   function switchTab(tabId) {
  //     if (!tabId) return;
  //     // Приводим к строке на всякий случай
  //     tabId = String(tabId);

  //     const allButtons = wrapper.querySelectorAll('.tab-button');
  //     const allPanes = wrapper.querySelectorAll('.tab-pane');

  //     allButtons.forEach(btn => {
  //         // Управляем классами напрямую, минимизируя перерисовки
  //         if(btn.getAttribute('data-tab') === tabId) {
  //              btn.classList.add('active');
  //         } else {
  //              btn.classList.remove('active');
  //         }
  //     });

  //     allPanes.forEach(pane => {
  //         if(pane.getAttribute('data-tab') === tabId) {
  //              pane.classList.add('active');
  //         } else {
  //              pane.classList.remove('active');
  //         }
  //     });
  //   }

  //   function getTabsFromTrait() {
  //     const traits = model.getTraits();
  //     const tabsTrait = traits.find(t => t.getName() === 'tabs');
  //     let tabs = [];
  //     try {
  //       const tabsValue = tabsTrait?.getValue();
  //       if (typeof tabsValue === 'string') {
  //         tabs = JSON.parse(tabsValue);
  //       } else if (Array.isArray(tabsValue)) {
  //         tabs = tabsValue;
  //       }
  //     } catch (e) {
  //       console.error('Error parsing tabs trait:', e);
  //     }

  //     if (!tabs || tabs.length === 0) {
  //         tabs = [
  //             { id: 'tab1', label: 'Tab 1' },
  //             { id: 'tab2', label: 'Tab 2' }
  //         ];
  //     }

  //     // ВАЖНО: Приводим ID к строке сразу здесь, чтобы везде сравнивать строки
  //     return tabs.map(t => ({
  //         id: String(t.id || t.value || 'tab-' + Math.random().toString(36).substr(2, 9)),
  //         label: t.label || t.name || 'Tab'
  //     }));
  //   }

  //   // --- Основная логика обновления (SMART DIFF) ---
  //   function updateTabs() {
  //     const tabsData = getTabsFromTrait();
  //     const navComponent = model.components().at(0);
  //     const contentComponent = model.components().at(1);

  //     if (!navComponent || !contentComponent) return;

  //     const navColl = navComponent.components();
  //     const contentColl = contentComponent.components();

  //     // 1. Создаем Set из новых ID (все строки)
  //     const newIds = new Set(tabsData.map(t => t.id));

  //     // 2. УДАЛЕНИЕ (Remove)
  //     // Удаляем только те, которых точно нет в новом списке
  //     for (let i = navColl.length - 1; i >= 0; i--) {
  //       const btn = navColl.at(i);
  //       // Получаем атрибуты безопасно
  //       const attrs = btn.get('attributes') || {};
  //       const btnId = String(attrs['data-tab']); // Приводим к строке

  //       if (!newIds.has(btnId)) {
  //         console.log('Removing old tab:', btnId);
  //         navColl.remove(btn);

  //         const paneToRemove = contentColl.filter(p => {
  //              const pAttrs = p.get('attributes') || {};
  //              return String(pAttrs['data-tab']) === btnId;
  //         })[0];

  //         if (paneToRemove) contentColl.remove(paneToRemove);
  //       }
  //     }

  //     // 3. ОБНОВЛЕНИЕ или СОЗДАНИЕ (Update / Create)
  //     tabsData.forEach((tabItem, index) => {
  //       // Ищем строго по строковому ID
  //       const existingBtn = navColl.filter(c => {
  //           const attrs = c.get('attributes') || {};
  //           return String(attrs['data-tab']) === tabItem.id;
  //       })[0];

  //       if (existingBtn) {
  //         // UPDATE: Изменяем только если реально поменялось
  //         const currentContent = existingBtn.get('content');
  //         if (currentContent !== tabItem.label) {
  //           console.log('Updating tab label:', tabItem.id);
  //           existingBtn.set('content', tabItem.label);
  //         }

  //         // Можно добавить синхронизацию порядка (move), но это дорого для DOM
  //       } else {
  //         // CREATE: Создаем только если не нашли
  //         console.log('Creating new tab:', tabItem.id);

  //         navColl.add({
  //           tagName: 'button',
  //           attributes: {
  //             class: 'tab-button',
  //             'data-tab': tabItem.id
  //           },
  //           content: tabItem.label,
  //           droppable: true,
  //           draggable: false,
  //           selectable: true
  //         }, { at: index });

  //         contentColl.add({
  //           tagName: 'div',
  //           attributes: {
  //             class: 'tab-pane',
  //             'data-tab': tabItem.id
  //           },
  //           components: [{
  //             type: 'container',
  //             tagName: 'div',
  //             content: 'Content for ' + tabItem.label,
  //             attributes: { class: 'placeholder-text' },
  //             droppable: true,
  //             selectable: true
  //           }],
  //           droppable: true,
  //           draggable: false
  //         });
  //       }
  //     });

  //     // 4. Восстановление активного состояния
  //     // Делаем это с небольшой задержкой, чтобы DOM успел отреагировать на add/remove
  //     setTimeout(() => {
  //         const activeInDom = wrapper.querySelector('.tab-button.active');
  //         // Если вообще нет активной кнопки (даже после обновлений), активируем первую из списка
  //         if (!activeInDom && tabsData.length > 0) {
  //             switchTab(tabsData[0].id);
  //         }
  //     }, 50);
  //   }

  //   // --- Event Listeners ---

  //   wrapper.addEventListener('click', function(e) {
  //     const tabBtn = e.target.closest('.tab-button');
  //     if (!tabBtn) return;
  //     e.stopPropagation();
  //     e.preventDefault();
  //     switchTab(tabBtn.getAttribute('data-tab'));
  //   });

  //   model.on('change:tabs', updateTabs);

  //   // Orientation
  // model.on('change:orientation', () => {
  //   const orientation = model.get('orientation') || 'horizontal';
  //   const wrapper = model.getEl();
  //   if (!wrapper) return;

  //   // Удаляем старые классы ориентации
  //   wrapper.classList.remove('vertical', 'horizontal', 'vertical-custom', 'horizontal-custom');

  //   if (orientation === 'vertical-custom') {
  //     wrapper.classList.add('vertical-custom');
  //     wrapper.setAttribute('data-orientation', 'vertical-custom');
  //   } else if (orientation === 'horizontal-custom') {
  //     wrapper.classList.add('horizontal-custom');
  //     wrapper.setAttribute('data-orientation', 'horizontal-custom');
  //   } else if (orientation === 'vertical') {
  //     wrapper.classList.add('vertical');
  //     wrapper.setAttribute('data-orientation', 'vertical');
  //   } else {
  //     wrapper.setAttribute('data-orientation', 'horizontal');
  //   }
  // });

  //   // Init
  //   setTimeout(() => {
  //      // Проверяем класс ориентации
  //      const orientation = model.get('orientation') || 'horizontal';
  //      if (orientation === 'vertical') wrapper.classList.add('vertical');

  //      // Запускаем синхронизацию
  //      updateTabs();
  //   }, 100);
  // }

  // if (typeof model !== 'undefined') {
  //   setTimeout(() => initTabsAdvanced(model), 100);
  // }
  // `
};
