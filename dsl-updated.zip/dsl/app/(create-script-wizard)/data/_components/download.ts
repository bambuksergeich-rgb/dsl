import { ComponentConfig } from '../elements';
import { createFileControlScript, FILE_CONTROL_STYLES } from './file-control-runtime';

export const Download: ComponentConfig = {
  id: '10',
  type: 'mui-download',
  label: 'Download',
  category: 'Basic',
  content: {
    tagName: 'div',
    attributes: {
      class: 'file-control file-control--download',
      'data-component-id': '10',
      'data-file-mode': 'download'
    },
    components: [
      {
        tagName: 'input',
        attributes: {
          type: 'file',
          class: 'file-control__input'
        },
        draggable: false,
        droppable: false,
        editable: false,
        selectable: false
      },
      {
        tagName: 'div',
        attributes: { class: 'file-control__empty' },
        components: [
          {
            tagName: 'button',
            attributes: { type: 'button', class: 'file-control__choose' },
            content: 'Choice a File',
            draggable: false,
            droppable: false,
            editable: false,
            selectable: false
          }
        ],
        draggable: false,
        droppable: false,
        editable: false,
        selectable: false
      },
      {
        tagName: 'div',
        attributes: { class: 'file-control__list' },
        draggable: false,
        droppable: false,
        editable: false,
        selectable: false
      },
      {
        tagName: 'div',
        attributes: { class: 'file-control__add-row' },
        components: [
          {
            tagName: 'button',
            attributes: {
              type: 'button',
              class: 'file-control__add',
              title: 'Add file'
            },
            content: '+',
            draggable: false,
            droppable: false,
            editable: false,
            selectable: false
          }
        ],
        draggable: false,
        droppable: false,
        editable: false,
        selectable: false
      }
    ],
    draggable: true,
    editable: false,
    selectable: true,
    droppable: false,
    resizable: {
      tl: true,
      tc: true,
      tr: true,
      cl: true,
      cr: true,
      bl: true,
      bc: true,
      br: true,
      minDim: 42
    }
  },
  block: true,
  icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 3V15M12 15L7.5 10.5M12 15L16.5 10.5M4 17V19C4 20.1046 4.89543 21 6 21H18C19.1046 21 20 20.1046 20 19V17" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  traits: [
    {
      id: 'multiple',
      name: 'multiple',
      type: 'checkbox',
      label: 'Multiple Files',
      changeProp: true,
      value: false
    }
  ],
  styles: FILE_CONTROL_STYLES,
  script: createFileControlScript('download'),
  styleConfig: {
    sectors: [
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          { id: 'width', name: 'Width', property: 'width', type: 'number', units: ['px', '%'] },
          { id: 'height', name: 'Height', property: 'height', type: 'number', units: ['px'] },
          { id: 'min-width', name: 'Min Width', property: 'min-width', type: 'number', units: ['px'], default: 252 },
          { id: 'min-height', name: 'Min Height', property: 'min-height', type: 'number', units: ['px'], default: 54 }
        ]
      },
      {
        id: 'file-card',
        name: 'File Card',
        open: false,
        properties: [
          { id: 'border-color', name: 'Border Color', property: 'border-color', type: 'color', default: '#FFFFFF26', selector: '.file-control__item' },
          { id: 'text-color', name: 'Text Color', property: 'color', type: 'color', default: '#FFFFFF', selector: '.file-control__name' }
        ]
      }
    ]
  }
};
