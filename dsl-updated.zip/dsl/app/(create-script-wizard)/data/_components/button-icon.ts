import { ComponentConfig } from '../elements';

const DEFAULT_BUTTON_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MiIgaGVpZ2h0PSI1MiIgdmlld0JveD0iMCAwIDUyIDUyIiBmaWxsPSJub25lIj4KPGNpcmNsZSBjeD0iMjYiIGN5PSIyNiIgcj0iMjIiIHN0cm9rZT0iI0ZGRkZGRiIgc3Ryb2tlLXdpZHRoPSIzIi8+CjxwYXRoIGQ9Ik0xNiAxOWgyME0xNiAyNmgyME0xNiAzM2gxMiIgc3Ryb2tlPSIjRkZGRkZGIiBzdHJva2Utd2lkdGg9IjMiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgo8L3N2Zz4=';

export const ButtonIcon: ComponentConfig = {
  id: 'button-icon',
  type: 'button-icon',
  label: 'Button Icon',
  category: 'Form',
  content: {
    tagName: 'button',
    attributes: {
      type: 'button',
      class: 'button-icon button-icon-component',
      'aria-label': 'Button Icon',
      'data-image': DEFAULT_BUTTON_ICON
    },
    selectable: true,
    hoverable: true,
    draggable: true,
    droppable: false,
    resizable: {
      tl: true, tc: true, tr: true, cl: true, cr: true,
      bl: true, bc: true, br: true, minDim: 48
    },
    components: [
      {
        tagName: 'img',
        attributes: {
          class: 'button-icon-image',
          src: DEFAULT_BUTTON_ICON,
          alt: ''
        },
        draggable: false,
        selectable: false,
        hoverable: false,
        droppable: false
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="9" stroke="white" stroke-width="1.5"/>
    <path d="M8 8.5h8M8 12h8M8 15.5h5" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
  </svg>`,
  traits: [
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'Image',
      type: 'select-icon',
      changeProp: true,
      value: ''
    }
  ],
  styles: `
    .button-icon-component {
      position: relative;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 72px;
      height: 72px;
      min-width: 44px;
      min-height: 44px;
      padding: 8px;
      margin: 0;
      border: 0;
      border-radius: 4px;
      background: rgba(255,255,255,.06);
      color: #FFFFFF;
      box-sizing: border-box;
      cursor: pointer !important;
      pointer-events: auto !important;
      overflow: hidden;
    }
    .button-icon-component:hover { background: rgba(255,255,255,.10); }
    .button-icon-component:focus { outline: none; }
    .button-icon-image {
      display: block;
      width: 100%;
      height: 100%;
      margin: auto;
      object-fit: contain;
      object-position: center center;
      align-self: center;
      justify-self: center;
      pointer-events: none;
      user-select: none;
    }
  `,
  script: `
    (function () {
      if (!model || !model.getEl || !model.getEl()) return;

      var root = model.getEl();
      if (root.classList) root.classList.add('button-icon-component');
      root.style.pointerEvents = 'auto';
      root.style.cursor = 'pointer';
      var img = root.querySelector('.button-icon-image');
      var fallbackImage = '${DEFAULT_BUTTON_ICON}';

      function traitValue(name, fallback) {
        var trait = model.getTrait && model.getTrait(name);
        var value = trait && trait.getValue ? trait.getValue() : undefined;
        return value === undefined || value === null || value === '' ? fallback : value;
      }

      function render() {
        if (!img) return;
        var attrs = model.getAttributes ? model.getAttributes() : {};
        var src = String(traitValue('selectImage', attrs['data-image'] || fallbackImage) || fallbackImage);
        if (!src || src === 'undefined' || src === 'null') src = fallbackImage;

        if (img.getAttribute('src') !== src) img.setAttribute('src', src);
        var imageComponent = model.find && model.find('.button-icon-image')[0];
        if (imageComponent && imageComponent.getAttributes) {
          var current = imageComponent.getAttributes();
          if (current.src !== src) imageComponent.addAttributes({ src: src });
        }
        model.addAttributes({ 'data-image': src }, { silent: true });
      }

      if (model.__stage15ButtonIconCleanup) model.__stage15ButtonIconCleanup();
      var onUpdate = function () { render(); };

      var requestSelection = function () {
        try {
          var attrs = model.getAttributes ? model.getAttributes() : {};
          var draftId = attrs && attrs['data-draft-id'];
          var componentId = model.getId ? model.getId() : null;
          var detail = { draftId: draftId || null, componentId: componentId || null };
          window.dispatchEvent(new CustomEvent('dsl:button-icon-select', { detail: detail }));
          if (window.parent && window.parent !== window && window.parent.CustomEvent) {
            window.parent.dispatchEvent(
              new window.parent.CustomEvent('dsl:button-icon-select', { detail: detail })
            );
          }
        } catch (e) {
          console.error('Error dispatching dsl:button-icon-select event:', e);
        }
      };

      root.addEventListener('pointerdown', requestSelection, true);
      root.addEventListener('click', requestSelection, true);

      model.on('change:traits', onUpdate);
      model.on('change:selectImage', onUpdate);
      model.on('change:attributes', onUpdate);
      model.on('active', onUpdate);
      model.__stage15ButtonIconCleanup = function () {
        root.removeEventListener('pointerdown', requestSelection, true);
        root.removeEventListener('click', requestSelection, true);
        model.off('change:traits', onUpdate);
        model.off('change:selectImage', onUpdate);
        model.off('change:attributes', onUpdate);
        model.off('active', onUpdate);
      };

      if (img) {
        img.onerror = function () {
          if (img.getAttribute('src') !== fallbackImage) img.setAttribute('src', fallbackImage);
        };
      }

      render();
    })();
  `
};
