import { ComponentConfig } from '../elements';

export const Container: ComponentConfig = {
  id: 'container',
  type: 'container',
  label: 'Container',
  category: 'Main',
  content: {
    tagName: 'div',
    attributes: {
      class: 'container-wrapper',
      'data-container': 'true'
    },
    components: [],
    droppable: true,
    editable: true,
    selectable: true,
    resizable: {
      tl: true,
      tr: true,
      bl: true,
      br: true,
      tc: true,
      bc: true,
      cr: true,
      cl: true,
      minDim: 50,
      maxDim: 1500,
      updateTarget: (el, rect) => {
        const width = rect.width || rect.w;
        const height = rect.height || rect.h;

        console.log('Resizing container to:', width + 'px', height + 'px');

        el.style.width = width + 'px';
        el.style.height = height + 'px';
        el.style.minWidth = '50px';
        el.style.minHeight = '50px';
        el.style.flex = '0 0 auto';
      }
    }
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 4H7.2C6.0799 4 5.51984 4 5.09202 4.21799C4.71569 4.40973 4.40973 4.71569 4.21799 5.09202C4 5.51984 4 6.07989 4 7.2V8M4 11V13M4 16V16.8C4 17.9201 4 18.4802 4.21799 18.908C4.40973 19.2843 4.71569 19.5903 5.09202 19.782C5.51984 20 6.07989 20 7.2 20H8M11 20H13M16 20H16.8C17.9201 20 18.4802 20 18.908 19.782C19.2843 19.5903 19.5903 19.2843 19.782 18.908C20 18.4802 20 17.9201 20 16.8V16M20 13V11M20 8V7.2C20 6.0799 20 5.51984 19.782 5.09202C19.5903 4.71569 19.2843 4.40973 18.908 4.21799C18.4802 4 17.9201 4 16.8 4H16M13 4H11" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`,
  traits: [],
  styles: `
  .container-wrapper {
    /* 1. Переменные, которые уже были в твоем стиле и конфиге */
    --order: 0;
    --flex-grow: 1;
    --flex-shrink: 1;
    --flex-basis: auto;
    --grid-column-start: auto;
    --grid-column-end: auto;
    --grid-row-start: auto;
    --grid-row-end: auto;
    --justify-self: start;
    --align-self: stretch;
    --text-align: left;
    --position: relative; 
    --top: auto;
    --right: auto;
    --bottom: auto;
    --left: auto;
    --z-index: auto;
    --grid-template-columns: 1fr;
    --grid-template-rows: 1fr;
    --column-gap: 0;
    --row-gap: 0;

    /* 2. НЕДОСТАЮЩИЕ ПЕРЕМЕННЫЕ (для синхронизации с твоим styleConfig) */
    /* В твоем конфиге эти свойства указаны без --, поэтому создаем для них мост */
    --display: flex;
    --width: 100%;
    --height: 100vh;
    --min-width: 50px;
    --min-height: 50px;
    --max-width: 100%;
    --max-height: 100%;
    
    --justify-content: stretch;
    --align-items: stretch;
    --justify-items: stretch;
    --justify-self: start;
    /* Добавляем алиасы для свойств, которые в конфиге указаны нативно */
    /* GrapesJS запишет в инлайн стиль 'width: 100%', а мы заставим CSS приоритетно слушать это */

    /* === ПРИМЕНЕНИЕ ВСЕХ СВОЙСТВ === */
    
    /* Flex/Grid контейнер */
    display: var(--display);
    justify-content: var(--justify-content);
    align-items: var(--align-items);
    justify-items: var(--justify-items);
    justify-self: var(--justify-self);
    
    grid-template-columns: var(--grid-template-columns);
    grid-template-rows: var(--grid-template-rows);
    column-gap: var(--column-gap);
    row-gap: var(--row-gap);

    /* Дочерние элементы (Flex/Grid Children) */
    order: var(--order);
    flex-grow: var(--flex-grow);
    flex-shrink: var(--flex-shrink);
    flex-basis: var(--flex-basis);
    align-self: var(--align-self);
    
    grid-column-start: var(--grid-column-start);
    grid-column-end: var(--grid-column-end);
    grid-row-start: var(--grid-row-start);
    grid-row-end: var(--grid-row-end);
    justify-self: var(--justify-self);

    /* Позиционирование и размеры */
    position: var(--position);
    top: var(--top);
    right: var(--right);
    bottom: var(--bottom);
    left: var(--left);
    z-index: var(--z-index);
    text-align: var(--text-align);

    width: var(--width);
    height: var(--height);
    min-width: var(--min-width);
    min-height: var(--min-height);
    max-width: var(--max-width);
    max-height: var(--max-height);

    /* Базовое оформление */
    padding: 16px;
    box-sizing: border-box;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    overflow: auto;
    background-color: transparent;
    margin: 0;
    transition: none;
  }
`,
  script: `
      function initializeContainer(model) {
        const wrapper = model.getEl();
        if (!wrapper) return;
        
        // Начальные стили, синхронизированные с твоим CSS и styleConfig
        const initialStyles = {
          'width': '100%',
          'height': '100%',
          'display': 'flex',
          'justify-content': 'stretch',
          'align-items': 'stretch',
          'justify-items': 'stretch',
          'column-gap': '0',
          'row-gap': '0',
          'grid-template-columns': '1fr',
          'grid-template-rows': '1fr',
          'position': 'relative',
          'text-align': 'left',
          '--order': '0',
          '--flex-grow': '1',
          '--flex-shrink': '1',
          '--flex-basis': 'auto',
          '--align-self': 'stretch',
          '--justify-self': 'start',
          '--grid-column-start': 'auto',
          '--grid-column-end': 'auto',
          '--grid-row-start': 'auto',
          '--grid-row-end': 'auto',
          '--top': 'auto',
          '--right': 'auto',
          '--bottom': 'auto',
          '--left': 'auto',
          '--z-index': 'auto',
          '--min-width': '50px',
          '--min-height': '50px',
          '--max-width': '100%',
          '--max-height': '100%'
        };

        model.setStyle(initialStyles);
        applyStylesToElement(wrapper, initialStyles);
        ensureParentHeight(wrapper);
      }

      // Вспомогательная функция для применения стилей и переменных
      function applyStylesToElement(el, styles) {
        Object.keys(styles).forEach(prop => {
          const value = styles[prop];
          if (prop.startsWith('--')) {
            el.style.setProperty(prop, value);
          } else {
            // Маппим нативное свойство (например, width) в переменную (--width)
            // Это обеспечит работу твоего CSS: width: var(--width)
            el.style.setProperty('--' + prop, value);
            el.style[prop] = value;
          }
        });
      }

      function ensureParentHeight(element) {
        let current = element;
        while (current && current !== document.body) {
          if (current.parentElement) {
            const parent = current.parentElement;
            if (!parent.style.height || parent.style.height === '0px') {
              parent.style.height = '100%';
              parent.style.display = 'flex';
              parent.style.flexDirection = 'column';
            }
            current = parent;
          } else {
            break;
          }
        }
        document.body.style.height = '100%';
        document.documentElement.style.height = '100%';
      }

      function updateContainer(model) {
        const wrapper = model.getEl();
        if (!wrapper) return;

        const styles = model.getStyle() || {};
        applyStylesToElement(wrapper, styles);

        // Специфичная логика для высоты (viewport)
        if (!styles.height || styles.height === '100%') {
          wrapper.style.height = '100vh';
          wrapper.style.setProperty('--height', '100vh');
        }

        // Логика для ширины при ресайзе
        if (!wrapper.classList.contains('resizing')) {
          const currentWidth = styles.width || wrapper.style.width;
          if (!currentWidth || currentWidth === '100%' || currentWidth.includes('%')) {
            wrapper.style.width = '100%';
            wrapper.style.setProperty('--width', '100%');
          }
        }
      }

      model.on('loaded', () => {
        setTimeout(() => {
          initializeContainer(model);
          updateContainer(model);
        }, 100);
      });

      model.on('change:style', () => {
        setTimeout(() => updateContainer(model), 10);
      });
      
      model.on('component:mount', () => {
        setTimeout(() => {
          initializeContainer(model);
          updateContainer(model);
        }, 200);
      });
    `,
  styleConfig: {
    sectors: [
      {
        id: 'flex-children',
        name: 'Flex-Children',
        open: true,
        properties: [
          {
            id: 'flex-order-type',
            name: 'Flex Order Type',
            property: 'order-type', // UI Only
            type: 'radio',
            default: '0',
            options: [
              { id: 'type1', label: 'Type 1', name: '', value: '' },
              { id: 'type2', label: 'Type 2', name: '', value: '' }
            ]
          },
          {
            id: 'order',
            name: 'Order',
            property: '--order',
            type: 'number',
            default: '0'
          },
          {
            id: 'flex-grow-shrink-group',
            name: 'Flex Shrink/Grow',
            type: 'composite',
            property: 'flex-group',
            properties: [
              {
                id: 'flex-basis',
                name: 'Basis',
                property: '--flex-basis',
                type: 'number',
                default: 'auto'
              },
              {
                id: 'flex-shrink',
                name: 'Shrink',
                property: '--flex-shrink',
                type: 'number',
                default: '1'
              },
              {
                id: 'flex-grow',
                name: 'Grow',
                property: '--flex-grow',
                type: 'number',
                default: '0'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align Self',
            property: 'align-self',
            type: 'radio',
            default: 'auto',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'flex-start' },
              { id: 'end', label: 'End', name: '', value: 'flex-end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' }
            ]
          },
          {
            id: 'justify-self',
            name: 'Justify Self',
            property: '--justify-self',
            type: 'radio',
            default: 'start',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'start' },
              { id: 'end', label: 'End', name: '', value: 'end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' },
              { id: 'auto', label: 'Auto', name: '', value: 'auto' }
            ]
          },
          // {
          //   id: 'justify-items',
          //   name: 'Justify Items',
          //   property: '--justify-items',
          //   type: 'radio',
          //   default: 'stretch',
          //   options: [
          //     { id: 'start', label: 'Start', value: 'start', name: '' },
          //     { id: 'end', label: 'End', value: 'end', name: '' },
          //     { id: 'center', label: 'Center', value: 'center', name: '' },
          //     { id: 'stretch', label: 'Stretch', value: 'stretch', name: '' },
          //     { id: 'normal', label: 'Normal', value: 'normal', name: '' }
          //   ]
          // },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: 'justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: 'align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              { id: 'stretch', label: 'Stretch', value: 'stretch', name: '' },
              { id: 'baseline', label: 'Baseline', value: 'baseline', name: '' }
            ]
          }
        ]
      },
      {
        id: 'grid-parent',
        name: 'Grid-Parent',
        open: true,
        properties: [
          {
            id: 'grid-template-columns',
            name: 'Columns',
            property: 'grid-template-columns',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-template-rows',
            name: 'Rows',
            property: 'grid-template-rows',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-column-gap',
            name: 'Gap Column',
            property: 'column-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '0'
          },
          {
            id: 'grid-row-gap',
            name: 'Gap Row',
            property: 'row-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '0'
          },
          {
            id: 'justify-items',
            name: 'Justify Items',
            property: 'justify-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'normal',
                label: 'Normal',
                value: 'normal',
                name: ''
              }
            ]
          },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: 'justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: 'align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-grid',
        name: 'Grid-Children',
        open: true,
        properties: [
          {
            id: 'grid-column-start',
            name: 'Start Column',
            property: '--grid-column-start',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-column-end',
            name: 'End Column',
            property: '--grid-column-end',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-row-start',
            name: 'Start Row',
            property: '--grid-row-start',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-row-end',
            name: 'End Row',
            property: '--grid-row-end',
            type: 'number',
            default: '1'
          },
          {
            id: 'justify-self',
            name: 'Justify-Self',
            property: '--justify-self',
            type: 'radio',
            default: 'start',
            options: [
              {
                id: 'start',
                label: 'Start',
                name: '',
                value: 'start'
              },
              {
                id: 'end',
                label: 'End',
                name: '',
                value: 'end'
              },
              {
                id: 'stretch',
                label: 'Stretch',
                name: '',
                value: 'stretch'
              },
              {
                id: 'center',
                label: 'Center',
                name: '',
                value: 'center'
              },
              {
                id: 'auto',
                label: 'Auto',
                name: '',
                value: 'auto'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align-Self',
            property: '--align-self',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-position',
        name: 'Position',
        open: true,
        properties: [
          {
            id: 'text-align',
            name: 'Align',
            property: '--text-align',
            type: 'radio',
            default: 'left',
            options: [
              {
                id: 'left',
                label: 'Left',
                name: '',
                value: 'left'
              },
              {
                id: 'center',
                label: 'Center',
                name: '',
                value: 'center'
              },
              {
                id: 'right',
                label: 'Right',
                name: '',
                value: 'right'
              }
            ]
          },
          {
            id: 'position',
            name: 'Position',
            property: '--position',
            type: 'select',
            default: 'relative',
            options: [
              {
                id: 'static',
                label: 'Static',
                name: '',
                value: 'static'
              },
              {
                id: 'relative',
                label: 'Relative',
                name: '',
                value: 'relative'
              },
              {
                id: 'absolute',
                label: 'Absolute',
                name: '',
                value: 'absolute'
              },
              {
                id: 'fixed',
                label: 'Fixed',
                name: '',
                value: 'fixed'
              },
              {
                id: 'sticky',
                label: 'Sticky',
                name: '',
                value: 'sticky'
              }
            ]
          },

          {
            id: 'top',
            name: 'Top',
            property: '--top',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'right',
            name: 'Right',
            property: '--right',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'left',
            name: 'Left',
            property: '--left',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'bottom',
            name: 'Bottom',
            property: '--bottom',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw', 'auto'],
            default: '100%'
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            units: ['vh', '%', 'px', 'rem', 'auto'],
            default: '100vh'
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw'],
            default: '50px'
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            units: ['%', 'px', 'rem', 'vh'],
            default: '50px'
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw'],
            default: '100%'
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            units: ['%', 'px', 'rem', 'vh'],
            default: '100%'
          },
          {
            id: 'display',
            name: 'Display',
            property: 'display',
            type: 'select',
            default: 'flex',
            options: [
              {
                value: 'block',
                name: 'Block',
                id: 'block'
              },
              {
                value: 'flex',
                name: 'Flex',
                id: 'flex'
              },
              {
                value: 'grid',
                name: 'Grid',
                id: 'grid'
              },
              {
                value: 'inline-block',
                name: 'Inline Block',
                id: 'inline-block'
              }
            ]
          }
        ]
      }
    ]
  }
};
