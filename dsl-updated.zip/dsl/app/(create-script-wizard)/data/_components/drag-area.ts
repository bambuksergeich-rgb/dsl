import { ComponentConfig } from '../elements';

export const DragArea: ComponentConfig = {
  id: 'drag-area',
  type: 'drag-area',
  label: 'Drag Area',
  category: 'Basic',
  content: {
    tagName: 'div',
    attributes: { class: 'drag-area', droppable: 'true' },
    components: []
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M16.0275 12.8199L24 17.5539L20.5964 18.5446L23.0292 22.8346L21.0464 24L18.6136 19.7112L16.0687 22.2169L16.0275 12.8199ZM13.7378 2.33089H16.0275V6.99267H21.7516C22.0552 6.99267 22.3464 7.11545 22.5611 7.33402C22.7758 7.55258 22.8964 7.84902 22.8964 8.15811V12.8199H20.6068V9.32356H9.15856V20.978H13.7378V23.3089H8.01374C7.71011 23.3089 7.41892 23.1861 7.20423 22.9675C6.98953 22.749 6.86892 22.4525 6.86892 22.1434V16.3162H4.57928V13.9853L5.60962 11.8875L6.86892 8.15811C6.86892 7.84902 6.98953 7.55258 7.20423 7.33402C7.41892 7.11545 13.4342 2.33089 13.7378 2.33089ZM4.57928 13.9853V16.3162H0V13.9853H4.57928ZM6.86892 9.32356L4.57928 13.9853H0V9.32356H6.86892ZM2.28964 2.33089H13.7378L6.86892 9.32356H0V2.33089H2.28964ZM4.57928 0V2.33089H0V0H4.57928ZM9.15856 0V2.33089H4.57928V0H9.15856ZM13.7378 0V2.33089H9.15856V0H13.7378ZM16.0275 0V2.33089H13.7378V0H16.0275Z" fill="white"/>
  </svg>
  `,
  traits: [],
  styles: `
    .drag-area {
      width: 100%;
      height: 100%;
      min-height: 200px;
      background-color: transparent;
      border: 2px solid #e0e0e0;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
    }
    .drag-area.drag-over {
      border: 2px dashed #3182ce;
      background-color: rgba(49, 130, 206, 0.1);
    }
  `,
  script: `
    function handleDragOver(event) {
      event.preventDefault();
      event.stopPropagation();
      event.target.classList.add('drag-over');
    }

    function handleDragEnter(event) {
      event.preventDefault();
      event.stopPropagation();
      event.target.classList.add('drag-over');
    }

    function handleDragLeave(event) {
      event.target.classList.remove('drag-over');
    }

    function handleDrop(event, model) {
      event.preventDefault();
      event.stopPropagation();
      event.target.classList.remove('drag-over');
      
      const componentId = event.dataTransfer.getData('text/plain');
      console.log('Dropped component ID:', componentId);
      
      // Предполагается, что редактор (например, GrapesJS) обрабатывает добавление компонента
      if (model && componentId) {
        try {
          const editor = model.getEditor && model.getEditor();
          if (editor) {
            const component = editor.Components.getById(componentId);
            if (component) {
              model.append(component.clone());
              console.log('Component added to drag area:', componentId);
            } else {
              console.error('Component not found:', componentId);
            }
          } else {
            console.error('Editor not available');
          }
        } catch (e) {
          console.error('Error adding component:', e);
        }
      }
    }

    if (model && model.getEl()) {
      const dragAreaEl = model.getEl();
      dragAreaEl.addEventListener('dragover', handleDragOver);
      dragAreaEl.addEventListener('dragenter', handleDragEnter);
      dragAreaEl.addEventListener('dragleave', handleDragLeave);
      dragAreaEl.addEventListener('drop', (event) => handleDrop(event, model));
    } else {
      console.error('Model or element not available');
    }
  `,
  styleConfig: { sectors: [] }
};
