import { ComponentConfig } from '../elements';

export const Chat: ComponentConfig = {
  id: 'chat',
  type: 'chat',
  label: 'Chat',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: { class: 'chat-wrapper' },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'chat-messages' },
        content: '<div class="chat-message">Welcome to the chat!</div>'
      },
      {
        tagName: 'div',
        attributes: { class: 'chat-input' },
        components: [
          {
            tagName: 'input',
            attributes: {
              type: 'text',
              class: 'chat-input-field',
              placeholder: 'Type a message...'
            }
          },
          {
            tagName: 'button',
            attributes: { class: 'chat-send-button' },
            content: 'Send'
          }
        ]
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M18.2984 13.65V6.71018C18.2984 4.97112 16.8758 3.54846 15.1367 3.54846H4.64609C2.90703 3.54846 1.48438 4.97112 1.48438 6.71018V13.65C1.48438 15.3024 2.76875 16.6664 4.38594 16.8C4.38594 16.8 3.91719 20.4422 4.50078 20.4422C5.08437 20.4422 8.91641 16.8117 8.91641 16.8117H15.1344C16.8758 16.8117 18.2984 15.3891 18.2984 13.65ZM8.35859 15.4055L7.95078 15.7899C7.94375 15.7969 7.14219 16.5563 6.23516 17.3625C6.03594 17.5383 5.85547 17.6977 5.68906 17.843C5.73359 17.3532 5.78047 16.9852 5.78047 16.9805L5.96797 15.5203L4.50078 15.3985C3.59844 15.3235 2.89062 14.5547 2.89062 13.65V6.71018C2.89062 6.24377 3.07344 5.80549 3.40859 5.47268C3.74141 5.13987 4.18203 4.95471 4.64609 4.95471H15.1367C15.6031 4.95471 16.0414 5.13752 16.3742 5.47268C16.707 5.80549 16.8922 6.24612 16.8922 6.71018V13.65C16.8922 14.1164 16.7094 14.5547 16.3742 14.8875C16.0414 15.2203 15.6008 15.4055 15.1367 15.4055H8.35859Z" fill="white"/>
<path d="M19.4605 7.91959C19.0809 7.84224 18.7082 8.08599 18.6309 8.46568C18.5535 8.84537 18.7973 9.21803 19.177 9.29537C20.091 9.48287 20.7543 10.2962 20.7543 11.229V15.3774C20.7543 16.3524 20.0254 17.1938 19.0598 17.3321L18.2934 17.4422L18.4762 18.1946C18.523 18.3844 18.5676 18.5883 18.6121 18.7876C18.1996 18.4032 17.7379 17.9626 17.3184 17.5524L17.1144 17.3508H13.184C12.6707 17.3508 12.3262 17.318 12.0777 17.1493C11.7566 16.9313 11.3184 17.0133 11.1004 17.3344C10.8824 17.6555 10.9645 18.0938 11.2855 18.3118C11.8879 18.7219 12.5816 18.7571 13.184 18.7571H16.5402C16.7746 18.9844 17.1801 19.3735 17.5949 19.7602C17.9746 20.1141 18.2887 20.3954 18.5277 20.6016C18.9965 21.0001 19.2144 21.143 19.5027 21.143C19.7301 21.143 19.941 21.0399 20.084 20.8594C20.3207 20.5571 20.323 20.1774 20.0957 19.0149C20.0629 18.8462 20.0277 18.6821 19.9949 18.5321C21.2699 18.0376 22.1605 16.7907 22.1605 15.3774V11.229C22.1629 9.63521 21.0262 8.24303 19.4605 7.91959Z" fill="white"/>
<path d="M10.1859 14.1281C9.34453 14.1281 8.52187 13.7274 7.87031 13.0008C7.29375 12.3563 6.94922 11.5571 6.94922 10.8586V10.1625L7.64531 10.1555C7.65469 10.1555 8.49375 10.1461 9.88125 10.1461C10.2703 10.1461 10.5844 10.4602 10.5844 10.8492C10.5844 11.2383 10.2703 11.5524 9.88125 11.5524C9.35859 11.5524 8.91562 11.5547 8.56406 11.5547C8.65312 11.7211 8.77031 11.8946 8.91797 12.061C9.29297 12.4805 9.75469 12.7196 10.1859 12.7196C10.6172 12.7196 11.0789 12.4781 11.4539 12.061C11.6062 11.8899 11.7258 11.7117 11.8148 11.5406C11.4937 11.475 11.25 11.1891 11.2523 10.8492C11.2547 10.4625 11.5687 10.1485 11.9555 10.1485H11.9578C12.593 10.1508 12.7195 10.1531 12.7453 10.1555L13.4227 10.1813V10.8586C13.4227 11.5571 13.0781 12.3563 12.5016 13.0008C11.8477 13.7274 11.0273 14.1281 10.1859 14.1281Z" fill="white"/>
</svg>
`,
  traits: [
    {
      id: 'placeholder',
      name: 'placeholder',
      label: 'Input Placeholder',
      type: 'text',
      changeProp: true,
      value: 'Type a message...'
    },
    {
      id: 'bgColor',
      name: 'bgColor',
      label: 'Background Color',
      type: 'color',
      changeProp: true,
      value: '#f7fafc'
    },
    {
      id: 'borderColor',
      name: 'borderColor',
      label: 'Border Color',
      type: 'color',
      changeProp: true,
      value: '#e2e8f0'
    }
  ],
  styles: `
    .chat-wrapper {
      max-width: 400px;
      padding: 16px;
      background-color: #f7fafc;
      border: 2px solid var(--border-color, #e2e8f0);
      border-radius: 4px;
      text-align: left;
    }
    .chat-messages {
      background-color: var(--bg-color, #f7fafc);
      border-radius: 4px;
      padding: 12px;
      min-height: 100px;
      max-height: 200px;
      overflow-y: auto;
      margin-bottom: 12px;
    }
    .chat-message {
      background-color: #e2e8f0;
      padding: 8px;
      border-radius: 4px;
      margin-bottom: 8px;
      max-width: 80%;
    }
    .chat-input {
      display: flex;
      gap: 8px;
    }
    .chat-input-field {
      flex: 1;
      padding: 8px;
      border: 1px solid #e2e8f0;
      border-radius: 4px;
      font-size: 1em;
    }
    .chat-send-button {
      padding: 8px 16px;
      background-color: #3182ce;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    .chat-send-button:hover {
      background-color: #2b6cb0;
    }
  `,
  script: `
    function updateChat(model) {
      console.log('updateChat called:', model.changed);
      if (!model || !model.getEl()) {
        console.error('No model or wrapper element');
        return;
      }
      const wrapper = model.getEl();
      const traits = model.getTraits();
      try {
        const messagesEl = wrapper.querySelector('.chat-messages');
        const inputEl = wrapper.querySelector('.chat-input-field');
        const buttonEl = wrapper.querySelector('.chat-send-button');
        if (messagesEl && inputEl && buttonEl) {
          const placeholder = traits.find(t => t.getName() === 'placeholder')?.getValue() || 'Type a message...';
          const bgColor = traits.find(t => t.getName() === 'bgColor')?.getValue() || '#f7fafc';
          const borderColor = traits.find(t => t.getName() === 'borderColor')?.getValue() || '#e2e8f0';
          inputEl.placeholder = placeholder;
          messagesEl.style.setProperty('--bg-color', bgColor);
          wrapper.style.setProperty('--border-color', borderColor);
          buttonEl.addEventListener('click', () => {
            if (inputEl.value.trim()) {
              const message = document.createElement('div');
              message.className = 'chat-message';
              message.textContent = inputEl.value;
              messagesEl.appendChild(message);
              inputEl.value = '';
              messagesEl.scrollTop = messagesEl.scrollHeight;
              console.log('Message added:', message.textContent);
            }
          });
          console.log('Chat updated:', { placeholder, bgColor, borderColor });
        } else {
          console.error('Missing chat elements');
        }
      } catch (e) {
        console.error('Error updating chat:', e);
      }
    }
    if (model && model.getEl()) {
      updateChat(model);
    } else {
      console.error('Model or element not available');
    }
    model.on('change', () => {
      console.log('Model changed:', model.changed);
      updateChat(model);
    });
  `,
  styleConfig: { sectors: [] }
};
