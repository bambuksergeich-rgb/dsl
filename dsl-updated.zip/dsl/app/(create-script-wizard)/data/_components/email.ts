import { ComponentConfig } from '../elements';

const EMAIL_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIxOCIgdmlld0JveD0iMCAwIDI0IDE4IiBmaWxsPSJub25lIj48cmVjdCB4PSIxIiB5PSIyIiB3aWR0aD0iMjIiIGhlaWdodD0iMTQiIHJ4PSIxLjUiIGZpbGw9IndoaXRlIi8+PHBhdGggZD0iTTIuNSAzLjUgMTIgMTFsOS41LTcuNSIgc3Ryb2tlPSIjM0EzQTNBIiBzdHJva2Utd2lkdGg9IjEuOCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+PC9zdmc+';

export const Email: ComponentConfig = {
  id: 'email',
  type: 'email',
  label: 'Email Input',
  category: 'Inputs',
  content: {
    tagName: 'div',
    attributes: { class: 'email-input-container' },
    components: [
      { tagName: 'input', attributes: { type: 'email', class: 'email-input', placeholder: 'Normal', autocomplete: 'email' }, draggable: false },
      {
        tagName: 'span',
        attributes: { class: 'email-icon' },
        draggable: false,
        components: [{ tagName: 'img', attributes: { class: 'email-icon-image', src: EMAIL_ICON, 'data-default-src': EMAIL_ICON }, draggable: false }]
      }
    ]
  },
  block: true,
  icon: '<svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="1" y="2" width="22" height="14" rx="1.5" fill="white"/><path d="M2.5 3.5 12 11l9.5-7.5" stroke="#1F1923" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  traits: [
    { id: 'showIcon', name: 'showIcon', label: 'Show Icon', type: 'checkbox', changeProp: true, value: true },
    { id: 'placeholder', name: 'placeholder', label: 'Placeholder', type: 'text', changeProp: true, value: 'Normal' },
    { id: 'selectImage', name: 'selectImage', label: 'Image', type: 'select-icon', changeProp: true, value: '' }
  ],
  styles: `
/* Standard single-line control height from the editor design. */
.email-input-container .email-input { height: 34px !important; min-height: 34px !important; max-height: 34px !important; line-height: 20px !important; }
[data-draft-id].email-input-container, .email-input-container { height: 34px !important; min-height: 34px !important; max-height: 34px !important; }

    .email-input-container {
      position: relative;
      display: inline-flex;
      align-items: center;
      width: 320px;
      min-width: 180px;
      height: 48px;
      min-height: 48px;
      box-sizing: border-box;
      font-family: Montserrat, Arial, sans-serif;
    }
    .email-input {
      display: block;
      width: 100%;
      height: 48px !important;
      min-height: 48px !important;
      padding: 0 58px 0 18px;
      border: 1px solid transparent;
      border-radius: 4px;
      background: #3A3A3A;
      color: #FFFFFF;
      font: 400 16px/48px Montserrat, Arial, sans-serif;
      box-sizing: border-box;
    }
    .email-input::placeholder { color: rgba(255,255,255,.56); }
    .email-input:hover { border-color: rgba(255,255,255,.12); }
    .email-input:focus { outline: none; border-color: rgba(255,255,255,.28); }
    .email-icon {
      position: absolute;
      right: 16px;
      top: 50%;
      transform: translateY(-50%);
      width: 28px;
      height: 28px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
    }
    .email-icon-image { width: 24px; height: 18px; object-fit: contain; }
  `,
  script: `
    (function () {
      if (!model || !model.getEl()) return;
      const root = model.getEl();
      const input = root.querySelector('.email-input');
      const iconBox = root.querySelector('.email-icon');
      const icon = root.querySelector('.email-icon-image');
      const defaultIcon = icon ? String(icon.getAttribute('data-default-src') || icon.getAttribute('src') || '') : '';
      const traitValue = function (name, fallback) {
        const trait = model.getTrait && model.getTrait(name);
        const value = trait && trait.getValue ? trait.getValue() : undefined;
        return value === undefined || value === null || value === '' ? fallback : value;
      };
      const asBool = function (value) { return value === true || value === 'true' || value === 1 || value === '1'; };
      const render = function () {
        if (!input) return;
        input.placeholder = String(traitValue('placeholder', 'Normal'));
        const attrs = model.getAttributes ? model.getAttributes() : {};
        if (attrs['data-value'] != null && input.value !== String(attrs['data-value'])) input.value = String(attrs['data-value']);
        const showIcon = asBool(traitValue('showIcon', true));
        if (iconBox) iconBox.style.display = showIcon ? 'inline-flex' : 'none';
        input.style.paddingRight = showIcon ? '58px' : '18px';
        const src = String(traitValue('selectImage', '') || defaultIcon);
        if (icon && src && icon.getAttribute('src') !== src) icon.setAttribute('src', src);

        const inputComponent = model.find && model.find('.email-input')[0];
        if (inputComponent && inputComponent.getAttributes) {
          const inputAttrs = inputComponent.getAttributes();
          if (inputAttrs.placeholder !== input.placeholder) {
            inputComponent.addAttributes({ placeholder: input.placeholder });
          }
        }
        const iconComponent = model.find && model.find('.email-icon-image')[0];
        if (iconComponent && iconComponent.getAttributes) {
          const iconAttrs = iconComponent.getAttributes();
          if (iconAttrs.src !== src) iconComponent.addAttributes({ src: src });
        }
      };
      if (input) {
        input.oninput = function (event) {
          event.stopPropagation();
          model.addAttributes({ 'data-value': input.value });
        };
        input.onpointerdown = function (event) { event.stopPropagation(); };
      }
      if (model.__stage13EmailCleanup) model.__stage13EmailCleanup();
      const onUpdate = function () { render(); };
      model.on('change:traits', onUpdate);
      model.on('change:attributes', onUpdate);
      model.on('active', onUpdate);
      model.__stage13EmailCleanup = function () {
        model.off('change:traits', onUpdate);
        model.off('change:attributes', onUpdate);
        model.off('active', onUpdate);
      };
      render();
    })();
  `
};
