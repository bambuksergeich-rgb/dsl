import { ComponentConfig } from '../elements';

export const Form: ComponentConfig = {
  id: 'form',
  type: 'form',
  label: 'Form',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: { class: 'form-wrapper' },
    components: [
      {
        tagName: 'h2',
        attributes: { class: 'form-header' },
        content: 'Form Header',
        droppable: false,
        draggable: false,
        selectable: true
      },
      {
        tagName: 'div',
        attributes: { class: 'form-container' },
        components: [
          {
            tagName: 'div',
            attributes: { class: 'form-nav vertical' },
            components: [
              {
                tagName: 'div',
                attributes: { class: 'tab-item active' },
                components: [
                  {
                    tagName: 'button',
                    attributes: {
                      class: 'tab-button',
                      'data-value': 'tab1',
                      title: 'Tab 1'
                    },
                    content: 'Tab 1',
                    droppable: false,
                    draggable: false
                  },
                  {
                    tagName: 'button',
                    attributes: { class: 'remove-tab', 'data-value': 'tab1' },
                    content:
                      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4L4 12M4 4L12 12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                    droppable: false,
                    draggable: false
                  }
                ],
                droppable: false,
                draggable: false
              },
              {
                tagName: 'div',
                attributes: { class: 'tab-item' },
                components: [
                  {
                    tagName: 'button',
                    attributes: {
                      class: 'tab-button',
                      'data-value': 'tab2',
                      title: 'Tab 2'
                    },
                    content: 'Tab 2',
                    droppable: false,
                    draggable: false
                  },
                  {
                    tagName: 'button',
                    attributes: { class: 'add-tab' },
                    content:
                      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 3V13M3 8H13" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                    droppable: false,
                    draggable: false
                  },
                  {
                    tagName: 'button',
                    attributes: { class: 'remove-tab', 'data-value': 'tab2' },
                    content:
                      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4L4 12M4 4L12 12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                    droppable: false,
                    draggable: false
                  }
                ],
                droppable: false,
                draggable: false
              }
            ],
            droppable: false,
            draggable: false,
            selectable: false
          },
          {
            tagName: 'div',
            attributes: { class: 'form-content' },
            components: [
              {
                tagName: 'div',
                attributes: {
                  class: 'tab-pane active',
                  'data-value': 'tab1'
                },
                content: '',
                droppable: true,
                draggable: false,
                selectable: true
              },
              {
                tagName: 'div',
                attributes: { class: 'tab-pane', 'data-value': 'tab2' },
                content: '',
                droppable: true,
                draggable: false,
                selectable: true
              }
            ],
            droppable: true,
            draggable: false,
            selectable: true
          }
        ],
        droppable: false,
        draggable: false,
        selectable: false
      }
    ]
  },
  block: true,
  icon: `<svg width="22" height="18" viewBox="0 0 22 18" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M4.5 8.443C4.29913 8.63027 4.06315 8.77591 3.8057 8.87151C3.54825 8.96711 3.27442 9.01078 3 9V8C3.74 8 3.948 7.583 4 7.429V4.569C3.952 4.426 3.749 4 3 4V3C3.27442 2.98922 3.54825 3.03289 3.8057 3.12849C4.06315 3.22409 4.29913 3.36973 4.5 3.557C4.70087 3.36973 4.93685 3.22409 5.1943 3.12849C5.45175 3.03289 5.72558 2.98922 6 3V4C5.26 4 5.052 4.417 5 4.571V7.431C5.048 7.574 5.251 8 6 8V9C5.72558 9.01078 5.45175 8.96711 5.1943 8.87151C4.93685 8.77591 4.70087 8.63027 4.5 8.443ZM22 1.5V16.5C21.9995 16.8977 21.8413 17.2789 21.5601 17.5601C21.2789 17.8413 20.8977 17.9995 20.5 18H1.5C1.10234 17.9995 0.721114 17.8413 0.439924 17.5601C0.158734 17.2789 0.000529159 16.8977 0 16.5V1.5C0.000529159 1.10234 0.158734 0.721114 0.439924 0.439924C0.721114 0.158734 1.10234 0.000529159 1.5 0H20.5C20.8977 0.000529159 21.2789 0.158734 21.5601 0.439924C21.8413 0.721114 21.9995 1.10234 22 1.5ZM21 1.5C21 1.36739 20.9473 1.24021 20.8536 1.14645C20.7598 1.05268 20.6326 1 20.5 1H1.5C1.36739 1 1.24021 1.05268 1.14645 1.14645C1.05268 1.24021 1 1.36739 1 1.5V16.5C1 16.6326 1.05268 16.7598 1.14645 16.8536C1.24021 16.9473 1.36739 17 1.5 17H20.5C20.6326 17 20.7598 16.9473 20.8536 16.8536C20.9473 16.7598 21 16.6326 21 16.5V1.5ZM12 9H13V8H12V9ZM8 9H9V8H8V9ZM14 9H15V8H14V9ZM10 9H11V8H10V9ZM18 9H19V8H18V9ZM16 9H17V8H16V9ZM6 15H7V14H6V15ZM8 15H9V14H8V15ZM10 15H11V14H10V15ZM4 15H5V14H4V15ZM12 15H13V14H12V15ZM18 15H19V14H18V15ZM16 15H17V14H16V15ZM14 15H15V14H14V15Z" fill="white"/>
  </svg>
  `,
  traits: [
    {
      id: 'tabs',
      name: 'tabs',
      type: 'list',
      label: 'Tabs',
      changeProp: true,
      value:
        '[{"value":"tab1","label":"Tab 1","components":[]},{"value":"tab2","label":"Tab 2","components":[]}]'
    },
    {
      id: 'headerText',
      name: 'headerText',
      type: 'text',
      label: 'Header Text',
      changeProp: true,
      value: 'Form Header'
    }
  ],
  styleConfig: {
    sectors: [
      {
        id: 'Form Dimension',
        name: 'Form Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '758',
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: '800',
            units: ['px', '%']
          }
        ]
      },
      {
        id: 'Header Text',
        name: 'Header Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: '24',
            units: ['px']
          },
          {
            id: 'color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  },
  styles: `
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap');

    .form-wrapper {
      min-width: 758px;
      min-height: 800px;
      width: var(--width, 758px);
      height: var(--height, 800px);
      padding: 16px 0px;
      background-color: var(--bg-color, #10161C80);
      border: 2px solid var(--border-color, #3D3AB8);
      border-radius: 12px;
      display: flex;
      flex-direction: column;
      gap: 0px;
      font-family: 'Montserrat', sans-serif;
    }
    .form-header {
      margin: 0 0 16px 0;
      font-size: var(--font-size, 24px);
      color: var(--color, #FFFFFF);
      font-weight: 500;
      font-family: 'Montserrat', sans-serif;
      text-align: left;
    }
    .form-container {
      display: flex;
      flex-direction: row;
      gap: 12px;
      flex: 1;
    }
    .form-nav {
      display: flex;
      flex-direction: column;
      gap: 8px;
      min-width: 120px;
      max-height: 600px;
      overflow-y: auto;
      scrollbar-width: none;
      background-color: transparent;
      position: relative;
      align-items: flex-start;
    }
    .form-nav::-webkit-scrollbar {
      display: none;
    }
    .tab-item {
      display: flex;
      align-items: center;
      gap: 8px;
      width: 320px;
    }
    .tab-item.active {
      background-color: rgba(61, 58, 184, 0.6);
      border: 1px solid #3D3AB8;
      border-radius: 4px;
    }
    .tab-button {
      padding: 8px 16px;
      border: none;
      cursor: pointer;
      transition: all 0.2s;
      width: calc(100% - 32px); /* 24px (remove-tab) + 8px (gap) */
      max-width: calc(320 - 64px); /* Ограничение для ~15 символов */
      text-align: left;
      color: var(--tab-color, #FFFFFF26);
      background: transparent;
      font-size: 16px;
      font-family: 'Montserrat', sans-serif;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .tab-button:last-child {
      width: calc(320 - 64px); /* 24px (add-tab) + 24px (remove-tab) + 16px (2 gaps) */
    }
    .tab-button:hover {
      color: #ffffff;
    }
    .tab-button.active {
      color: #ffffff;
    }
    .remove-tab {
      width: 24px;
      height: 24px;
      padding: 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      background-color: #3D3AB8;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .remove-tab svg {
      width: 16px;
      height: 16px;
    }
    .add-tab {
      width: 24px;
      height: 24px;
      padding: 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      background-color: #3D3AB8;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .add-tab svg {
      width: 16px;
      height: 16px;
    }
    .form-content {
      background-color: var(--bg-color, #10161C80);
      padding: 12px;
      border-radius: 4px;
      flex: 1;
      min-height: 400px;
    }
    .tab-pane {
      display: none;
      min-height: 100px;
      padding: 16px;
      border-radius: 4px;
    }
    .tab-pane.active {
      display: block;
    }
    .tab-pane > * {
      width: 100%;
    }
    @media (max-width: 768px) {
      .form-wrapper {
        min-width: 100%;
        width: 100%;
        max-width: none;
      }
      .form-container {
        flex-direction: column;
      }
      .form-nav {
        flex-direction: row;
        min-width: 0;
        max-height: none;
        overflow-x: auto;
        overflow-y: visible;
        margin-bottom: 12px;
      }
      .tab-item {
        flex-direction: column;
        align-items: center;
        width: auto;
      }
      .tab-item.active {
        border: none;
        background-color: transparent;
      }
      .tab-button {
        width: auto;
        max-width: 80px;
        text-align: center;
      }
      .tab-button:last-child {
        width: auto;
        max-width: 80px;
      }
      .remove-tab, .add-tab {
        width: 20px;
        height: 20px;
      }
      .remove-tab svg, .add-tab svg {
        width: 12px;
        height: 12px;
      }
    }
  `,
  script: `
    function updateForm(model, editor) {
      console.log('updateForm called:', model.changed);
      if (!model || !model.getEl() || !editor) {
        console.error('No model, editor, or wrapper element');
        return;
      }
      const wrapper = model.getEl();
      const traits = model.getTraits();
      try {
        const headerEl = wrapper.querySelector('.form-header');
        const navEl = wrapper.querySelector('.form-nav');
        const contentEl = wrapper.querySelector('.form-content');
        if (headerEl && navEl && contentEl) {
          const tabsTrait = traits.find(t => t.getName() === 'tabs');
          const headerTextTrait = traits.find(t => t.getName() === 'headerText');
          let tabs = [];
          try {
            tabs = tabsTrait?.getValue() ? JSON.parse(tabsTrait.getValue()) : [
              { value: 'tab1', label: 'Tab 1', components: [] },
              { value: 'tab2', label: 'Tab 2', components: [] }
            ];
          } catch (e) {
            console.error('Invalid JSON in tabs trait:', e);
          }

          // Обновляем текст заголовка
          headerEl.textContent = headerTextTrait?.getValue() || 'Form Header';

          // Устанавливаем стили из styleConfig
          const styles = model.getStyle() || {};
          wrapper.style.setProperty('--width', styles.width || '758px');
          wrapper.style.setProperty('--height', styles.height || '800px');
          wrapper.style.setProperty('--bg-color', '#10161C80');
          wrapper.style.setProperty('--border-color', '#3D3AB8');
          headerEl.style.setProperty('--font-size', styles['font-size'] ? \`\${styles['font-size']}px\` : '24px');
          headerEl.style.setProperty('--color', styles.color || '#FFFFFF');

          // Обновляем кнопки и добавляем remove-tab и add-tab
          navEl.innerHTML = tabs.map((tab, i) => \`
            <div class="tab-item \${i === 0 ? 'active' : ''}">
              <button class="tab-button \${i === tabs.length - 1 ? 'last-child' : ''}" data-value="\${tab.value}" title="\${tab.label}">\${tab.label}</button>
              \${i === tabs.length - 1 ? \`
                <button class="add-tab">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 3V13M3 8H13" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </button>
              \` : ''}
              <button class="remove-tab" data-value="\${tab.value}">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 4L4 12M4 4L12 12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </button>
            </div>
          \`).join('');

          // Обновляем содержимое вкладок
          contentEl.innerHTML = '';
          tabs.forEach((tab, i) => {
            const pane = document.createElement('div');
            pane.className = \`tab-pane\${i === 0 ? ' active' : ''}\`;
            pane.setAttribute('data-value', tab.value);
            pane.setAttribute('data-droppable', 'true');
            contentEl.appendChild(pane);
            // Восстанавливаем компоненты
            const paneModel = editor.getWrapper().find(\`.tab-pane[data-value="\${tab.value}"]\`)[0];
            if (paneModel && tab.components && tab.components.length > 0) {
              paneModel.components(tab.components);
            }
          });

          // Добавляем обработчики событий для tab-button
          const buttons = navEl.querySelectorAll('.tab-button');
          buttons.forEach(button => {
            button.removeEventListener('click', handleTabClick);
            button.addEventListener('click', handleTabClick);
            function handleTabClick() {
              const items = navEl.querySelectorAll('.tab-item');
              items.forEach(item => item.classList.remove('active'));
              const panes = contentEl.querySelectorAll('.tab-pane');
              panes.forEach(p => p.classList.remove('active'));
              button.parentElement.classList.add('active');
              const pane = contentEl.querySelector(\`.tab-pane[data-value="\${button.dataset.value}"]\`);
              if (pane) {
                pane.classList.add('active');
                console.log('Tab switched:', button.dataset.value);
              } else {
                console.error('Pane not found for value:', button.dataset.value);
              }
            }
          });

          // Обработчики для remove-tab
          const removeButtons = navEl.querySelectorAll('.remove-tab');
          removeButtons.forEach(button => {
            button.removeEventListener('click', handleRemoveTab);
            button.addEventListener('click', handleRemoveTab);
            function handleRemoveTab() {
              editor.runCommand('remove-tab', { component: model, tabValue: button.dataset.value });
            }
          });

          // Обработчик для add-tab
          const addButton = navEl.querySelector('.add-tab');
          if (addButton) {
            addButton.removeEventListener('click', handleAddTab);
            addButton.addEventListener('click', handleAddTab);
            function handleAddTab() {
              editor.runCommand('add-tab', { component: model });
            }
          }

          // Сохраняем компоненты в трейт при изменении содержимого tab-pane
          editor.on('component:add component:remove component:update', (component) => {
            if (component.closest('.tab-pane')) {
              const panes = contentEl.querySelectorAll('.tab-pane');
              const updatedTabs = Array.from(panes).map((pane, i) => ({
                value: tabs[i]?.value || \`tab\${i + 1}\`,
                label: tabs[i]?.label || \`Tab \${i + 1}\`,
                components: editor.getWrapper().find(\`.tab-pane[data-value="\${tabs[i]?.value || \`tab\${i + 1}\`}"]\`)[0]?.components().toJSON() || []
              }));
              tabsTrait.setValue(JSON.stringify(updatedTabs));
              console.log('Tabs updated with components:', updatedTabs);
            }
          });

          // Перехватываем изменение трейта tabs
          editor.on('trait:change:tabs', () => {
            let tabs = [];
            try {
              tabs = JSON.parse(tabsTrait.getValue() || '[]');
            } catch (e) {
              console.error('Error parsing tabs JSON:', e);
            }
            if (tabs.length > 10) {
              tabs = tabs.slice(0, 10);
              editor.Modal.open({ title: 'Warning', content: 'Maximum 10 tabs allowed.' });
            }
            tabs = tabs.map((tab, i) => {
              const existingValues = tabs.slice(0, i).map(t => t.value);
              if (!tab.value || existingValues.includes(tab.value) || tab.value.startsWith('option')) {
                return {
                  value: \`tab\${i + 1}-\${Date.now()}\`,
                  label: tab.label && !tab.label.startsWith('option') ? tab.label : \`Tab \${i + 1}\`,
                  components: tab.components || []
                };
              }
              return tab;
            });
            tabsTrait.setValue(JSON.stringify(tabs));
            updateForm(model, editor);
            console.log('Tabs trait updated:', tabs);
          });

          console.log('Form updated:', { tabs, headerText: headerTextTrait?.getValue() });
        } else {
          console.error('Missing form elements');
        }
      } catch (e) {
        console.error('Error updating form:', e);
      }
    }

    // Команда для добавления вкладки
    editor.Commands.add('add-tab', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component || component.get('type') !== 'form') {
          editor.Modal.open({ title: 'Error', content: 'Please select a Form component.' });
          return;
        }
        const tabsTrait = component.getTrait('tabs');
        let tabs = [];
        try {
          tabs = JSON.parse(tabsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing tabs JSON:', e);
        }
        if (tabs.length >= 10) {
          editor.Modal.open({ title: 'Error', content: 'Maximum 10 tabs allowed.' });
          return;
        }
        const newTab = { value: \`tab\${tabs.length + 1}-\${Date.now()}\`, label: \`Tab \${tabs.length + 1}\`, components: [] };
        tabs.push(newTab);
        tabsTrait.setValue(JSON.stringify(tabs));
        console.log('Tab added:', tabs);
        updateForm(component, editor);
        editor.Modal.open({ title: 'Success', content: 'Tab added successfully!' });
      }
    });

    // Команда для удаления конкретной вкладки
    editor.Commands.add('remove-tab', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        const tabValue = options.tabValue;
        if (!component || component.get('type') !== 'form' || !tabValue) {
          editor.Modal.open({ title: 'Error', content: 'Please select a Form component and specify a tab to remove.' });
          return;
        }
        const tabsTrait = component.getTrait('tabs');
        let tabs = [];
        try {
          tabs = JSON.parse(tabsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing tabs JSON:', e);
        }
        if (tabs.length <= 1) {
          editor.Modal.open({ title: 'Error', content: 'At least one tab must remain.' });
          return;
        }
        tabs = tabs.filter(tab => tab.value !== tabValue);
        // Если удалена активная вкладка, сделать первую вкладку активной
        if (!tabs.some((tab, i) => i === 0 && document.querySelector(\`.tab-item[data-value="\${tab.value}"]\`)?.classList.contains('active'))) {
          tabs[0].active = true;
        }
        tabsTrait.setValue(JSON.stringify(tabs));
        console.log('Tab removed:', tabValue, tabs);
        updateForm(component, editor);
        editor.Modal.open({ title: 'Success', content: 'Tab removed successfully!' });
      }
    });

    if (model && model.getEl()) {
      console.log('Initial updateForm call');
      updateForm(model, editor);
    }
    model.on('change', () => {
      console.log('Model changed:', model.changed);
      updateForm(model, editor);
    });
  `
};
