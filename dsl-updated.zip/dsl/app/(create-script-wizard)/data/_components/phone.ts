import { ComponentConfig } from '../elements';

const TELEPHONE_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMiIgaGVpZ2h0PSIyMiIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIj48cGF0aCBkPSJNNy4xIDMuNSA0LjggNS44Yy0uOC44LS43IDIuNS4xIDQuMiAxLjYgMy41IDQuNiA2LjUgOC4xIDguMSAxLjcuOCAzLjQuOSA0LjIuMWwyLjMtMi4zLTQtMy4xLTEuOCAxLjhjLTIuMS0xLTMuMy0yLjItNC4zLTQuM2wxLjgtMS44LTMuMS00WiIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPjxwYXRoIGQ9Ik0xNS41IDQuNWMyLjIuNCAzLjYgMS44IDQgNE0xNC43IDcuNGMxLjEuMiAxLjcuOCAxLjkgMS45IiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9zdmc+';

export const Phone: ComponentConfig = {
  id: 'telephone',
  type: 'telephone',
  label: 'Telephone Input',
  category: 'Inputs',
  content: {
    tagName: 'div',
    attributes: { class: 'telephone-input-container' },
    components: [
      {
        tagName: 'select',
        attributes: {
          class: 'telephone-country-code',
          'aria-label': 'Country code'
        },
        draggable: false,
        components: [
          {
            tagName: 'option',
            attributes: { value: '+7' },
            content: '🇷🇺  +7',
            draggable: false
          },
          {
            tagName: 'option',
            attributes: { value: '+1' },
            content: '🇺🇸  +1',
            draggable: false
          },
          {
            tagName: 'option',
            attributes: { value: '+44' },
            content: '🇬🇧  +44',
            draggable: false
          }
        ]
      },
      {
        tagName: 'input',
        attributes: {
          type: 'tel',
          class: 'telephone-input',
          placeholder: 'Normal',
          inputmode: 'tel',
          autocomplete: 'tel'
        },
        draggable: false
      },
      {
        tagName: 'span',
        attributes: { class: 'telephone-icon' },
        draggable: false,
        components: [
          {
            tagName: 'img',
            attributes: {
              class: 'telephone-icon-image',
              src: TELEPHONE_ICON,
              'data-default-src': TELEPHONE_ICON
            },
            draggable: false
          }
        ]
      }
    ]
  },
  block: true,
  icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.1 3.5 4.8 5.8c-.8.8-.7 2.5.1 4.2 1.6 3.5 4.6 6.5 8.1 8.1 1.7.8 3.4.9 4.2.1l2.3-2.3-4-3.1-1.8 1.8c-2.1-1-3.3-2.2-4.3-4.3l1.8-1.8-3.1-4Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M15.5 4.5c2.2.4 3.6 1.8 4 4M14.7 7.4c1.1.2 1.7.8 1.9 1.9" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>',
  traits: [
    {
      id: 'showIcon',
      name: 'showIcon',
      label: 'Show Icon',
      type: 'checkbox',
      changeProp: true,
      value: true
    },
    {
      id: 'inputType',
      name: 'inputType',
      label: 'Type',
      type: 'select',
      changeProp: true,
      value: '',
      options: [
        { id: 'normal', name: 'Normal', value: 'Normal' },
        {
          id: 'with-code-selector',
          name: 'With Code Selector',
          value: 'With Code Selector'
        }
      ]
    },
    {
      id: 'placeholder',
      name: 'placeholder',
      label: 'Placeholder',
      type: 'text',
      changeProp: true,
      value: 'Normal'
    },
    {
      id: 'mask',
      name: 'mask',
      label: 'Mask',
      type: 'text',
      changeProp: true,
      value: '123-123-1234'
    },
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'Image',
      type: 'select-icon',
      changeProp: true,
      value: ''
    }
  ],
  styles: `
/* Standard single-line control height from the editor design. */
.telephone-input-container .telephone-input, .telephone-input-container .telephone-country-code { height: 32px !important; min-height: 32px !important; max-height: 32px !important; line-height: 20px !important; }
[data-draft-id].telephone-input-container, .telephone-input-container { height: 34px !important; min-height: 34px !important; max-height: 34px !important; }

    .telephone-input-container {
      position: relative;
      display: inline-flex;
      align-items: center;
      width: 320px;
      min-width: 240px;
      height: 48px;
      min-height: 48px;
      box-sizing: border-box;
      border: 1px solid transparent;
      border-radius: 4px;
      background: #3A3A3A;
      font-family: Montserrat, Arial, sans-serif;
      overflow: hidden;
      transition: border-color .15s ease, background-color .15s ease;
    }
    .telephone-input-container:hover {
      border-color: rgba(255,255,255,.12);
    }
    .telephone-input-container:focus-within {
      border-color: rgba(255,255,255,.28);
    }
    .telephone-input {
      flex: 1 1 auto;
      width: 100%;
      height: 46px !important;
      min-height: 46px !important;
      padding: 0 56px 0 16px;
      border: 0;
      background: transparent;
      color: #FFFFFF;
      font: 400 15px/46px Montserrat, Arial, sans-serif;
      box-sizing: border-box;
      min-width: 0;
      letter-spacing: .1px;
    }
    .telephone-input::placeholder { color: rgba(255,255,255,.42); }
    .telephone-input:focus { outline: none; }
    .telephone-country-code {
      display: none;
      flex: 0 0 94px;
      width: 94px;
      height: 36px;
      margin: 5px 0 5px 6px;
      padding: 0 8px;
      border: 0;
      border-radius: 3px;
      background: #4B4B4D;
      color: #FFFFFF;
      font: 400 13px Montserrat, Arial, sans-serif;
      box-sizing: border-box;
      outline: none;
      color-scheme: dark;
      cursor: pointer;
    }
    .telephone-country-code option {
      background: #2D2F31;
      color: #FFFFFF;
    }
    .telephone-input-container.with-code .telephone-country-code {
      display: block;
    }
    .telephone-input-container.with-code .telephone-input {
      padding-left: 12px;
    }
    .telephone-icon {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      width: 28px;
      height: 28px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      opacity: .92;
    }
    .telephone-icon-image {
      width: 22px;
      height: 22px;
      object-fit: contain;
    }
  `,
  script: `
    (function () {
      if (!model || !model.getEl()) return;
      const root = model.getEl();
      const input = root.querySelector('.telephone-input');
      const selector = root.querySelector('.telephone-country-code');
      const iconBox = root.querySelector('.telephone-icon');
      const icon = root.querySelector('.telephone-icon-image');
      const defaultIcon = icon
        ? String(icon.getAttribute('data-default-src') || icon.getAttribute('src') || '')
        : '';

      const traitValue = function (name, fallback) {
        const trait = model.getTrait && model.getTrait(name);
        const value = trait && trait.getValue ? trait.getValue() : undefined;
        return value === undefined || value === null || value === '' ? fallback : value;
      };
      const asBool = function (value) {
        return value === true || value === 'true' || value === 1 || value === '1';
      };
      const digitsOnly = function (value) {
        return String(value || '').replace(/\\D/g, '');
      };
      const countryDigits = function (code) {
        return digitsOnly(code || '+7');
      };
      const availableCountryCodes = function () {
        const values = selector && selector.options
          ? Array.from(selector.options).map(function (option) { return String(option.value || ''); })
          : ['+7', '+1', '+44'];
        return values.filter(Boolean).sort(function (a, b) { return b.length - a.length; });
      };
      const explicitCountryCode = function (value) {
        const raw = String(value || '').trim();
        const codes = availableCountryCodes();
        for (let i = 0; i < codes.length; i += 1) {
          if (raw.indexOf(codes[i]) === 0) return codes[i];
        }
        return '';
      };
      const splitLocalDigits = function (value, code, mask, stripExplicitCode) {
        const raw = String(value || '').trim();
        let digits = digitsOnly(raw).slice(0, 15);
        const activeCode = String(code || '');
        const prefix = countryDigits(activeCode);
        if (
          stripExplicitCode &&
          activeCode &&
          raw.indexOf(activeCode) === 0 &&
          prefix &&
          digits.indexOf(prefix) === 0
        ) {
          digits = digits.slice(prefix.length);
        } else if (
          stripExplicitCode &&
          activeCode === '+7' &&
          raw.charAt(0) === '8' &&
          digits.length === 11
        ) {
          digits = digits.slice(1);
        }
        return digits.slice(0, maskSlotCount(mask));
      };
      const normalizeMask = function (value) {
        return String(value || '').trim();
      };
      const maskSlotCount = function (mask) {
        const normalized = normalizeMask(mask);
        if (!normalized) return 10;
        const matches = normalized.match(/[0-9#]/g);
        return matches && matches.length ? matches.length : 10;
      };
      const applyMask = function (digits, mask) {
        const source = String(digits || '');
        const normalized = normalizeMask(mask);
        if (!normalized) return source;
        let index = 0;
        let output = '';
        for (let i = 0; i < normalized.length; i += 1) {
          const char = normalized.charAt(i);
          if (/[0-9#]/.test(char)) {
            if (index >= source.length) break;
            output += source.charAt(index);
            index += 1;
          } else if (index > 0 && index < source.length + 1) {
            output += char;
          }
        }
        return output;
      };
      const formatLocal = function (digits, mask) {
        const limit = maskSlotCount(mask);
        const value = String(digits || '').slice(0, limit);
        if (!value) return '';
        const normalized = normalizeMask(mask);
        if (normalized) return applyMask(value, normalized);
        if (value.length <= 3) return value;
        if (value.length <= 5) return value.slice(0, 3) + '-' + value.slice(3);
        if (value.length <= 7) {
          return value.slice(0, 3) + '-' + value.slice(3, 5) + '-' + value.slice(5);
        }
        if (value.length <= 8) {
          return value.slice(0, 3) + '-' + value.slice(3, 6) + '-' + value.slice(6);
        }
        return (
          value.slice(0, 3) + '-' +
          value.slice(3, 6) + '-' +
          value.slice(6, 8) + '-' +
          value.slice(8, 10)
        );
      };
      const formatFull = function (value, code, mask) {
        const activeCode = String(code || '+7');
        const local = splitLocalDigits(value, activeCode, mask, true);
        return local ? activeCode + '-' + formatLocal(local, mask) : '';
      };
      const formatNormal = function (value, mask) {
        const raw = String(value || '').trim();
        if (!raw) return '';

        const code = explicitCountryCode(raw);
        if (code) {
          const local = splitLocalDigits(raw, code, mask, true);
          return local ? code + '-' + formatLocal(local, mask) : code;
        }

        // Keep an incomplete international prefix editable instead of replacing it with +7.
        if (/^\\+\\d{0,2}$/.test(raw)) return raw;
        return formatLocal(digitsOnly(raw), mask);
      };
      const isWithCode = function () {
        const type = String(traitValue('inputType', 'Normal'));
        return type === 'With Code Selector' || type === 'international';
      };

      const syncNestedModels = function (placeholder, iconSrc, countryCode) {
        const inputComponent = model.find && model.find('.telephone-input')[0];
        if (inputComponent && inputComponent.getAttributes) {
          const attrs = inputComponent.getAttributes();
          if (attrs.placeholder !== placeholder) {
            inputComponent.addAttributes({ placeholder: placeholder });
          }
        }
        const iconComponent = model.find && model.find('.telephone-icon-image')[0];
        if (iconComponent && iconComponent.getAttributes) {
          const attrs = iconComponent.getAttributes();
          if (attrs.src !== iconSrc) iconComponent.addAttributes({ src: iconSrc });
        }
        const selectorComponent = model.find && model.find('.telephone-country-code')[0];
        if (selectorComponent && selectorComponent.getAttributes) {
          const attrs = selectorComponent.getAttributes();
          if (attrs.value !== countryCode) selectorComponent.addAttributes({ value: countryCode });
        }
      };

      const render = function () {
        if (!input) return;
        const attrs = model.getAttributes ? model.getAttributes() : {};
        const withCode = isWithCode();
        const countryCode = String(attrs['data-country-code'] || (selector && selector.value) || '+7');
        const storedValue = attrs['data-value'] == null ? '' : String(attrs['data-value']);
        const placeholder = String(traitValue('placeholder', 'Normal'));
        const mask = normalizeMask(traitValue('mask', '123-123-1234'));
        const showIcon = asBool(traitValue('showIcon', true));
        const iconSrc = String(traitValue('selectImage', '') || defaultIcon);

        root.classList.toggle('with-code', withCode);
        input.placeholder = placeholder;
        if (selector && selector.value !== countryCode) selector.value = countryCode;
        if (iconBox) iconBox.style.display = showIcon ? 'inline-flex' : 'none';
        input.style.paddingRight = showIcon ? '56px' : '16px';
        if (icon && iconSrc && icon.getAttribute('src') !== iconSrc) {
          icon.setAttribute('src', iconSrc);
        }

        const nextVisible = storedValue
          ? (withCode
              ? formatLocal(splitLocalDigits(storedValue, countryCode, mask, true), mask)
              : formatNormal(storedValue, mask))
          : '';
        const activeElement = root.ownerDocument && root.ownerDocument.activeElement;
        if (activeElement !== input && input.value !== nextVisible) input.value = nextVisible;

        syncNestedModels(placeholder, iconSrc, countryCode);
      };

      const persist = function () {
        if (!input) return;
        const countryCode = String((selector && selector.value) || '+7');
        const mask = normalizeMask(traitValue('mask', '123-123-1234'));
        const withCode = isWithCode();
        const localDigits = splitLocalDigits(input.value, countryCode, mask, false);
        const fullValue = withCode
          ? (localDigits ? countryCode + '-' + formatLocal(localDigits, mask) : '')
          : formatNormal(input.value, mask);
        model.addAttributes({
          'data-value': fullValue,
          'data-country-code': countryCode
        });
      };

      if (input) {
        input.oninput = function (event) {
          event.stopPropagation();
          const countryCode = String((selector && selector.value) || '+7');
          const mask = normalizeMask(traitValue('mask', '123-123-1234'));
          const withCode = isWithCode();
          const localDigits = splitLocalDigits(input.value, countryCode, mask, false);
          const next = withCode
            ? formatLocal(localDigits, mask)
            : formatNormal(input.value, mask);
          const cursorAtEnd = input.selectionStart === input.value.length;
          if (input.value !== next) input.value = next;
          if (cursorAtEnd && input.setSelectionRange) {
            input.setSelectionRange(input.value.length, input.value.length);
          }
          persist();
        };
        input.onpointerdown = function (event) { event.stopPropagation(); };
      }

      if (selector) {
        selector.onchange = function (event) {
          event.stopPropagation();
          persist();
        };
        selector.onpointerdown = function (event) { event.stopPropagation(); };
      }

      if (model.__stage14TelephoneCleanup) model.__stage14TelephoneCleanup();
      const onUpdate = function () { render(); };
      model.on('change:traits', onUpdate);
      model.on('change:attributes', onUpdate);
      model.on('active', onUpdate);
      model.__stage14TelephoneCleanup = function () {
        model.off('change:traits', onUpdate);
        model.off('change:attributes', onUpdate);
        model.off('active', onUpdate);
      };
      render();
    })();
  `
};
