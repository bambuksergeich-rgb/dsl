import { ComponentConfig } from '../elements';

export const Tooltip: ComponentConfig = {
  id: 'tooltip',
  type: 'tooltip',
  label: 'Tooltip',
  category: 'Form',
  content: {
    tagName: 'div',
    attributes: { class: 'tooltip-bubble' },
    components: [
      {
        tagName: 'span',
        attributes: { class: 'tooltip-text' },
        content: 'Tooltip content..'
      }
    ],
    droppable: false,
    editable: true,
    selectable: true
  },
  block: false,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4 6C4 4.89543 4.89543 4 6 4H18C19.1046 4 20 4.89543 20 6V14C20 15.1046 19.1046 16 18 16H10L6 20V16H6C4.89543 16 4 15.1046 4 14V6Z" stroke="white" stroke-width="1.5" stroke-linejoin="round"/>
</svg>`,
  traits: [
    {
      id: 'text',
      name: 'text',
      label: 'Text',
      type: 'text',
      changeProp: true,
      value: 'Tooltip content..'
    }
  ],
  styles: `
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap');

    .tooltip-bubble {
      position: relative;
      display: inline-flex;
      align-items: center;
      width: fit-content;
      max-width: 280px;
      background: #FFFFFF;
      color: #1A1A1A;
      padding: 10px 14px;
      border-radius: 6px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
      box-sizing: border-box;
      font-family: 'Montserrat', sans-serif;
      margin-left: 8px;
    }
    .tooltip-bubble::before {
      content: '';
      position: absolute;
      left: -6px;
      top: 50%;
      transform: translateY(-50%);
      width: 0;
      height: 0;
      border-style: solid;
      border-width: 6px 6px 6px 0;
      border-color: transparent #FFFFFF transparent transparent;
    }
    .tooltip-text {
      color: #1A1A1A;
      font-size: 14px;
      font-weight: 400;
      line-height: 1.3;
      white-space: nowrap;
    }
  `,
  script: `
    function updateTooltip(model) {
      if (!model || !model.getEl()) return;
      const textTrait = model.getTrait('text');
      const text = textTrait?.getValue() || 'Tooltip content..';
      const textEl = model.getEl().querySelector('.tooltip-text');
      if (textEl && textEl.textContent !== text) {
        textEl.textContent = text;
      }
      const textComp = model.find('.tooltip-text')?.[0];
      if (textComp) {
        const current = textComp.components().models[0]?.get('content');
        if (current !== text) {
          textComp.components().reset();
          textComp.append(text);
        }
      }
    }

    if (model && model.getEl()) {
      updateTooltip(model);
    }
    model.on('change:text change:traits', () => updateTooltip(model));
    model.on('load', () => updateTooltip(model));
  `,
  styleConfig: {
    sectors: [
      {
        id: 'style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: '#FFFFFF',
            selector: '.tooltip-bubble'
          },
          {
            id: 'text-color',
            name: 'Text Color',
            property: 'color',
            type: 'color',
            default: '#1A1A1A',
            selector: '.tooltip-text'
          },
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            units: ['px'],
            default: 14,
            selector: '.tooltip-text'
          }
        ]
      }
    ]
  }
};
