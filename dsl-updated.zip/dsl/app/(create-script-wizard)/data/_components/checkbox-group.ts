import { ComponentConfig } from '../elements';
import { Checkbox } from './checkbox'; // Импортируем вашу конфигурацию Single Checkbox

export const CheckboxGroup: ComponentConfig = {
  id: 'checkbox-group',
  type: 'checkbox-group', // Новый тип для группы
  label: 'Checkbox',
  category: 'Main',
  block: false,
  content: {
    tagName: 'div',
    attributes: {
      class: 'checkbox-group-container',
      data_type: 'Array',
      data: '["Check-box"]',
      table_role: 'true'
    },
    components: [
      {
        type: 'single-checkbox',
        // ✅ Удаляем traits, пишем сразу в attributes
        attributes: {
          text: 'Check-box',
          data: 'false'
        }
      }
    ]
  },
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="3" y="3" width="18" height="18" rx="2" stroke="white" stroke-width="2"/>
    <path d="M7 12L10 15L17 8" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M7 7H7.01" stroke="white" stroke-width="2" stroke-linecap="round"/>
    <path d="M7 17H7.01" stroke="white" stroke-width="2" stroke-linecap="round"/>
  </svg>`,

  traits: [
    {
      type: 'repeater',
      name: 'checkbox-list',
      label: 'Checkboxes',
      itemId: 'single-checkbox',
      // ✅ Должно быть 'text' (согласно вашим логам "Updating: ... text")
      itemLabel: 'text',
      defaultLabel: 'New Checkbox'
    },

    {
      id: 'group-direction',
      type: 'select',
      name: 'group-direction',
      label: 'Axis',
      changeProp: true,
      options: [
        {
          id: 'row',
          name: 'Horizontal',
          value: 'row'
        },
        {
          id: 'column',
          name: 'Vertical',
          value: 'column'
        }
      ]
    },
    {
      id: 'button-position',
      type: 'select',
      name: 'buttonPosition',
      label: 'Button Position',
      changeProp: true,
      value: 'left',
      options: [
        { id: 'left', name: 'Left', value: 'left' },
        { id: 'right', name: 'Right', value: 'right' },
        { id: 'top', name: 'Top', value: 'top' },
        { id: 'bottom', name: 'Bottom', value: 'bottom' }
      ]
    },
    {
      id: 'group-gap',
      type: 'number',
      name: 'group-gap',
      label: 'Gap (px)',
      changeProp: true,
      min: 0,
      max: 400,
      default: '10px',
      units: ['px', '%', 'vw']
    }
  ],

  styles: `
    ${Checkbox.styles} /* Включаем стили одиночного чекбокса */

    .checkbox-group-container {
      display: flex;
      flex-wrap: wrap;
      width: 100%;
      min-height: 40px;
      padding: 10px;

      /* Дефолтные значения, будут переопределены скриптом/стилями */
      flex-direction: row;
      gap: 10px;

      outline: 1px dashed transparent;
      transition: outline 0.2s;
    }

    .checkbox-group-container.gjs-selected {
      outline: 1px dashed #4170FF;
    }
  `,

  script: `
    function updateGroup(model) {
        if (!model || typeof model.getEl !== 'function') return;
        const el = model.getEl();

        // 1. Логика направления и отступов (сохраняем старую)
        const direction = model.get('group-direction') || 'row';
        const gap = model.get('group-gap') || 10;
        const position = model.get('buttonPosition') || 'left';

        if (el) {
            el.style.flexDirection = direction;
            el.style.gap = gap + 'px';
            if (direction === 'row') {
              el.style.justifyContent = position === 'right' ? 'flex-end' : position === 'left' ? 'flex-start' : 'center';
              el.style.alignItems = position === 'top' ? 'flex-start' : position === 'bottom' ? 'flex-end' : 'center';
            } else {
              el.style.justifyContent = position === 'bottom' ? 'flex-end' : position === 'top' ? 'flex-start' : 'center';
              el.style.alignItems = position === 'right' ? 'flex-end' : position === 'left' ? 'flex-start' : 'center';
            }
        }

        // 2. ✅ НОВАЯ ЛОГИКА: Синхронизация массива данных (data)
        const syncDataArray = () => {
            const children = model.components();
            // Собираем массив значений 'text' от всех дочерних чекбоксов
            const texts = children.map(child => {
                const attrs = child.getAttributes();
                // Берем 'text' (который меняет Repeater) или контент лейбла
                return attrs.text || 'Check-box';
            });

            const newDataValue = JSON.stringify(texts);

            // Обновляем атрибут только если он реально изменился
            if (model.getAttributes().data !== newDataValue) {
                model.addAttributes({ data: newDataValue });
            }
        };

        // Запускаем синхронизацию при инициализации
        syncDataArray();

        // Подписываемся на изменения дочерних элементов
        // 'child:add' - когда добавили через Repeater
        // 'child:remove' - когда удалили
        // 'component:update:attributes' - когда в Repeater поменяли текст у ребенка
        model.listenTo(model.components(), 'add remove change:attributes', syncDataArray);
    }

    if (typeof model !== 'undefined') {
        // Слушаем настройки группы
        model.on('change:group-direction change:group-gap change:buttonPosition', () => updateGroup(model));

        // Инициализация
        setTimeout(() => updateGroup(model), 50);
    }
  `,

  styleConfig: {
    target: '.checkbox-group-container',
    sectors: [
      {
        id: 'flex-children',
        name: 'Flex-Children',
        open: true,
        properties: [
          {
            id: 'flex-order-type',
            name: 'Flex Order Type',
            property: 'order-type', // UI Only
            type: 'radio',
            default: '0',
            options: [
              { id: 'type1', label: 'Type 1', name: '', value: '' },
              { id: 'type2', label: 'Type 2', name: '', value: '' }
            ]
          },
          {
            id: 'order',
            name: 'Order',
            property: '--order',
            type: 'number',
            default: '0'
          },
          {
            id: 'flex-grow-shrink-group',
            name: 'Flex Shrink/Grow',
            type: 'composite',
            property: 'flex-group',
            properties: [
              {
                id: 'flex-basis',
                name: 'Basis',
                property: '--flex-basis',
                type: 'number',
                default: 'auto'
              },
              {
                id: 'flex-shrink',
                name: 'Shrink',
                property: '--flex-shrink',
                type: 'number',
                default: '1'
              },
              {
                id: 'flex-grow',
                name: 'Grow',
                property: '--flex-grow',
                type: 'number',
                default: '0'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align Self',
            property: 'align-self',
            type: 'radio',
            default: 'auto',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'flex-start' },
              { id: 'end', label: 'End', name: '', value: 'flex-end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' }
            ]
          },
          {
            id: 'justify-self',
            name: 'Justify Self',
            property: 'justify-self',
            type: 'radio',
            default: 'start',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'start' },
              { id: 'end', label: 'End', name: '', value: 'end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' },
              { id: 'auto', label: 'Auto', name: '', value: 'auto' }
            ]
          },
          // {
          //   id: 'justify-items',
          //   name: 'Justify Items',
          //   property: '--justify-items',
          //   type: 'radio',
          //   default: 'stretch',
          //   options: [
          //     { id: 'start', label: 'Start', value: 'start', name: '' },
          //     { id: 'end', label: 'End', value: 'end', name: '' },
          //     { id: 'center', label: 'Center', value: 'center', name: '' },
          //     { id: 'stretch', label: 'Stretch', value: 'stretch', name: '' },
          //     { id: 'normal', label: 'Normal', value: 'normal', name: '' }
          //   ]
          // },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: 'justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: 'align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              { id: 'stretch', label: 'Stretch', value: 'stretch', name: '' },
              { id: 'baseline', label: 'Baseline', value: 'baseline', name: '' }
            ]
          }
        ]
      },
      {
        id: 'grid-parent',
        name: 'Grid-Parent',
        open: true,
        properties: [
          {
            id: 'grid-template-columns',
            name: 'Columns',
            property: 'grid-template-columns',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-template-rows',
            name: 'Rows',
            property: 'grid-template-rows',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-column-gap',
            name: 'Gap Column',
            property: 'column-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '10px'
          },
          {
            id: 'grid-row-gap',
            name: 'Gap Row',
            property: 'row-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '10px'
          },
          {
            id: 'justify-items',
            name: 'Justify Items',
            property: 'justify-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'normal',
                label: 'Normal',
                value: 'normal',
                name: ''
              }
            ]
          },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: 'justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: 'align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-grid',
        name: 'Grid-Children',
        open: true,
        properties: [
          {
            id: 'grid-column-start',
            name: 'Start Column',
            property: '--grid-column-start',
            type: 'number',
            default: 'auto',
            units: ['%', 'px', 'rem', 'vw', 'fr']
          },
          {
            id: 'grid-column-end',
            name: 'End Column',
            property: '--grid-column-end',
            type: 'number',
            default: 'auto',
            units: ['%', 'px', 'rem', 'vw', 'fr']
          },
          {
            id: 'grid-row-start',
            name: 'Start Row',
            property: '--grid-row-start',
            type: 'number',
            default: 'auto',
            units: ['%', 'px', 'rem', 'vw', 'fr']
          },
          {
            id: 'grid-row-end',
            name: 'End Row',
            property: '--grid-row-end',
            type: 'number',
            default: 'auto',
            units: ['%', 'px', 'rem', 'vw', 'fr']
          },
          {
            id: 'justify-self',
            name: 'Justify-Self',
            property: '--justify-self',
            type: 'radio',
            default: 'start',
            options: [
              {
                id: 'start',
                label: 'Start',
                name: '',
                value: 'start'
              },
              {
                id: 'end',
                label: 'End',
                name: '',
                value: 'end'
              },
              {
                id: 'stretch',
                label: 'Stretch',
                name: '',
                value: 'stretch'
              },
              {
                id: 'center',
                label: 'Center',
                name: '',
                value: 'center'
              },
              {
                id: 'auto',
                label: 'Auto',
                name: '',
                value: 'auto'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align-Self',
            property: '--align-self',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-position',
        name: 'Position',
        open: true,
        properties: [
          {
            id: 'text-align',
            name: 'Align',
            property: '--text-align',
            type: 'radio',
            default: 'left',
            options: [
              {
                id: 'left',
                label: 'Left',
                name: '',
                value: 'left'
              },
              {
                id: 'center',
                label: 'Center',
                name: '',
                value: 'center'
              },
              {
                id: 'right',
                label: 'Right',
                name: '',
                value: 'right'
              }
            ]
          },
          {
            id: 'position',
            name: 'Position',
            property: '--position',
            type: 'select',
            default: 'relative',
            options: [
              {
                id: 'static',
                label: 'Static',
                name: '',
                value: 'static'
              },
              {
                id: 'relative',
                label: 'Relative',
                name: '',
                value: 'relative'
              },
              {
                id: 'absolute',
                label: 'Absolute',
                name: '',
                value: 'absolute'
              },
              {
                id: 'fixed',
                label: 'Fixed',
                name: '',
                value: 'fixed'
              },
              {
                id: 'sticky',
                label: 'Sticky',
                name: '',
                value: 'sticky'
              }
            ]
          },

          {
            id: 'top',
            name: 'Top',
            property: '--top',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'right',
            name: 'Right',
            property: '--right',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'left',
            name: 'Left',
            property: '--left',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          },
          {
            id: 'bottom',
            name: 'Bottom',
            property: '--bottom',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: false,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw', 'auto'],
            default: 'auto'
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            units: ['vh', '%', 'px', 'rem', 'auto'],
            default: 'auto'
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw'],
            default: '50px'
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            units: ['%', 'px', 'rem', 'vh'],
            default: '50px'
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            units: ['%', 'px', 'rem', 'vw'],
            default: '100%'
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            units: ['%', 'px', 'rem', 'vh'],
            default: '100%'
          },
          {
            id: 'display',
            name: 'Display',
            property: 'display',
            type: 'select',
            default: 'flex',
            options: [
              {
                value: 'block',
                name: 'Block',
                id: 'block'
              },
              {
                value: 'flex',
                name: 'Flex',
                id: 'flex'
              },
              {
                value: 'grid',
                name: 'Grid',
                id: 'grid'
              },
              {
                value: 'inline-block',
                name: 'Inline Block',
                id: 'inline-block'
              }
            ]
          },
          {
            id: 'flex-wrap',
            name: 'Wrap',
            property: 'flex-wrap',
            type: 'select',
            default: 'wrap',
            options: [
              {
                id: 'nowrap',
                label: 'No Wrap',
                value: 'nowrap',
                name: ''
              },
              {
                id: 'wrap',
                label: 'Wrap',
                value: 'wrap',
                name: ''
              }
            ]
          }
        ]
      }
    ]
  }
};
