import { ComponentConfig } from '../elements';

export const Counter: ComponentConfig = {
  id: 'counter',
  type: 'counter',
  label: 'Counter',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: { class: 'counter-wrapper', 'data-value': '0' },
    droppable: false,
    components: [
      {
        tagName: 'div',
        attributes: { class: 'counter-controls' },
        draggable: false,
        components: [
          {
            tagName: 'button',
            attributes: { type: 'button', class: 'counter-decrement', 'aria-label': 'Decrease value' },
            draggable: false,
            content: '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 9H15" stroke="white" stroke-width="1.8" stroke-linecap="round"/></svg>'
          },
          {
            tagName: 'span',
            attributes: { class: 'counter-value' },
            draggable: false,
            content: '0'
          },
          {
            tagName: 'button',
            attributes: { type: 'button', class: 'counter-increment', 'aria-label': 'Increase value' },
            draggable: false,
            content: '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 3V15M3 9H15" stroke="white" stroke-width="1.8" stroke-linecap="round"/></svg>'
          }
        ]
      }
    ]
  },
  block: true,
  icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><text x="1" y="16" fill="#E53950" font-family="Montserrat,Arial,sans-serif" font-size="11" font-weight="700">3D</text></svg>',
  traits: [
    {
      id: 'value',
      name: 'value',
      label: 'Default Value',
      type: 'number',
      changeProp: true,
      value: 0,
      step: 0.01
    },
    {
      id: 'step',
      name: 'step',
      label: 'Step Value',
      type: 'number',
      changeProp: true,
      value: 0.01,
      step: 0.01,
      min: 0.00000001
    }
  ],
  styles: `
    .counter-wrapper {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 188px;
      min-width: 154px;
      min-height: 48px;
      box-sizing: border-box;
      font-family: Montserrat, Arial, sans-serif;
      background: transparent;
      overflow: visible;
    }
    .counter-controls {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      min-height: 48px;
      width: 100%;
      box-sizing: border-box;
    }
    .counter-wrapper button {
      width: 48px;
      height: 48px;
      min-width: 48px;
      min-height: 48px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0;
      border: 0;
      border-radius: 4px;
      background: #4170FF;
      cursor: pointer;
      box-sizing: border-box;
    }
    .counter-value {
      min-width: 62px;
      height: 48px;
      padding: 0 14px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      background: rgba(255, 255, 255, 0.16);
      color: #FFFFFF;
      font-size: 16px;
      font-weight: 500;
      line-height: 1;
      box-sizing: border-box;
      white-space: nowrap;
    }
    .counter-wrapper button:hover { opacity: .9; }
    .counter-wrapper button svg, .counter-wrapper button svg * { pointer-events: none; }
  `,
  script: `
    (function () {
      if (!model || !model.getEl()) return;
      const root = model.getEl();
      const valueEl = root.querySelector('.counter-value');
      const minus = root.querySelector('.counter-decrement');
      const plus = root.querySelector('.counter-increment');

      const numberValue = function (raw, fallback) {
        const value = Number(raw);
        return Number.isFinite(value) ? value : fallback;
      };
      const precision = function (value) {
        const text = String(value);
        const dot = text.indexOf('.');
        return dot < 0 ? 0 : Math.min(8, text.length - dot - 1);
      };
      const readValue = function () {
        const attrs = model.getAttributes ? model.getAttributes() : {};
        return numberValue(attrs['data-value'], 0);
      };
      const render = function () {
        if (!valueEl) return;
        const current = readValue();
        valueEl.textContent = String(current);
      };
      const writeValue = function (next) {
        const stepTrait = model.getTrait && model.getTrait('step');
        const step = numberValue(stepTrait && stepTrait.getValue ? stepTrait.getValue() : 0.01, 0.01);
        const digits = Math.max(precision(step), precision(next));
        const fixed = Number(Number(next).toFixed(digits));
        model.addAttributes({ 'data-value': String(fixed) });
        model.set && model.set('counterValue', fixed);

        // Keep the sidebar's "Default Value" field in sync with the value
        // shown on canvas. This also makes the current value persist through
        // the normal element value pipeline.
        const valueTrait = model.getTrait && model.getTrait('value');
        if (valueTrait && valueTrait.getValue && valueTrait.setValue) {
          const currentTraitValue = Number(valueTrait.getValue());
          if (!Number.isFinite(currentTraitValue) || currentTraitValue !== fixed) {
            valueTrait.setValue(fixed);
          }
        }

        model.trigger && model.trigger('change:counterValue');
        render();
      };
      const change = function (direction, event) {
        if (event) {
          event.preventDefault();
          event.stopPropagation();
        }
        const stepTrait = model.getTrait && model.getTrait('step');
        const step = numberValue(stepTrait && stepTrait.getValue ? stepTrait.getValue() : 0.01, 0.01);
        writeValue(readValue() + direction * step);
      };

      if (minus) minus.onclick = function (event) { change(-1, event); };
      if (plus) plus.onclick = function (event) { change(1, event); };
      [minus, plus].forEach(function (button) {
        if (!button) return;
        button.onpointerdown = function (event) { event.stopPropagation(); };
        button.onmousedown = function (event) { event.stopPropagation(); };
      });

      if (model.__stage13CounterCleanup) model.__stage13CounterCleanup();
      const onUpdate = function () { render(); };
      model.on('change:attributes', onUpdate);
      model.on('change:traits', onUpdate);
      model.on('active', onUpdate);
      model.__stage13CounterCleanup = function () {
        model.off('change:attributes', onUpdate);
        model.off('change:traits', onUpdate);
        model.off('active', onUpdate);
      };
      render();
    })();
  `
};
