import { ComponentConfig } from '../elements';

export const Range: ComponentConfig = {
  id: 'range',
  type: 'range',
  label: 'Range',
  category: 'Form',
  content: {
    tagName: 'div',
    attributes: {
      class: 'range-wrapper range-type-basic',
      'data-value': '50'
    },
    components: [
      {
        tagName: 'label',
        attributes: { class: 'range-label' },
        content: 'Text1',
        draggable: false,
        droppable: false,
        selectable: false
      },
      {
        tagName: 'input',
        attributes: {
          type: 'range',
          class: 'range-input',
          min: '0',
          max: '100',
          value: '50',
          step: '1'
        },
        draggable: false,
        droppable: false,
        selectable: false
      },
      {
        tagName: 'div',
        attributes: { class: 'range-value-display' },
        content: '50',
        draggable: false,
        droppable: false,
        selectable: false
      },
      {
        tagName: 'div',
        attributes: { class: 'range-progress' },
        components: [
          {
            tagName: 'div',
            attributes: { class: 'range-progress-bar' },
            components: [
              {
                tagName: 'span',
                attributes: { class: 'range-progress-text' },
                content: 'Text1',
                draggable: false,
                droppable: false,
                selectable: false
              }
            ],
            draggable: false,
            droppable: false,
            selectable: false
          }
        ],
        draggable: false,
        droppable: false,
        selectable: false
      }
    ],
    droppable: false,
    selectable: true
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M24 7.5C24 6.6 23.4 6 22.5 6H1.5C0.6 6 0 6.6 0 7.5V16.5C0 17.4 0.6 18 1.5 18H22.5C23.4 18 24 17.4 24 16.5V7.5ZM22.5 16.5H1.5V7.5H22.5V16.5Z" fill="white"/>
    <path d="M3 9H4.5V15H3V9Z" fill="white"/>
  </svg>`,
  traits: [
    {
      id: 'min',
      name: 'min',
      label: 'Min value',
      type: 'number',
      changeProp: true,
      value: 0
    },
    {
      id: 'text',
      name: 'text',
      label: 'Text',
      type: 'text',
      changeProp: true,
      value: 'Text1'
    },
    {
      id: 'max',
      name: 'max',
      label: 'Max value',
      type: 'number',
      changeProp: true,
      value: 100
    },
    {
      id: 'color',
      name: 'color',
      label: 'Color',
      type: 'color',
      changeProp: true,
      value: '#4170FF'
    },
    {
      id: 'step',
      name: 'step',
      label: 'Step',
      type: 'number',
      changeProp: true,
      value: 1,
      min: 0.01
    },
    {
      id: 'type',
      name: 'type',
      label: 'Type',
      type: 'select',
      changeProp: true,
      value: 'Type1',
      options: [
        { id: 'Type1', name: 'Basic', value: 'Type1' },
        { id: 'Type2', name: 'Progress Bar', value: 'Type2' }
      ]
    }
  ],
  styles: `
    .range-wrapper {
      width: 320px;
      max-width: 100%;
      min-width: 180px;
      min-height: 56px;
      box-sizing: border-box;
      padding: 8px 0;
      display: flex;
      flex-direction: column;
      align-items: stretch;
      justify-content: center;
      color: #D3D6E7;
      font-family: Montserrat, Arial, sans-serif;
      user-select: none;
      --range-color: #4170FF;
    }

    .range-label {
      display: block;
      width: 100%;
      margin: 0 0 8px 0;
      color: #D3D6E7;
      font-size: 14px;
      font-weight: 500;
      line-height: 18px;
      text-align: left;
      align-self: flex-start;
      justify-self: flex-start;
      pointer-events: none;
    }

    .range-input {
      width: 100%;
      min-width: 0;
      height: 20px;
      margin: 0;
      padding: 0;
      appearance: none;
      -webkit-appearance: none;
      background: transparent;
      outline: none;
      cursor: pointer;
      pointer-events: auto;
    }

    .range-input::-webkit-slider-runnable-track {
      height: 6px;
      border-radius: 999px;
      background: rgba(255,255,255,0.28);
    }

    .range-input::-moz-range-track {
      height: 6px;
      border-radius: 999px;
      background: rgba(255,255,255,0.28);
    }

    .range-input::-webkit-slider-thumb {
      width: 18px;
      height: 18px;
      margin-top: -6px;
      appearance: none;
      -webkit-appearance: none;
      border: 2px solid #FFFFFF;
      border-radius: 50%;
      background: #FFFFFF;
      box-shadow: 0 1px 4px rgba(0,0,0,0.3);
      cursor: pointer;
    }

    .range-input::-moz-range-thumb {
      width: 18px;
      height: 18px;
      border: 2px solid #FFFFFF;
      border-radius: 50%;
      background: #FFFFFF;
      box-shadow: 0 1px 4px rgba(0,0,0,0.3);
      cursor: pointer;
    }

    .range-value-display {
      margin-top: 4px;
      min-height: 16px;
      color: #D3D6E7;
      font-size: 12px;
      line-height: 16px;
      text-align: center;
      align-self: stretch;
      pointer-events: none;
    }

    .range-progress {
      display: none;
      width: 100%;
      min-height: 34px;
      border-radius: 4px;
      overflow: hidden;
      background: rgba(255,255,255,0.14);
      pointer-events: none;
    }

    .range-progress-bar {
      height: 34px;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      padding: 0 12px;
      box-sizing: border-box;
      background: var(--range-color);
      transition: width 120ms ease;
    }

    .range-progress-text {
      overflow: hidden;
      color: #FFFFFF;
      font-size: 14px;
      font-weight: 500;
      line-height: 18px;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .range-wrapper.range-type-progress .range-label,
    .range-wrapper.range-type-progress .range-input {
      display: none;
    }

    .range-wrapper.range-type-progress .range-progress {
      display: block;
    }

    .range-wrapper.range-type-progress .range-value-display {
      text-align: right;
    }
  `,
  script: `
function stage14RangeTrait(model, name, fallback) {
  const trait = model.getTrait && model.getTrait(name);
  const value = trait && trait.getValue ? trait.getValue() : undefined;
  return value === undefined || value === null || value === '' ? fallback : value;
}

function stage14RangeNumber(raw, fallback) {
  const value = Number(raw);
  return Number.isFinite(value) ? value : fallback;
}

function stage14RangeType(raw) {
  const value = String(raw || '').toLowerCase();
  return value === 'type2' || value === 'filled-text' || value === 'progress' || value === 'progress-bar'
    ? 'progress'
    : 'basic';
}

function stage14UpdateRange(model) {
  if (!model || !model.getEl || !model.getEl()) return;

  const wrapper = model.getEl();
  const input = wrapper.querySelector('.range-input');
  const label = wrapper.querySelector('.range-label');
  const progress = wrapper.querySelector('.range-progress-bar');
  const progressText = wrapper.querySelector('.range-progress-text');
  const valueDisplay = wrapper.querySelector('.range-value-display');
  if (!input) return;

  let min = stage14RangeNumber(stage14RangeTrait(model, 'min', 0), 0);
  let max = stage14RangeNumber(stage14RangeTrait(model, 'max', 100), 100);
  if (max < min) {
    const tmp = min;
    min = max;
    max = tmp;
  }
  const step = Math.max(0.000001, stage14RangeNumber(stage14RangeTrait(model, 'step', 1), 1));
  const text = String(stage14RangeTrait(model, 'text', 'Text1'));
  const color = String(stage14RangeTrait(model, 'color', '#4170FF'));
  const type = stage14RangeType(stage14RangeTrait(model, 'type', 'Type1'));
  const attrs = model.getAttributes ? model.getAttributes() : {};
  const stored = model.get && model.get('rangeValue');
  const rawValue = stored !== undefined && stored !== null
    ? stored
    : attrs['data-value'] !== undefined
      ? attrs['data-value']
      : input.value;
  const numeric = stage14RangeNumber(rawValue, min);
  const value = Math.max(min, Math.min(max, numeric));

  input.min = String(min);
  input.max = String(max);
  input.step = String(step);
  input.value = String(value);
  wrapper.style.setProperty('--range-color', color);
  wrapper.classList.toggle('range-type-progress', type === 'progress');
  wrapper.classList.toggle('range-type-basic', type !== 'progress');

  if (label) label.textContent = text;
  if (progressText) progressText.textContent = text;
  if (valueDisplay) valueDisplay.textContent = String(value);

  if (progress) {
    const span = max - min;
    const percent = span > 0 ? ((value - min) / span) * 100 : 0;
    progress.style.width = Math.max(0, Math.min(100, percent)) + '%';
    progress.style.background = color;
  }

  if (!input.__stage14RangeBound) {
    input.__stage14RangeBound = true;
    const stop = function(event) { event.stopPropagation(); };
    input.addEventListener('pointerdown', stop);
    input.addEventListener('mousedown', stop);
    input.addEventListener('touchstart', stop, { passive: true });
    input.addEventListener('input', function() {
      const next = stage14RangeNumber(input.value, min);
      model.set && model.set('rangeValue', next);
      model.addAttributes && model.addAttributes({ 'data-value': String(next) });
      if (valueDisplay) valueDisplay.textContent = String(next);
      if (progress) {
        const liveMin = stage14RangeNumber(input.min, 0);
        const liveMax = stage14RangeNumber(input.max, 100);
        const span = liveMax - liveMin;
        const percent = span > 0 ? ((next - liveMin) / span) * 100 : 0;
        progress.style.width = Math.max(0, Math.min(100, percent)) + '%';
      }
    });
  }
}

if (model && model.getEl && model.getEl()) stage14UpdateRange(model);
if (model.__stage19RangeCleanup) model.__stage19RangeCleanup();
const stage19OnRangeChange = function() { stage14UpdateRange(model); };
model.on('change:traits', stage19OnRangeChange);
model.on('change:attributes', stage19OnRangeChange);
model.on('change:rangeValue', stage19OnRangeChange);
model.__stage19RangeCleanup = function() {
  model.off('change:traits', stage19OnRangeChange);
  model.off('change:attributes', stage19OnRangeChange);
  model.off('change:rangeValue', stage19OnRangeChange);
};
`,
  styleConfig: {
    sectors: []
  }
};
