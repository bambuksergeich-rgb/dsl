import { ComponentConfig } from '../elements';

const TABLE_HEADER_SORT_ICON =
  '<svg width="14" height="14" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 2.25H15C15.2 2.25 15.4 2.33 15.5 2.47C15.7 2.61 15.75 2.8 15.75 3V4.2C15.75 4.4 15.67 4.6 15.53 4.72L10.7 9.53C10.6 9.67 10.5 9.86 10.5 10.1V14.8C10.5 14.9 10.47 15 10.42 15.1C10.37 15.2 10.3 15.3 10.2 15.4C10.1 15.45 10 15.5 9.9 15.52C9.8 15.55 9.7 15.54 9.6 15.5L8.1 15.14C7.9 15.1 7.8 15 7.7 14.88C7.6 14.74 7.5 14.6 7.5 14.4V10.1C7.5 9.9 7.4 9.7 7.3 9.5L2.5 4.7C2.3 4.6 2.25 4.4 2.25 4.2V3C2.25 2.8 2.3 2.6 2.5 2.5C2.6 2.3 2.8 2.25 3 2.25Z"/></svg>';

const buildTableHeaderContent = (label: string) =>
  '<div class="th-content"><span>' +
  label +
  '</span><button class="sort-btn" type="button">' +
  TABLE_HEADER_SORT_ICON +
  '</button></div>';

const createTableHeaderCell = (label: string) => ({
  tagName: 'th',
  type: 'cell',
  content: buildTableHeaderContent(label),
  droppable: true,
  selectable: true,
});

const createTableDataCell = (text: string) => ({
  tagName: 'td',
  type: 'cell',
  content: text,
  droppable: true,
  selectable: true,
});

const createBodyRow = (cells: string[]) => ({
  tagName: 'tr',
  type: 'row',
  components: cells.map(createTableDataCell),
});

const DEFAULT_COLUMNS = ['Language', 'Country', 'Jan', 'Feb', 'Mar'];
const DEFAULT_ROWS = [
  ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
  ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
  ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
  ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
  ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
  ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
  ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
];

export const Table: ComponentConfig = {
  id: 'table',
  type: 'wz-table',
  label: 'Table',
  category: 'Main',
  content: {
    tagName: 'div',
    attributes: {
      class: 'table-wrapper',
      'data-component-type': 'wz-table',
      table_columns_list: JSON.stringify({
        data: DEFAULT_COLUMNS,
        table_role: true,
      }),
      table_rows: JSON.stringify({
        data: DEFAULT_ROWS,
      }),
    },
    components: [
      {
        tagName: 'h3',
        attributes: { class: 'table-header' },
        content: 'Table Title',
        editable: true,
        selectable: true,
        droppable: true,
      },
      {
        tagName: 'div',
        attributes: { class: 'table-content' },
        components: [
          {
            tagName: 'table',
            type: 'table',
            attributes: { class: 'table' },
            droppable: false,
            components: [
              {
                tagName: 'thead',
                type: 'thead',
                components: [
                  {
                    tagName: 'tr',
                    type: 'row',
                    components: DEFAULT_COLUMNS.map(createTableHeaderCell),
                  },
                ],
              },
              {
                tagName: 'tbody',
                type: 'tbody',
                components: DEFAULT_ROWS.map(createBodyRow),
              },
            ],
          },
        ],
      },
    ],
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 18.385V5.615C4 5.171 4.15833 4.791 4.475 4.475C4.791 4.15833 5.171 4 5.615 4H18.385C18.829 4 19.209 4.15833 19.525 4.475C19.8417 4.791 20 5.171 20 5.615V18.385C20 18.829 19.8417 19.209 19.525 19.525C19.209 19.8417 18.829 20 18.385 20H5.615C5.171 20 4.791 19.8417 4.475 19.525C4.15833 19.209 4 18.829 4 18.385ZM5 9.154H19V5.615C19 5.43567 18.9423 5.28833 18.827 5.173C18.7117 5.05767 18.5643 5 18.385 5H5.615C5.43567 5 5.28833 5.05767 5.173 5.173C5.05767 5.28833 5 5.43567 5 5.615V9.154ZM9.998 14.077H14.002V10.154H9.998V14.077ZM9.998 19H14.002V15.077H9.998V19ZM5 14.077H8.998V10.154H5V14.077ZM15.002 14.077H19V10.154H15.002V14.077ZM5.615 19H8.998V15.077H5V18.385C5 18.5643 5.05767 18.7117 5.173 18.827C5.28833 18.9423 5.43567 19 5.615 19ZM15.002 19H18.385C18.5643 19 18.7117 18.9423 18.827 18.827C18.9423 18.7117 19 18.5643 19 18.385V15.077H15.002V19Z" fill="white"/></svg>`,

  traits: [
    {
      id: 'table-data',
      name: 'table-data',
      type: 'json',
      label: 'Data',
      changeProp: true,
      value: JSON.stringify([DEFAULT_COLUMNS, ...DEFAULT_ROWS]),
    },
    {
      id: 'header',
      name: 'header',
      type: 'text',
      label: 'Title',
      changeProp: true,
      value: 'Table Title',
    },
    {
      id: 'showHeader',
      name: 'showHeader',
      type: 'checkbox',
      label: 'Show Header',
      changeProp: true,
      value: true,
    },
    {
      id: 'enableScroll',
      name: 'enableScroll',
      type: 'checkbox',
      label: 'Pagination/Scroll',
      changeProp: true,
      value: true,
    },
    {
      id: 'stickyHeader',
      name: 'stickyHeader',
      type: 'checkbox',
      label: 'Sticky Header',
      changeProp: true,
      value: false,
    },
  ],

  styleConfig: {
    target: '.table-wrapper',
    sectors: [
      {
        id: 'table-style',
        name: 'Table Style',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: '--table-width',
            type: 'number',
            default: '100',
            units: ['%', 'px', 'vw'],
          },
          {
            id: 'height',
            name: 'Height',
            property: '--table-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto'],
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: '--table-min-width',
            type: 'number',
            default: '100',
            units: ['px', '%', 'vw'],
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: '--table-min-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto'],
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: '--table-max-width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vw', 'auto'],
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: '--table-max-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto'],
          },
          {
            id: 'bg-color',
            name: 'Color',
            property: '--table-bg',
            type: 'color',
            default: '#10161C80',
          },
          {
            id: 'border-color',
            name: 'Border Color',
            property: '--table-bc',
            type: 'color',
            default: '#3D3AB8',
          },
          {
            id: 'border-width',
            name: 'Border Width',
            property: '--table-bw',
            type: 'number',
            default: 2,
            units: ['px'],
          },
        ],
      },
      {
        id: 'header-style',
        name: 'Header Style',
        open: true,
        properties: [
          {
            id: 'header-bg',
            name: 'Color',
            property: '--header-bg',
            type: 'color',
            default: '#10161C',
          },
          {
            id: 'header-border-color',
            name: 'Border Color',
            property: '--header-bc',
            type: 'color',
            default: '#3D3AB8',
          },
          {
            id: 'header-border-width',
            name: 'Border Width',
            property: '--header-bw',
            type: 'number',
            default: 1,
            units: ['px'],
          },
          {
            id: 'header-fs',
            name: 'Header Font Size',
            property: '--header-fs',
            type: 'number',
            default: 16,
            units: ['px'],
          },
          {
            id: 'header-color',
            name: 'Header Font Color',
            property: '--header-color',
            type: 'color',
            default: '#FFFFFF',
          },
        ],
      },
      {
        id: 'cell-style',
        name: 'Cell',
        open: true,
        properties: [
          {
            id: 'cell-bg',
            name: 'Background',
            property: '--cell-bg',
            type: 'color',
            default: '#10161C80',
          },
          {
            id: 'cell-height',
            name: 'Height',
            property: '--cell-height',
            type: 'number',
            default: 44,
            units: ['px', '%', 'auto'],
          },
          {
            id: 'cell-min-height',
            name: 'Min-Height',
            property: '--cell-min-height',
            type: 'number',
            default: 44,
            units: ['px', '%', 'auto'],
          },
          {
            id: 'cell-max-height',
            name: 'Max-Height',
            property: '--cell-max-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'auto'],
          },
        ],
      },
    ],
  },

  styles: `
    .th-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 14px;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }

    .sort-btn {
      background: none;
      border: none;
      cursor: pointer;
      padding: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      transition: background 0.2s;
      color: #D3D6E7;
      min-width: 24px;
      min-height: 24px;
    }

    .sort-btn:hover { background-color: rgba(255, 255, 255, 0.1); }
    .sort-btn.active { color: #4170FF !important; }
    .sort-btn.desc svg { transform: rotate(180deg); }
    .sort-btn svg { stroke: currentColor; display: block; width: 14px; height: 14px; }

    .table-wrapper {
      display: flex;
      flex-direction: column;
      --table-width: 100%;
      --table-height: auto;
      --table-min-width: 100px;
      --table-min-height: auto;
      --table-max-width: none;
      --table-max-height: none;
      --table-bg: #10161C80;
      --table-bc: #3D3AB8;
      --table-bw: 2px;
      --header-bg: #10161C;
      --header-bc: #3D3AB8;
      --header-bw: 1px;
      --header-fs: 16px;
      --header-color: #FFFFFF;
      --cell-bg: #10161C80;
      --cell-height: auto;
      --cell-min-height: 44px;
      --cell-max-height: none;
      width: var(--table-width);
      height: var(--table-height);
      min-width: var(--table-min-width);
      min-height: var(--table-min-height);
      max-width: var(--table-max-width);
      max-height: var(--table-max-height);
      background-color: var(--table-bg);
      border-style: solid;
      border-width: var(--table-bw);
      border-color: var(--table-bc);
      border-radius: 12px;
      overflow: hidden;
      box-sizing: border-box;
      font-family: 'Montserrat', sans-serif;
    }

    .table-header {
      background-color: var(--header-bg);
      color: var(--header-color);
      font-size: var(--header-fs);
      border-bottom-style: solid;
      border-bottom-width: var(--header-bw);
      border-bottom-color: var(--header-bc);
      padding: 10px;
      margin: 0;
      text-align: center;
      display: block;
      gap: 10px;
    }

    .table-content {
      width: 100%;
      overflow-x: auto;
      flex: 1;
    }
    .table-content.no-scroll { overflow-x: visible; }

    .table {
      width: 100%;
      border-collapse: collapse;
      table-layout: auto;
    }

    .table th {
      background-color: var(--header-bg);
      color: var(--header-color);
      font-size: var(--header-fs);
      border-bottom-style: solid;
      border-bottom-width: var(--header-bw);
      border-bottom-color: var(--header-bc);
      font-weight: bold;
      padding: 0;
      text-align: left;
      vertical-align: middle;
    }

    .table th.sticky-header {
        position: sticky;
        top: 0;
        z-index: 5;
        box-shadow: 0 1px 0 var(--header-bc);
    }

    .table td {
      background-color: var(--cell-bg);
      height: var(--cell-height);
      min-height: var(--cell-min-height);
      max-height: var(--cell-max-height);
      color: #E2E8F0;
      padding: 14px;
      border: 1px solid #FFFFFF26;
      text-align: left;
      vertical-align: top;
      gap: 10px;
    }
  `,

  script: `
function initTableAdvanced(model) {
  if (!model) return;

  if (model.__wzTableUpdating) return;

  const SORT_ICON = '<svg width="14" height="14" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 2.25H15C15.2 2.25 15.4 2.33 15.5 2.47C15.7 2.61 15.75 2.8 15.75 3V4.2C15.75 4.4 15.67 4.6 15.53 4.72L10.7 9.53C10.6 9.67 10.5 9.86 10.5 10.1V14.8C10.5 14.9 10.47 15 10.42 15.1C10.37 15.2 10.3 15.3 10.2 15.4C10.1 15.45 10 15.5 9.9 15.52C9.8 15.55 9.7 15.54 9.6 15.5L8.1 15.14C7.9 15.1 7.8 15 7.7 14.88C7.6 14.74 7.5 14.6 7.5 14.4V10.1C7.5 9.9 7.4 9.7 7.3 9.5L2.5 4.7C2.3 4.6 2.25 4.4 2.25 4.2V3C2.25 2.8 2.3 2.6 2.5 2.5C2.6 2.3 2.8 2.25 3 2.25Z"/></svg>';

  function findByClass(root, className) {
    if (!root) return null;
    const found = root.find('.' + className);
    if (found && found.length) return found[0];
    const comps = root.components ? root.components() : null;
    if (!comps) return null;
    for (let i = 0; i < comps.length; i++) {
      const child = comps.at(i);
      const classes = child.getClasses ? child.getClasses() : [];
      const attrs = child.getAttributes ? child.getAttributes() : {};
      const attrClass = attrs.class || attrs.className || '';
      const classList = Array.isArray(classes) ? classes : [];
      const attrList = typeof attrClass === 'string' ? attrClass.split(/\\s+/) : [];
      if (classList.includes(className) || attrList.includes(className)) {
        return child;
      }
    }
    return null;
  }

  function syncRowComponents(rowModel, rowData, type) {
    if (!rowModel || !Array.isArray(rowData)) return;
    const cells = rowModel.components();
    while (cells.length > rowData.length) {
      cells.remove(cells.at(cells.length - 1));
    }
    rowData.forEach((text, index) => {
      let cell = cells.at(index);
      const safeText = text == null ? '' : String(text);
      if (type === 'th') {
        const htmlContent = '<div class="th-content"><span>' + safeText + '</span><button class="sort-btn" type="button">' + SORT_ICON + '</button></div>';
        if (!cell) {
          cell = cells.add({
            tagName: 'th',
            type: 'cell',
            content: htmlContent,
            droppable: true,
            selectable: true,
          });
        } else if (cell.get('content') !== htmlContent) {
          cell.set('content', htmlContent);
        }
      } else if (!cell) {
        cells.add({
          tagName: 'td',
          type: 'cell',
          content: safeText,
          droppable: true,
          selectable: true,
        });
      } else if (cell.get('content') !== safeText) {
        cell.set('content', safeText);
      }
    });
  }

  function updateTableFromTraits() {
    if (model.__wzTableUpdating) return;
    model.__wzTableUpdating = true;

    try {
      const traits = model.getTraits ? model.getTraits() : [];
      const dataTrait = traits.find(function(t) { return t.getName() === 'table-data'; });
      if (!dataTrait) return;

      let data = [];
      try {
        data = JSON.parse(dataTrait.getValue() || '[]');
      } catch (e) {
        console.error('Invalid JSON in table-data', e);
        return;
      }

      if (!Array.isArray(data) || !data.length) return;

      const cols = data[0] || [];
      const bodyRows = data.slice(1);
      const currentAttributes = model.getAttributes() || {};

      model.setAttributes({
        ...currentAttributes,
        table_columns_list: JSON.stringify({
          data: cols,
          table_role: true,
        }),
        table_rows: JSON.stringify({
          data: bodyRows,
        }),
      });

      const headerComp = findByClass(model, 'table-header');
      if (headerComp) {
        const headerTrait = traits.find(function(t) { return t.getName() === 'header'; });
        const showHeaderTrait = traits.find(function(t) { return t.getName() === 'showHeader'; });
        const headerText = (headerTrait && headerTrait.getValue()) || 'Table Title';
        const showHeader = showHeaderTrait ? showHeaderTrait.getValue() : true;
        if (headerComp.get('content') !== headerText) {
          headerComp.set('content', headerText);
        }
        const style = headerComp.getStyle() || {};
        if (showHeader && style.display === 'none') {
          headerComp.addStyle({ display: 'block' });
        } else if (!showHeader && style.display !== 'none') {
          headerComp.addStyle({ display: 'none' });
        }
      }

      const contentDiv = findByClass(model, 'table-content');
      if (!contentDiv) return;

      const enableScrollTrait = traits.find(function(t) { return t.getName() === 'enableScroll'; });
      const enableScroll = enableScrollTrait ? enableScrollTrait.getValue() : true;
      if (enableScroll) {
        contentDiv.removeClass('no-scroll');
      } else {
        contentDiv.addClass('no-scroll');
      }

      const table = contentDiv.components().at(0);
      if (!table) return;

      let thead = table.components().at(0);
      let tbody = table.components().at(1);
      if (!thead || thead.get('tagName') !== 'thead') {
        thead = table.components().add({ tagName: 'thead', type: 'thead' }, { at: 0 });
      }
      if (!tbody || tbody.get('tagName') !== 'tbody') {
        tbody = table.components().add({ tagName: 'tbody', type: 'tbody' });
      }

      const headRow = thead.components().at(0) || thead.components().add({ tagName: 'tr', type: 'row' });
      syncRowComponents(headRow, cols, 'th');

      const rows = tbody.components();
      while (rows.length > bodyRows.length) {
        rows.remove(rows.at(rows.length - 1));
      }
      bodyRows.forEach(function(rowData, index) {
        let row = rows.at(index);
        if (!row) row = rows.add({ tagName: 'tr', type: 'row' });
        syncRowComponents(row, rowData, 'td');
      });

      const stickyTrait = traits.find(function(t) { return t.getName() === 'stickyHeader'; });
      const sticky = stickyTrait ? stickyTrait.getValue() : false;
      headRow.components().forEach(function(th) {
        if (sticky) th.addClass('sticky-header');
        else th.removeClass('sticky-header');
      });
    } finally {
      model.__wzTableUpdating = false;
      setTimeout(function() { initSortListeners(); }, 0);
    }
  }

  function initSortListeners(attempt) {
    attempt = attempt || 0;
    const wrapper = model.getEl && model.getEl();
    if (!wrapper) {
      if (attempt < 20) {
        setTimeout(function() { initSortListeners(attempt + 1); }, 50);
      }
      return;
    }
    const table = wrapper.querySelector('table');
    if (!table) {
      if (attempt < 20) {
        setTimeout(function() { initSortListeners(attempt + 1); }, 50);
      }
      return;
    }
    if (table._sortListenerAttached) return;

    table.addEventListener('click', function(e) {
      const btn = e.target.closest('.sort-btn');
      if (!btn) return;

      e.preventDefault();
      e.stopPropagation();

      const th = btn.closest('th');
      if (!th || !th.parentElement) return;
      const thIndex = Array.from(th.parentElement.children).indexOf(th);
      const tbody = table.querySelector('tbody');
      if (!tbody) return;

      table.querySelectorAll('.sort-btn').forEach(function(b) {
        if (b !== btn) b.classList.remove('active', 'desc');
      });

      const isAsc = !btn.classList.contains('active') || btn.classList.contains('desc');
      btn.classList.add('active');
      if (isAsc) btn.classList.remove('desc');
      else btn.classList.add('desc');

      const sortedRows = Array.from(tbody.querySelectorAll('tr')).sort(function(rowA, rowB) {
        const cellA = (rowA.children[thIndex] && rowA.children[thIndex].textContent || '').trim();
        const cellB = (rowB.children[thIndex] && rowB.children[thIndex].textContent || '').trim();
        const numA = parseFloat(cellA.replace(/[^0-9.-]+/g, ''));
        const numB = parseFloat(cellB.replace(/[^0-9.-]+/g, ''));
        if (!isNaN(numA) && !isNaN(numB)) return isAsc ? numA - numB : numB - numA;
        return isAsc ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
      });

      sortedRows.forEach(function(row) { tbody.appendChild(row); });
    });

    table._sortListenerAttached = true;
  }

  model.__updateTableFromTraits = updateTableFromTraits;
  model.__initSortListeners = initSortListeners;

  if (!model.__wzTableInited) {
    model.__wzTableInited = true;
    model.on('change:traits', updateTableFromTraits);
    ['table-data', 'header', 'showHeader', 'enableScroll', 'stickyHeader'].forEach(function(name) {
      model.on('change:' + name, updateTableFromTraits);
    });
  }

  setTimeout(function() {
    updateTableFromTraits();
    initSortListeners();
  }, 50);
}

if (typeof model !== 'undefined') {
  if (model.__updateTableFromTraits) {
    model.__updateTableFromTraits();
  } else {
    setTimeout(function() { initTableAdvanced(model); }, 50);
  }
}
`,
};
