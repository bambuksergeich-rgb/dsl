import { getActiveEditor } from '@/src/editor/editorRegistry';
import { ComponentConfig } from '../elements';

export const Icon: ComponentConfig = {
  id: 'image-icon',
  type: 'image-icon',
  label: 'Icon',
  category: 'Main',
  content: {
    tagName: 'img',
    attributes: {
      class: 'icon-element',
      src: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNDUuNDk3OSAyOC42ODk5SDQwLjIxODVDNDAuMjE4NSAzMS40IDM5LjE0MTkgMzMuOTk5MSAzNy4yMjU2IDM1LjkxNTQgQzM1LjMwOTIgMzcuODMxNyAzMi43MTAyIDM4LjkwODMgMzAgMzguOTA4MyBDMjcuMjkgMzguOTA4MyAyNC42OTEgMzcuODMxNyAyMi43NzQ3IDM1LjkxNTQgQzIwLjg1ODQgMzMuOTk5MSAxOS43ODE4IDMxLjQgMTkuNzgxOCAyOC42ODk5SDUuNTAyMzNDNC4zNzYwOSAyOC43MTY0IDMuMzA1MzEgMjkuMTg0NSAyLjUyMTA3IDI5Ljk5MzIgQzEuNzM2ODMgMzAuODAyIDEuMzAxOTYgMzEuODg2NiAxLjMxMDE3IDMzLjAxMzFWMzMuMDEzMUMxLjMwMTk2IDU0Ljc3MjggMS43MzY4MyA1NS44NTc0IDIuNTIxMDcgNTYuNjY2MSBDMy4zMDUzMSA1Ny40NzQ5IDQuMzc2MDkgNTcuOTQzIDUuNTAyMzMgNTcuOTY5NEg1NC40OTc5QzU1LjYyNDIgNTcuOTQzIDU2LjY5NDkgNTcuNDc0OSA1Ny40NzkxIDU2LjY2NjEgQzU4LjI2MzMgNTUuODU3NCA1OC42OTgzIDU0Ljc3MjggNTguNjkwMSA1My42NDYzVjMzLjAxMzFDNTguNjk4MyAzMS44ODY2IDU4LjI2MzMgMzAuODAyIDU3LjQ3OTEgMjkuOTkzMiBDNTYuNjk0OSAyOS4xODQ1IDU1LjYyNDIgMjguNzE2NCA1NC40OTc5IDI4LjY4OTlaIiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48cGF0aCBkPSJNNTEuNTUwNCAyOC40Mjc5VjEzLjk1MTlDNTEuNTUwNCA2LjY4MTE2IDUyLjcyOTQgMi4yOTI1MyA0Ni41MDY3IDIuMDMwNTJIMTQuMTQ4NkM3LjY2MzkyIDIuMDMwNTIgOC4zODQ0MSA2LjM1MzY3IDguMzg0NDEgMTIuOTAzOVYyOC43NTU0IiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNMTguMjA5NiAxMi43NzI5SDE3Ljk0NzZDMTcuNzU3MSAxMi43NzEyIDE3LjU3NDcgMTIuNjk0NyAxNy40NDAgMTIuNTYwMEMxNy4zMDUyIDEyLjQyNTIgMTcuMjI4OCAxMi4yNDI5IDE3LjIyNzEgMTIuMDUyNFYxMS43OTA0QzE3LjIyODggMTEuNTk5OCAxNy4zMDUyIDExLjQxNzUgMTcuNDQwIDExLjI4MjhDMTcuNTc0NyAxMS4xNDggMTcuNzU3MSAxMS4wNzE1IDE3Ljk0NzYgMTEuMDY5OEgxOC4yMDk2QzE4LjQwMDEgMTEuMDcxNSAxOC41ODI1IDExLjE0OCAxOC43MTcyIDExLjI4MjhDMTguODUyIDExLjQxNzUgMTguOTI4NSAxMS41OTk4IDE4LjkzMDIgMTEuNzkwNFYxMi4wNTI0QzE4LjkyODUgMTIuMjQyOSAxOC44NTIgMTIuNDI1MiAxOC43MTcyIDEyLjU2MDBDMTguNTgyNSAxMi42OTQ3IDE4LjQwMDEgMTIuNzcxMiAxOC4yMDk2IDEyLjc3MjlaIiBmaWxsPSIjNDE3MEZGIiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMS4zMTAwNCIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIi8+PHBhdGggZD0iTTIyLjAwODkgMTkuMTI2NkgyMS43NDY5QzIxLjU1NjMgMTkuMTI0OSAyMS4zNzQxIDE5LjA0ODUgMjEuMjM5MyAxOC45MTM3QzIxLjEwNDUgMTguNzc5IDIxLjAyODEgMTguNTk2NyAyMS4wMjY0IDE4LjQwNjFWMTguMTQ0MUMyMS4wMjgxIDE3Ljk1MzUgMjEuMTA0NSAxNy43NzEzIDIxLjIzOTMgMTcuNjM2NUMyMS4zNzQxIDE3LjUwMTggMjEuNTU2MyAxNy40MjUzIDIxLjc0NjkgMTcuNDIzNkgxMi4wMDg5QzIyLjE5OTUgMTcuNDI1MyAyMi4zODE3IDE3LjUwMTggMjIuNTE2NSAxNy42MzY1QzIyLjY1MTIgMTcuNzcxMyAyMi43Mjc3IDE3Ljk1MzUgMjIuNzI5NCAxOC4xNDQxVjE4LjQwNjFDMjIuNzM5NyAxOC41MDMzIDIyLjcyODIgMTguNjAxNSAyMi42OTU3IDE4LjY5MzZDIDIyLjY2MzEgMTguNzg1NyAyMi42MTAzIDE4Ljg2OTQgMjIuNTQxMyAxOC45Mzg0QzIyLjQ3MjIgMTkuMDA3NSAyMi4zODg1IDE5LjA2MDMgMjIuMjk2NCAxOS4wOTI4QzIyLjIwNDIgMTkuMTI1NCAyMi4xMDYgMTkuMTM3IDIyLjAwODkgMTkuMTI2NloiIGZpbGw9IiM0MTcwRkYiIHN0cm9rZT0iIzQxNzBGRiIgc3Ryb2tlLXdpZHRoPSIxLjMxMDA0IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiLz48cGF0aCBkPSJN NTEuNjgxNCAxMy4wMzQ5TDU4LjAzNTEgMzAuMzkzIiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNMS44OTk2NiAzMC41ODk1TDguMTg3ODcgMTMuNjg5OSIgc3Ryb2tlPSIjNDE3MEZGIiBzdHJva2Utd2lkdGg9IjIuNjIwMDkiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PHBhdGggZD0iTTIzLjQ0OTcgMTEuOTIxNEgzNC45MTI2IiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNMjYuOTg3MSAxOC4yNzVIMzguNDQ5OSIgc3Ryb2tlPSIjNDE3MEZGIiBzdHJva2Utd2lkdGg9IjIuNjIwMDkiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9zdmc+',
      alt: 'Icon',
      'data-icon-src':
        'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNDUuNDk3OSAyOC42ODk5SDQwLjIxODVDNDAuMjE4NSAzMS40IDM5LjE0MTkgMzMuOTk5MSAzNy4yMjU2IDM1LjkxNTQgQzM1LjMwOTIgMzcuODMxNyAzMi43MTAyIDM4LjkwODMgMzAgMzguOTA4MyBDMjcuMjkgMzguOTA4MyAyNC42OTEgMzcuODMxNyAyMi43NzQ3IDM1LjkxNTQgQzIwLjg1ODQgMzMuOTk5MSAxOS43ODE4IDMxLjQgMTkuNzgxOCAyOC42ODk5SDUuNTAyMzNDNC4zNzYwOSAyOC43MTY0IDMuMzA1MzEgMjkuMTg0NSAyLjUyMTA3IDI5Ljk5MzIgQzEuNzM2ODMgMzAuODAyIDEuMzAxOTYgMzEuODg2NiAxLjMxMDE3IDMzLjAxMzFWMzMuMDEzMUMxLjMwMTk2IDU0Ljc3MjggMS43MzY4MyA1NS44NTc0IDIuNTIxMDcgNTYuNjY2MSBDMy4zMDUzMSA1Ny40NzQ5IDQuMzc2MDkgNTcuOTQzIDUuNTAyMzMgNTcuOTY5NEg1NC40OTc5QzU1LjYyNDIgNTcuOTQzIDU2LjY5NDkgNTcuNDc0OSA1Ny40NzkxIDU2LjY2NjEgQzU4LjI2MzMgNTUuODU3NCA1OC42OTgzIDU0Ljc3MjggNTguNjkwMSA1My42NDYzVjMzLjAxMzFDNTguNjk4MyAzMS44ODY2IDU4LjI2MzMgMzAuODAyIDU3LjQ3OTEgMjkuOTkzMiBDNTYuNjk0OSAyOS4xODQ1IDU1LjYyNDIgMjguNzE2NCA1NC40OTc5IDI4LjY4OTlaIiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48cGF0aCBkPSJNNTEuNTUwNCAyOC40Mjc5VjEzLjk1MTlDNTEuNTUwNCA2LjY4MTE2IDUyLjcyOTQgMi4yOTI1MyA0Ni41MDY3IDIuMDMwNTJIMTQuMTQ4NkM3LjY2MzkyIDIuMDMwNTIgOC4zODQ0MSA2LjM1MzY3IDguMzg0NDEgMTIuOTAzOVYyOC43NTU0IiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNMTguMjA5NiAxMi43NzI5SDE3Ljk0NzZDMTcuNzU3MSAxMi43NzEyIDE3LjU3NDcgMTIuNjk0NyAxNy40NDAgMTIuNTYwMEMxNy4zMDUyIDEyLjQyNTIgMTcuMjI4OCAxMi4yNDI5IDE3LjIyNzEgMTIuMDUyNFYxMS43OTA0QzE3LjIyODggMTEuNTk5OCAxNy4zMDUyIDExLjQxNzUgMTcuNDQwIDExLjI4MjhDMTcuNTc0NyAxMS4xNDggMTcuNzU3MSAxMS4wNzE1IDE3Ljk0NzYgMTEuMDY5OEgxOC4yMDk2QzE4LjQwMDEgMTEuMDcxNSAxOC41ODI1IDExLjE0OCAxOC43MTcyIDExLjI4MjhDMTguODUyIDExLjQxNzUgMTguOTI4NSAxMS41OTk4IDE4LjkzMDIgMTEuNzkwNFYxMi4wNTI0QzE4LjkyODUgMTIuMjQyOSAxOC44NTIgMTIuNDI1MiAxOC43MTcyIDEyLjU2MDBDMTguNTgyNSAxMi42OTQ3IDE4LjQwMDEgMTIuNzcxMiAxOC4yMDk2IDEyLjc3MjlaIiBmaWxsPSIjNDE3MEZGIiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMS4zMTAwNCIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIi8+PHBhdGggZD0iTTIyLjAwODkgMTkuMTI2NkgyMS43NDY5QzIxLjU1NjMgMTkuMTI0OSAyMS4zNzQxIDE5LjA0ODUgMjEuMjM5MyAxOC45MTM3QzIxLjEwNDUgMTguNzc5IDIxLjAyODEgMTguNTk2NyAyMS4wMjY0IDE4LjQwNjFWMTguMTQ0MUMyMS4wMjgxIDE3Ljk1MzUgMjEuMTA0NSAxNy43NzEzIDIxLjIzOTMgMTcuNjM2NUMyMS4zNzQxIDE3LjUwMTggMjEuNTU2MyAxNy40MjUzIDIxLjc0NjkgMTcuNDIzNkgxMi4wMDg5QzIyLjE5OTUgMTcuNDI1MyAyMi4zODE3IDE3LjUwMTggMjIuNTE2NSAxNy42MzY1QzIyLjY1MTIgMTcuNzcxMyAyMi43Mjc3IDE3Ljk1MzUgMjIuNzI5NCAxOC4xNDQxVjE4LjQwNjFDMjIuNzM5NyAxOC41MDMzIDIyLjcyODIgMTguNjAxNSAyMi42OTU3IDE4LjY5MzZDIDIyLjY2MzEgMTguNzg1NyAyMi42MTAzIDE4Ljg2OTQgMjIuNTQxMyAxOC45Mzg0QzIyLjQ3MjIgMTkuMDA3NSAyMi4zODg1IDE5LjA2MDMgMjIuMjk2NCAxOS4wOTI4QzIyLjIwNDIgMTkuMTI1NCAyMi4xMDYgMTkuMTM3IDIyLjAwODkgMTkuMTI2NloiIGZpbGw9IiM0MTcwRkYiIHN0cm9rZT0iIzQxNzBGRiIgc3Ryb2tlLXdpZHRoPSIxLjMxMDA0IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiLz48cGF0aCBkPSJN NTEuNjgxNCAxMy4wMzQ5TDU4LjAzNTEgMzAuMzkzIiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNMS44OTk2NiAzMC41ODk1TDguMTg3ODcgMTMuNjg5OSIgc3Ryb2tlPSIjNDE3MEZGIiBzdHJva2Utd2lkdGg9IjIuNjIwMDkiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PHBhdGggZD0iTTIzLjQ0OTcgMTEuOTIxNEgzNC45MTI2IiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNMjYuOTg3MSAxOC4yNzVIMzguNDQ5OSIgc3Ryb2tlPSIjNDE3MEZGIiBzdHJva2Utd2lkdGg9IjIuNjIwMDkiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9zdmc+'
    },
    droppable: true,
    editable: true,
    selectable: true,
    resizable: {
      cr: true, // Правый край для ширины
      bc: true, // Нижний край для высоты
      minDim: 10,
      maxDim: 2000,
      updateTarget: (el: HTMLElement, rect: any) => {
        const width = Number(rect.width ?? rect.w ?? 0);
        const height = Number(rect.height ?? rect.h ?? 0);
        const size = Math.max(width, height);
        const clampedSize = Math.max(50, Math.min(1200, size));

        console.log('Resizing subcolumn to:', clampedSize + 'px');

        el.style.width = clampedSize + 'px';
        el.style.height = clampedSize + 'px';
        el.style.minWidth = clampedSize + 'px';
        el.style.minHeight = clampedSize + 'px';
        el.style.aspectRatio = '1/1';

        const editor = getActiveEditor();
        if (editor) {
          const component = editor.getSelected();
          if (component && component.getEl() === el) {
            const styles = {
              width: clampedSize + 'px',
              height: clampedSize + 'px',
              'min-width': clampedSize + 'px',
              'min-height': clampedSize + 'px',
              'aspect-ratio': '1/1'
            };

            component.setStyle(styles);
            component.trigger('change:style');

            component.addAttributes({
              'data-custom-width': clampedSize + 'px',
              'data-custom-height': clampedSize + 'px'
            });

            console.log('Styles saved to model:', styles);
          }
        }
      }
    }
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M20.0409 0L12.0941 2.46463L3.95909 0C1.77248 0 0 2.91155 0 6.50005V17.5C0 21.0885 1.77248 24 3.95909 24L12.0941 21.7698L20.0409 24C22.2275 24 24 21.0885 24 17.5V6.50005C24 2.91155 22.2275 0 20.0409 0ZM14.8003 13.401L11.0279 17.6007C10.4015 18.2996 9.52952 18.2952 8.89252 17.592L8.93619 6.41022C9.56717 5.71136 10.3593 5.92387 10.9963 6.63149L14.7927 10.8597C15.4282 11.5629 15.4313 12.7021 14.8003 13.401Z" fill="white"/>
</svg>`,
  traits: [
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'File icon',
      type: 'select-icon',
      changeProp: true,
      value: ''
    }
  ],
  styles: `
    .icon-wrapper {
      max-width: var(--wrapper-max-width, fit-content);
      padding: auto;
      border-radius: 4px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .icon-element {
      display: block;
      width: var(--image-width, 48px);
      height: var(--image-height, 48px);
      min-width: var(--image-min-width, 24px);
      min-height: var(--image-min-height, 24px);
      max-width: var(--image-max-width, 200px);
      max-height: var(--image-max-height, 200px);
      object-fit: contain;
      object-position: center center;
      margin: auto;
      vertical-align: middle;
    }
  `,
  script: `
function updateIcon(model) {
  if (!model || typeof model.getEl !== 'function') return;
  const imgEl = model.getEl();
  if (!imgEl) return;
  
  const parentBtn = model.closestType ? model.closestType('custom-button') : null;
  if (parentBtn) return;

  const trait = model.getTrait('selectImage');
  const traitValue = trait?.getValue() || '';
  
  // Дефолтная иконка
  const defaultSrc = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNDUuNDk3OSAyOC42ODk5SDQwLjIxODVDNDAuMjE4NSAzMS40IDM5LjE0MTkgMzMuOTk5MSAzNy4yMjU2IDM1LjkxNTQgQzM1LjMwOTIgMzcuODMxNyAzMi43MTAyIDM4LjkwODMgMzAgMzguOTA4MyBDMjcuMjkgMzguOTA4MyAyNC42OTEgMzcuODMxNyAyMi43NzQ3IDM1LjkxNTQgQzIwLjg1ODQgMzMuOTk5MSAxOS43ODE4IDMxLjQgMTkuNzgxOCAyOC42ODk5SDUuNTAyMzNDNC4zNzYwOSAyOC43MTY0IDMuMzA1MzEgMjkuMTg0NSAyLjUyMTA3IDI5Ljk5MzIgQzEuNzM2ODMgMzAuODAyIDEuMzAxOTYgMzEuODg2NiAxLjMxMDE3IDMzLjAxMzFWMzMuMDEzMUMxLjMwMTk2IDU0Ljc3MjggMS43MzY4MyA1NS44NTc0IDIuNTIxMDcgNTYuNjY2MSBDMy4zMDUzMSA1Ny40NzQ5IDQuMzc2MDkgNTcuOTQzIDUuNTAyMzMgNTcuOTY5NEg1NC40OTc5QzU1LjYyNDIgNTcuOTQzIDU2LjY5NDkgNTcuNDc0OSA1Ny40NzkxIDU2LjY2NjEgQzU4LjI2MzMgNTUuODU3NCA1OC42OTgzIDU0Ljc3MjggNTguNjkwMSA1My42NDYzVjMzLjAxMzFDNTguNjk4MyAzMS44ODY2IDU4LjI2MzMgMzAuODAyIDU3LjQ3OTEgMjkuOTkzMiBDNTYuNjk0OSAyOS4xODQ1IDU1LjYyNDIgMjguNzE2NCA1NC40OTc5IDI4LjY4OTlaIiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48cGF0aCBkPSJNNTEuNTUwNCAyOC40Mjc5VjEzLjk1MTlDNTEuNTUwNCA2LjY4MTE2IDUyLjcyOTQgMi4yOTI1MyA0Ni41MDY3IDIuMDMwNTJIMTQuMTQ4NkM3LjY2MzkyIDIuMDMwNTIgOC4zODQ0MSA2LjM1MzY3IDguMzg0NDEgMTIuOTAzOVYyOC43NTU0IiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMi42MjAwOSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNMTguMjA5NiAxMi43NzI5SDE3Ljk0NzZDMTcuNzU3MSAxMi43NzEyIDE3LjU3NDcgMTIuNjk0NyAxNy40NDAgMTIuNTYwMEMxNy4zMDUyIDEyLjQyNTIgMTcuMjI4OCAxMi4yNDI5IDE3LjIyNzEgMTIuMDUyNFYxMS43OTA0QzE3LjIyODggMTEuNTk5OCAxNy4zMDUyIDExLjQxNzUgMTcuNDQwIDExLjI4MjhDMTcuNTc0NyAxMS4xNDggMTcuNzU3MSAxMS4wNzE1IDE3Ljk0NzYgMTEuMDY5OEgxOC4yMDk2QzE4LjQwMDEgMTEuMDcxNSAxOC41ODI1IDExLjE0OCAxOC43MTcyIDExLjI4MjhDMTguODUyIDExLjQxNzUgMTguOTI4NSAxMS41OTk4IDE4LjkzMDIgMTEuNzkwNFYxMi4wNTI0QzE4LjkyODUgMTIuMjQyOSAxOC44NTIgMTIuNDI1MiAxOC43MTcyIDEyLjU2MDBDMTguNTgyNSAxMi42OTQ3IDE4LjQwMDEgMTIuNzcxMiAxOC4yMDk2IDEyLjc3MjlaIiBmaWxsPSIjNDE3MEZGIiBzdHJva2U9IiM0MTcwRkYiIHN0cm9rZS13aWR0aD0iMS4zMTAwNCIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIi8+PHBhdGggZD0iTTIyLjAwODkgMTkuMTI2NkgyMS43NDY5QzIxLjU1NjMgMTkuMTI0OSAyMS4zNzQxIDE5LjA0ODUgMjEuMjM5MyAxOC45MTM3QzIxLjEwNDUgMTguNzc5IDIxLjAyODEgMTguNTk2NyAyMS4wMjY0IDE4LjQwNjFWMTguMTQ0MUMyMS4wMjgxIDE3Ljk1MzUgMjEuMTA0NSAxNy43NzEzIDIxLjIzOTMgMTcuNjM2NUMyMS4zNzQxIDE3LjUwMTggMjEuNTU2MyAxNy40MjUzIDIxLjc0NjkgMTcuNDIzNkgxMi4wMDg5QzIyLjE5OTUgMTcuNDI1MyAyMi4zODE3IDE3LjUwMTggMjIuNTE2NSAxNy42MzY1QzIyLjY1MTIgMTcuNzcxMyAyMi43Mjc3IDE3Ljk1MzUgMjIuNzI5NCAxOC4xNDQxVjE4LjQwNjFDMjIuNzM5NyAxOC41MDMzIDIyLjcyODIgMTguNjAxNSAyMi42OTU3IDE4LjY5MzZDIDIyLjY2MzEgMTguNzg1NyAyMi42MTAzIDE4Ljg2OTQgMjIuNTQxMyAxOC45Mzg0QzIyLjQ3MjIgMTkuMDA3NSAyMi4zODg1IDE5LjA2MDMgMjIuMjk2NCAxOS4wOTI4QzIyLjIwNDIgMTkuMTI1NCAyMi4xMDYgMTkuMTM3IDIyLjAwODkgMTkuMTI2NloiIGZpbGw9IiM0MTcwRkYiIHN0cm9rZT0iIzQxNzBGRiIgc3Ryb2tlLXdpZHRoPSIxLjMxMDA0IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiLz48cGF0aCBkPSJNIDUxLjY4MTQgMTMuMDM0OUw1OC4wMzUxIDMwLjM5MyIgc3Ryb2tlPSIjNDE3MEZGIiBzdHJva2Utd2lkdGg9IjIuNjIwMDkiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PHBhdGggZD0iTTEuODk5NjYgMzAuNTg5NUw4LjE4Nzg3IDEzLjY4OTkiIHN0cm9rZT0iIzQxNzBGRiIgc3Ryb2tlLXdpZHRoPSIyLjYyMDA5IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Ik0yMy40NDk3IDExLjkyMTRIMzQuOTEyNiIgc3Ryb2tlPSIjNDE3MEZGIiBzdHJva2Utd2lkdGg9IjIuNjIwMDkiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PHBhdGggZD0iTTI2Ljk4NzEgMTguMjc1SDM4LjQ0OTkiIHN0cm9rZT0iIzQxNzBGRiIgc3Ryb2tlLXdpZHRoPSIyLjYyMDA5IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg==';

  // 2. Определяем, какую картинку показывать
  let finalSrc = traitValue || defaultSrc;

  // 3. Устанавливаем в DOM
  if (imgEl.getAttribute('src') !== finalSrc) {
     imgEl.src = finalSrc;
     imgEl.setAttribute('src', finalSrc);
  }

  // 4. ГЛАВНОЕ: Синхронизируем Модель и Трейт
  // Это сохраняет состояние, чтобы при ресайзе (когда DOM перерисовывается)
  // GrapesJS знал правильный src
  
  // Если в модели src отличается от finalSrc -> сохраняем
  const modelSrc = model.getAttributes()['src'];
  if (modelSrc !== finalSrc) {
      model.addAttributes({ src: finalSrc });
  }

  // Если в трейте пусто, но мы поставили дефолт -> пишем в трейт (чтобы UI был в курсе)
  if (!traitValue && finalSrc === defaultSrc && trait) {
      // trait.setValue(defaultSrc); // Можно раскомментировать, если хотите видеть SVG код в инпуте
  }
}

// Инициализация при загрузке
(function init() {
  if (typeof model === 'undefined' || !model) return;
  const parentBtn = model.closestType ? model.closestType('custom-button') : null;
  if (parentBtn) return;
  
  updateIcon(model);
})();

if (typeof model !== 'undefined') {
    // Слушаем изменение трейта пользователем
    model.on('change:selectImage', () => {
      const parentBtn = model.closestType ? model.closestType('custom-button') : null;
      if (parentBtn) return;
      updateIcon(model);
    });
    
    // Слушаем изменение атрибутов (например, Asset Manager меняет 'src')
    // И обновляем трейт 'selectImage', чтобы они были в синхроне
    model.on('change:attributes:src', () => {
       const newSrc = model.getAttributes()['src'];
       const trait = model.getTrait('selectImage');
       if (trait && trait.getValue() !== newSrc) {
           trait.setValue(newSrc);
       }
    });
}
`,
  styleConfig: {
    sectors: [
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: '--image-width',
            type: 'number',
            units: ['px', 'auto'],
            default: '20px',
            selector: '.icon-element'
          },
          {
            id: 'height',
            name: 'Height',
            property: '--image-height',
            type: 'number',
            units: ['px', 'auto'],
            default: '20px',
            selector: '.icon-element'
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: '--image-min-width',
            type: 'number',
            units: ['px'],
            default: '10px',
            selector: '.icon-element'
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: '--image-min-height',
            type: 'number',
            units: ['px'],
            default: '10px',
            selector: '.icon-element'
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: '--image-max-width',
            type: 'number',
            units: ['px'],
            default: '200',
            selector: '.icon-element'
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: '--image-max-height',
            type: 'number',
            units: ['px'],
            default: '200',
            selector: '.icon-element'
          }
        ]
      }
    ]
  }
};
