import { ComponentConfig } from '../elements';

export const TextRedactor: ComponentConfig = {
  id: 'text-redactor',
  type: 'text-redactor',
  label: 'Text with Redactor',
  category: 'Content',
  content: {
    tagName: 'div',
    attributes: { class: 'redactor-wrapper' },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'redactor-content' },
        content: '<p>Edit this text</p>'
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M9.39844 3.19995V21.2M6.39844 21.2H12.3984M16.3984 6.19995V3.19995H2.39844V6.19995" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<g clip-path="url(#clip0_196_55489)">
<mask id="path-2-inside-1_196_55489" fill="white">
<path d="M12.8984 8.80005H18.8984V9.80005H20.3984V12.7043L16.8984 13.4543V13.8H17.3984V16.8H15.3984V13.8H15.8984V12.6458L19.3984 11.8958V10.8H18.8984V11.3H12.8984V8.80005Z"/>
</mask>
<path d="M12.8984 8.80005H18.8984V9.80005H20.3984V12.7043L16.8984 13.4543V13.8H17.3984V16.8H15.3984V13.8H15.8984V12.6458L19.3984 11.8958V10.8H18.8984V11.3H12.8984V8.80005Z" fill="black"/>
<path d="M12.8984 8.80005V5.05005H9.14844V8.80005H12.8984ZM18.8984 8.80005H22.6484V5.05005H18.8984V8.80005ZM18.8984 9.80005H15.1484V13.55H18.8984V9.80005ZM20.3984 9.80005H24.1484V6.05005H20.3984V9.80005ZM20.3984 12.7043L21.1842 16.371L24.1484 15.7358V12.7043H20.3984ZM16.8984 13.4543L16.1127 9.7875L13.1484 10.4227V13.4543H16.8984ZM16.8984 13.8H13.1484V17.55H16.8984V13.8ZM17.3984 13.8H21.1484V10.05H17.3984V13.8ZM17.3984 16.8V20.55H21.1484V16.8H17.3984ZM15.3984 16.8H11.6484V20.55H15.3984V16.8ZM15.3984 13.8V10.05H11.6484V13.8H15.3984ZM15.8984 13.8V17.55H19.6484V13.8H15.8984ZM15.8984 12.6458L15.1127 8.97908L12.1484 9.61428V12.6458H15.8984ZM19.3984 11.8958L20.1842 15.5626L23.1484 14.9274V11.8958H19.3984ZM19.3984 10.8H23.1484V7.05005H19.3984V10.8ZM18.8984 10.8V7.05005H15.1484V10.8H18.8984ZM18.8984 11.3V15.05H22.6484V11.3H18.8984ZM12.8984 11.3H9.14844V15.05H12.8984V11.3ZM12.8984 12.55H18.8984V5.05005H12.8984V12.55ZM15.1484 8.80005V9.80005H22.6484V8.80005H15.1484ZM18.8984 13.55H20.3984V6.05005H18.8984V13.55ZM16.6484 9.80005V12.7043H24.1484V9.80005H16.6484ZM19.6127 9.0375L16.1127 9.7875L17.6842 17.121L21.1842 16.371L19.6127 9.0375ZM13.1484 13.4543V13.8H20.6484V13.4543H13.1484ZM16.8984 17.55H17.3984V10.05H16.8984V17.55ZM13.6484 13.8V16.8H21.1484V13.8H13.6484ZM17.3984 13.05H15.3984V20.55H17.3984V13.05ZM19.1484 16.8V13.8H11.6484V16.8H19.1484ZM15.3984 17.55H15.8984V10.05H15.3984V17.55ZM19.6484 13.8V12.6458H12.1484V13.8H19.6484ZM16.6842 16.3126L20.1842 15.5626L18.6127 8.22908L15.1127 8.97908L16.6842 16.3126ZM23.1484 11.8958V10.8H15.6484V11.8958H23.1484ZM19.3984 7.05005H18.8984V14.55H19.3984V7.05005ZM15.1484 10.8V11.3H22.6484V10.8H15.1484ZM18.8984 7.55005H12.8984V15.05H18.8984V7.55005ZM16.6484 11.3V8.80005H9.14844V11.3H16.6484Z" fill="white" mask="url(#path-2-inside-1_196_55489)"/>
</g>
<defs>
<clipPath id="clip0_196_55489">
<rect width="8" height="8" fill="white" transform="translate(12.3984 8.80005)"/>
</clipPath>
</defs>
</svg>
`,
  traits: [
    {
      id: 'content',
      name: 'content',
      label: 'Content',
      type: 'text',
      changeProp: true,
      value: '<p>Edit this text</p>'
    }
  ],
  styles: `
      .redactor-wrapper {
        padding: 16px;
        background-color: #f7fafc;
        border: 1px solid #e2e8f0;
        border-radius: 4px;
      }
      .redactor-content {
        min-height: 100px;
        color: #4a5568;
      }
      .ql-container {
        font-size: 16px;
      }
      .ql-editor {
        min-height: 100px;
        background-color: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 4px;
        padding: 12px;
      }
    `,
  script: `
      (function(model, editor) {
        function initializeRedactor(model) {
          console.log('initializeRedactor called');
          const wrapper = model.getEl();
          if (!wrapper) return;
          const contentEl = wrapper.querySelector('.redactor-content');
          if (!contentEl) return;
          // Загрузка Quill
          if (!window.Quill) {
            const script = document.createElement('script');
            script.src = 'https://cdn.quilljs.com/1.3.6/quill.min.js';
            script.onload = () => {
              const link = document.createElement('link');
              link.rel = 'stylesheet';
              link.href = 'https://cdn.quilljs.com/1.3.6/quill.snow.css';
              document.head.appendChild(link);
              setupRedactor(model, contentEl);
            };
            document.head.appendChild(script);
          } else {
            setupRedactor(model, contentEl);
          }
        }
        function setupRedactor(model, contentEl) {
          const quill = new Quill(contentEl, {
            theme: 'snow',
            modules: { toolbar: [['bold', 'italic'], ['link'], [{ 'list': 'ordered'}, { 'list': 'bullet' }]] }
          });
          const initialContent = model.getTrait('content')?.getValue() || '<p>Edit this text</p>';
          quill.root.innerHTML = initialContent;
          quill.on('text-change', () => {
            const content = quill.root.innerHTML;
            model.getTrait('content').setValue(content);
          });
        }
        function updateRedactor(model) {
          console.log('updateRedactor called:', model.changed);
          const wrapper = model.getEl();
          if (!wrapper) return;
          const contentEl = wrapper.querySelector('.redactor-content');
          if (!contentEl) return;
          if (!contentEl.classList.contains('ql-container')) {
            initializeRedactor(model);
          } else {
            const quill = contentEl.quill || window.Quill.find(contentEl);
            if (quill) {
              const content = model.getTrait('content')?.getValue() || '<p>Edit this text</p>';
              if (quill.root.innerHTML !== content) {
                quill.root.innerHTML = content;
              }
            }
          }
        }
        if (model && model.getEl()) updateRedactor(model);
        model.on('change:content', () => updateRedactor(model));
      })(model, editor);
    `,
  styleConfig: {
    sectors: []
  }
};
