import { ComponentConfig } from '../elements';

export const Select: ComponentConfig = {
  id: 'custom-select',
  type: 'custom-select',
  label: 'Select',
  category: 'Components',
  content: {
    tagName: 'select',
    attributes: {
      class: 'custom-select',
      'data-component-id': 'custom-select'
    },
    components: [],
    droppable: false
  },
  styleConfig: {
    sectors: [
      {
        id: 'Style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'gap-x',
            name: 'Gap X',
            property: 'gap-x',
            type: 'number',
            default: 10,
            units: ['px']
          },
          {
            id: 'gap-y',
            name: 'Gap Y',
            property: 'gap-y',
            type: 'number',
            default: 10,
            units: ['px']
          },
          {
            id: 'active-color',
            name: 'Active Color',
            property: 'active-color',
            type: 'color',
            default: '#1976d2'
          },
          {
            id: 'active-border-color',
            name: 'Active Border Color',
            property: 'active-border-color',
            type: 'color',
            default: '#1976d2'
          }
        ]
      },
      {
        id: 'Select Dimension',
        name: 'Select Dimension',
        open: true,
        properties: [
          {
            id: 'active-border-width',
            name: 'Active Border Width',
            property: 'active-border-width',
            type: 'number',
            default: 1,
            units: ['px']
          },
          {
            id: 'select-width',
            name: 'Select Width',
            property: 'select-width',
            type: 'number',
            default: 163,
            units: ['px', '%']
          },
          {
            id: 'select-height',
            name: 'Select Height',
            property: 'select-height',
            type: 'number',
            default: 34,
            units: ['px']
          }
        ]
      },
      {
        id: 'Dimension',
        name: 'Dimension',
        open: false,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: 163,
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 34,
            units: ['px']
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            default: 150,
            units: ['px', '%']
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            default: 34,
            units: ['px']
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            default: 'none',
            units: ['px', '%']
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            default: 'none',
            units: ['px']
          }
        ]
      },
      {
        id: 'Select Text',
        name: 'Select Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: 16,
            units: ['px']
          },
          {
            id: 'color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#D3D6E7'
          }
        ]
      }
    ]
  },
  traits: [
    {
      id: 'options',
      name: 'options',
      type: 'list',
      label: 'Elements',
      changeProp: true,
      value: JSON.stringify([
        { value: 'Option 1', label: 'Option 1' },
        { value: 'Option 2', label: 'Option 2' }
      ])
    },
    {
      id: 'value',
      name: 'value',
      type: 'text',
      label: 'Value',
      changeProp: true,
      value: ''
    },
    {
      id: 'placeholder',
      name: 'placeholder',
      type: 'text',
      label: 'Placeholder',
      changeProp: true,
      value: 'Enter...'
    },
    {
      id: 'disabled',
      name: 'disabled',
      type: 'checkbox',
      label: 'Disabled',
      changeProp: true,
      value: false
    },
    {
      id: 'multiple',
      name: 'multiple',
      type: 'checkbox',
      label: 'Multiple Choice',
      changeProp: true,
      value: false
    }
  ],
  styles: `
/* Standard single-line control height from the editor design. */
select.custom-select[data-draft-id], select.custom-select { height: 34px !important; min-height: 34px !important; max-height: 34px !important; }

.custom-select {
  display: block;
  width: var(--width, 163px);
  height: var(--height, 34px);
  padding: 0 38px 0 14px;
  border: 1px solid transparent;
  border-radius: 6px;
  background-color: #5F6163;
  color: var(--text-color, #D3D6E7);
  color-scheme: dark;
  font-family: var(--font-family, Montserrat);
  font-size: var(--font-size, 16px);
  box-sizing: border-box;
  cursor: pointer;
  touch-action: none;
  appearance: none;
  direction: ltr;
  background-image: url('data:image/svg+xml;utf8,<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 10L12 15L17 10" stroke="%23D3D6E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>');
  background-repeat: no-repeat;
  background-position: calc(100% - 12px) center;
  background-size: 16px;
}
.custom-select:focus,
.custom-select[data-popup-open="true"] {
  outline: none;
  border-color: rgba(75, 72, 196, 0.78);
  box-shadow: none;
}
.custom-select:disabled {
  background-color: #44474A;
  border-color: transparent;
  color: #85898D;
  cursor: not-allowed;
}
.custom-select[multiple] {
  height: var(--height, 34px);
  min-height: var(--height, 34px);
  padding: 0 38px 0 14px;
  background-image: url('data:image/svg+xml;utf8,<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 10L12 15L17 10" stroke="%23D3D6E7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>');
  background-repeat: no-repeat;
  background-position: calc(100% - 12px) center;
  background-size: 16px;
}

/* Native <option> popup styling is inconsistent across browsers/OSes.
   The rendered menu below is intentionally custom so it matches the mock. */
.custom-select-popup {
  position: fixed;
  z-index: 2147483000;
  overflow: hidden;
  box-sizing: border-box;
  border: 1px solid #2C2F32;
  border-radius: 10px;
  background: #171A1D;
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.35);
  font-family: var(--font-family, Montserrat);
  font-size: var(--font-size, 16px);
  color: #D3D6E7;
  padding: 0;
  scrollbar-width: thin;
  scrollbar-color: rgba(126, 139, 164, 0.72) transparent;
}
.custom-select-popup::-webkit-scrollbar {
  width: 5px;
  height: 5px;
}
.custom-select-popup::-webkit-scrollbar-track {
  background: transparent;
}
.custom-select-popup::-webkit-scrollbar-thumb {
  background: rgba(126, 139, 164, 0.72);
  border-radius: 999px;
}
.custom-select-popup::-webkit-scrollbar-thumb:hover {
  background: rgba(151, 164, 190, 0.9);
}
.custom-select-popup__option {
  position: relative;
  display: flex;
  align-items: center;
  min-height: 40px;
  padding: 0 14px 0 24px;
  box-sizing: border-box;
  background: #171A1D;
  color: #D3D6E7;
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.custom-select-popup__option::before {
  content: "";
  position: absolute;
  inset: 0 auto 0 0;
  width: 4px;
  background: transparent;
}
.custom-select-popup__option:hover,
.custom-select-popup__option:focus,
.custom-select-popup__option[aria-selected="true"] {
  outline: none;
  background: #2A2B6B;
  color: #FFFFFF;
}
.custom-select-popup__option:hover::before,
.custom-select-popup__option:focus::before,
.custom-select-popup__option[aria-selected="true"]::before {
  background: #3D3AB8;
}
.custom-select-popup__option[data-multiple="true"][aria-selected="true"]::after {
  content: "✓";
  margin-left: auto;
  padding-left: 12px;
  color: #FFFFFF;
  font-weight: 600;
}
.custom-select-popup__empty {
  min-height: 40px;
  display: flex;
  align-items: center;
  padding: 0 14px;
  color: #85898D;
}
  `,
  script: `
    (function initCustomSelect(model) {
      if (!model || !model.getEl()) return;

      function parseList(raw) {
        if (Array.isArray(raw)) {
          return raw.map(function(item) {
            if (item && typeof item === 'object') {
              return String(item.label || item.name || item.value || '').trim();
            }
            return String(item == null ? '' : item).trim();
          }).filter(Boolean);
        }
        if (raw == null) return [];
        var text = String(raw).trim();
        if (!text) return [];
        text = text.replace(/[“”]/g, '"').replace(/[‘’]/g, "'");
        if (text.charAt(0) === '[' && text.charAt(text.length - 1) === ']') {
          try { return parseList(JSON.parse(text)); } catch (e) {}
        }
        return text
          .replace(/^\\[|\\]$/g, '')
          .split(/[\\n,;]/)
          .map(function(item) { return item.trim().replace(/^['"]|['"]$/g, '').trim(); })
          .filter(Boolean);
      }

      function asBoolean(raw) {
        if (typeof raw === 'boolean') return raw;
        if (typeof raw === 'number') return raw !== 0;
        var normalized = String(raw == null ? '' : raw).trim().toLowerCase();
        return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'checked';
      }

      function getTrait(name) {
        return model.getTraits().find(function(trait) {
          return trait.getName() === name;
        });
      }

      function traitValue(name, fallback) {
        var trait = getTrait(name);
        var value = trait && trait.getValue ? trait.getValue() : undefined;
        return value == null || value === '' ? fallback : value;
      }

      function optionRows(raw) {
        if (Array.isArray(raw)) {
          return raw.map(function(item, index) {
            if (item && typeof item === 'object') {
              var label = String(item.label || item.name || item.value || '').trim();
              var value = String(item.value || label || ('option' + (index + 1))).trim();
              return label ? { label: label, value: value } : null;
            }
            var text = String(item == null ? '' : item).trim();
            return text ? { label: text, value: text } : null;
          }).filter(Boolean);
        }
        var text = raw == null ? '' : String(raw).trim();
        if (!text) return [];
        try { return optionRows(JSON.parse(text)); } catch (e) {
          return parseList(text).map(function(item) { return { label: item, value: item }; });
        }
      }

      function normalizeSelected(raw, multiple, rows) {
        var selected = parseList(raw);
        selected = selected.map(function(value) {
          var match = /^option(\\d+)$/i.exec(value);
          if (!match) return value;
          var row = rows[Number(match[1]) - 1];
          return row ? row.value : value;
        });
        return multiple ? selected : selected.slice(0, 1);
      }

      function readSelected(selectEl) {
        if (selectEl.multiple) {
          return Array.from(selectEl.selectedOptions || []).map(function(option) {
            return option.value || option.textContent || '';
          }).filter(Boolean);
        }
        return selectEl.value ? [selectEl.value] : [];
      }

      function writeValueTrait(values, multiple) {
        var next = multiple ? JSON.stringify(values) : (values[0] || '');
        var trait = getTrait('value');
        if (trait && trait.setValue && String(trait.getValue ? trait.getValue() : '') !== String(next)) {
          trait.setValue(next);
        }
        if (String(model.get('value') == null ? '' : model.get('value')) !== String(next)) {
          model.set('value', next);
        }
        model.addAttributes({ 'data-value': next });
        return next;
      }

      function syncOptionComponents(rows, placeholder, multiple) {
        var signature = JSON.stringify({
          rows: rows,
          placeholder: placeholder,
          multiple: multiple
        });

        if (model.__selectComponentsSignature === signature) return;
        model.__selectComponentsSignature = signature;

        var components = [];
        if (!multiple) {
          components.push({
            tagName: 'option',
            attributes: { value: '', disabled: 'true' },
            content: placeholder,
            droppable: false,
            draggable: false,
            selectable: false,
            hoverable: false
          });
        }

        rows.forEach(function(row) {
          components.push({
            tagName: 'option',
            attributes: { value: row.value },
            content: row.label,
            droppable: false,
            draggable: false,
            selectable: false,
            hoverable: false
          });
        });

        model.components(components);
      }

      function getSelectManager(doc) {
        var manager = doc.__dslSelectManager;
        if (!manager) {
          manager = { activeModel: null };
          doc.__dslSelectManager = manager;
        }
        return manager;
      }

      function closePopup() {
        var popup = model.__customSelectPopup;
        var select = model.getEl && model.getEl();
        var doc = (popup && popup.ownerDocument) || (select && select.ownerDocument) || document;
        if (popup && popup.parentNode) popup.parentNode.removeChild(popup);
        model.__customSelectPopup = null;
        if (select) select.removeAttribute('data-popup-open');
        var manager = getSelectManager(doc);
        if (manager.activeModel === model) manager.activeModel = null;
      }

      function commitSelection(selectEl, values, multiple, keepOpen) {
        var selectedSet = new Set(values);
        Array.from(selectEl.options || []).forEach(function(option) {
          option.selected = selectedSet.has(option.value) || selectedSet.has(option.textContent || '');
        });
        if (!multiple) selectEl.value = values[0] || '';

        var next = writeValueTrait(values, multiple);
        selectEl.setAttribute('data-value', next);

        try { selectEl.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
        try { selectEl.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}

        if (!keepOpen) closePopup();
      }

      function buildPopup(selectEl) {
        closePopup();
        if (!selectEl || selectEl.disabled) return;

        var multiple = asBoolean(traitValue('multiple', false));
        var rows = optionRows(traitValue('options', '[]'));
        var selected = normalizeSelected(traitValue('value', ''), multiple, rows);
        var selectedSet = new Set(selected);
        var doc = selectEl.ownerDocument || document;
        var manager = getSelectManager(doc);
        var previousModel = manager.activeModel;
        if (previousModel && previousModel !== model) {
          if (typeof previousModel.__closeCustomSelectPopup === 'function') {
            previousModel.__closeCustomSelectPopup();
          } else if (previousModel.__customSelectPopup) {
            var previousPopup = previousModel.__customSelectPopup;
            if (previousPopup.parentNode) previousPopup.parentNode.removeChild(previousPopup);
            previousModel.__customSelectPopup = null;
            var previousSelect = previousModel.getEl && previousModel.getEl();
            if (previousSelect) previousSelect.removeAttribute('data-popup-open');
          }
        }
        manager.activeModel = model;
        var win = doc.defaultView || window;
        var rect = selectEl.getBoundingClientRect();
        var popup = doc.createElement('div');
        popup.className = 'custom-select-popup';
        popup.setAttribute('role', multiple ? 'listbox' : 'listbox');
        if (multiple) popup.setAttribute('aria-multiselectable', 'true');

        var estimatedHeight = Math.max(40, rows.length * 40);
        var viewportHeight = win.innerHeight || doc.documentElement.clientHeight || 0;
        var roomBelow = Math.max(0, viewportHeight - rect.bottom - 8);
        var roomAbove = Math.max(0, rect.top - 8);
        var openUp = roomBelow < estimatedHeight && roomAbove > roomBelow;
        var availableSpace = Math.max(40, openUp ? roomAbove : roomBelow);
        var popupHeight = Math.min(240, estimatedHeight, availableSpace);
        var top = openUp
          ? Math.max(8, rect.top - popupHeight - 6)
          : rect.bottom + 6;

        popup.style.left = Math.round(rect.left) + 'px';
        popup.style.top = Math.round(top) + 'px';
        popup.style.width = Math.max(120, Math.round(rect.width)) + 'px';
        popup.style.maxHeight = Math.round(popupHeight) + 'px';
        popup.style.overflowY = estimatedHeight > popupHeight ? 'auto' : 'hidden';

        if (!rows.length) {
          var empty = doc.createElement('div');
          empty.className = 'custom-select-popup__empty';
          empty.textContent = 'No options';
          popup.appendChild(empty);
        }

        rows.forEach(function(row) {
          var option = doc.createElement('div');
          option.className = 'custom-select-popup__option';
          option.setAttribute('role', 'option');
          option.setAttribute('tabindex', '0');
          option.setAttribute('data-value', row.value);
          option.setAttribute('data-multiple', multiple ? 'true' : 'false');
          option.setAttribute('aria-selected', selectedSet.has(row.value) ? 'true' : 'false');
          option.textContent = row.label;

          var choose = function(event) {
            event.preventDefault();
            event.stopPropagation();
            var nextValues;
            if (multiple) {
              var nextSet = new Set(selectedSet);
              if (nextSet.has(row.value)) nextSet.delete(row.value);
              else nextSet.add(row.value);
              selectedSet = nextSet;
              nextValues = rows.map(function(item) { return item.value; }).filter(function(value) { return nextSet.has(value); });
              option.setAttribute('aria-selected', nextSet.has(row.value) ? 'true' : 'false');
            } else {
              selectedSet = new Set([row.value]);
              nextValues = [row.value];
              Array.from(popup.querySelectorAll('.custom-select-popup__option')).forEach(function(node) {
                node.setAttribute('aria-selected', node.getAttribute('data-value') === row.value ? 'true' : 'false');
              });
            }
            commitSelection(selectEl, nextValues, multiple, multiple);
          };

          option.addEventListener('pointerdown', function(event) {
            event.preventDefault();
            event.stopPropagation();
          });
          option.addEventListener('click', choose);
          option.addEventListener('keydown', function(event) {
            if (event.key === 'Enter' || event.key === ' ') choose(event);
            if (event.key === 'Escape') closePopup();
          });
          popup.appendChild(option);
        });

        doc.body.appendChild(popup);
        model.__customSelectPopup = popup;
        model.__closeCustomSelectPopup = closePopup;
        manager.activeModel = model;
        selectEl.setAttribute('data-popup-open', 'true');
      }

      function updateSelectField() {
        var disabled = asBoolean(traitValue('disabled', false));
        var multiple = asBoolean(traitValue('multiple', false));
        var placeholder = String(traitValue('placeholder', 'Enter...') || 'Enter...');
        var rows = optionRows(traitValue('options', '[]'));
        var selected = normalizeSelected(traitValue('value', ''), multiple, rows);
        var selectedSet = new Set(selected);

        syncOptionComponents(rows, placeholder, multiple);

        var selectEl = model.getEl();
        if (!selectEl) return;
        selectEl.disabled = disabled;
        selectEl.multiple = multiple;

        /* Keep the native control one-line. The visual multi-selection is handled
           by the custom popup rather than by the browser's native list box. */
        selectEl.removeAttribute('size');

        Array.from(selectEl.options || []).forEach(function(option) {
          option.selected = selectedSet.has(option.value) || selectedSet.has(option.textContent || '');
        });
        if (!multiple && !selected.length) selectEl.value = '';

        var styles = model.getStyle() || {};
        selectEl.style.setProperty('--font-family', styles['font-family'] || 'Montserrat');
        selectEl.style.setProperty('--font-size', styles['font-size'] || '16px');
        selectEl.style.setProperty('--text-color', styles['text-color'] || styles.color || '#D3D6E7');
        selectEl.style.setProperty('--width', styles.width || '163px');
        selectEl.style.setProperty('--height', styles.height || '34px');
        selectEl.setAttribute('data-value', multiple ? JSON.stringify(selected) : (selected[0] || ''));

        if (model.__customSelectPopup) closePopup();
      }

      var selectEl = model.getEl();
      if (model.__customSelectElement !== selectEl) {
        if (model.__customSelectElement) {
          if (model.__customSelectChangeHandler) model.__customSelectElement.removeEventListener('change', model.__customSelectChangeHandler);
          if (model.__customSelectPointerHandler) model.__customSelectElement.removeEventListener('pointerdown', model.__customSelectPointerHandler);
          if (model.__customSelectMouseDownHandler) model.__customSelectElement.removeEventListener('mousedown', model.__customSelectMouseDownHandler);
          if (model.__customSelectClickHandler) model.__customSelectElement.removeEventListener('click', model.__customSelectClickHandler);
        }
        model.__customSelectElement = selectEl;

        model.__customSelectChangeHandler = function(event) {
          var current = event.currentTarget;
          var values = readSelected(current);
          var next = writeValueTrait(values, current.multiple);
          current.setAttribute('data-value', next);
        };
        model.__customSelectPointerHandler = function(event) {
          if (selectEl.disabled) return;
          // Do not stop/prevent pointerdown. GrapesJS needs the very first
          // gesture to bubble so an unselected Select can be grabbed and moved
          // immediately. Popup interaction is decided on click after we know
          // whether the pointer actually moved.
          model.__customSelectPointerStart = {
            x: Number(event.clientX || 0),
            y: Number(event.clientY || 0),
            moved: false
          };
        };
        model.__customSelectMouseDownHandler = function(event) {
          if (selectEl.disabled) return;
          event.preventDefault();
        };
        model.__customSelectClickHandler = function(event) {
          if (selectEl.disabled) return;
          event.preventDefault();
          event.stopPropagation();
          var pointer = model.__customSelectPointerStart;
          model.__customSelectPointerStart = null;
          if (pointer && pointer.moved) {
            closePopup();
            return;
          }
          if (model.__customSelectPopup) closePopup();
          else buildPopup(selectEl);
        };

        selectEl.addEventListener('change', model.__customSelectChangeHandler);
        selectEl.addEventListener('pointerdown', model.__customSelectPointerHandler);
        selectEl.addEventListener('mousedown', model.__customSelectMouseDownHandler);
        selectEl.addEventListener('click', model.__customSelectClickHandler);
      }

      if (!model.__customSelectDocumentBound) {
        model.__customSelectDocumentBound = true;
        var doc = selectEl.ownerDocument || document;
        model.__customSelectOutsideHandler = function(event) {
          var target = event.target;
          if (target === model.getEl()) return;
          if (model.__customSelectPopup && model.__customSelectPopup.contains(target)) return;
          closePopup();
        };
        model.__customSelectMoveHandler = function(event) {
          var pointer = model.__customSelectPointerStart;
          if (!pointer || pointer.moved) return;
          var dx = Number(event.clientX || 0) - pointer.x;
          var dy = Number(event.clientY || 0) - pointer.y;
          if ((dx * dx) + (dy * dy) < 16) return;
          pointer.moved = true;
          // If the Select was open and the user starts dragging it, close the
          // popup immediately so it cannot intercept the rest of the gesture.
          if (model.__customSelectPopup) closePopup();
        };
        model.__customSelectCancelHandler = function() {
          model.__customSelectPointerStart = null;
        };
        model.__customSelectKeyHandler = function(event) {
          if (event.key === 'Escape') closePopup();
        };
        model.__customSelectDocument = doc;
        doc.addEventListener('pointerdown', model.__customSelectOutsideHandler, true);
        doc.addEventListener('pointermove', model.__customSelectMoveHandler, true);
        doc.addEventListener('pointercancel', model.__customSelectCancelHandler, true);
        doc.addEventListener('keydown', model.__customSelectKeyHandler, true);
      }

      function destroySelectRuntime() {
        closePopup();
        var element = model.__customSelectElement;
        if (element) {
          if (model.__customSelectChangeHandler) element.removeEventListener('change', model.__customSelectChangeHandler);
          if (model.__customSelectPointerHandler) element.removeEventListener('pointerdown', model.__customSelectPointerHandler);
          if (model.__customSelectMouseDownHandler) element.removeEventListener('mousedown', model.__customSelectMouseDownHandler);
          if (model.__customSelectClickHandler) element.removeEventListener('click', model.__customSelectClickHandler);
        }
        var boundDoc = model.__customSelectDocument;
        if (boundDoc) {
          if (model.__customSelectOutsideHandler) boundDoc.removeEventListener('pointerdown', model.__customSelectOutsideHandler, true);
          if (model.__customSelectMoveHandler) boundDoc.removeEventListener('pointermove', model.__customSelectMoveHandler, true);
          if (model.__customSelectCancelHandler) boundDoc.removeEventListener('pointercancel', model.__customSelectCancelHandler, true);
          if (model.__customSelectKeyHandler) boundDoc.removeEventListener('keydown', model.__customSelectKeyHandler, true);
        }
        model.__customSelectPointerStart = null;
        model.__customSelectElement = null;
        model.__customSelectDocument = null;
        model.__customSelectDocumentBound = false;
      }

      model.__customSelectRefresh = updateSelectField;
      if (!model.__customSelectModelBound) {
        model.__customSelectModelBound = true;
        model.on('change:value', updateSelectField);
        model.on('change:style', updateSelectField);
        model.on('change:disabled change:multiple change:placeholder change:options', updateSelectField);
        model.on('removed', destroySelectRuntime);
      }
      updateSelectField();
    })(model);
  `,
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4.605 0H19.395C21.9295 0 24 2.21695 24 4.9303V19.0697C24 21.7825 21.9291 24 19.395 24H4.605C2.07047 24 0 21.783 0 19.0697V4.9303C0 2.22247 2.07609 0 4.605 0ZM11.5228 15.0935L7.81125 10.8925C7.56234 10.6105 7.57359 10.1653 7.83703 9.89824C7.96406 9.76975 8.12672 9.7055 8.28844 9.7055V9.70199H15.7116C16.0763 9.70199 16.372 10.0187 16.372 10.4092C16.372 10.6235 16.2825 10.8157 16.1414 10.9457L12.4772 15.0935C12.2283 15.3761 11.812 15.3882 11.5486 15.1211L11.5228 15.0935ZM19.395 2.26313H4.605C3.23109 2.26313 2.11359 3.45969 2.11359 4.9303V19.0697C2.11359 20.5343 3.23719 21.7369 4.605 21.7369H19.395C20.7623 21.7369 21.8864 20.5333 21.8864 19.0697V4.9303C21.8864 3.46571 20.7628 2.26313 19.395 2.26313Z" fill="white"/>
</svg>`,
  attributes: { class: 'custom-select', 'data-component-id': 'custom-select' }
};
