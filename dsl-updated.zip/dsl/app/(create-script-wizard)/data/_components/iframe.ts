import { ComponentConfig } from '../elements';

export const Iframe: ComponentConfig = {
  id: 'iframe',
  type: 'iframe',
  label: 'Iframe',
  category: 'Form',
  content: {
    tagName: 'iframe',
    attributes: {
      class: 'iframe-content',
      src: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
      frameborder: '0'
    },
    resizable: {
      cr: true,
      bc: true,
      minDim: 100,
      maxDim: 2000,
      updateTarget: (el, rect) => {
        el.style.height = `${rect.h}px`;
        el.style.width = `${rect.w}px`;
      }
    }
  },
  traits: [
    {
      id: 'src',
      name: 'src',
      label: 'URL',
      type: 'text',
      changeProp: true,
      value: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
      placeholder: 'Enter iframe URL'
    }
  ],
  block: true,
  icon: `<svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.0006 6.9997C18.2101 6.9997 20.0013 8.7909 20.0013 11.0003C20.0013 12.0154 19.6232 12.9422 19.0003 13.6475L19.0002 18.2484C19.0002 18.8192 18.3957 19.1678 17.9101 18.9173L17.8206 18.8632L16.0003 17.5909L14.1806 18.8632C13.7127 19.1901 13.0807 18.8943 13.008 18.3527L13.0011 18.2484L13.0001 13.6465C12.3777 12.9413 12 12.0149 12 11.0003C12 8.7909 13.7911 6.9997 16.0006 6.9997ZM17.4994 14.7108C17.0365 14.8979 16.5306 15.001 16.0006 15.001C15.4699 15.001 14.9633 14.8976 14.4999 14.71L14.5003 16.8089L15.5711 16.0618C15.7968 15.9041 16.0878 15.8844 16.3298 16.0027L16.4302 16.0618L17.4993 16.8089L17.4994 14.7108ZM17.25 0.00390625C18.7125 0.00390625 19.9084 1.14561 19.995 2.58638L20 2.75391L20.0014 7.9998C19.5971 7.4616 19.0867 7.0076 18.5013 6.66887L18.5 2.75391C18.5 2.1067 18.0081 1.57437 17.3778 1.51036L17.25 1.50391H2.75C2.10279 1.50391 1.57047 1.99578 1.50645 2.6261L1.5 2.75391V12.2539C1.5 12.9011 1.99187 13.4334 2.62219 13.4975L2.75 13.5039L11.6716 13.5051L11.7955 13.7076L11.9291 13.9043L12 13.9977L11.999 15.0039H2.75C1.28747 15.0039 0.0915999 13.8622 0.0050199 12.4214L0 12.2539V2.75391C0 1.29137 1.1417 0.0954961 2.58248 0.00891614L2.75 0.00390625H17.25ZM16.0006 8.4997C14.6196 8.4997 13.5 9.6193 13.5 11.0003C13.5 12.3814 14.6196 13.501 16.0006 13.501C17.3817 13.501 18.5013 12.3814 18.5013 11.0003C18.5013 9.6193 17.3817 8.4997 16.0006 8.4997ZM9.25 9.4997C9.6642 9.4997 10 9.8355 10 10.2497C10 10.6294 9.7178 10.9432 9.3518 10.9929L9.25 10.9997H4.75C4.33579 10.9997 4 10.6639 4 10.2497C4 9.87 4.28215 9.5562 4.64823 9.5065L4.75 9.4997H9.25ZM15.25 3.9997C15.6642 3.9997 16 4.33549 16 4.7497C16 5.1294 15.7178 5.44319 15.3518 5.49286L15.25 5.4997H4.75C4.33579 5.4997 4 5.16392 4 4.7497C4 4.37001 4.28215 4.05621 4.64823 4.00655L4.75 3.9997H15.25Z" fill="white"/></svg>`,
  styles: `
    .iframe-content {
      width: var(--width, 100%);
      height: var(--height, 400px);
      min-width: var(--min-width, auto);
      min-height: var(--min-height, auto);
      max-width: var(--max-width, none);
      max-height: var(--max-height, none);
      background: #FFFFFF26;
      border: var(--border-width, 2px) solid var(--border-color, #e2e8f0);
      border-radius: var(--border-radius, 4px);
      transition: all 0.2s;
      display: block;
      margin: 0 auto;
    }
  `,
  script: `
    function updateIframe(model) {
      if (!model || !model.getEl()) return;
      const iframeEl = model.getEl();
      const attrs = model.getAttributes();
      let src = attrs.src || 'https://www.youtube.com/embed/dQw4w9WgXcQ';

      if (!src || typeof src !== 'string' || src.trim() === '') {
        iframeEl.src = 'https://www.youtube.com/embed/dQw4w9WgXcQ';
        return;
      }

      try {
        new URL(src);
        iframeEl.src = src;
      } catch (e) {
        console.error('Invalid URL', e);
        iframeEl.src = 'https://www.youtube.com/embed/dQw4w9WgXcQ';
      }
    }

    if (model && model.getEl()) {
      updateIframe(model);
      model.on('change:attributes:src', () => {
        updateIframe(model);
      });
    }
  `,
  styleConfig: {
    sectors: [
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            units: ['px', '%'],
            default: '100%',
            selector: '.iframe-content'
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            units: ['px'],
            default: 400,
            selector: '.iframe-content'
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: 'min-width',
            type: 'number',
            units: ['px', '%'],
            default: 'auto',
            selector: '.iframe-content'
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: 'min-height',
            type: 'number',
            units: ['px'],
            default: 'auto',
            selector: '.iframe-content'
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: 'max-width',
            type: 'number',
            units: ['px', '%'],
            default: 'none',
            selector: '.iframe-content'
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: 'max-height',
            type: 'number',
            units: ['px'],
            default: 'none',
            selector: '.iframe-content'
          }
        ]
      }
    ]
  }
};
