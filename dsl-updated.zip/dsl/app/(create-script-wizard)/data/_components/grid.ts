import { getActiveEditor } from '@/src/editor/editorRegistry';
import { Component } from 'grapesjs';
import { ComponentConfig } from '../elements';

export const Grid: ComponentConfig = {
  id: 'grid',
  type: 'grid',
  label: 'Grid',
  category: 'Container',
  content: {
    tagName: 'div',
    attributes: {
      class: 'mui-grid-wrapper',
      'data-component-id': 'grid',
      'data-grid-width': '100%',
      'data-grid-height': 'auto'
    },
    components: [
      {
        type: 'grid-cell',
        tagName: 'div',
        attributes: {
          class: 'mui-grid-cell',
          'data-cell-id': 'cell-1'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 100,
          maxDim: 1200,
          updateTarget: (el, rect, component) => {
            const width = rect.width || rect.w;
            const height = rect.height || rect.h;

            console.log('Resizing grid cell to:', width + 'px', height + 'px');

            // Применяем стили к DOM
            el.style.width = width + 'px';
            el.style.height = height + 'px';
            el.style.minWidth = width + 'px';
            el.style.minHeight = height + 'px';

            // Получаем компонент через редактор
            const editor = getActiveEditor();
            if (editor) {
              const cellComponent = editor.getSelected();
              if (cellComponent && cellComponent.getEl() === el) {
                // Сохраняем стили в модель GrapesJS
                const styles = {
                  width: width + 'px',
                  height: height + 'px',
                  'min-width': width + 'px',
                  'min-height': height + 'px'
                };

                cellComponent.setStyle(styles);
                cellComponent.trigger('change:style');

                // Сохраняем размер в пользовательских атрибутах
                cellComponent.addAttributes({
                  'data-custom-width': width + 'px',
                  'data-custom-height': height + 'px'
                });

                console.log('Grid cell styles saved to model:', styles);
              }
            }
          }
        }
      },
      {
        type: 'grid-cell',
        tagName: 'div',
        attributes: {
          class: 'mui-grid-cell',
          'data-cell-id': 'cell-2'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 100,
          maxDim: 1200,
          updateTarget: (el, rect, component) => {
            const width = rect.width || rect.w;
            const height = rect.height || rect.h;

            console.log('Resizing grid cell to:', width + 'px', height + 'px');

            // Применяем стили к DOM
            el.style.width = width + 'px';
            el.style.height = height + 'px';
            el.style.minWidth = width + 'px';
            el.style.minHeight = height + 'px';

            // Получаем компонент через редактор
            const editor = getActiveEditor();
            if (editor) {
              const cellComponent = editor.getSelected();
              if (cellComponent && cellComponent.getEl() === el) {
                // Сохраняем стили в модель GrapesJS
                const styles = {
                  width: width + 'px',
                  height: height + 'px',
                  'min-width': width + 'px',
                  'min-height': height + 'px'
                };

                cellComponent.setStyle(styles);
                cellComponent.trigger('change:style');

                // Сохраняем размер в пользовательских атрибутах
                cellComponent.addAttributes({
                  'data-custom-width': width + 'px',
                  'data-custom-height': height + 'px'
                });

                console.log('Grid cell styles saved to model:', styles);
              }
            }
          }
        }
      },
      {
        type: 'grid-cell',
        tagName: 'div',
        attributes: {
          class: 'mui-grid-cell',
          'data-cell-id': 'cell-3'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 100,
          maxDim: 1200,
          updateTarget: (el, rect, component) => {
            const width = rect.width || rect.w;
            const height = rect.height || rect.h;

            console.log('Resizing grid cell to:', width + 'px', height + 'px');

            el.style.width = width + 'px';
            el.style.height = height + 'px';
            el.style.minWidth = width + 'px';
            el.style.minHeight = height + 'px';

            const editor = getActiveEditor();
            if (editor) {
              const cellComponent = editor.getSelected();
              if (cellComponent && cellComponent.getEl() === el) {
                const styles = {
                  width: width + 'px',
                  height: height + 'px',
                  'min-width': width + 'px',
                  'min-height': height + 'px'
                };

                cellComponent.setStyle(styles);
                cellComponent.trigger('change:style');
                cellComponent.addAttributes({
                  'data-custom-width': width + 'px',
                  'data-custom-height': height + 'px'
                });

                console.log('Grid cell styles saved to model:', styles);
              }
            }
          }
        }
      },
      {
        type: 'grid-cell',
        tagName: 'div',
        attributes: {
          class: 'mui-grid-cell',
          'data-cell-id': 'cell-4'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 100,
          maxDim: 1200,
          updateTarget: (el, rect, component) => {
            const width = rect.width || rect.w;
            const height = rect.height || rect.h;

            console.log('Resizing grid cell to:', width + 'px', height + 'px');

            // Применяем стили к DOM
            el.style.width = width + 'px';
            el.style.height = height + 'px';
            el.style.minWidth = width + 'px';
            el.style.minHeight = height + 'px';

            // Получаем компонент через редактор
            const editor = getActiveEditor();
            if (editor) {
              const cellComponent = editor.getSelected();
              if (cellComponent && cellComponent.getEl() === el) {
                // Сохраняем стили в модель GrapesJS
                const styles = {
                  width: width + 'px',
                  height: height + 'px',
                  'min-width': width + 'px',
                  'min-height': height + 'px'
                };

                cellComponent.setStyle(styles);
                cellComponent.trigger('change:style');

                // Сохраняем размер в пользовательских атрибутах
                cellComponent.addAttributes({
                  'data-custom-width': width + 'px',
                  'data-custom-height': height + 'px'
                });

                console.log('Grid cell styles saved to model:', styles);
              }
            }
          }
        }
      },
      {
        type: 'grid-cell',
        tagName: 'div',
        attributes: {
          class: 'mui-grid-cell',
          'data-cell-id': 'cell-5'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 100,
          maxDim: 1200,
          updateTarget: (el, rect, component) => {
            const width = rect.width || rect.w;
            const height = rect.height || rect.h;

            console.log('Resizing grid cell to:', width + 'px', height + 'px');

            // Применяем стили к DOM
            el.style.width = width + 'px';
            el.style.height = height + 'px';
            el.style.minWidth = width + 'px';
            el.style.minHeight = height + 'px';

            // Получаем компонент через редактор
            const editor = getActiveEditor();
            if (editor) {
              const cellComponent = editor.getSelected();
              if (cellComponent && cellComponent.getEl() === el) {
                // Сохраняем стили в модель GrapesJS
                const styles = {
                  width: width + 'px',
                  height: height + 'px',
                  'min-width': width + 'px',
                  'min-height': height + 'px'
                };

                cellComponent.setStyle(styles);
                cellComponent.trigger('change:style');

                // Сохраняем размер в пользовательских атрибутах
                cellComponent.addAttributes({
                  'data-custom-width': width + 'px',
                  'data-custom-height': height + 'px'
                });

                console.log('Grid cell styles saved to model:', styles);
              }
            }
          }
        }
      },
      {
        type: 'grid-cell',
        tagName: 'div',
        attributes: {
          class: 'mui-grid-cell',
          'data-cell-id': 'cell-6'
        },
        draggable: false,
        droppable: true,
        editable: true,
        selectable: true,
        resizable: {
          cr: true,
          bc: true,
          minDim: 100,
          maxDim: 1200,
          updateTarget: (el, rect, component) => {
            const width = rect.width || rect.w;
            const height = rect.height || rect.h;

            console.log('Resizing grid cell to:', width + 'px', height + 'px');

            // Применяем стили к DOM
            el.style.width = width + 'px';
            el.style.height = height + 'px';
            el.style.minWidth = width + 'px';
            el.style.minHeight = height + 'px';

            // Получаем компонент через редактор
            const editor = getActiveEditor();
            if (editor) {
              const cellComponent = editor.getSelected();
              if (cellComponent && cellComponent.getEl() === el) {
                // Сохраняем стили в модель GrapesJS
                const styles = {
                  width: width + 'px',
                  height: height + 'px',
                  'min-width': width + 'px',
                  'min-height': height + 'px'
                };

                cellComponent.setStyle(styles);
                cellComponent.trigger('change:style');

                // Сохраняем размер в пользовательских атрибутах
                cellComponent.addAttributes({
                  'data-custom-width': width + 'px',
                  'data-custom-height': height + 'px'
                });

                console.log('Grid cell styles saved to model:', styles);
              }
            }
          }
        }
      }
    ],
    droppable: true,
    editable: true,
    selectable: true,
    resizable: {
      cr: true,
      bc: true,
      minDim: 100,
      maxDim: 2000,
      updateTarget: (el: HTMLElement, rect: any, component: Component) => {
        const width = rect.width || rect.w;
        const height = rect.height || rect.h;

        console.log('Resizing grid wrapper to:', width + 'px', height + 'px');

        // Применяем стили к DOM
        el.style.width = width + 'px';
        el.style.height = height + 'px';
      }
    }
  },
  block: true,
  icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M15.6 21.6H21.6V15.6H15.6V21.6ZM13.2 24H24V13.2H13.2V24ZM2.4 21.6H8.4V15.6H2.4V21.6ZM0 24H10.8V13.2H0V24ZM15.6 8.4H21.6V2.4H15.6V8.4ZM13.2 10.8H24V0H13.2V10.8ZM2.4 8.4H8.4V2.4H2.4V8.4ZM0 10.8H10.8V0H0V10.8Z" fill="white"/></svg>',
  traits: [
    {
      id: 'axis',
      name: 'axis',
      type: 'select',
      label: 'Axis',
      options: [
        { id: 'row', name: 'Row', value: 'row' },
        { id: 'column', name: 'Column', value: 'column' }
      ],
      value: 'row',
      changeProp: true
    },
    {
      id: 'mainAxisCount',
      name: 'mainAxisCount',
      type: 'number',
      label: 'Main Axis Count',
      min: 1,
      max: 12,
      value: 3,
      changeProp: true
    },
    {
      id: 'crossAxisCount',
      name: 'crossAxisCount',
      type: 'number',
      label: 'Cross Axis Count',
      min: 1,
      max: 12,
      value: 2,
      changeProp: true
    },
    {
      id: 'gapX',
      name: 'gapX',
      type: 'number',
      label: 'Gap X',
      min: 0,
      max: 32,
      value: 16,
      units: ['px', '%', 'auto'],
      changeProp: true
    },
    {
      id: 'gapY',
      name: 'gapY',
      type: 'number',
      label: 'Gap Y',
      min: 0,
      max: 32,
      value: 32,
      units: ['px', '%', 'auto'],
      changeProp: true
    },
    {
      id: 'childAspectRatio',
      name: 'childAspectRatio',
      type: 'number',
      label: 'Child Aspect Ratio',
      min: 0.1,
      step: 0.1,
      value: 1,
      changeProp: true
    },
    {
      id: 'minMax',
      name: 'minMax',
      type: 'select',
      label: 'Size',
      options: [
        { id: 'min', name: 'min', value: 'min' },
        { id: 'max', name: 'max', value: 'max' }
      ],
      value: 'min',
      changeProp: true
    },
    {
      id: 'scrollable',
      name: 'scrollable',
      type: 'switch',
      label: 'Scrollable',
      value: false,
      changeProp: true
    }
  ],
  styles: `
    .mui-grid-wrapper {
      display: grid;
      grid-template-columns: var(--grid-template-columns, repeat(3, minmax(100px, 1fr)));
      grid-template-rows: var(--grid-template-rows, repeat(2, minmax(100px, auto)));
      row-gap: var(--gap-y, 32px);
      column-gap: var(--gap-x, 16px);
      padding: 16px;
      background-color: #3D3AB899;
      border-radius: 8px;
      min-height: 120px;
      height: var(--grid-height, auto);
      width: var(--grid-width, 100%);
      box-sizing: border-box;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      font-family: 'Montserrat', sans-serif;
      position: relative;
      overflow: var(--overflow, visible);
      z-index: 1;
    }
    .mui-grid-cell {
      background-color: #3D3AB899;
      color: #fff;
      padding: 16px;
      border-radius: 4px;
      aspect-ratio: var(--child-aspect-ratio, 1);
      box-sizing: border-box;
      box-shadow: 0 1px 3px rgba(0,0,0,0.3);
      transition: transform 0.2s, box-shadow 0.2s;
      z-index: 1;
    }
    .mui-grid-cell:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4);
    }
    .gjs-resizer {
      background-color: red !important;
      border: 2px solid yellow !important;
      z-index: 100000 !important;
      width: 16px !important;
      height: 16px !important;
      cursor: move !important;
      opacity: 1 !important;
      display: block !important;
    }
    @media (max-width: 600px) {
      .mui-grid-wrapper {
        grid-template-columns: repeat(1, 1fr);
        row-gap: var(--gap-y, 32px);
        column-gap: var(--gap-x, 16px);
      }
    }
  `,
  styleConfig: { sectors: [] },
  script: `
    let cellCounter = 6;
    
    function parseUnitValue(value) {
      if (!value || typeof value !== 'string' || value === 'auto') {
        return { value: value === 'auto' ? 'auto' : '0', unit: value === 'auto' ? 'auto' : 'px' };
      }
      const match = value.match(/^(\\d*\\.?\\d+)?([a-zA-Z%]*)$/);
      if (!match) return { value: '0', unit: 'px' };
      const [, num, unit] = match;
      return { value: num || '0', unit: unit || 'px' };
    }

    function validateUnitValue(trait, value, unit) {
      if (unit === 'auto') return 'auto';
      const min = trait.attributes.min ?? 0;
      const max = trait.attributes.max ?? Infinity;
      const numValue = parseFloat(value) || 0;
      const clampedValue = Math.max(min, Math.min(max, numValue));
      return \`\${clampedValue}\${unit}\`;
    }

    function updateGrid(model) {
      console.log('updateGrid called');
      const wrapper = model.getEl();
      if (!wrapper) {
        console.error('Wrapper element not found');
        return;
      }

      const axis = model.getTrait('axis')?.getValue() || 'row';
      const mainAxisCount = parseInt(model.getTrait('mainAxisCount')?.getValue() || '3');
      const crossAxisCount = parseInt(model.getTrait('crossAxisCount')?.getValue() || '2');
      const gapXData = parseUnitValue(model.getTrait('gapX')?.getValue() || '16px');
      const gapYData = parseUnitValue(model.getTrait('gapY')?.getValue() || '32px');
      const gapX = gapXData.unit === 'auto' ? 'auto' : validateUnitValue(model.getTrait('gapX'), gapXData.value, gapXData.unit);
      const gapY = gapYData.unit === 'auto' ? 'auto' : validateUnitValue(model.getTrait('gapY'), gapYData.value, gapYData.unit);
      const childAspectRatio = parseFloat(model.getTrait('childAspectRatio')?.getValue() || '1');
      const scrollable = model.getTrait('scrollable')?.getValue() || false;
      const minMax = model.getTrait('minMax')?.getValue() || 'min';

      const cellSize = minMax === 'min' ? 100 : 300;
      console.log('Grid config:', { axis, mainAxisCount, crossAxisCount, gapX, gapY, childAspectRatio, scrollable, minMax, cellSize });

      wrapper.style.setProperty('--gap-x', gapX);
      wrapper.style.setProperty('--gap-y', gapY);
      wrapper.style.setProperty('--child-aspect-ratio', childAspectRatio);
      wrapper.style.overflow = scrollable ? 'auto' : 'visible';

      let rows, columns;
      if (axis === 'row') {
        columns = mainAxisCount;
        rows = crossAxisCount;
      } else {
        rows = mainAxisCount;
        columns = crossAxisCount;
      }

      wrapper.style.gridTemplateColumns = \`repeat(\${columns}, minmax(\${cellSize}px, 1fr))\`;
      wrapper.style.gridTemplateRows = \`repeat(\${rows}, minmax(\${cellSize}px, auto))\`;

      const gapXValue = gapX === 'auto' ? 16 : parseFloat(gapX) || 16;
      const gapYValue = gapY === 'auto' ? 32 : parseFloat(gapY) || 32;
      const padding = 16;
      const calculatedWidth = columns * cellSize + (columns - 1) * gapXValue + 2 * padding;
      const calculatedHeight = rows * cellSize + (rows - 1) * gapYValue + 2 * padding;

      wrapper.style.minWidth = \`\${calculatedWidth}px\`;
      wrapper.style.minHeight = scrollable ? '0' : \`\${calculatedHeight}px\`;

      const resized = model.get('resized') || false;
      const currentWidth = model.getAttributes()['data-grid-width'] || '100%';
      const currentHeight = model.getAttributes()['data-grid-height'] || 'auto';

      const width = resized ? currentWidth : 'fit-content';
      const height = resized ? currentHeight : (scrollable ? \`\${calculatedHeight}px\` : 'fit-content');

      wrapper.style.width = width;
      wrapper.style.height = height;

      if (model.changed && (model.changed.gapX || model.changed.gapY || model.changed.mainAxisCount || model.changed.crossAxisCount || model.changed.minMax || model.changed.axis)) {
        model.set('resized', false);
      }

      // Manual component scaling is disabled. Grid dimensions are derived from
      // its own configuration (rows/columns/cell size), not drag handles.
      model.set('resizable', false);

      const currentCells = model.find('.mui-grid-cell').length;
      const requiredCells = mainAxisCount * crossAxisCount;
      
      if (requiredCells > currentCells) {
        for (let i = currentCells; i < requiredCells; i++) {
          cellCounter++;
          const newCell = model.append({
            type: 'grid-cell',
            tagName: 'div',
            attributes: {
              class: 'mui-grid-cell',
              'data-cell-id': 'cell-' + cellCounter
            },
            components: [],
            draggable: false,
            droppable: true,
            editable: true,
            selectable: true,
            resizable: {
              cr: true,
              bc: true,
              minDim: 100,
              maxDim: 1200,
              updateTarget: (el, rect, component) => {
                const width = rect.width || rect.w;
                const height = rect.height || rect.h;
                
                console.log('Resizing grid cell to:', width + 'px', height + 'px');

                el.style.width = width + 'px';
                el.style.height = height + 'px';
                el.style.minWidth = width + 'px';
                el.style.minHeight = height + 'px';

                // Сохраняем стили в модель компонента
                if (component && component.setStyle) {
                  const styles = {
                    width: width + 'px',
                    height: height + 'px',
                    'min-width': width + 'px',
                    'min-height': height + 'px'
                  };

                  component.setStyle(styles);

                  // Сохраняем размер в пользовательских атрибутах
                  component.addAttributes({
                    'data-custom-width': width + 'px',
                    'data-custom-height': height + 'px'
                  });

                  console.log('Grid cell styles saved to model:', styles);
                }
              }
            }
          });
        }
      } else if (requiredCells < currentCells) {
        const cellsToRemove = model.find('.mui-grid-cell').slice(requiredCells);
        cellsToRemove.forEach(cell => cell.remove());
      }

      // Обновляем размеры существующих ячеек, сохраняя кастомные размеры
      const cells = model.find('.mui-grid-cell');
      cells.forEach(cell => {
        const customWidth = cell.getAttributes()['data-custom-width'];
        const customHeight = cell.getAttributes()['data-custom-height'];
        
        if (customWidth && customHeight) {
          // Используем кастомные размеры если они есть
          updateGridCellSize(cell, parseInt(customWidth), parseInt(customHeight));
        } else {
          // Иначе используем размер из трейта
          updateGridCellSize(cell, cellSize, cellSize);
        }
      });
    }

    function updateGridCellSize(cell, width, height) {
      const el = cell.getEl();
      if (!el) return;

      const styles = {
        'width': width + 'px',
        'height': height + 'px',
        'min-width': width + 'px',
        'min-height': height + 'px'
      };

      Object.entries(styles).forEach(([prop, value]) => {
        el.style[prop] = value;
      });

      cell.setStyle(styles);
    }

    // Функция для принудительного сохранения размеров ячеек при ресайзе
    function forceSaveGridCellSize(cell) {
      const el = cell.getEl();
      if (!el) return;

      const computedStyle = window.getComputedStyle(el);
      const width = computedStyle.width;
      const height = computedStyle.height;

      if (width && height) {
        const styles = {
          'width': width,
          'height': height,
          'min-width': width,
          'min-height': height
        };

        cell.setStyle(styles);
        
        cell.addAttributes({
          'data-custom-width': width,
          'data-custom-height': height
        });

        console.log('Force saved grid cell size:', width, height);
      }
    }

    // Инициализация грида
    if (model && model.getEl) {
      const wrapper = model.getEl();
      if (wrapper) {
        console.log('Grid component initialized');
        updateGrid(model);
      }
    }

    // Слушатели изменений трейтов
    if (model && model.on) {
      model.on('change:axis change:mainAxisCount change:crossAxisCount change:gapX change:gapY change:childAspectRatio change:minMax change:scrollable', () => {
        console.log('Trait changed, updating grid');
        updateGrid(model);
      });

      model.on('change:attributes', () => {
        console.log('Attributes changed, updating grid dimensions');
        const wrapper = model.getEl();
        if (wrapper) {
          const width = model.getAttributes()['data-grid-width'] || '100%';
          const height = model.getAttributes()['data-grid-height'] || 'auto';
          wrapper.style.width = width;
          wrapper.style.height = height;
          console.log('Updated grid dimensions:', { width, height });
        }
      });

      // Слушатель для завершения ресайза ячеек
      model.on('component:resize:end', (component) => {
        if (component && component.get && component.get('type') === 'grid-cell') {
          console.log('Grid cell resize ended, forcing save...');
          setTimeout(() => {
            forceSaveGridCellSize(component);
          }, 100);
        }
      });

      // Слушатель для любых изменений ячеек
      model.on('component:update', (component) => {
        if (component && component.get && component.get('type') === 'grid-cell') {
          console.log('Grid cell updated, checking styles...');
          setTimeout(() => {
            forceSaveGridCellSize(component);
          }, 50);
        }
      });
    }
  `
};
