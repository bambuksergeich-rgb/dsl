import { ComponentConfig } from '../elements';

export const Panel: ComponentConfig = {
  id: 'panel',
  type: 'panel',
  label: 'Panel',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: { class: 'panel-wrapper' },
    components: [
      {
        tagName: 'h2',
        attributes: { class: 'panel-header' },
        content: '',
        droppable: false,
        draggable: false,
        selectable: true,
        hidden: true
      },
      {
        tagName: 'div',
        attributes: { class: 'panel-content' },
        components: [
          ...Array(6).map((_, i) => ({
            type: 'panel-card',
            attributes: { class: 'panel-card', 'data-card-index': `${i}` },
            components: [
              {
                tagName: 'img',
                attributes: {
                  src: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MCA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPHJlY3QgeT0iMC4yNSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iMjAiIGZpbGw9IiM0MTcwRkYiLz4gPHBhdGggZD0iTTExLjkxMSAxNy42MzI3QzEyLjI4MDMgMTYuNDkwNSAxMi44ODg2IDE1LjQ0MjEgMTMuNjkxMyAxNC41NTM2QzEzLjgyNzEgMTQuNDAzNCAxNC4wNCAxNC4zNDk4IDE0LjIzMDcgMTQuNDE4TDE2LjE0OSAxNS4xMDM5QzE2LjY2OSAxNS4yODk4IDE3LjI0MTMgMTUuMDE4OCAxNy40MjcyIDE0LjQ5ODhDMTcuNDQ1NCAxNC40NDc2IDE3LjQ1OTUgMTQuMzk1MSAxNy40NjkyIDE0LjM0MTdMMTcuODM0NyAxMi4zMzU3QzE3Ljg3MSAxMi4xMzYzIDE4LjAyNDIgMTEuOTc4NSAxOC4yMjI1IDExLjkzNjNDMTguODAyNyAxMS44MTI4IDE5LjM5NzYgMTEuNzUgMjAuMDAwMyAxMS43NUMyMC42MDI2IDExLjc1IDIxLjE5NzEgMTEuODEyNyAyMS43NzcgMTEuOTM2MUMyMS45NzUyIDExLjk3ODIgMjIuMTI4NCAxMi4xMzU5IDIyLjE2NDggMTIuMzM1M0wyMi41MzEzIDE0LjM0MTdDMjIuNjMwMyAxNC44ODUgMjMuMTUxMSAxNS4yNDUxIDIzLjY5NDQgMTUuMTQ2QzIzLjc0NzkgMTUuMTM2MyAyMy44MDA0IDE1LjEyMjIgMjMuODUxNSAxNS4xMDRMMjUuNzY5OCAxNC40MThDMjUuOTYwNSAxNC4zNDk4IDI2LjE3MzUgMTQuNDAzNCAyNi4zMDkyIDE0LjU1MzZDMjcuMTExOSAxNS40NDIxIDI3LjcyMDIgMTYuNDkwNSAyOC4wODk1IDE3LjYzMjdDMjguMTUxOCAxNy44MjUzIDI4LjA5MTggMTguMDM2NiAyNy45Mzc0IDE4LjE2NzZMMjYuMzgyNiAxOS40ODc3QzI1Ljk2MTYgMTkuODQ1MiAyNS45MTAxIDIwLjQ3NjMgMjYuMjY3NSAyMC44OTczQzI2LjMwMjcgMjAuOTM4NyAyNi4zNDEyIDIwLjk3NzEgMjYuMzgyNSAyMS4wMTIzTDI3LjkzNzQgMjIuMzMyNEMyOC4wOTE4IDIyLjQ2MzQgMjguMTUxOCAyMi42NzQ3IDI4LjA4OTUgMjIuODY3M0MyNy43MjAyIDI0LjAwOTUgMjcuMTExOSAyNS4wNTc5IDI2LjMwOTIgMjUuOTQ2NEMyNi4xNzM1IDI2LjA5NjYgMjUuOTYwNSAyNi4xNTAyIDI1Ljc2OTggMjYuMDgyTDIzLjg1MTYgMjUuMzk2MUMyMy4zMzE1IDI1LjIxMDIgMjIuNzU5MiAyNS40ODEyIDIyLjU3MzQgMjYuMDAxMkMyMi41NTUxIDI2LjA1MjQgMjIuNTQxIDI2LjEwNDkgMjIuNTMxMiAyNi4xNTg1TDIyLjE2NDggMjguMTY0N0MyMi4xMjg0IDI4LjM2NDEgMjEuOTc1MiAyOC41MjE4IDIxLjc3NyAyOC41NjM5QzIxLjE5NzEgMjguNjg3MyAyMC42MDI2IDI4Ljc1IDIwLjAwMDMgMjguNzVDMTkuMzk3NiAyOC43NSAxOC44MDI3IDI4LjY4NzIgMTguMjIyNSAyOC41NjM3QzE4LjAyNDIgMjguNTIxNSAxNy44NzEgMjguMzYzNyAxNy44MzQ3IDI4LjE2NDNMMTcuNDY5MyAyNi4xNTg0QzE3LjM3MDIgMjUuNjE1IDE2Ljg0OTQgMjUuMjU0OSAxNi4zMDYxIDI1LjM1NEMxNi4yNTI2IDI1LjM2MzcgMTYuMjAwMSAyNS4zNzc4IDE2LjE0OTEgMjUuMzk2MUwxNC4yMzA3IDI2LjA4MkMxNC4wNCAyNi4xNTAyIDEzLjgyNzEgMjYuMDk2NiAxMy42OTEzIDI1Ljk0NjRDMTIuODg4NiAyNS4wNTc5IDEyLjI4MDMgMjQuMDA5NSAxMS45MTEgMjIuODY3M0MxMS44NDg3IDIyLjY3NDcgMTEuOTA4OCAyMi40NjM0IDEyLjA2MzEgMjIuMzMyNEwxMy42MTggMjEuMDEyM0MxNC4wMzkgMjAuNjU0OCAxNC4wOTA1IDIwLjAyMzcgMTMuNzMzIDE5LjYwMjdDMTMuNjk3OCAxOS41NjE0IDEzLjY1OTQgMTkuNTIyOSAxMy42MTggMTkuNDg3OEwxMi4wNjMxIDE4LjE2NzZDMTEuOTA4OCAxOC4wMzY2IDExLjg0ODcgMTcuODI1MyAxMS45MTEgMTcuNjMyN1pNMTIuOTcxNSAxNy42MjcxTDE0LjI2NTIgMTguNzI1NUMxNC4zNDggMTguNzk1OCAxNC40MjUgMTguODcyNyAxNC40OTUzIDE4Ljk1NTVDMTUuMjEwMiAxOS43OTc1IDE1LjEwNzIgMjEuMDU5NiAxNC4yNjUyIDIxLjc3NDZMMTIuOTcxNSAyMi44NzI5QzEzLjI2MzYgMjMuNjU1MSAxMy42ODUgMjQuMzgyMiAxNC4yMTY1IDI1LjAyNTFMMTUuODEyNSAyNC40NTQ0QzE1LjkxNDcgMjQuNDE3OSAxNi4wMTk4IDI0LjM4OTcgMTYuMTI2NyAyNC4zNzAyQzE3LjIxMzMgMjQuMTcyIDE4LjI1NDkgMjQuODkyMyAxOC40NTMxIDI1Ljk3OUwxOC43NTcgMjcuNjQ3NUMxOS4xNjQ5IDI3LjcxNTUgMTkuNTgwMyAyNy43NSAyMC4wMDAzIDI3Ljc1QzIwLjQyIDI3Ljc1IDIwLjgzNTEgMjcuNzE1NiAyMS4yNDI3IDI3LjY0NzZMMjEuNTQ3NSAyNS45Nzg5QzIxLjU2NyAyNS44NzIxIDIxLjU5NTEgMjUuNzY3IDIxLjYzMTcgMjUuNjY0N0MyMi4wMDM0IDI0LjYyNDYgMjMuMTQ3OSAyNC4wODI3IDI0LjE4ODIgMjQuNDU0NEwyNS43ODQgMjUuMDI1MUMyNi4zMTU1IDI0LjM4MjIgMjYuNzM2OSAyMy42NTUxIDI3LjAyOSAyMi44NzI5TDI1LjczNTMgMjEuNzc0NUMyNS42NTI1IDIxLjcwNDIgMjUuNTc1NiAyMS42MjczIDI1LjUwNTMgMjEuNTQ0NUMyNC43OTAzIDIwLjcwMjUgMjQuODkzMyAxOS40NDA0IDI1LjczNTMgMTguNzI1NEwyNy4wMjkgMTcuNjI3MUMyNi43MzY5IDE2Ljg0NDkgMjYuMzE1NSAxNi4xMTc4IDI1Ljc4NCAxNS40NzQ5TDI0LjE4ODEgMTYuMDQ1NkMyNC4wODU4IDE2LjA4MjEgMjMuOTgwNyAxNi4xMTAzIDIzLjg3MzkgMTYuMTI5OEMyMi43ODcyIDE2LjMyOCAyMS43NDU3IDE1LjYwNzcgMjEuNTQ3NSAxNC41MjEyTDIxLjI0MjcgMTIuODUyM0MyMC44MzUxIDEyLjc4NDQgMjAuNDIgMTIuNzUgMjAuMDAwMyAxMi43NUMxOS41ODAzIDEyLjc1IDE5LjE2NDkgMTIuNzg0NSAxOC43NTcgMTIuODUyNUwxOC40NTMgMTQuNTIxQzE4LjQzMzUgMTQuNjI3OSAxOC40MDU0IDE0LjczMyAxOC4zNjg4IDE0LjgzNTNDMTcuOTk3MSAxNS44NzU0IDE2Ljg1MjYgMTYuNDE3MyAxNS44MTI0IDE2LjA0NTZMMTQuMjE2NSAxNS40NzQ5QzEzLjY4NSAxNi4xMTc4IDEzLjI2MzYgMTYuODQ0OSAxMi45NzE1IDE3LjYyNzFaTTE3LjUwMDMgMjAuMjVDMTcuNTAwMyAxOC44NjkzIDE4LjYxOTYgMTcuNzUgMjAuMDAwMyAxNy43NUMyMS4zODEgMTcuNzUgMjIuNTAwMyAxOC44NjkzIDIyLjUwMDMgMjAuMjVDMjIuNTAwMyAyMS42MzA3IDIxLjM4MSAyMi43NSAyMC4wMDAzIDIyLjc1QzE4LjYxOTYgMjIuNzUgMTcuNTAwMyAyMS42MzA3IDE3LjUwMDMgMjAuMjVaTTE4LjUwMDMgMjAuMjVDMTguNTAwMyAyMS4wNzg0IDE5LjE3MTggMjEuNzUgMjAuMDAwMyAyMS43NUMyMC44Mjg3IDIxLjc1IDIxLjUwMDMgMjEuMDc4NCAyMS41MDAzIDIwLjI1QzIxLjUwMDMgMTkuNDIxNiAyMC44Mjg3IDE4Ljc1IDIwLjAwMDMgMTguNzVDMTkuMTcxOCAxOC43NSAxOC41MDAzIDE5LjQyMTYgMTguNTAwMyAyMC4yNVoiIGZpbGw9IndoaXRlIi8+IDwvc3ZnPg==',
                  alt: `Product ${i + 1}`
                },
                droppable: true,
                draggable: false
              },
              {
                tagName: 'h3',
                content: `Product ${i + 1}`,
                droppable: true,
                draggable: false
              },
              {
                tagName: 'p',
                content: 'Description',
                droppable: true,
                draggable: false
              }
            ]
          }))
        ],
        droppable: false,
        draggable: false,
        selectable: true
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_47_4502)">
<path d="M22.9809 5.04459H20.1274V2.03823H22.9299C23.4904 2.03823 24 1.57963 24 1.01914C24 0.458647 23.5414 0 22.9809 0H1.01909C0.458599 0 0 0.458599 0 1.01909C0 1.57959 0.458599 2.03818 1.01909 2.03818H3.82166V5.04459H1.01909C0.458599 5.04459 0 5.50318 0 6.06368V22.9809C0 23.5414 0.458599 24 1.01909 24H22.9299C23.4904 24 23.949 23.5414 24 23.0318V6.06368C24 5.50318 23.5414 5.04459 22.9809 5.04459ZM5.85989 2.03823H18.0892V5.04459H5.85989V2.03823ZM21.9618 22.0127H1.98726V7.03185H21.9618V22.0127Z" fill="white"/>
<path d="M17.0697 13.1975L12.6875 9.07014C12.2799 8.71344 11.7194 8.71344 11.3117 9.07014L6.9296 13.1975C6.52197 13.6052 6.52197 14.2166 6.87863 14.6243C7.2863 15.0319 7.89777 15.0319 8.30539 14.6753L10.9551 12.1275V19.2103C10.9551 19.7708 11.4137 20.2294 11.9742 20.2294C12.5347 20.2294 12.9933 19.8218 12.9933 19.2103V12.1275L15.6939 14.6752C15.8468 14.8281 16.1015 14.93 16.3563 14.93C16.6111 14.93 16.8659 14.8281 17.1207 14.6242C17.4774 14.2166 17.4774 13.5542 17.0697 13.1975Z" fill="white"/>
</g>
<defs>
<clipPath id="clip0_47_4502">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>
</svg>`,
  traits: [
    {
      id: 'cards',
      name: 'cards',
      label: 'Cards (JSON)',
      type: 'json',
      changeProp: true,
      value: JSON.stringify([
        ...Array(6).map((_, i) => ({
          title: `Product ${i + 1}`,
          description: 'Description',
          image:
            'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MCA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPHJlY3QgeT0iMC4yNSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iMjAiIGZpbGw9IiM0MTcwRkYiLz4gPHBhdGggZD0iTTExLjkxMSAxNy42MzI3QzEyLjI4MDMgMTYuNDkwNSAxMi44ODg2IDE1LjQ0MjEgMTMuNjkxMyAxNC41NTM2QzEzLjgyNzEgMTQuNDAzNCAxNC4wNCAxNC4zNDk4IDE0LjIzMDcgMTQuNDE4TDE2LjE0OSAxNS4xMDM5QzE2LjY2OSAxNS4yODk4IDE3LjI0MTMgMTUuMDE4OCAxNy40MjcyIDE0LjQ5ODhDMTcuNDQ1NCAxNC40NDc2IDE3LjQ1OTUgMTQuMzk1MSAxNy40NjkyIDE0LjM0MTdMMTcuODM0NyAxMi4zMzU3QzE3Ljg3MSAxMi4xMzYzIDE4LjAyNDIgMTEuOTc4NSAxOC4yMjI1IDExLjkzNjNDMTguODAyNyAxMS44MTI4IDE5LjM5NzYgMTEuNzUgMjAuMDAwMyAxMS43NUMyMC42MDI2IDExLjc1IDIxLjE5NzEgMTEuODEyNyAyMS43NzcgMTEuOTM2MUMyMS45NzUyIDExLjk3ODIgMjIuMTI4NCAxMi4xMzU5IDIyLjE2NDggMTIuMzM1M0wyMi41MzEzIDE0LjM0MTdDMjIuNjMwMyAxNC44ODUgMjMuMTUxMSAxNS4yNDUxIDIzLjY5NDQgMTUuMTQ2QzIzLjc0NzkgMTUuMTM2MyAyMy44MDA0IDE1LjEyMjIgMjMuODUxNSAxNS4xMDRMMjUuNzY5OCAxNC40MThDMjUuOTYwNSAxNC4zNDk4IDI2LjE3MzUgMTQuNDAzNCAyNi4zMDkyIDE0LjU1MzZDMjcuMTExOSAxNS40NDIxIDI3LjcyMDIgMTYuNDkwNSAyOC4wODk1IDE3LjYzMjdDMjguMTUxOCAxNy44MjUzIDI4LjA5MTggMTguMDM2NiAyNy45Mzc0IDE4LjE2NzZMMjYuMzgyNiAxOS40ODc3QzI1Ljk2MTYgMTkuODQ1MiAyNS45MTAxIDIwLjQ3NjMgMjYuMjY3NSAyMC44OTczQzI2LjMwMjcgMjAuOTM4NyAyNi4zNDEyIDIwLjk3NzEgMjYuMzgyNSAyMS4wMTIzTDI3LjkzNzQgMjIuMzMyNEMyOC4wOTE4IDIyLjQ2MzQgMjguMTUxOCAyMi42NzQ3IDI4LjA4OTUgMjIuODY3M0MyNy43MjAyIDI0LjAwOTUgMjcuMTExOSAyNS4wNTc5IDI2LjMwOTIgMjUuOTQ2NEMyNi4xNzM1IDI2LjA5NjYgMjUuOTYwNSAyNi4xNTAyIDI1Ljc2OTggMjYuMDgyTDIzLjg1MTYgMjUuMzk2MUMyMy4zMzE1IDI1LjIxMDIgMjIuNzU5MiAyNS40ODEyIDIyLjU3MzQgMjYuMDAxMkMyMi41NTUxIDI2LjA1MjQgMjIuNTQxIDI2LjEwNDkgMjIuNTMxMiAyNi4xNTg1TDIyLjE2NDggMjguMTY0N0MyMi4xMjg0IDI4LjM2NDEgMjEuOTc1MiAyOC41MjE4IDIxLjc3NyAyOC41NjM5QzIxLjE5NzEgMjguNjg3MyAyMC42MDI2IDI4Ljc1IDIwLjAwMDMgMjguNzVDMTkuMzk3NiAyOC43NSAxOC44MDI3IDI4LjY4NzIgMTguMjIyNSAyOC41NjM3QzE4LjAyNDIgMjguNTIxNSAxNy44NzEgMjguMzYzNyAxNy44MzQ3IDI4LjE2NDNMMTcuNDY5MyAyNi4xNTg0QzE3LjM3MDIgMjUuNjE1IDE2Ljg0OTQgMjUuMjU0OSAxNi4zMDYxIDI1LjM1NEMxNi4yNTI2IDI1LjM2MzcgMTYuMjAwMSAyNS4zNzc4IDE2LjE0OTEgMjUuMzk2MUwxNC4yMzA3IDI2LjA4MkMxNC4wNCAyNi4xNTAyIDEzLjgyNzEgMjYuMDk2NiAxMy42OTEzIDI1Ljk0NjRDMTIuODg4NiAyNS4wNTc5IDEyLjI4MDMgMjQuMDA5NSAxMS45MTEgMjIuODY3M0MxMS44NDg3IDIyLjY3NDcgMTEuOTA4OCAyMi40NjM0IDEyLjA2MzEgMjIuMzMyNEwxMy42MTggMjEuMDEyM0MxNC4wMzkgMjAuNjU0OCAxNC4wOTA1IDIwLjAyMzcgMTMuNzMzIDE5LjYwMjdDMTMuNjk3OCAxOS41NjE0IDEzLjY1OTQgMTkuNTIyOSAxMy42MTggMTkuNDg3OEwxMi4wNjMxIDE4LjE2NzZDMTEuOTA4OCAxOC4wMzY2IDExLjg0ODcgMTcuODI1MyAxMS45MTEgMTcuNjMyN1pNMTIuOTcxNSAxNy42MjcxTDE0LjI2NTIgMTguNzI1NUMxNC4zNDggMTguNzk1OCAxNC40MjUgMTguODcyNyAxNC40OTUzIDE4Ljk1NTVDMTUuMjEwMiAxOS43OTc1IDE1LjEwNzIgMjEuMDU5NiAxNC4yNjUyIDIxLjc3NDZMMTIuOTcxNSAyMi44NzI5QzEzLjI2MzYgMjMuNjU1MSAxMy42ODUgMjQuMzgyMiAxNC4yMTY1IDI1LjAyNTFMMTUuODEyNSAyNC40NTQ0QzE1LjkxNDcgMjQuNDE3OSAxNi4wMTk4IDI0LjM4OTcgMTYuMTI2NyAyNC4zNzAyQzE3LjIxMzMgMjQuMTcyIDE4LjI1NDkgMjQuODkyMyAxOC40NTMxIDI1Ljk3OUwxOC43NTcgMjcuNjQ3NUMxOS4xNjQ5IDI3LjcxNTUgMTkuNTgwMyAyNy43NSAyMC4wMDAzIDI3Ljc1QzIwLjQyIDI3Ljc1IDIwLjgzNTEgMjcuNzE1NiAyMS4yNDI3IDI3LjY0NzZMMjEuNTQ3NSAyNS45Nzg5QzIxLjU2NyAyNS44NzIxIDIxLjU5NTEgMjUuNzY3IDIxLjYzMTcgMjUuNjY0N0MyMi4wMDM0IDI0LjYyNDYgMjMuMTQ3OSAyNC4wODI3IDI0LjE4ODIgMjQuNDU0NEwyNS43ODQgMjUuMDI1MUMyNi4zMTU1IDI0LjM4MjIgMjYuNzM2OSAyMy42NTUxIDI3LjAyOSAyMi44NzI5TDI1LjczNTMgMjEuNzc0NUMyNS42NTI1IDIxLjcwNDIgMjUuNTc1NiAyMS42MjczIDI1LjUwNTMgMjEuNTQ0NUMyNC43OTAzIDIwLjcwMjUgMjQuODkzMyAxOS40NDA0IDI1LjczNTMgMTguNzI1NEwyNy4wMjkgMTcuNjI3MUMyNi43MzY5IDE2Ljg0NDkgMjYuMzE1NSAxNi4xMTc4IDI1Ljc4NCAxNS40NzQ5TDI0LjE4ODEgMTYuMDQ1NkMyNC4wODU4IDE2LjA4MjEgMjMuOTgwNyAxNi4xMTAzIDIzLjg3MzkgMTYuMTI5OEMyMi43ODcyIDE2LjMyOCAyMS43NDU3IDE1LjYwNzcgMjEuNTQ3NSAxNC41MjEyTDIxLjI0MjcgMTIuODUyM0MyMC44MzUxIDEyLjc4NDQgMjAuNDIgMTIuNzUgMjAuMDAwMyAxMi43NUMxOS41ODAzIDEyLjc1IDE5LjE2NDkgMTIuNzg0NSAxOC43NTcgMTIuODUyNUwxOC40NTMgMTQuNTIxQzE4LjQzMzUgMTQuNjI3OSAxOC40MDU0IDE0LjczMyAxOC4zNjg4IDE0LjgzNTNDMTcuOTk3MSAxNS44NzU0IDE2Ljg1MjYgMTYuNDE3MyAxNS44MTI0IDE2LjA0NTZMMTQuMjE2NSAxNS40NzQ5QzEzLjY4NSAxNi4xMTc4IDEzLjI2MzYgMTYuODQ0OSAxMi45NzE1IDE3LjYyNzFaTTE3LjUwMDMgMjAuMjVDMTcuNTAwMyAxOC44NjkzIDE4LjYxOTYgMTcuNzUgMjAuMDAwMyAxNy43NUMyMS4zODEgMTcuNzUgMjIuNTAwMyAxOC44NjkzIDIyLjUwMDMgMjAuMjVDMjIuNTAwMyAyMS42MzA3IDIxLjM4MSAyMi43NSAyMC4wMDAzIDIyLjc1QzE4LjYxOTYgMjIuNzUgMTcuNTAwMyAyMS42MzA3IDE3LjUwMDMgMjAuMjVaTTE4LjUwMDMgMjAuMjVDMTguNTAwMyAyMS4wNzg0IDE5LjE3MTggMjEuNzUgMjAuMDAwMyAyMS43NUMyMC44Mjg3IDIxLjc1IDIxLjUwMDMgMjEuMDc4NCAyMS41MDAzIDIwLjI1QzIxLjUwMDMgMTkuNDIxNiAyMC44Mjg3IDE4Ljc1IDIwLjAwMDMgMTguNzVDMTkuMTcxOCAxOC43NSAxOC41MDAzIDE5LjQyMTYgMTguNTAwMyAyMC4yNVoiIGZpbGw9IndoaXRlIi8+IDwvc3ZnPg=='
        }))
      ])
    },
    {
      id: 'columns',
      name: 'columns',
      label: 'Columns',
      type: 'number',
      changeProp: true,
      value: 2,
      min: 1,
      max: 4
    },
    {
      id: 'scrollable',
      name: 'scrollable',
      label: 'Scrollable',
      type: 'checkbox',
      changeProp: true,
      value: false
    },
    {
      id: 'page',
      name: 'page',
      label: 'Page',
      type: 'checkbox',
      changeProp: true,
      value: false
    },
    {
      id: 'header',
      name: 'header',
      label: 'Header',
      type: 'text',
      changeProp: true,
      value: ''
    },
    {
      id: 'pageType',
      name: 'pageType',
      label: 'Page Type',
      type: 'select',
      changeProp: true,
      value: 'Home',
      options: [
        {
          value: 'Home',
          label: 'Home',
          id: '',
          name: ''
        },
        {
          value: 'Blog',
          label: 'Blog',
          id: '',
          name: ''
        },
        {
          value: 'About',
          label: 'About',
          id: '',
          name: ''
        },
        {
          value: 'Contact',
          label: 'Contact',
          id: '',
          name: ''
        }
      ]
    },
    {
      id: 'addCard',
      name: 'addCard',
      label: 'Add Card',
      type: 'button',
      command: 'add-panel-card'
    },
    {
      id: 'removeLastCard',
      name: 'removeLastCard',
      label: 'Remove Last Card',
      type: 'button',
      command: 'remove-last-panel-card'
    }
  ],
  styleConfig: {
    sectors: [
      {
        id: 'Style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'border-color',
            name: 'Border Color',
            property: 'border-color',
            type: 'color',
            default: '#3D3AB8'
          },
          {
            id: 'color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#FFFFFF26'
          },
          {
            id: 'border-width',
            name: 'Border Width',
            property: 'border-width',
            type: 'number',
            default: '2',
            units: ['px']
          },
          {
            id: 'border-style',
            name: 'Border Type',
            property: 'border-style',
            type: 'select',
            default: 'solid',
            options: [
              {
                value: 'solid',
                label: 'Solid',
                id: '',
                name: ''
              },
              {
                value: 'dashed',
                label: 'Dashed',
                id: '',
                name: ''
              },
              {
                value: 'dotted',
                label: 'Dotted',
                id: '',
                name: ''
              },
              {
                value: 'none',
                label: 'None',
                id: '',
                name: ''
              }
            ]
          },
          {
            id: 'element-border-color',
            name: 'Element Border Color',
            property: '--element-border-color',
            type: 'color',
            default: '#FFFFFF26'
          },
          {
            id: 'element-color',
            name: 'Element Color',
            property: '--element-color',
            type: 'color',
            default: '#FFFFFF26'
          },
          {
            id: 'element-border-width',
            name: 'Element Border Width',
            property: '--element-border-width',
            type: 'number',
            default: '1',
            units: ['px']
          },
          {
            id: 'element-border-style',
            name: 'Element Border Type',
            property: '--element-border-style',
            type: 'select',
            default: 'solid',
            options: [
              {
                value: 'solid',
                label: 'Solid',
                id: '',
                name: ''
              },
              {
                value: 'dashed',
                label: 'Dashed',
                id: '',
                name: ''
              },
              {
                value: 'dotted',
                label: 'Dotted',
                id: '',
                name: ''
              },
              {
                value: 'none',
                label: 'None',
                id: '',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'Dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            default: '50%',
            units: ['px', '%']
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            default: '752px',
            units: ['px', '%']
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          }
        ]
      },
      {
        id: 'Element Text',
        name: 'Element Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: '--element-font-size',
            type: 'number',
            default: '16',
            units: ['px']
          },
          {
            id: 'element-text-color',
            name: 'Color',
            property: '--element-text-color',
            type: 'color',
            default: '#FFFFFF26'
          }
        ]
      }
    ]
  },
  styles: `
    .panel-wrapper {
      width: var(--width, auto);
      min-width: var(--min-width, 50%);
      max-width: var(--max-width, 752px);
      height: var(--height, auto);
      min-height: var(--min-height, auto);
      max-height: var(--max-height, auto);
      padding: 0;
      background-color: var(--bg-color, #10161C80);
      border: var(--border-width, 2px) var(--border-style, solid) var(--border-color, #3D3AB8);
      border-radius: 12px;
      text-align: left;
      display: flex;
      flex-direction: column;
    }
    .panel-wrapper.full-page {
      width: 100%;
      min-width: 100%;
      max-width: 100%;
    }
    .panel-header {
      padding: 16px;
      margin: 0;
      font-size: 24px;
      color: var(--element-text-color, #FFFFFF26);
      display: none;
    }
    .panel-content {
      padding: 16px;
      flex: 1;
      overflow-x: auto;
      overflow-y: var(--scrollable, auto);
      display: grid;
      grid-template-columns: repeat(var(--columns, 2), minmax(150px, 1fr));
      gap: 16px;
    }
    .panel-card {
      background-color: #10161C80;
      border: var(--element-border-width, 1px) var(--element-border-style, solid) var(--element-border-color, #FFFFFF26);
      border-radius: 8px;
      padding: 16px;
      text-align: center;
      min-height: 200px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }
    .panel-card img {
      max-width: 100%;
      height: auto;
      border-radius: 4px;
      margin-bottom: 12px;
    }
    .panel-card h3 {
      margin: 12px 0 8px;
      font-size: var(--element-font-size, 16px);
      color: var(--element-text-color, #FFFFFF26);
    }
    .panel-card p {
      color: var(--element-text-color, #FFFFFF26);
      font-size: calc(var(--element-font-size, 16px) - 2px);
    }
    @media (max-width: 600px) {
      .panel-wrapper {
        min-width: 100%;
        width: 100%;
        max-width: none;
      }
      .panel-content {
        grid-template-columns: repeat(var(--columns, 1), minmax(100px, 1fr));
      }
      .panel-card h3 {
        font-size: calc(var(--element-font-size, 16px) - 2px);
      }
      .panel-card p {
        font-size: calc(var(--element-font-size, 16px) - 4px);
      }
    }
  `,
  script: `
    function updatePanel(model, editor) {
      console.log('updatePanel called:', model.changed);
      if (!model || !model.getEl() || !editor) {
        console.error('No model, editor, or wrapper element:', { model, editor, el: model?.getEl() });
        return;
      }
      const wrapper = model.getEl();
      const traits = model.getTraits();
      try {
        const contentEl = wrapper.querySelector('.panel-content');
        const headerEl = wrapper.querySelector('.panel-header');
        if (!contentEl) {
          console.error('Missing panel-content element');
          return;
        }
        const cardsTrait = traits.find(t => t.getName() === 'cards');
        const columns = traits.find(t => t.getName() === 'columns')?.getValue() || 2;
        const scrollable = traits.find(t => t.getName() === 'scrollable')?.getValue() || false;
        const page = traits.find(t => t.getName() === 'page')?.getValue() || false;
        const header = traits.find(t => t.getName() === 'header')?.getValue() || '';
        const pageType = traits.find(t => t.getName() === 'pageType')?.getValue() || 'Home';

        // Устанавливаем столбцы и атрибуты
        wrapper.style.setProperty('--columns', columns);
        wrapper.style.setProperty('--scrollable', scrollable ? 'auto' : 'hidden');
        wrapper.setAttribute('data-page-type', pageType);
        if (page) {
          wrapper.classList.add('full-page');
        } else {
          wrapper.classList.remove('full-page');
        }

        // Обновляем заголовок
        if (headerEl) {
          headerEl.textContent = header;
          headerEl.style.display = header ? 'block' : 'none';
        }

        // Устанавливаем стили из styleConfig
        const styles = model.getStyle() || {};
        wrapper.style.setProperty('--width', page ? '100%' : (styles.width || 'auto'));
        wrapper.style.setProperty('--min-width', page ? '100%' : (styles['min-width'] || '50%'));
        wrapper.style.setProperty('--max-width', page ? '100%' : (styles['max-width'] || '752px'));
        wrapper.style.setProperty('--height', styles.height || 'auto');
        wrapper.style.setProperty('--min-height', styles['min-height'] || 'auto');
        wrapper.style.setProperty('--max-height', styles['max-height'] || 'auto');
        wrapper.style.setProperty('--bg-color', '#10161C80');
        wrapper.style.setProperty('--border-color', styles['border-color'] || '#3D3AB8');
        wrapper.style.setProperty('--border-width', styles['border-width'] || '2px');
        wrapper.style.setProperty('--border-style', styles['border-style'] || 'solid');
        wrapper.style.setProperty('--element-border-color', styles['--element-border-color'] || '#FFFFFF26');
        wrapper.style.setProperty('--element-color', styles['--element-color'] || '#FFFFFF26');
        wrapper.style.setProperty('--element-border-width', styles['--element-border-width'] || '1px');
        wrapper.style.setProperty('--element-border-style', styles['--element-border-style'] || 'solid');
        wrapper.style.setProperty('--element-font-size', styles['--element-font-size'] || '16px');
        wrapper.style.setProperty('--element-text-color', styles['--element-text-color'] || '#FFFFFF26');

        // Получаем текущее содержимое карточек
        let cardsData = [];
        try {
          cardsData = cardsTrait?.getValue() ? JSON.parse(cardsTrait.getValue()) : [
            ...Array.from({ length: 6 }, (_, i) => ({
              title: \`Product \${i + 1}\`,
              description: 'Description',
              image:'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MCA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPHJlY3QgeT0iMC4yNSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iMjAiIGZpbGw9IiM0MTcwRkYiLz4gPHBhdGggZD0iTTExLjkxMSAxNy42MzI3QzEyLjI4MDMgMTYuNDkwNSAxMi44ODg2IDE1LjQ0MjEgMTMuNjkxMyAxNC41NTM2QzEzLjgyNzEgMTQuNDAzNCAxNC4wNCAxNC4zNDk4IDE0LjIzMDcgMTQuNDE4TDE2LjE0OSAxNS4xMDM5QzE2LjY2OSAxNS4yODk4IDE3LjI0MTMgMTUuMDE4OCAxNy40MjcyIDE0LjQ5ODhDMTcuNDQ1NCAxNC40NDc2IDE3LjQ1OTUgMTQuMzk1MSAxNy40NjkyIDE0LjM0MTdMMTcuODM0NyAxMi4zMzU3QzE3Ljg3MSAxMi4xMzYzIDE4LjAyNDIgMTEuOTc4NSAxOC4yMjI1IDExLjkzNjNDMTguODAyNyAxMS44MTI4IDE5LjM5NzYgMTEuNzUgMjAuMDAwMyAxMS43NUMyMC42MDI2IDExLjc1IDIxLjE5NzEgMTEuODEyNyAyMS43NzcgMTEuOTM2MUMyMS45NzUyIDExLjk3ODIgMjIuMTI4NCAxMi4xMzU5IDIyLjE2NDggMTIuMzM1M0wyMi41MzEzIDE0LjM0MTdDMjIuNjMwMyAxNC44ODUgMjMuMTUxMSAxNS4yNDUxIDIzLjY5NDQgMTUuMTQ2QzIzLjc0NzkgMTUuMTM2MyAyMy44MDA0IDE1LjEyMjIgMjMuODUxNSAxNS4xMDRMMjUuNzY5OCAxNC40MThDMjUuOTYwNSAxNC4zNDk4IDI2LjE3MzUgMTQuNDAzNCAyNi4zMDkyIDE0LjU1MzZDMjcuMTExOSAxNS40NDIxIDI3LjcyMDIgMTYuNDkwNSAyOC4wODk1IDE3LjYzMjdDMjguMTUxOCAxNy44MjUzIDI4LjA5MTggMTguMDM2NiAyNy45Mzc0IDE4LjE2NzZMMjYuMzgyNiAxOS40ODc3QzI1Ljk2MTYgMTkuODQ1MiAyNS45MTAxIDIwLjQ3NjMgMjYuMjY3NSAyMC44OTczQzI2LjMwMjcgMjAuOTM4NyAyNi4zNDEyIDIwLjk3NzEgMjYuMzgyNSAyMS4wMTIzTDI3LjkzNzQgMjIuMzMyNEMyOC4wOTE4IDIyLjQ2MzQgMjguMTUxOCAyMi42NzQ3IDI4LjA4OTUgMjIuODY3M0MyNy43MjAyIDI0LjAwOTUgMjcuMTExOSAyNS4wNTc5IDI2LjMwOTIgMjUuOTQ2NEMyNi4xNzM1IDI2LjA5NjYgMjUuOTYwNSAyNi4xNTAyIDI1Ljc2OTggMjYuMDgyTDIzLjg1MTYgMjUuMzk2MUMyMy4zMzE1IDI1LjIxMDIgMjIuNzU5MiAyNS40ODEyIDIyLjU3MzQgMjYuMDAxMkMyMi41NTUxIDI2LjA1MjQgMjIuNTQxIDI2LjEwNDkgMjIuNTMxMiAyNi4xNTg1TDIyLjE2NDggMjguMTY0N0MyMi4xMjg0IDI4LjM2NDEgMjEuOTc1MiAyOC41MjE4IDIxLjc3NyAyOC41NjM5QzIxLjE5NzEgMjguNjg3MyAyMC42MDI2IDI4Ljc1IDIwLjAwMDMgMjguNzVDMTkuMzk3NiAyOC43NSAxOC44MDI3IDI4LjY4NzIgMTguMjIyNSAyOC41NjM3QzE4LjAyNDIgMjguNTIxNSAxNy44NzEgMjguMzYzNyAxNy44MzQ3IDI4LjE2NDNMMTcuNDY5MyAyNi4xNTg0QzE3LjM3MDIgMjUuNjE1IDE2Ljg0OTQgMjUuMjU0OSAxNi4zMDYxIDI1LjM1NEMxNi4yNTI2IDI1LjM2MzcgMTYuMjAwMSAyNS4zNzc4IDE2LjE0OTEgMjUuMzk2MUwxNC4yMzA3IDI2LjA4MkMxNC4wNCAyNi4xNTAyIDEzLjgyNzEgMjYuMDk2NiAxMy42OTEzIDI1Ljk0NjRDMTIuODg4NiAyNS4wNTc5IDEyLjI4MDMgMjQuMDA5NSAxMS45MTEgMjIuODY3M0MxMS44NDg3IDIyLjY3NDcgMTEuOTA4OCAyMi40NjM0IDEyLjA2MzEgMjIuMzMyNEwxMy42MTggMjEuMDEyM0MxNC4wMzkgMjAuNjU0OCAxNC4wOTA1IDIwLjAyMzcgMTMuNzMzIDE5LjYwMjdDMTMuNjk3OCAxOS41NjE0IDEzLjY1OTQgMTkuNTIyOSAxMy42MTggMTkuNDg3OEwxMi4wNjMxIDE4LjE2NzZDMTEuOTA4OCAxOC4wMzY2IDExLjg0ODcgMTcuODI1MyAxMS45MTEgMTcuNjMyN1pNMTIuOTcxNSAxNy42MjcxTDE0LjI2NTIgMTguNzI1NUMxNC4zNDggMTguNzk1OCAxNC40MjUgMTguODcyNyAxNC40OTUzIDE4Ljk1NTVDMTUuMjEwMiAxOS43OTc1IDE1LjEwNzIgMjEuMDU5NiAxNC4yNjUyIDIxLjc3NDZMMTIuOTcxNSAyMi44NzI5QzEzLjI2MzYgMjMuNjU1MSAxMy42ODUgMjQuMzgyMiAxNC4yMTY1IDI1LjAyNTFMMTUuODEyNSAyNC40NTQ0QzE1LjkxNDcgMjQuNDE3OSAxNi4wMTk4IDI0LjM4OTcgMTYuMTI2NyAyNC4zNzAyQzE3LjIxMzMgMjQuMTcyIDE4LjI1NDkgMjQuODkyMyAxOC40NTMxIDI1Ljk3OUwxOC43NTcgMjcuNjQ3NUMxOS4xNjQ5IDI3LjcxNTUgMTkuNTgwMyAyNy43NSAyMC4wMDAzIDI3Ljc1QzIwLjQyIDI3Ljc1IDIwLjgzNTEgMjcuNzE1NiAyMS4yNDI3IDI3LjY0NzZMMjEuNTQ3NSAyNS45Nzg5QzIxLjU2NyAyNS44NzIxIDIxLjU5NTEgMjUuNzY3IDIxLjYzMTcgMjUuNjY0N0MyMi4wMDM0IDI0LjYyNDYgMjMuMTQ3OSAyNC4wODI3IDI0LjE4ODIgMjQuNDU0NEwyNS43ODQgMjUuMDI1MUMyNi4zMTU1IDI0LjM4MjIgMjYuNzM2OSAyMy42NTUxIDI3LjAyOSAyMi44NzI5TDI1LjczNTMgMjEuNzc0NUMyNS42NTI1IDIxLjcwNDIgMjUuNTc1NiAyMS42MjczIDI1LjUwNTMgMjEuNTQ0NUMyNC43OTAzIDIwLjcwMjUgMjQuODkzMyAxOS40NDA0IDI1LjczNTMgMTguNzI1NEwyNy4wMjkgMTcuNjI3MUMyNi43MzY5IDE2Ljg0NDkgMjYuMzE1NSAxNi4xMTc4IDI1Ljc4NCAxNS40NzQ5TDI0LjE4ODEgMTYuMDQ1NkMyNC4wODU4IDE2LjA4MjEgMjMuOTgwNyAxNi4xMTAzIDIzLjg3MzkgMTYuMTI5OEMyMi43ODcyIDE2LjMyOCAyMS43NDU3IDE1LjYwNzcgMjEuNTQ3NSAxNC41MjEyTDIxLjI0MjcgMTIuODUyM0MyMC44MzUxIDEyLjc4NDQgMjAuNDIgMTIuNzUgMjAuMDAwMyAxMi43NUMxOS41ODAzIDEyLjc1IDE5LjE2NDkgMTIuNzg0NSAxOC43NTcgMTIuODUyNUwxOC40NTMgMTQuNTIxQzE4LjQzMzUgMTQuNjI3OSAxOC40MDU0IDE0LjczMyAxOC4zNjg4IDE0LjgzNTNDMTcuOTk3MSAxNS44NzU0IDE2Ljg1MjYgMTYuNDE3MyAxNS44MTI0IDE2LjA0NTZMMTQuMjE2NSAxNS40NzQ5QzEzLjY4NSAxNi4xMTc4IDEzLjI2MzYgMTYuODQ0OSAxMi45NzE1IDE3LjYyNzFaTTE3LjUwMDMgMjAuMjVDMTcuNTAwMyAxOC44NjkzIDE4LjYxOTYgMTcuNzUgMjAuMDAwMyAxNy43NUMyMS4zODEgMTcuNzUgMjIuNTAwMyAxOC44NjkzIDIyLjUwMDMgMjAuMjVDMjIuNTAwMyAyMS42MzA3IDIxLjM4MSAyMi43NSAyMC4wMDAzIDIyLjc1QzE4LjYxOTYgMjIuNzUgMTcuNTAwMyAyMS42MzA3IDE3LjUwMDMgMjAuMjVaTTE4LjUwMDMgMjAuMjVDMTguNTAwMyAyMS4wNzg0IDE5LjE3MTggMjEuNzUgMjAuMDAwMyAyMS43NUMyMC44Mjg3IDIxLjc1IDIxLjUwMDMgMjEuMDc4NCAyMS41MDAzIDIwLjI1QzIxLjUwMDMgMTkuNDIxNiAyMC44Mjg3IDE4Ljc1IDIwLjAwMDMgMTguNzVDMTkuMTcxOCAxOC43NSAxOC41MDAzIDE5LjQyMTYgMTguNTAwMyAyMC4yNVoiIGZpbGw9IndoaXRlIi8+IDwvc3ZnPg=='
            }))
          ];
        } catch (e) {
          console.error('Invalid JSON in cards trait:', e);
          cardsData = [
            ...Array.from({ length: 6 }, (_, i) => ({
              title: \`Product \${i + 1}\`,
              description: 'Description',
              image: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MCA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPHJlY3QgeT0iMC4yNSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iMjAiIGZpbGw9IiM0MTcwRkYiLz4gPHBhdGggZD0iTTExLjkxMSAxNy42MzI3QzEyLjI4MDMgMTYuNDkwNSAxMi44ODg2IDE1LjQ0MjEgMTMuNjkxMyAxNC41NTM2QzEzLjgyNzEgMTQuNDAzNCAxNC4wNCAxNC4zNDk4IDE0LjIzMDcgMTQuNDE4TDE2LjE0OSAxNS4xMDM5QzE2LjY2OSAxNS4yODk4IDE3LjI0MTMgMTUuMDE4OCAxNy40MjcyIDE0LjQ5ODhDMTcuNDQ1NCAxNC40NDc2IDE3LjQ1OTUgMTQuMzk1MSAxNy40NjkyIDE0LjM0MTdMMTcuODM0NyAxMi4zMzU3QzE3Ljg3MSAxMi4xMzYzIDE4LjAyNDIgMTEuOTc4NSAxOC4yMjI1IDExLjkzNjNDMTguODAyNyAxMS44MTI4IDE5LjM5NzYgMTEuNzUgMjAuMDAwMyAxMS43NUMyMC42MDI2IDExLjc1IDIxLjE5NzEgMTEuODEyNyAyMS43NzcgMTEuOTM2MUMyMS45NzUyIDExLjk3ODIgMjIuMTI4NCAxMi4xMzU5IDIyLjE2NDggMTIuMzM1M0wyMi41MzEzIDE0LjM0MTdDMjIuNjMwMyAxNC44ODUgMjMuMTUxMSAxNS4yNDUxIDIzLjY5NDQgMTUuMTQ2QzIzLjc0NzkgMTUuMTM2MyAyMy44MDA0IDE1LjEyMjIgMjMuODUxNSAxNS4xMDRMMjUuNzY5OCAxNC40MThDMjUuOTYwNSAxNC4zNDk4IDI2LjE3MzUgMTQuNDAzNCAyNi4zMDkyIDE0LjU1MzZDMjcuMTExOSAxNS40NDIxIDI3LjcyMDIgMTYuNDkwNSAyOC4wODk1IDE3LjYzMjdDMjguMTUxOCAxNy44MjUzIDI4LjA5MTggMTguMDM2NiAyNy45Mzc0IDE4LjE2NzZMMjYuMzgyNiAxOS40ODc3QzI1Ljk2MTYgMTkuODQ1MiAyNS45MTAxIDIwLjQ3NjMgMjYuMjY3NSAyMC44OTczQzI2LjMwMjcgMjAuOTM4NyAyNi4zNDEyIDIwLjk3NzEgMjYuMzgyNSAyMS4wMTIzTDI3LjkzNzQgMjIuMzMyNEMyOC4wOTE4IDIyLjQ2MzQgMjguMTUxOCAyMi42NzQ3IDI4LjA4OTUgMjIuODY3M0MyNy43MjAyIDI0LjAwOTUgMjcuMTExOSAyNS4wNTc5IDI2LjMwOTIgMjUuOTQ2NEMyNi4xNzM1IDI2LjA5NjYgMjUuOTYwNSAyNi4xNTAyIDI1Ljc2OTggMjYuMDgyTDIzLjg1MTYgMjUuMzk2MUMyMy4zMzE1IDI1LjIxMDIgMjIuNzU5MiAyNS40ODEyIDIyLjU3MzQgMjYuMDAxMkMyMi41NTUxIDI2LjA1MjQgMjIuNTQxIDI2LjEwNDkgMjIuNTMxMiAyNi4xNTg1TDIyLjE2NDggMjguMTY0N0MyMi4xMjg0IDI4LjM2NDEgMjEuOTc1MiAyOC41MjE4IDIxLjc3NyAyOC41NjM5QzIxLjE5NzEgMjguNjg3MyAyMC42MDI2IDI4Ljc1IDIwLjAwMDMgMjguNzVDMTkuMzk3NiAyOC43NSAxOC44MDI3IDI4LjY4NzIgMTguMjIyNSAyOC41NjM3QzE4LjAyNDIgMjguNTIxNSAxNy44NzEgMjguMzYzNyAxNy44MzQ3IDI4LjE2NDNMMTcuNDY5MyAyNi4xNTg0QzE3LjM3MDIgMjUuNjE1IDE2Ljg0OTQgMjUuMjU0OSAxNi4zMDYxIDI1LjM1NEMxNi4yNTI2IDI1LjM2MzcgMTYuMjAwMSAyNS4zNzc4IDE2LjE0OTEgMjUuMzk2MUwxNC4yMzA3IDI2LjA4MkMxNC4wNCAyNi4xNTAyIDEzLjgyNzEgMjYuMDk2NiAxMy42OTEzIDI1Ljk0NjRDMTIuODg4NiAyNS4wNTc5IDEyLjI4MDMgMjQuMDA5NSAxMS45MTEgMjIuODY3M0MxMS44NDg3IDIyLjY3NDcgMTEuOTA4OCAyMi40NjM0IDEyLjA2MzEgMjIuMzMyNEwxMy42MTggMjEuMDEyM0MxNC4wMzkgMjAuNjU0OCAxNC4wOTA1IDIwLjAyMzcgMTMuNzMzIDE5LjYwMjdDMTMuNjk3OCAxOS41NjE0IDEzLjY1OTQgMTkuNTIyOSAxMy42MTggMTkuNDg3OEwxMi4wNjMxIDE4LjE2NzZDMTEuOTA4OCAxOC4wMzY2IDExLjg0ODcgMTcuODI1MyAxMS45MTEgMTcuNjMyN1pNMTIuOTcxNSAxNy42MjcxTDE0LjI2NTIgMTguNzI1NUMxNC4zNDggMTguNzk1OCAxNC40MjUgMTguODcyNyAxNC40OTUzIDE4Ljk1NTVDMTUuMjEwMiAxOS43OTc1IDE1LjEwNzIgMjEuMDU5NiAxNC4yNjUyIDIxLjc3NDZMMTIuOTcxNSAyMi44NzI5QzEzLjI2MzYgMjMuNjU1MSAxMy42ODUgMjQuMzgyMiAxNC4yMTY1IDI1LjAyNTFMMTUuODEyNSAyNC40NTQ0QzE1LjkxNDcgMjQuNDE3OSAxNi4wMTk4IDI0LjM4OTcgMTYuMTI2NyAyNC4zNzAyQzE3LjIxMzMgMjQuMTcyIDE4LjI1NDkgMjQuODkyMyAxOC40NTMxIDI1Ljk3OUwxOC43NTcgMjcuNjQ3NUMxOS4xNjQ5IDI3LjcxNTUgMTkuNTgwMyAyNy43NSAyMC4wMDAzIDI3Ljc1QzIwLjQyIDI3Ljc1IDIwLjgzNTEgMjcuNzE1NiAyMS4yNDI3IDI3LjY0NzZMMjEuNTQ3NSAyNS45Nzg5QzIxLjU2NyAyNS44NzIxIDIxLjU5NTEgMjUuNzY3IDIxLjYzMTcgMjUuNjY0N0MyMi4wMDM0IDI0LjYyNDYgMjMuMTQ3OSAyNC4wODI3IDI0LjE4ODIgMjQuNDU0NEwyNS43ODQgMjUuMDI1MUMyNi4zMTU1IDI0LjM4MjIgMjYuNzM2OSAyMy42NTUxIDI3LjAyOSAyMi44NzI5TDI1LjczNTMgMjEuNzc0NUMyNS42NTI1IDIxLjcwNDIgMjUuNTc1NiAyMS42MjczIDI1LjUwNTMgMjEuNTQ0NUMyNC43OTAzIDIwLjcwMjUgMjQuODkzMyAxOS40NDA0IDI1LjczNTMgMTguNzI1NEwyNy4wMjkgMTcuNjI3MUMyNi43MzY5IDE2Ljg0NDkgMjYuMzE1NSAxNi4xMTc4IDI1Ljc4NCAxNS40NzQ5TDI0LjE4ODEgMTYuMDQ1NkMyNC4wODU4IDE2LjA4MjEgMjMuOTgwNyAxNi4xMTAzIDIzLjg3MzkgMTYuMTI5OEMyMi43ODcyIDE2LjMyOCAyMS43NDU3IDE1LjYwNzcgMjEuNTQ3NSAxNC41MjEyTDIxLjI0MjcgMTIuODUyM0MyMC44MzUxIDEyLjc4NDQgMjAuNDIgMTIuNzUgMjAuMDAwMyAxMi43NUMxOS41ODAzIDEyLjc1IDE5LjE2NDkgMTIuNzg0NSAxOC43NTcgMTIuODUyNUwxOC40NTMgMTQuNTIxQzE4LjQzMzUgMTQuNjI3OSAxOC40MDU0IDE0LjczMyAxOC4zNjg4IDE0LjgzNTNDMTcuOTk3MSAxNS44NzU0IDE2Ljg1MjYgMTYuNDE3MyAxNS44MTI0IDE2LjA0NTZMMTQuMjE2NSAxNS40NzQ5QzEzLjY4NSAxNi4xMTc4IDEzLjI2MzYgMTYuODQ0OSAxMi45NzE1IDE3LjYyNzFaTTE3LjUwMDMgMjAuMjVDMTcuNTAwMyAxOC44NjkzIDE4LjYxOTYgMTcuNzUgMjAuMDAwMyAxNy43NUMyMS4zODEgMTcuNzUgMjIuNTAwMyAxOC44NjkzIDIyLjUwMDMgMjAuMjVDMjIuNTAwMyAyMS42MzA3IDIxLjM4MSAyMi43NSAyMC4wMDAzIDIyLjc1QzE4LjYxOTYgMjIuNzUgMTcuNTAwMyAyMS42MzA3IDE3LjUwMDMgMjAuMjVaTTE4LjUwMDMgMjAuMjVDMTguNTAwMyAyMS4wNzg0IDE5LjE3MTggMjEuNzUgMjAuMDAwMyAyMS43NUMyMC44Mjg3IDIxLjc1IDIxLjUwMDMgMjEuMDc4NCAyMS41MDAzIDIwLjI1QzIxLjUwMDMgMTkuNDIxNiAyMC44Mjg3IDE4Ljc1IDIwLjAwMDMgMTguNzVDMTkuMTcxOCAxOC43NSAxOC41MDAzIDE5LjQyMTYgMTguNTAwMyAyMC4yNVoiIGZpbGw9IndoaXRlIi8+IDwvc3ZnPg=='
            }))
          ];
        }

        // Проверяем текущее содержимое DOM
        const existingCards = Array.from(wrapper.querySelectorAll('.panel-card')).map(cardEl => {
          const imgEl = cardEl.querySelector('img');
          const h3El = cardEl.querySelector('h3');
          const pEl = cardEl.querySelector('p');
          return {
            image: imgEl?.src || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MCA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPHJlY3QgeT0iMC4yNSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iMjAiIGZpbGw9IiM0MTcwRkYiLz4gPHBhdGggZD0iTTExLjkxMSAxNy42MzI3QzEyLjI4MDMgMTYuNDkwNSAxMi44ODg2IDE1LjQ0MjEgMTMuNjkxMyAxNC41NTM2QzEzLjgyNzEgMTQuNDAzNCAxNC4wNCAxNC4zNDk4IDE0LjIzMDcgMTQuNDE4TDE2LjE0OSAxNS4xMDM5QzE2LjY2OSAxNS4yODk4IDE3LjI0MTMgMTUuMDE4OCAxNy40MjcyIDE0LjQ5ODhDMTcuNDQ1NCAxNC40NDc2IDE3LjQ1OTUgMTQuMzk1MSAxNy40NjkyIDE0LjM0MTdMMTcuODM0NyAxMi4zMzU3QzE3Ljg3MSAxMi4xMzYzIDE4LjAyNDIgMTEuOTc4NSAxOC4yMjI1IDExLjkzNjNDMTguODAyNyAxMS44MTI4IDE5LjM5NzYgMTEuNzUgMjAuMDAwMyAxMS43NUMyMC42MDI2IDExLjc1IDIxLjE5NzEgMTEuODEyNyAyMS43NzcgMTEuOTM2MUMyMS45NzUyIDExLjk3ODIgMjIuMTI4NCAxMi4xMzU5IDIyLjE2NDggMTIuMzM1M0wyMi41MzEzIDE0LjM0MTdDMjIuNjMwMyAxNC44ODUgMjMuMTUxMSAxNS4yNDUxIDIzLjY5NDQgMTUuMTQ2QzIzLjc0NzkgMTUuMTM2MyAyMy44MDA0IDE1LjEyMjIgMjMuODUxNSAxNS4xMDRMMjUuNzY5OCAxNC40MThDMjUuOTYwNSAxNC4zNDk4IDI2LjE3MzUgMTQuNDAzNCAyNi4zMDkyIDE0LjU1MzZDMjcuMTExOSAxNS40NDIxIDI3LjcyMDIgMTYuNDkwNSAyOC4wODk1IDE3LjYzMjdDMjguMTUxOCAxNy44MjUzIDI4LjA5MTggMTguMDM2NiAyNy45Mzc0IDE4LjE2NzZMMjYuMzgyNiAxOS40ODc3QzI1Ljk2MTYgMTkuODQ1MiAyNS45MTAxIDIwLjQ3NjMgMjYuMjY3NSAyMC44OTczQzI2LjMwMjcgMjAuOTM4NyAyNi4zNDEyIDIwLjk3NzEgMjYuMzgyNSAyMS4wMTIzTDI3LjkzNzQgMjIuMzMyNEMyOC4wOTE4IDIyLjQ2MzQgMjguMTUxOCAyMi42NzQ3IDI4LjA4OTUgMjIuODY3M0MyNy43MjAyIDI0LjAwOTUgMjcuMTExOSAyNS4wNTc5IDI2LjMwOTIgMjUuOTQ2NEMyNi4xNzM1IDI2LjA5NjYgMjUuOTYwNSAyNi4xNTAyIDI1Ljc2OTggMjYuMDgyTDIzLjg1MTYgMjUuMzk2MUMyMy4zMzE1IDI1LjIxMDIgMjIuNzU5MiAyNS40ODEyIDIyLjU3MzQgMjYuMDAxMkMyMi41NTUxIDI2LjA1MjQgMjIuNTQxIDI2LjEwNDkgMjIuNTMxMiAyNi4xNTg1TDIyLjE2NDggMjguMTY0N0MyMi4xMjg0IDI4LjM2NDEgMjEuOTc1MiAyOC41MjE4IDIxLjc3NyAyOC41NjM5QzIxLjE5NzEgMjguNjg3MyAyMC42MDI2IDI4Ljc1IDIwLjAwMDMgMjguNzVDMTkuMzk3NiAyOC43NSAxOC44MDI3IDI4LjY4NzIgMTguMjIyNSAyOC41NjM3QzE4LjAyNDIgMjguNTIxNSAxNy44NzEgMjguMzYzNyAxNy44MzQ3IDI4LjE2NDNMMTcuNDY5MyAyNi4xNTg0QzE3LjM3MDIgMjUuNjE1IDE2Ljg0OTQgMjUuMjU0OSAxNi4zMDYxIDI1LjM1NEMxNi4yNTI2IDI1LjM2MzcgMTYuMjAwMSAyNS4zNzc4IDE2LjE0OTEgMjUuMzk2MUwxNC4yMzA3IDI2LjA4MkMxNC4wNCAyNi4xNTAyIDEzLjgyNzEgMjYuMDk2NiAxMy42OTEzIDI1Ljk0NjRDMTIuODg4NiAyNS4wNTc5IDEyLjI4MDMgMjQuMDA5NSAxMS45MTEgMjIuODY3M0MxMS44NDg3IDIyLjY3NDcgMTEuOTA4OCAyMi40NjM0IDEyLjA2MzEgMjIuMzMyNEwxMy42MTggMjEuMDEyM0MxNC4wMzkgMjAuNjU0OCAxNC4wOTA1IDIwLjAyMzcgMTMuNzMzIDE5LjYwMjdDMTMuNjk3OCAxOS41NjE0IDEzLjY1OTQgMTkuNTIyOSAxMy42MTggMTkuNDg3OEwxMi4wNjMxIDE4LjE2NzZDMTEuOTA4OCAxOC4wMzY2IDExLjg0ODcgMTcuODI1MyAxMS45MTEgMTcuNjMyN1pNMTIuOTcxNSAxNy42MjcxTDE0LjI2NTIgMTguNzI1NUMxNC4zNDggMTguNzk1OCAxNC40MjUgMTguODcyNyAxNC40OTUzIDE4Ljk1NTVDMTUuMjEwMiAxOS43OTc1IDE1LjEwNzIgMjEuMDU5NiAxNC4yNjUyIDIxLjc3NDZMMTIuOTcxNSAyMi44NzI5QzEzLjI2MzYgMjMuNjU1MSAxMy42ODUgMjQuMzgyMiAxNC4yMTY1IDI1LjAyNTFMMTUuODEyNSAyNC40NTQ0QzE1LjkxNDcgMjQuNDE3OSAxNi4wMTk4IDI0LjM4OTcgMTYuMTI2NyAyNC4zNzAyQzE3LjIxMzMgMjQuMTcyIDE4LjI1NDkgMjQuODkyMyAxOC40NTMxIDI1Ljk3OUwxOC43NTcgMjcuNjQ3NUMxOS4xNjQ5IDI3LjcxNTUgMTkuNTgwMyAyNy43NSAyMC4wMDAzIDI3Ljc1QzIwLjQyIDI3Ljc1IDIwLjgzNTEgMjcuNzE1NiAyMS4yNDI3IDI3LjY0NzZMMjEuNTQ3NSAyNS45Nzg5QzIxLjU2NyAyNS44NzIxIDIxLjU5NTEgMjUuNzY3IDIxLjYzMTcgMjUuNjY0N0MyMi4wMDM0IDI0LjYyNDYgMjMuMTQ3OSAyNC4wODI3IDI0LjE4ODIgMjQuNDU0NEwyNS43ODQgMjUuMDI1MUMyNi4zMTU1IDI0LjM4MjIgMjYuNzM2OSAyMy42NTUxIDI3LjAyOSAyMi44NzI5TDI1LjczNTMgMjEuNzc0NUMyNS42NTI1IDIxLjcwNDIgMjUuNTc1NiAyMS42MjczIDI1LjUwNTMgMjEuNTQ0NUMyNC43OTAzIDIwLjcwMjUgMjQuODkzMyAxOS40NDA0IDI1LjczNTMgMTguNzI1NEwyNy4wMjkgMTcuNjI3MUMyNi43MzY5IDE2Ljg0NDkgMjYuMzE1NSAxNi4xMTc4IDI1Ljc4NCAxNS40NzQ5TDI0LjE4ODEgMTYuMDQ1NkMyNC4wODU4IDE2LjA4MjEgMjMuOTgwNyAxNi4xMTAzIDIzLjg3MzkgMTYuMTI5OEMyMi43ODcyIDE2LjMyOCAyMS43NDU3IDE1LjYwNzcgMjEuNTQ3NSAxNC41MjEyTDIxLjI0MjcgMTIuODUyM0MyMC44MzUxIDEyLjc4NDQgMjAuNDIgMTIuNzUgMjAuMDAwMyAxMi43NUMxOS41ODAzIDEyLjc1IDE5LjE2NDkgMTIuNzg0NSAxOC43NTcgMTIuODUyNUwxOC40NTMgMTQuNTIxQzE4LjQzMzUgMTQuNjI3OSAxOC40MDU0IDE0LjczMyAxOC4zNjg4IDE0LjgzNTNDMTcuOTk3MSAxNS44NzU0IDE2Ljg1MjYgMTYuNDE3MyAxNS44MTI0IDE2LjA0NTZMMTQuMjE2NSAxNS40NzQ5QzEzLjY4NSAxNi4xMTc4IDEzLjI2MzYgMTYuODQ0OSAxMi45NzE1IDE3LjYyNzFaTTE3LjUwMDMgMjAuMjVDMTcuNTAwMyAxOC44NjkzIDE4LjYxOTYgMTcuNzUgMjAuMDAwMyAxNy43NUMyMS4zODEgMTcuNzUgMjIuNTAwMyAxOC44NjkzIDIyLjUwMDMgMjAuMjVDMjIuNTAwMyAyMS42MzA3IDIxLjM4MSAyMi43NSAyMC4wMDAzIDIyLjc1QzE4LjYxOTYgMjIuNzUgMTcuNTAwMyAyMS42MzA3IDE3LjUwMDMgMjAuMjVaTTE4LjUwMDMgMjAuMjVDMTguNTAwMyAyMS4wNzg0IDE5LjE3MTggMjEuNzUgMjAuMDAwMyAyMS43NUMyMC44Mjg3IDIxLjc1IDIxLjUwMDMgMjEuMDc4NCAyMS41MDAzIDIwLjI1QzIxLjUwMDMgMTkuNDIxNiAyMC44Mjg3IDE4Ljc1IDIwLjAwMDMgMTguNzVDMTkuMTcxOCAxOC43NSAxOC41MDAzIDE5LjQyMTYgMTguNTAwMyAyMC4yNVoiIGZpbGw9IndoaXRlIi8+IDwvc3ZnPg==',
            title: h3El?.textContent || '',
            description: pEl?.textContent || ''
          };
        });

        // Обновляем только если данные изменились
        if (JSON.stringify(existingCards) !== JSON.stringify(cardsData)) {
          console.log('Cards data changed, updating DOM');
          contentEl.innerHTML = '';
          model.find('.panel-content')[0].components().reset();

          cardsData.forEach((card, index) => {
            model.find('.panel-content')[0].append({
              type: 'panel-card',
              attributes: { class: 'panel-card', 'data-card-index': index },
              components: [
                {
                  tagName: 'img',
                  attributes: {
                    src: card.image || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MCA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPHJlY3QgeT0iMC4yNSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iMjAiIGZpbGw9IiM0MTcwRkYiLz4gPHBhdGggZD0iTTExLjkxMSAxNy42MzI3QzEyLjI4MDMgMTYuNDkwNSAxMi44ODg2IDE1LjQ0MjEgMTMuNjkxMyAxNC41NTM2QzEzLjgyNzEgMTQuNDAzNCAxNC4wNCAxNC4zNDk4IDE0LjIzMDcgMTQuNDE4TDE2LjE0OSAxNS4xMDM5QzE2LjY2OSAxNS4yODk4IDE3LjI0MTMgMTUuMDE4OCAxNy40MjcyIDE0LjQ5ODhDMTcuNDQ1NCAxNC40NDc2IDE3LjQ1OTUgMTQuMzk1MSAxNy40NjkyIDE0LjM0MTdMMTcuODM0NyAxMi4zMzU3QzE3Ljg3MSAxMi4xMzYzIDE4LjAyNDIgMTEuOTc4NSAxOC4yMjI1IDExLjkzNjNDMTguODAyNyAxMS44MTI4IDE5LjM5NzYgMTEuNzUgMjAuMDAwMyAxMS43NUMyMC42MDI2IDExLjc1IDIxLjE5NzEgMTEuODEyNyAyMS43NzcgMTEuOTM2MUMyMS45NzUyIDExLjk3ODIgMjIuMTI4NCAxMi4xMzU5IDIyLjE2NDggMTIuMzM1M0wyMi41MzEzIDE0LjM0MTdDMjIuNjMwMyAxNC44ODUgMjMuMTUxMSAxNS4yNDUxIDIzLjY5NDQgMTUuMTQ2QzIzLjc0NzkgMTUuMTM2MyAyMy44MDA0IDE1LjEyMjIgMjMuODUxNSAxNS4xMDRMMjUuNzY5OCAxNC40MThDMjUuOTYwNSAxNC4zNDk4IDI2LjE3MzUgMTQuNDAzNCAyNi4zMDkyIDE0LjU1MzZDMjcuMTExOSAxNS40NDIxIDI3LjcyMDIgMTYuNDkwNSAyOC4wODk1IDE3LjYzMjdDMjguMTUxOCAxNy44MjUzIDI4LjA5MTggMTguMDM2NiAyNy45Mzc0IDE4LjE2NzZMMjYuMzgyNiAxOS40ODc3QzI1Ljk2MTYgMTkuODQ1MiAyNS45MTAxIDIwLjQ3NjMgMjYuMjY3NSAyMC44OTczQzI2LjMwMjcgMjAuOTM4NyAyNi4zNDEyIDIwLjk3NzEgMjYuMzgyNSAyMS4wMTIzTDI3LjkzNzQgMjIuMzMyNEMyOC4wOTE4IDIyLjQ2MzQgMjguMTUxOCAyMi42NzQ3IDI4LjA4OTUgMjIuODY3M0MyNy43MjAyIDI0LjAwOTUgMjcuMTExOSAyNS4wNTc5IDI2LjMwOTIgMjUuOTQ2NEMyNi4xNzM1IDI2LjA5NjYgMjUuOTYwNSAyNi4xNTAyIDI1Ljc2OTggMjYuMDgyTDIzLjg1MTYgMjUuMzk2MUMyMy4zMzE1IDI1LjIxMDIgMjIuNzU5MiAyNS40ODEyIDIyLjU3MzQgMjYuMDAxMkMyMi41NTUxIDI2LjA1MjQgMjIuNTQxIDI2LjEwNDkgMjIuNTMxMiAyNi4xNTg1TDIyLjE2NDggMjguMTY0N0MyMi4xMjg0IDI4LjM2NDEgMjEuOTc1MiAyOC41MjE4IDIxLjc3NyAyOC41NjM5QzIxLjE5NzEgMjguNjg3MyAyMC42MDI2IDI4Ljc1IDIwLjAwMDMgMjguNzVDMTkuMzk3NiAyOC43NSAxOC44MDI3IDI4LjY4NzIgMTguMjIyNSAyOC41NjM3QzE4LjAyNDIgMjguNTIxNSAxNy44NzEgMjguMzYzNyAxNy44MzQ3IDI4LjE2NDNMMTcuNDY5MyAyNi4xNTg0QzE3LjM3MDIgMjUuNjE1IDE2Ljg0OTQgMjUuMjU0OSAxNi4zMDYxIDI1LjM1NEMxNi4yNTI2IDI1LjM2MzcgMTYuMjAwMSAyNS4zNzc4IDE2LjE0OTEgMjUuMzk2MUwxNC4yMzA3IDI2LjA4MkMxNC4wNCAyNi4xNTAyIDEzLjgyNzEgMjYuMDk2NiAxMy42OTEzIDI1Ljk0NjRDMTIuODg4NiAyNS4wNTc5IDEyLjI4MDMgMjQuMDA5NSAxMS45MTEgMjIuODY3M0MxMS44NDg3IDIyLjY3NDcgMTEuOTA4OCAyMi40NjM0IDEyLjA2MzEgMjIuMzMyNEwxMy42MTggMjEuMDEyM0MxNC4wMzkgMjAuNjU0OCAxNC4wOTA1IDIwLjAyMzcgMTMuNzMzIDE5LjYwMjdDMTMuNjk3OCAxOS41NjE0IDEzLjY1OTQgMTkuNTIyOSAxMy42MTggMTkuNDg3OEwxMi4wNjMxIDE4LjE2NzZDMTEuOTA4OCAxOC4wMzY2IDExLjg0ODcgMTcuODI1MyAxMS45MTEgMTcuNjMyN1pNMTIuOTcxNSAxNy42MjcxTDE0LjI2NTIgMTguNzI1NUMxNC4zNDggMTguNzk1OCAxNC40MjUgMTguODcyNyAxNC40OTUzIDE4Ljk1NTVDMTUuMjEwMiAxOS43OTc1IDE1LjEwNzIgMjEuMDU5NiAxNC4yNjUyIDIxLjc3NDZMMTIuOTcxNSAyMi44NzI5QzEzLjI2MzYgMjMuNjU1MSAxMy42ODUgMjQuMzgyMiAxNC4yMTY1IDI1LjAyNTFMMTUuODEyNSAyNC40NTQ0QzE1LjkxNDcgMjQuNDE3OSAxNi4wMTk4IDI0LjM4OTcgMTYuMTI2NyAyNC4zNzAyQzE3LjIxMzMgMjQuMTcyIDE4LjI1NDkgMjQuODkyMyAxOC40NTMxIDI1Ljk3OUwxOC43NTcgMjcuNjQ3NUMxOS4xNjQ5IDI3LjcxNTUgMTkuNTgwMyAyNy43NSAyMC4wMDAzIDI3Ljc1QzIwLjQyIDI3Ljc1IDIwLjgzNTEgMjcuNzE1NiAyMS4yNDI3IDI3LjY0NzZMMjEuNTQ3NSAyNS45Nzg5QzIxLjU2NyAyNS44NzIxIDIxLjU5NTEgMjUuNzY3IDIxLjYzMTcgMjUuNjY0N0MyMi4wMDM0IDI0LjYyNDYgMjMuMTQ3OSAyNC4wODI3IDI0LjE4ODIgMjQuNDU0NEwyNS43ODQgMjUuMDI1MUMyNi4zMTU1IDI0LjM4MjIgMjYuNzM2OSAyMy42NTUxIDI3LjAyOSAyMi44NzI5TDI1LjczNTMgMjEuNzc0NUMyNS42NTI1IDIxLjcwNDIgMjUuNTc1NiAyMS42MjczIDI1LjUwNTMgMjEuNTQ0NUMyNC43OTAzIDIwLjcwMjUgMjQuODkzMyAxOS40NDA0IDI1LjczNTMgMTguNzI1NEwyNy4wMjkgMTcuNjI3MUMyNi43MzY5IDE2Ljg0NDkgMjYuMzE1NSAxNi4xMTc4IDI1Ljc4NCAxNS40NzQ5TDI0LjE4ODEgMTYuMDQ1NkMyNC4wODU4IDE2LjA4MjEgMjMuOTgwNyAxNi4xMTAzIDIzLjg3MzkgMTYuMTI5OEMyMi43ODcyIDE2LjMyOCAyMS43NDU3IDE1LjYwNzcgMjEuNTQ3NSAxNC41MjEyTDIxLjI0MjcgMTIuODUyM0MyMC44MzUxIDEyLjc4NDQgMjAuNDIgMTIuNzUgMjAuMDAwMyAxMi43NUMxOS41ODAzIDEyLjc1IDE5LjE2NDkgMTIuNzg0NSAxOC43NTcgMTIuODUyNUwxOC40NTMgMTQuNTIxQzE4LjQzMzUgMTQuNjI3OSAxOC40MDU0IDE0LjczMyAxOC4zNjg4IDE0LjgzNTNDMTcuOTk3MSAxNS44NzU0IDE2Ljg1MjYgMTYuNDE3MyAxNS44MTI0IDE2LjA0NTZMMTQuMjE2NSAxNS40NzQ5QzEzLjY4NSAxNi4xMTc4IDEzLjI2MzYgMTYuODQ0OSAxMi45NzE1IDE3LjYyNzFaTTE3LjUwMDMgMjAuMjVDMTcuNTAwMyAxOC44NjkzIDE4LjYxOTYgMTcuNzUgMjAuMDAwMyAxNy43NUMyMS4zODEgMTcuNzUgMjIuNTAwMyAxOC44NjkzIDIyLjUwMDMgMjAuMjVDMjIuNTAwMyAyMS42MzA3IDIxLjM4MSAyMi43NSAyMC4wMDAzIDIyLjc1QzE4LjYxOTYgMjIuNzUgMTcuNTAwMyAyMS42MzA3IDE3LjUwMDMgMjAuMjVaTTE4LjUwMDMgMjAuMjVDMTguNTAwMyAyMS4wNzg0IDE5LjE3MTggMjEuNzUgMjAuMDAwMyAyMS43NUMyMC44Mjg3IDIxLjc1IDIxLjUwMDMgMjEuMDc4NCAyMS41MDAzIDIwLjI1QzIxLjUwMDMgMTkuNDIxNiAyMC44Mjg3IDE4Ljc1IDIwLjAwMDMgMTguNzVDMTkuMTcxOCAxOC43NSAxOC41MDAzIDE5LjQyMTYgMTguNTAwMyAyMC4yNVoiIGZpbGw9IndoaXRlIi8+IDwvc3ZnPg==',
                    alt: card.title || \`Product \${index + 1}\`
                  },
                  droppable: true,
                  draggable: false
                },
                {
                  tagName: 'h3',
                  content: card.title || \`Product \${index + 1}\`,
                  droppable: true,
                  draggable: false
                },
                {
                  tagName: 'p',
                  content: card.description || 'Description',
                  droppable: true,
                  draggable: false
                }
              ],
              droppable: true,
              draggable: false
            });
          });
        } else {
          console.log('No changes in cards data, skipping DOM update');
        }

        console.log('Panel updated:', { cardsData, columns, scrollable, page, header, pageType });
      } catch (e) {
        console.error('Error updating panel:', e);
      }
    }

    // Регистрируем обработчики событий один раз
    editor.Commands.add('add-panel-card', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component || component.get('type') !== 'panel') {
          editor.Modal.open({ title: 'Ошибка', content: 'Выберите компонент Panel.' });
          return;
        }
        const cardsTrait = component.getTrait('cards');
        let cardsData = [];
        try {
          cardsData = JSON.parse(cardsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing cards JSON:', e);
        }
        if (cardsData.length >= 20) {
          editor.Modal.open({ title: 'Ошибка', content: 'Максимум 20 карточек.' });
          return;
        }
        cardsData.push({
          title: \`Product \${cardsData.length + 1}\`,
          description: 'Description',
          image:'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MCA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPHJlY3QgeT0iMC4yNSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iMjAiIGZpbGw9IiM0MTcwRkYiLz4gPHBhdGggZD0iTTExLjkxMSAxNy42MzI3QzEyLjI4MDMgMTYuNDkwNSAxMi44ODg2IDE1LjQ0MjEgMTMuNjkxMyAxNC41NTM2QzEzLjgyNzEgMTQuNDAzNCAxNC4wNCAxNC4zNDk4IDE0LjIzMDcgMTQuNDE4TDE2LjE0OSAxNS4xMDM5QzE2LjY2OSAxNS4yODk4IDE3LjI0MTMgMTUuMDE4OCAxNy40MjcyIDE0LjQ5ODhDMTcuNDQ1NCAxNC40NDc2IDE3LjQ1OTUgMTQuMzk1MSAxNy40NjkyIDE0LjM0MTdMMTcuODM0NyAxMi4zMzU3QzE3Ljg3MSAxMi4xMzYzIDE4LjAyNDIgMTEuOTc4NSAxOC4yMjI1IDExLjkzNjNDMTguODAyNyAxMS44MTI4IDE5LjM5NzYgMTEuNzUgMjAuMDAwMyAxMS43NUMyMC42MDI2IDExLjc1IDIxLjE5NzEgMTEuODEyNyAyMS43NzcgMTEuOTM2MUMyMS45NzUyIDExLjk3ODIgMjIuMTI4NCAxMi4xMzU5IDIyLjE2NDggMTIuMzM1M0wyMi41MzEzIDE0LjM0MTdDMjIuNjMwMyAxNC44ODUgMjMuMTUxMSAxNS4yNDUxIDIzLjY5NDQgMTUuMTQ2QzIzLjc0NzkgMTUuMTM2MyAyMy44MDA0IDE1LjEyMjIgMjMuODUxNSAxNS4xMDRMMjUuNzY5OCAxNC40MThDMjUuOTYwNSAxNC4zNDk4IDI2LjE3MzUgMTQuNDAzNCAyNi4zMDkyIDE0LjU1MzZDMjcuMTExOSAxNS40NDIxIDI3LjcyMDIgMTYuNDkwNSAyOC4wODk1IDE3LjYzMjdDMjguMTUxOCAxNy44MjUzIDI4LjA5MTggMTguMDM2NiAyNy45Mzc0IDE4LjE2NzZMMjYuMzgyNiAxOS40ODc3QzI1Ljk2MTYgMTkuODQ1MiAyNS45MTAxIDIwLjQ3NjMgMjYuMjY3NSAyMC44OTczQzI2LjMwMjcgMjAuOTM4NyAyNi4zNDEyIDIwLjk3NzEgMjYuMzgyNSAyMS4wMTIzTDI3LjkzNzQgMjIuMzMyNEMyOC4wOTE4IDIyLjQ2MzQgMjguMTUxOCAyMi42NzQ3IDI4LjA4OTUgMjIuODY3M0MyNy43MjAyIDI0LjAwOTUgMjcuMTExOSAyNS4wNTc5IDI2LjMwOTIgMjUuOTQ2NEMyNi4xNzM1IDI2LjA5NjYgMjUuOTYwNSAyNi4xNTAyIDI1Ljc2OTggMjYuMDgyTDIzLjg1MTYgMjUuMzk2MUMyMy4zMzE1IDI1LjIxMDIgMjIuNzU5MiAyNS40ODEyIDIyLjU3MzQgMjYuMDAxMkMyMi41NTUxIDI2LjA1MjQgMjIuNTQxIDI2LjEwNDkgMjIuNTMxMiAyNi4xNTg1TDIyLjE2NDggMjguMTY0N0MyMi4xMjg0IDI4LjM2NDEgMjEuOTc1MiAyOC41MjE4IDIxLjc3NyAyOC41NjM5QzIxLjE5NzEgMjguNjg3MyAyMC42MDI2IDI4Ljc1IDIwLjAwMDMgMjguNzVDMTkuMzk3NiAyOC43NSAxOC44MDI3IDI4LjY4NzIgMTguMjIyNSAyOC41NjM3QzE4LjAyNDIgMjguNTIxNSAxNy44NzEgMjguMzYzNyAxNy44MzQ3IDI4LjE2NDNMMTcuNDY5MyAyNi4xNTg0QzE3LjM3MDIgMjUuNjE1IDE2Ljg0OTQgMjUuMjU0OSAxNi4zMDYxIDI1LjM1NEMxNi4yNTI2IDI1LjM2MzcgMTYuMjAwMSAyNS4zNzc4IDE2LjE0OTEgMjUuMzk2MUwxNC4yMzA3IDI2LjA4MkMxNC4wNCAyNi4xNTAyIDEzLjgyNzEgMjYuMDk2NiAxMy42OTEzIDI1Ljk0NjRDMTIuODg4NiAyNS4wNTc5IDEyLjI4MDMgMjQuMDA5NSAxMS45MTEgMjIuODY3M0MxMS44NDg3IDIyLjY3NDcgMTEuOTA4OCAyMi40NjM0IDEyLjA2MzEgMjIuMzMyNEwxMy42MTggMjEuMDEyM0MxNC4wMzkgMjAuNjU0OCAxNC4wOTA1IDIwLjAyMzcgMTMuNzMzIDE5LjYwMjdDMTMuNjk3OCAxOS41NjE0IDEzLjY1OTQgMTkuNTIyOSAxMy42MTggMTkuNDg3OEwxMi4wNjMxIDE4LjE2NzZDMTEuOTA4OCAxOC4wMzY2IDExLjg0ODcgMTcuODI1MyAxMS45MTEgMTcuNjMyN1pNMTIuOTcxNSAxNy42MjcxTDE0LjI2NTIgMTguNzI1NUMxNC4zNDggMTguNzk1OCAxNC40MjUgMTguODcyNyAxNC40OTUzIDE4Ljk1NTVDMTUuMjEwMiAxOS43OTc1IDE1LjEwNzIgMjEuMDU5NiAxNC4yNjUyIDIxLjc3NDZMMTIuOTcxNSAyMi44NzI5QzEzLjI2MzYgMjMuNjU1MSAxMy42ODUgMjQuMzgyMiAxNC4yMTY1IDI1LjAyNTFMMTUuODEyNSAyNC40NTQ0QzE1LjkxNDcgMjQuNDE3OSAxNi4wMTk4IDI0LjM4OTcgMTYuMTI2NyAyNC4zNzAyQzE3LjIxMzMgMjQuMTcyIDE4LjI1NDkgMjQuODkyMyAxOC40NTMxIDI1Ljk3OUwxOC43NTcgMjcuNjQ3NUMxOS4xNjQ5IDI3LjcxNTUgMTkuNTgwMyAyNy43NSAyMC4wMDAzIDI3Ljc1QzIwLjQyIDI3Ljc1IDIwLjgzNTEgMjcuNzE1NiAyMS4yNDI3IDI3LjY0NzZMMjEuNTQ3NSAyNS45Nzg5QzIxLjU2NyAyNS44NzIxIDIxLjU5NTEgMjUuNzY3IDIxLjYzMTcgMjUuNjY0N0MyMi4wMDM0IDI0LjYyNDYgMjMuMTQ3OSAyNC4wODI3IDI0LjE4ODIgMjQuNDU0NEwyNS43ODQgMjUuMDI1MUMyNi4zMTU1IDI0LjM4MjIgMjYuNzM2OSAyMy42NTUxIDI3LjAyOSAyMi44NzI5TDI1LjczNTMgMjEuNzc0NUMyNS42NTI1IDIxLjcwNDIgMjUuNTc1NiAyMS42MjczIDI1LjUwNTMgMjEuNTQ0NUMyNC43OTAzIDIwLjcwMjUgMjQuODkzMyAxOS40NDA0IDI1LjczNTMgMTguNzI1NEwyNy4wMjkgMTcuNjI3MUMyNi43MzY5IDE2Ljg0NDkgMjYuMzE1NSAxNi4xMTc4IDI1Ljc4NCAxNS40NzQ5TDI0LjE4ODEgMTYuMDQ1NkMyNC4wODU4IDE2LjA4MjEgMjMuOTgwNyAxNi4xMTAzIDIzLjg3MzkgMTYuMTI5OEMyMi43ODcyIDE2LjMyOCAyMS43NDU3IDE1LjYwNzcgMjEuNTQ3NSAxNC41MjEyTDIxLjI0MjcgMTIuODUyM0MyMC44MzUxIDEyLjc4NDQgMjAuNDIgMTIuNzUgMjAuMDAwMyAxMi43NUMxOS41ODAzIDEyLjc1IDE5LjE2NDkgMTIuNzg0NSAxOC43NTcgMTIuODUyNUwxOC40NTMgMTQuNTIxQzE4LjQzMzUgMTQuNjI3OSAxOC40MDU0IDE0LjczMyAxOC4zNjg4IDE0LjgzNTNDMTcuOTk3MSAxNS44NzU0IDE2Ljg1MjYgMTYuNDE3MyAxNS44MTI0IDE2LjA0NTZMMTQuMjE2NSAxNS40NzQ5QzEzLjY4NSAxNi4xMTc4IDEzLjI2MzYgMTYuODQ0OSAxMi45NzE1IDE3LjYyNzFaTTE3LjUwMDMgMjAuMjVDMTcuNTAwMyAxOC44NjkzIDE4LjYxOTYgMTcuNzUgMjAuMDAwMyAxNy43NUMyMS4zODEgMTcuNzUgMjIuNTAwMyAxOC44NjkzIDIyLjUwMDMgMjAuMjVDMjIuNTAwMyAyMS42MzA3IDIxLjM4MSAyMi43NSAyMC4wMDAzIDIyLjc1QzE4LjYxOTYgMjIuNzUgMTcuNTAwMyAyMS42MzA3IDE3LjUwMDMgMjAuMjVaTTE4LjUwMDMgMjAuMjVDMTguNTAwMyAyMS4wNzg0IDE5LjE3MTggMjEuNzUgMjAuMDAwMyAyMS43NUMyMC44Mjg3IDIxLjc1IDIxLjUwMDMgMjEuMDc4NCAyMS41MDAzIDIwLjI1QzIxLjUwMDMgMTkuNDIxNiAyMC44Mjg3IDE4Ljc1IDIwLjAwMDMgMTguNzVDMTkuMTcxOCAxOC43NSAxOC41MDAzIDE5LjQyMTYgMTguNTAwMyAyMC4yNVoiIGZpbGw9IndoaXRlIi8+IDwvc3ZnPg=='
        });
        cardsTrait.setValue(JSON.stringify(cardsData));
        console.log('Card added:', cardsData);
        updatePanel(component, editor);
        editor.Modal.open({ title: 'Успех', content: 'Карточка успешно добавлена!' });
      }
    });

    editor.Commands.add('remove-last-panel-card', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component || component.get('type') !== 'panel') {
          editor.Modal.open({ title: 'Ошибка', content: 'Выберите компонент Panel.' });
          return;
        }
        const cardsTrait = component.getTrait('cards');
        let cardsData = [];
        try {
          cardsData = JSON.parse(cardsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing cards JSON:', e);
        }
        if (cardsData.length <= 1) {
          editor.Modal.open({ title: 'Ошибка', content: 'Должна остаться хотя бы одна карточка.' });
          return;
        }
        cardsData.pop();
        cardsTrait.setValue(JSON.stringify(cardsData));
        console.log('Last card removed:', cardsData);
        updatePanel(component, editor);
        editor.Modal.open({ title: 'Успех', content: 'Последняя карточка успешно удалена!' });
      }
    });

    // Регистрируем обработчики событий один раз при инициализации
    if (model && model.getEl()) {
      console.log('Initial updatePanel call');
      const cardsTrait = model.getTrait('cards');
      editor.off('component:add component:remove component:update');
      editor.on('component:add component:remove component:update', (component) => {
        if (component.closest('.panel-content')) {
          const wrapper = model.getEl();
          const updatedCards = [];
          wrapper.querySelectorAll('.panel-card').forEach((cardEl, i) => {
            const imgEl = cardEl.querySelector('img');
            const h3El = cardEl.querySelector('h3');
            const pEl = cardEl.querySelector('p');
            updatedCards.push({
              image: imgEl?.src || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MCA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPHJlY3QgeT0iMC4yNSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iMjAiIGZpbGw9IiM0MTcwRkYiLz4gPHBhdGggZD0iTTExLjkxMSAxNy42MzI3QzEyLjI4MDMgMTYuNDkwNSAxMi44ODg2IDE1LjQ0MjEgMTMuNjkxMyAxNC41NTM2QzEzLjgyNzEgMTQuNDAzNCAxNC4wNCAxNC4zNDk4IDE0LjIzMDcgMTQuNDE4TDE2LjE0OSAxNS4xMDM5QzE2LjY2OSAxNS4yODk4IDE3LjI0MTMgMTUuMDE4OCAxNy40MjcyIDE0LjQ5ODhDMTcuNDQ1NCAxNC40NDc2IDE3LjQ1OTUgMTQuMzk1MSAxNy40NjkyIDE0LjM0MTdMMTcuODM0NyAxMi4zMzU3QzE3Ljg3MSAxMi4xMzYzIDE4LjAyNDIgMTEuOTc4NSAxOC4yMjI1IDExLjkzNjNDMTguODAyNyAxMS44MTI4IDE5LjM5NzYgMTEuNzUgMjAuMDAwMyAxMS43NUMyMC42MDI2IDExLjc1IDIxLjE5NzEgMTEuODEyNyAyMS43NzcgMTEuOTM2MUMyMS45NzUyIDExLjk3ODIgMjIuMTI4NCAxMi4xMzU5IDIyLjE2NDggMTIuMzM1M0wyMi41MzEzIDE0LjM0MTdDMjIuNjMwMyAxNC44ODUgMjMuMTUxMSAxNS4yNDUxIDIzLjY5NDQgMTUuMTQ2QzIzLjc0NzkgMTUuMTM2MyAyMy44MDA0IDE1LjEyMjIgMjMuODUxNSAxNS4xMDRMMjUuNzY5OCAxNC40MThDMjUuOTYwNSAxNC4zNDk4IDI2LjE3MzUgMTQuNDAzNCAyNi4zMDkyIDE0LjU1MzZDMjcuMTExOSAxNS40NDIxIDI3LjcyMDIgMTYuNDkwNSAyOC4wODk1IDE3LjYzMjdDMjguMTUxOCAxNy44MjUzIDI4LjA5MTggMTguMDM2NiAyNy45Mzc0IDE4LjE2NzZMMjYuMzgyNiAxOS40ODc3QzI1Ljk2MTYgMTkuODQ1MiAyNS45MTAxIDIwLjQ3NjMgMjYuMjY3NSAyMC44OTczQzI2LjMwMjcgMjAuOTM4NyAyNi4zNDEyIDIwLjk3NzEgMjYuMzgyNSAyMS4wMTIzTDI3LjkzNzQgMjIuMzMyNEMyOC4wOTE4IDIyLjQ2MzQgMjguMTUxOCAyMi42NzQ3IDI4LjA4OTUgMjIuODY3M0MyNy43MjAyIDI0LjAwOTUgMjcuMTExOSAyNS4wNTc5IDI2LjMwOTIgMjUuOTQ2NEMyNi4xNzM1IDI2LjA5NjYgMjUuOTYwNSAyNi4xNTAyIDI1Ljc2OTggMjYuMDgyTDIzLjg1MTYgMjUuMzk2MUMyMy4zMzE1IDI1LjIxMDIgMjIuNzU5MiAyNS40ODEyIDIyLjU3MzQgMjYuMDAxMkMyMi41NTUxIDI2LjA1MjQgMjIuNTQxIDI2LjEwNDkgMjIuNTMxMiAyNi4xNTg1TDIyLjE2NDggMjguMTY0N0MyMi4xMjg0IDI4LjM2NDEgMjEuOTc1MiAyOC41MjE4IDIxLjc3NyAyOC41NjM5QzIxLjE5NzEgMjguNjg3MyAyMC42MDI2IDI4Ljc1IDIwLjAwMDMgMjguNzVDMTkuMzk3NiAyOC43NSAxOC44MDI3IDI4LjY4NzIgMTguMjIyNSAyOC41NjM3QzE4LjAyNDIgMjguNTIxNSAxNy44NzEgMjguMzYzNyAxNy44MzQ3IDI4LjE2NDNMMTcuNDY5MyAyNi4xNTg0QzE3LjM3MDIgMjUuNjE1IDE2Ljg0OTQgMjUuMjU0OSAxNi4zMDYxIDI1LjM1NEMxNi4yNTI2IDI1LjM2MzcgMTYuMjAwMSAyNS4zNzc4IDE2LjE0OTEgMjUuMzk2MUwxNC4yMzA3IDI2LjA4MkMxNC4wNCAyNi4xNTAyIDEzLjgyNzEgMjYuMDk2NiAxMy42OTEzIDI1Ljk0NjRDMTIuODg4NiAyNS4wNTc5IDEyLjI4MDMgMjQuMDA5NSAxMS45MTEgMjIuODY3M0MxMS44NDg3IDIyLjY3NDcgMTEuOTA4OCAyMi40NjM0IDEyLjA2MzEgMjIuMzMyNEwxMy42MTggMjEuMDEyM0MxNC4wMzkgMjAuNjU0OCAxNC4wOTA1IDIwLjAyMzcgMTMuNzMzIDE5LjYwMjdDMTMuNjk3OCAxOS41NjE0IDEzLjY1OTQgMTkuNTIyOSAxMy42MTggMTkuNDg3OEwxMi4wNjMxIDE4LjE2NzZDMTEuOTA4OCAxOC4wMzY2IDExLjg0ODcgMTcuODI1MyAxMS45MTEgMTcuNjMyN1pNMTIuOTcxNSAxNy42MjcxTDE0LjI2NTIgMTguNzI1NUMxNC4zNDggMTguNzk1OCAxNC40MjUgMTguODcyNyAxNC40OTUzIDE4Ljk1NTVDMTUuMjEwMiAxOS43OTc1IDE1LjEwNzIgMjEuMDU5NiAxNC4yNjUyIDIxLjc3NDZMMTIuOTcxNSAyMi44NzI5QzEzLjI2MzYgMjMuNjU1MSAxMy42ODUgMjQuMzgyMiAxNC4yMTY1IDI1LjAyNTFMMTUuODEyNSAyNC40NTQ0QzE1LjkxNDcgMjQuNDE3OSAxNi4wMTk4IDI0LjM4OTcgMTYuMTI2NyAyNC4zNzAyQzE3LjIxMzMgMjQuMTcyIDE4LjI1NDkgMjQuODkyMyAxOC40NTMxIDI1Ljk3OUwxOC43NTcgMjcuNjQ3NUMxOS4xNjQ5IDI3LjcxNTUgMTkuNTgwMyAyNy43NSAyMC4wMDAzIDI3Ljc1QzIwLjQyIDI3Ljc1IDIwLjgzNTEgMjcuNzE1NiAyMS4yNDI3IDI3LjY0NzZMMjEuNTQ3NSAyNS45Nzg5QzIxLjU2NyAyNS44NzIxIDIxLjU5NTEgMjUuNzY3IDIxLjYzMTcgMjUuNjY0N0MyMi4wMDM0IDI0LjYyNDYgMjMuMTQ3OSAyNC4wODI3IDI0LjE4ODIgMjQuNDU0NEwyNS43ODQgMjUuMDI1MUMyNi4zMTU1IDI0LjM4MjIgMjYuNzM2OSAyMy42NTUxIDI3LjAyOSAyMi44NzI5TDI1LjczNTMgMjEuNzc0NUMyNS42NTI1IDIxLjcwNDIgMjUuNTc1NiAyMS42MjczIDI1LjUwNTMgMjEuNTQ0NUMyNC43OTAzIDIwLjcwMjUgMjQuODkzMyAxOS40NDA0IDI1LjczNTMgMTguNzI1NEwyNy4wMjkgMTcuNjI3MUMyNi43MzY5IDE2Ljg0NDkgMjYuMzE1NSAxNi4xMTc4IDI1Ljc4NCAxNS40NzQ5TDI0LjE4ODEgMTYuMDQ1NkMyNC4wODU4IDE2LjA4MjEgMjMuOTgwNyAxNi4xMTAzIDIzLjg3MzkgMTYuMTI5OEMyMi43ODcyIDE2LjMyOCAyMS43NDU3IDE1LjYwNzcgMjEuNTQ3NSAxNC41MjEyTDIxLjI0MjcgMTIuODUyM0MyMC44MzUxIDEyLjc4NDQgMjAuNDIgMTIuNzUgMjAuMDAwMyAxMi43NUMxOS41ODAzIDEyLjc1IDE5LjE2NDkgMTIuNzg0NSAxOC43NTcgMTIuODUyNUwxOC40NTMgMTQuNTIxQzE4LjQzMzUgMTQuNjI3OSAxOC40MDU0IDE0LjczMyAxOC4zNjg4IDE0LjgzNTNDMTcuOTk3MSAxNS44NzU0IDE2Ljg1MjYgMTYuNDE3MyAxNS44MTI0IDE2LjA0NTZMMTQuMjE2NSAxNS40NzQ5QzEzLjY4NSAxNi4xMTc4IDEzLjI2MzYgMTYuODQ0OSAxMi45NzE1IDE3LjYyNzFaTTE3LjUwMDMgMjAuMjVDMTcuNTAwMyAxOC44NjkzIDE4LjYxOTYgMTcuNzUgMjAuMDAwMyAxNy43NUMyMS4zODEgMTcuNzUgMjIuNTAwMyAxOC44NjkzIDIyLjUwMDMgMjAuMjVDMjIuNTAwMyAyMS42MzA3IDIxLjM4MSAyMi43NSAyMC4wMDAzIDIyLjc1QzE4LjYxOTYgMjIuNzUgMTcuNTAwMyAyMS42MzA3IDE3LjUwMDMgMjAuMjVaTTE4LjUwMDMgMjAuMjVDMTguNTAwMyAyMS4wNzg0IDE5LjE3MTggMjEuNzUgMjAuMDAwMyAyMS43NUMyMC44Mjg3IDIxLjc1IDIxLjUwMDMgMjEuMDc4NCAyMS41MDAzIDIwLjI1QzIxLjUwMDMgMTkuNDIxNiAyMC44Mjg3IDE4Ljc1IDIwLjAwMDMgMTguNzVDMTkuMTcxOCAxOC43NSAxOC41MDAzIDE5LjQyMTYgMTguNTAwMyAyMC4yNVoiIGZpbGw9IndoaXRlIi8+IDwvc3ZnPg==',
              title: h3El?.textContent || \`Product \${i + 1}\`,
              description: pEl?.textContent || 'Description'
            });
          });
          cardsTrait.setValue(JSON.stringify(updatedCards));
          console.log('Cards data updated:', updatedCards);
          updatePanel(model, editor);
        }
      });

      editor.off('trait:change');
      editor.on('trait:change', (trait) => {
        if (trait.getName() === 'cards') {
          let cardsData = [];
          try {
            cardsData = JSON.parse(trait.getValue() || '[]');
            if (cardsData.length > 20) {
              cardsData = cardsData.slice(0, 20);
              editor.Modal.open({ title: 'Предупреждение', content: 'Максимум 20 карточек.' });
              trait.setValue(JSON.stringify(cardsData));
            }
          } catch (e) {
            console.error('Error parsing cards JSON:', e);
          }
        }
        updatePanel(model, editor);
        console.log('Trait updated:', trait.getName());
      });

      updatePanel(model, editor);
    }

    model.on('change', () => {
      console.log('Model changed:', model.changed);
      updatePanel(model, editor);
    });
  `
};
