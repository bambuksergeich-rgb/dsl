import { ComponentConfig } from '../elements';

export const PieChart: ComponentConfig = {
  id: 'pie-chart-json',
  type: 'pie-chart-json',
  label: 'Pie Chart',
  category: 'Charts',
  content: {
    tagName: 'div',
    attributes: {
      class: 'pie-charts-wrapper w-full h-auto', // Класс обертки
      'data-component-id': 'pie-chart-json',
      'data-chart-type': 'doughnut', // Лучше по дефолту doughnut для многослойности
      'data-title': 'Browser Market Share',
      'data-sub-title': '2024 vs 2025'
    },
    components: [
      {
        tagName: 'canvas',
        attributes: {
          class: 'pie-chart-canvas',
          'data-chart-element': 'true'
        }
      }
    ],
    droppable: false,
    editable: true,
    selectable: true,
    resizable: {
      cr: true,
      bc: true,
      minDim: 200,
      maxDim: 1200,
      updateTarget: (el, rect) => {
        const canvas = el.querySelector('canvas');
        if (canvas) {
          canvas.style.maxWidth = `${rect.w}px`;
          canvas.style.maxHeight = `${rect.h}px`;
        }
      }
    }
  },
  block: true,
  icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.25 0V12.975L23.2103 16.563C23.676 15.4072 24 14.016 24 12.4282C24 5.56425 17.5898 0 11.25 0ZM9.75 2.25C4.52175 2.796 0 7.5195 0 13.125C0 19.131 4.869 24 10.875 24C15.2977 24 19.0973 21.3555 20.7968 17.5635L9.75 14.25V2.25Z" fill="white"/></svg>',

  traits: [
    {
      id: 'chart-type',
      name: 'chart-type',
      label: 'Chart Type',
      type: 'select',
      changeProp: true,
      options: [
        { id: 'pie', name: 'Pie-chart with text', value: 'pie' },
        { id: 'doughnut', name: 'Dognut with text', value: 'doughnut' },
        {
          id: 'doughnut-transparent',
          name: 'Dognut',
          value: 'doughnut-transparent'
        },
        {
          id: 'pie-transparent',
          name: 'Pie-chart',
          value: 'pie-transparent'
        }
      ],
      value: 'doughnut'
    },
    {
      id: 'title',
      name: 'title',
      label: 'Header',
      type: 'text',
      changeProp: true,
      value: 'Browser Market Share'
    },
    {
      id: 'sub-title',
      name: 'sub-title',
      label: 'Sub Header',
      type: 'text',
      changeProp: true,
      value: '2024 vs 2025'
    },
    {
      id: 'chart-data',
      name: 'chart-data',
      label: 'Chart Data',
      type: 'json',
      changeProp: true
      // Default value provided by script logic if empty
    },
    {
      id: 'add-layer',
      name: 'add-layer',
      label: 'Add Layer',
      type: 'button',
      command: 'pie-chart:add-layer'
    },
    {
      id: 'remove-layer',
      name: 'remove-layer',
      label: 'Remove Layer',
      type: 'button',
      command: 'pie-chart:remove-layer'
    },
    {
      id: 'add-point',
      name: 'add-point',
      label: 'Add Point',
      type: 'button',
      command: 'pie-chart:add-point'
    },
    {
      id: 'remove-point',
      name: 'remove-point',
      label: 'Remove Point',
      type: 'button',
      command: 'pie-chart:remove-point'
    },
    {
      id: 'points-manager',
      name: 'points-manager',
      label: 'Points',
      type: 'custom-points',
      changeProp: false
    }
  ],

  // --- STYLE CONFIG ---
  styleConfig: {
    target: '.pie-charts-wrapper',
    sectors: [
      {
        id: 'style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: '#10161C'
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '100',
            units: ['%', 'px', 'vw']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto']
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: 'min-width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vw', 'auto']
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: 'min-height',
            type: 'number',
            default: '450', // Дефолтное значение под ваши стили
            units: ['px', '%', 'vh', 'auto']
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: 'max-width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vw', 'auto']
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: 'max-height',
            type: 'number',
            default: '600', // Дефолтное значение под ваши стили
            units: ['px', '%', 'vh', 'auto']
          }
        ]
      },
      {
        id: 'header_text',
        name: 'Header Text',
        open: true,
        properties: [
          {
            id: 'header-fs',
            name: 'Font Size',
            property: '--chart-header-size',
            type: 'number',
            default: 16,
            units: ['px']
          },
          {
            id: 'header-color',
            name: 'Color',
            property: '--chart-header-color',
            type: 'color',
            default: '#ffffff'
          }
        ]
      },
      {
        id: 'subheader_text',
        name: 'Sub Header Text',
        open: true,
        properties: [
          {
            id: 'subheader-fs',
            name: 'Font Size',
            property: '--chart-subheader-size',
            type: 'number',
            default: 14,
            units: ['px']
          },
          {
            id: 'subheader-color',
            name: 'Color',
            property: '--chart-subheader-color',
            type: 'color',
            default: '#a0aec0'
          }
        ]
      },
      {
        id: 'grid_text',
        name: 'Grid Text', // Переименовал для ясности (в Bar Chart это Grid, тут Legend)
        open: true,
        properties: [
          {
            id: 'grid-fs',
            name: 'Font Size',
            property: '--chart-grid-size',
            type: 'number',
            default: 12,
            units: ['px']
          },
          {
            id: 'grid-color',
            name: 'Color',
            property: '--chart-grid-color',
            type: 'color',
            default: '#ffffff'
          }
        ]
      }
    ]
  },

  styles: `
  .pie-charts-wrapper {
    /* УБИРАЕМ ФОН */
    background-color: transparent; 
    /* Убираем рамку и тень, чтобы был только чарт */
    border: none;
    box-shadow: none;
    
    border-radius: 8px;
    padding: 20px;
    box-sizing: border-box;
    width: 100%;
    min-height: 450px; 
    height: auto;
    font-family: 'Montserrat', sans-serif;
    overflow: hidden;
    position: relative;
    
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center; 
    align-items: flex-start;

    /* Дефолтные цвета текста */
    --chart-header-color: #ffffff;
    --chart-header-size: 16px;
    --chart-subheader-color: #a0aec0;
    --chart-subheader-size: 14px;
    --chart-grid-color: #ffffff;
    --chart-grid-size: 12px;
  }
  
  .single-chart-box {
    flex: 1 1 300px;
    max-width: 600px;
    min-width: 250px;
    min-height: 400px;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
  }

  .pie-chart-canvas {
    width: 100% !important;
    height: auto !important;
    min-height: 350px; 
  }
`,

  script: `
const loadScripts = [
  { src: 'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js', global: 'Chart', fallback: 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.3/chart.umd.min.js' }
];
let scriptsLoaded = false;
let chartInstances = [];

// --- CUSTOM PLUGIN: OUTER LABELS ---
const outerLabelsPlugin = {
  id: 'outerLabels',
  afterDatasetsDraw: (chart, args, options) => {
    const { ctx, chartArea: { top, bottom, left, right, width, height } } = chart;
    chart.data.datasets.forEach((dataset, i) => {
      const meta = chart.getDatasetMeta(i);
      if (meta.hidden) return;
      const centerX = (left + right) / 2;
      const centerY = (top + bottom) / 2;
      let total = 0; dataset.data.forEach(val => total += val);

      meta.data.forEach((element, index) => {
        const value = dataset.data[index];
        if (value === 0 || value === null) return;
        const label = chart.data.labels[index];
        const percentage = Math.round((value / total) * 100) + '%';
        const color = element.options.backgroundColor;
        
        const outerRadius = element.outerRadius;
        const angle = element.startAngle + (element.endAngle - element.startAngle) / 2;
        const lineStartOffset = 5; 
        const lineLength = 20; 
        const lineBend = 15;
        const startX = centerX + Math.cos(angle) * (outerRadius + lineStartOffset);
        const startY = centerY + Math.sin(angle) * (outerRadius + lineStartOffset);
        const midX = centerX + Math.cos(angle) * (outerRadius + lineStartOffset + lineLength);
        const midY = centerY + Math.sin(angle) * (outerRadius + lineStartOffset + lineLength);
        const alignLeft = midX < centerX;
        const endX = alignLeft ? midX - lineBend : midX + lineBend;
        const endY = midY;

        ctx.save();
        ctx.beginPath(); ctx.moveTo(startX, startY); ctx.lineTo(midX, midY); ctx.lineTo(endX, endY);
        ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.font = 'bold 11px Montserrat, sans-serif'; ctx.fillStyle = '#ffffff';
        ctx.textBaseline = 'middle'; ctx.textAlign = alignLeft ? 'right' : 'left';
        const text = label + ' ' + percentage;
        const textX = alignLeft ? endX - 5 : endX + 5;
        ctx.fillText(text, textX, endY);
        ctx.restore();
      });
    });
  }
};

function getDefaultPieData() {
    return [{
        id: 'layer-1', name: '2024', color: '#4170FF',
        points: [
            { label: 'Chrome', value: 32, color: '#4170FF' },
            { label: 'Safari', value: 28, color: '#D4843B' },
            { label: 'Firefox', value: 16, color: '#3D3AB8' },
            { label: 'Opera', value: 16, color: '#8225A3' },
            { label: 'Other', value: 8, color: '#C83B0E' }
        ]
    }];
}

function loadScript(s) {
  return new Promise((res, rej) => {
    if (window[s.global]) { res(); return; }
    const e = document.createElement('script');
    e.src = s.src; e.async = true;
    e.onload = () => res();
    e.onerror = () => {
      if (s.fallback) {
        e.src = s.fallback; e.onload = () => res(); e.onerror = () => rej(new Error('Failed'));
        document.head.appendChild(e);
      } else { rej(new Error('Failed')); }
    };
    document.head.appendChild(e);
  });
}

function loadLibraries() {
  if (scriptsLoaded) return Promise.resolve();
  return Promise.all(loadScripts.map(loadScript)).then(() => { scriptsLoaded = true; });
}

function initPieChartEditor(model) {
  const container = model.getEl();
  if (!container) return;

  const traits = model.getTraits();
  const chartType = traits.find(t => t.getName() === 'chart-type')?.getValue() || 'doughnut';
  const title = traits.find(t => t.getName() === 'title')?.getValue() || 'Browser Market Share';
  const subTitle = traits.find(t => t.getName() === 'sub-title')?.getValue() || 'Comparison by Year';

  let chartData = [];
  try {
    const chartDataTrait = traits.find(t => t.getName() === 'chart-data');
    const val = chartDataTrait?.getValue();
    chartData = JSON.parse(val || '[]');
    if (!chartData.length) {
        chartData = getDefaultPieData();
        if (chartDataTrait) chartDataTrait.setValue(JSON.stringify(chartData));
    }
  } catch (e) { chartData = getDefaultPieData(); }

  container.setAttribute('data-chart-type', chartType);
  container.setAttribute('data-title', title);
  container.setAttribute('data-sub-title', subTitle);
  container.setAttribute('data-chart-data', JSON.stringify(chartData));

  loadLibraries().then(() => {
    renderPieCharts(container, chartData, chartType, title, subTitle);
  }).catch(err => console.error(err));
}
  
function renderPieCharts(container, chartData, chartTypeRaw, globalTitle, globalSubTitle) {
  if (chartInstances.length > 0) {
      chartInstances.forEach(i => i.destroy());
      chartInstances = [];
  }
  container.innerHTML = '';
  // Гарантируем прозрачный фон через JS
  container.style.backgroundColor = 'transparent';
  container.style.border = 'none';
  container.style.boxShadow = 'none';

  let chartJsType = chartTypeRaw;
  let isTransparentStyle = false;

  if (chartTypeRaw === 'doughnut-transparent') {
      chartJsType = 'doughnut';
      isTransparentStyle = true;
  } else if (chartTypeRaw === 'pie-transparent') {
      chartJsType = 'pie';
      isTransparentStyle = true;
  }

  const style = getComputedStyle(container);
  const headerColor = style.getPropertyValue('--chart-header-color').trim() || '#ffffff';
  const headerSize = style.getPropertyValue('--chart-header-size').trim() || '16px';
  const subHeaderColor = style.getPropertyValue('--chart-subheader-color').trim() || '#a0aec0';
  const subHeaderSize = style.getPropertyValue('--chart-subheader-size').trim() || '14px';
  const legendColor = style.getPropertyValue('--chart-grid-color').trim() || '#ffffff';
  const legendSize = parseInt(style.getPropertyValue('--chart-grid-size').trim() || '12', 10);

  // Для transparent стиля скрываем глобальные заголовки
  if (!isTransparentStyle) {
      const headerContainer = document.createElement('div');
      headerContainer.style.width = '100%';
      headerContainer.style.textAlign = 'center';
      headerContainer.style.marginBottom = '20px';

      if (globalTitle) {
          const h2 = document.createElement('h2');
          h2.textContent = globalTitle;
          h2.style.color = headerColor;
          h2.style.fontSize = headerSize;
          h2.style.margin = '0 0 5px 0';
          h2.style.fontWeight = 'bold';
          headerContainer.appendChild(h2);
      }
      if (globalSubTitle) {
          const h4 = document.createElement('h4');
          h4.textContent = globalSubTitle;
          h4.style.color = subHeaderColor;
          h4.style.fontSize = subHeaderSize;
          h4.style.margin = '0';
          h4.style.fontWeight = 'normal';
          headerContainer.appendChild(h4);
      }
      container.appendChild(headerContainer);
  }

  const chartsGrid = document.createElement('div');
  chartsGrid.style.display = 'flex';
  chartsGrid.style.flexWrap = 'wrap';
  chartsGrid.style.justifyContent = 'center';
  chartsGrid.style.gap = '20px';
  chartsGrid.style.width = '100%';
  container.appendChild(chartsGrid);

  const validLayers = chartData.filter(l => l.points && l.points.length > 0);
  if (validLayers.length === 0) return;

  validLayers.forEach((layer) => {
      const chartBox = document.createElement('div');
      chartBox.className = 'single-chart-box';
      chartBox.style.flex = '1 1 300px';
      chartBox.style.minWidth = '280px';
      chartBox.style.maxWidth = '600px';
      chartBox.style.position = 'relative';

      const canvas = document.createElement('canvas');
      canvas.className = 'pie-chart-canvas';
      chartBox.appendChild(canvas);
      chartsGrid.appendChild(chartBox);

      const ctx = canvas.getContext('2d');
      const labels = layer.points.map(p => p.label);
      
      const borderWidth = isTransparentStyle ? 0 : 2;
      // Для обычного чарта границы цвета фона нет, если фон прозрачный, то делаем их просто прозрачными или черными
      // Если у вас был темный фон (#10161C) для "разрезов", то при прозрачном фоне "разрезы" тоже должны быть прозрачными
      const borderColor = 'transparent'; 
      const hoverOffset = isTransparentStyle ? 8 : 4;

      const dataset = {
          label: layer.name,
          data: layer.points.map(p => p.value),
          backgroundColor: layer.points.map(p => p.color || layer.color),
          borderColor: borderColor, 
          borderWidth: borderWidth,
          hoverOffset: hoverOffset,
          spacing: 0
      };

      const pluginsList = isTransparentStyle ? [] : [outerLabelsPlugin];
      const layoutPadding = isTransparentStyle 
          ? { top: 10, bottom: 10, left: 10, right: 10 }
          : { top: 30, bottom: 30, left: 60, right: 60 };

      const config = {
        type: chartJsType,
        data: { labels, datasets: [dataset] },
        plugins: pluginsList,
        options: {
          responsive: true,
          maintainAspectRatio: false, 
          layout: { padding: layoutPadding },
          cutout: (chartJsType === 'doughnut') ? (isTransparentStyle ? '75%' : '50%') : undefined,
          plugins: {
            title: {
              display: !isTransparentStyle && validLayers.length > 1, 
              text: layer.name,
              color: headerColor, 
              font: { size: 14, weight: 'bold' },
              padding: { bottom: 10 }
            },
            subtitle: { display: false },
            legend: {
              display: !isTransparentStyle, 
              position: 'bottom', align: 'center',     
              labels: { 
                  color: legendColor, 
                  usePointStyle: true, 
                  padding: 20, 
                  font: { size: legendSize }
              }
            },
            tooltip: {
                enabled: true,
                callbacks: {
                    label: function(context) {
                        const l = context.label || '';
                        const v = context.parsed;
                        return l + ': ' + v;
                    }
                }
            }
          }
        }
      };

      try { 
          const newChart = new window.Chart(ctx, config);
          chartInstances.push(newChart);
      } catch (error) { console.error(error); }
  });
}

function initPieChartRuntime(container) {
  const chartType = container.getAttribute('data-chart-type') || 'doughnut';
  const title = container.getAttribute('data-title') || '';
  const subTitle = container.getAttribute('data-sub-title') || '';
  const chartDataAttr = container.getAttribute('data-chart-data');
  let chartData = [];
  if (!chartDataAttr) chartData = getDefaultPieData();
  else {
      try {
        const map = { '&quot;': '"', '&amp;': '&' };
        const decodedData = chartDataAttr.replace(/&quot;|&amp;/g, m => map[m]);
        chartData = JSON.parse(decodedData);
        if (!chartData.length) chartData = getDefaultPieData();
      } catch (e) { chartData = getDefaultPieData(); }
  }

  loadLibraries().then(() => {
    renderPieCharts(container, chartData, chartType, title, subTitle);
  }).catch(err => {});
}

if (typeof editor !== 'undefined') {
  editor.Commands.add('pie-chart:add-layer', {
    run: (editor, sender, options = {}) => {
      const component = options.component || editor.getSelected();
      if (!component || component.get('type') !== 'pie-chart-json') return;
      const chartDataTrait = component.getTrait('chart-data');
      let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
      if (!chartData.length) chartData = getDefaultPieData();
      if (chartData.length >= 6) return;
      const basePoints = chartData[0] ? chartData[0].points : [{label:'A', value:10, color:'#fff'}];
      const newLayerName = (new Date().getFullYear() + chartData.length).toString();
      const newPoints = basePoints.map(p => ({ 
          label: p.label, 
          value: Math.floor(Math.random() * 60) + 10, 
          color: p.color 
      }));
      chartData.push({ id: 'l-'+Date.now(), name: newLayerName, color: '#fff', points: newPoints });
      chartDataTrait.setValue(JSON.stringify(chartData));
      initPieChartEditor(component);
    }
  });

  editor.Commands.add('pie-chart:remove-layer', {
    run: (editor, sender, options = {}) => {
      const component = options.component || editor.getSelected();
      if (!component) return;
      const chartDataTrait = component.getTrait('chart-data');
      let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
      if (chartData.length <= 1) return;
      chartData.pop(); 
      chartDataTrait.setValue(JSON.stringify(chartData)); 
      initPieChartEditor(component);
    }
  });
  
  editor.Commands.add('pie-chart:add-point', {
      run: (editor, sender, options = {}) => {
          const component = options.component || editor.getSelected();
          if (!component) return;
          const chartDataTrait = component.getTrait('chart-data');
          let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
          if (!chartData.length) chartData = getDefaultPieData();
          if (chartData[0].points.length >= 15) return;
          const newLabel = 'Item ' + (chartData[0].points.length + 1);
          chartData.forEach(layer => { layer.points.push({ label: newLabel, value: 20, color: '#999' }); });
          chartDataTrait.setValue(JSON.stringify(chartData)); 
          initPieChartEditor(component);
      }
  });
  
  editor.Commands.add('pie-chart:remove-point', {
      run: (editor, sender, options = {}) => {
          const component = options.component || editor.getSelected();
          if (!component) return;
          const chartDataTrait = component.getTrait('chart-data');
          let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
          if (chartData.length && chartData[0].points.length > 1) {
              chartData.forEach(layer => layer.points.pop());
              chartDataTrait.setValue(JSON.stringify(chartData)); 
              initPieChartEditor(component);
          }
      }
  });
}

if (typeof model !== 'undefined') {
  if (model.getEl()) {
    setTimeout(() => initPieChartEditor(model), 100);
    model.on('change:traits', () => setTimeout(() => initPieChartEditor(model), 50));
    model.on('change:attributes', () => setTimeout(() => initPieChartEditor(model), 50));
    model.on('change:style', () => setTimeout(() => initPieChartEditor(model), 10));
  }
} else {
  const container = this;
  if (container && container.getAttribute('data-component-id') === 'pie-chart-json') {
    setTimeout(() => initPieChartRuntime(container), 100);
  }
}
`
};
