import { ComponentConfig } from '../elements';

export const Calendar: ComponentConfig = {
  id: 'calendar',
  type: 'calendar',
  label: 'Calendar',
  category: 'Data Visualization',
  content: {
    tagName: 'div',
    attributes: {
      class: 'calendar-container',
      'data-component-id': 'calendar'
    },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'calendar-field' },
        components: [
          {
            tagName: 'span',
            attributes: { class: 'calendar-date-text' },
            content: '—'
          },
          {
            tagName: 'span',
            attributes: { class: 'calendar-icon' },
            content: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="5" width="18" height="16" rx="2" stroke="white" stroke-width="1.5"/><path d="M3 10H21" stroke="white" stroke-width="1.5"/><path d="M8 3V7M16 3V7" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>`
          }
        ]
      },
      {
        tagName: 'div',
        attributes: { class: 'calendar-dropdown' }
      }
    ],
    droppable: false,
    editable: true,
    selectable: true
  },
  block: true,
  icon: `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="1" y="4" width="24" height="20" rx="2" stroke="white" stroke-width="1.5"/>
    <path d="M1 10H25" stroke="white" stroke-width="1.5"/>
    <path d="M7 2V6M19 2V6" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
    <rect x="5" y="12" width="3" height="3" fill="white"/>
    <rect x="10" y="12" width="3" height="3" fill="white"/>
    <rect x="15" y="12" width="3" height="3" fill="white"/>
  </svg>`,
  traits: [
    {
      id: 'calendar-type',
      name: 'calendar-type',
      label: 'Calendar Type',
      type: 'select',
      changeProp: true,
      options: [
        { id: 'normal', name: 'Normal', value: 'normal' },
        { id: 'with-time', name: 'With Time', value: 'with-time' }
      ],
      value: 'normal'
    },
    {
      id: 'value',
      name: 'value',
      label: 'Value',
      type: 'text',
      changeProp: true,
      value: ''
    },
    {
      id: 'selected-day-bg',
      name: 'selected-day-bg',
      label: 'Selected Day Background',
      type: 'color',
      changeProp: true,
      value: '#4170FF80'
    },
    {
      id: 'current-day-bg',
      name: 'current-day-bg',
      label: 'Current Day Background',
      type: 'color',
      changeProp: true,
      value: '#2d374880'
    }
  ],
  styles: `
    .calendar-container {
      background-color: transparent;
      border: none;
      border-radius: 0;
      padding: 0;
      box-sizing: border-box;
      width: 163px;
      height: 34px;
      min-width: 34px;
      min-height: 34px;
      display: inline-block;
      overflow: visible;
      position: relative;
      font-family: 'Montserrat', sans-serif;
    }
    .calendar-field {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      width: 100%;
      min-width: 0;
      max-width: 100%;
      height: 100%;
      min-height: 34px;
      background-color: rgba(255, 255, 255, 0.12);
      border: none;
      border-radius: 6px;
      padding: 0 12px;
      box-sizing: border-box;
      cursor: pointer;
    }
    .calendar-date-text {
      color: #FFFFFF;
      font-size: 14px;
      font-weight: 400;
      line-height: 1.2;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      pointer-events: none;
    }
    .calendar-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      pointer-events: none;
      opacity: 0.95;
    }
    .calendar-icon svg {
      display: block;
      width: 18px;
      height: 18px;
    }
    .calendar-dropdown {
      display: none;
      position: absolute;
      top: calc(100% + 6px);
      left: 0;
      z-index: 2147483100;
      background: #17151f;
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 10px;
      padding: 14px;
      min-width: min(268px, calc(100vw - 16px));
      max-width: calc(100vw - 16px);
      max-height: calc(100vh - 16px);
      width: max-content;
      height: auto;
      overflow: auto;
      box-sizing: border-box;
      box-shadow: 0 8px 28px rgba(0,0,0,0.38);
      pointer-events: auto;
      scrollbar-width: thin;
      scrollbar-color: rgba(126, 139, 164, 0.72) transparent;
    }
    .calendar-dropdown::-webkit-scrollbar { width: 5px; height: 5px; }
    .calendar-dropdown::-webkit-scrollbar-track {
      background: transparent;
      border-radius: 999px;
    }
    .calendar-dropdown::-webkit-scrollbar-thumb {
      background: rgba(126, 139, 164, 0.72);
      border-radius: 999px;
    }
    .calendar-dropdown::-webkit-scrollbar-thumb:hover {
      background: rgba(151, 164, 190, 0.9);
    }
    .cal-popup-head {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 12px;
    }
    .cal-type-row {
      position: relative;
      flex: 1 1 auto;
      min-width: 0;
    }
    .cal-close {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex: 0 0 30px;
      width: 30px;
      height: 30px;
      padding: 0;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 7px;
      background: rgba(255,255,255,0.06);
      color: rgba(255,255,255,0.85);
      cursor: pointer;
      font-size: 18px;
      line-height: 1;
      font-family: inherit;
      transition: background 0.15s, border-color 0.15s;
    }
    .cal-close:hover {
      background: rgba(255,255,255,0.11);
      border-color: rgba(255,255,255,0.2);
    }
    .cal-type-btn {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: rgba(255,255,255,0.08);
      border: none;
      border-radius: 8px;
      padding: 8px 12px;
      cursor: pointer;
      user-select: none;
      width: 100%;
      box-sizing: border-box;
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      font-family: inherit;
    }
    .cal-type-btn svg { opacity: 0.6; }
    .cal-type-menu {
      display: none;
      position: absolute;
      top: calc(100% + 4px);
      left: 0;
      right: 0;
      background: #241f30;
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 8px;
      overflow: hidden;
      z-index: 10;
      box-shadow: 0 4px 16px rgba(0,0,0,0.3);
    }
    .cal-type-item {
      padding: 8px 12px;
      color: #fff;
      font-size: 13px;
      cursor: pointer;
      transition: background 0.15s;
      border: none;
      background: none;
      width: 100%;
      text-align: left;
      font-family: inherit;
      box-sizing: border-box;
    }
    .cal-type-item:hover { background: rgba(255,255,255,0.1); }
    .cal-type-item.active { background: rgba(65,112,255,0.3); }
    .cal-nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
    }
    .cal-month { color: #fff; font-size: 14px; font-weight: 600; }
    .cal-nav-right { display: flex; align-items: center; gap: 4px; }
    .cal-time-inline {
      background: rgba(255,255,255,0.08);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 6px;
      color: #fff;
      font-size: 13px;
      font-family: 'Montserrat', monospace;
      padding: 4px 8px;
      width: 56px;
      text-align: center;
      outline: none;
      border: 1px solid rgba(255,255,255,0.12);
      margin-right: 8px;
    }
    .cal-time-inline:focus { border-color: rgba(65,112,255,0.5); }
    .cal-arrow {
      background: none;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 6px;
      width: 28px;
      height: 28px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      padding: 0;
      transition: background 0.15s;
      color: #fff;
      font-family: inherit;
    }
    .cal-arrow:hover { background: rgba(255,255,255,0.08); }
    .cal-weekdays {
      display: grid;
      grid-template-columns: repeat(7, 1fr);
      margin-bottom: 4px;
    }
    .cal-weekdays span {
      text-align: center;
      color: rgba(255,255,255,0.45);
      font-size: 12px;
      font-weight: 500;
      padding: 4px 0;
      user-select: none;
    }
    .cal-days {
      display: grid;
      grid-template-columns: repeat(7, 1fr);
      gap: 2px;
    }
    .cal-day {
      text-align: center;
      color: #fff;
      font-size: 13px;
      padding: 6px 0;
      border-radius: 6px;
      cursor: pointer;
      user-select: none;
      transition: background 0.15s;
      line-height: 1.4;
      border: none;
      background: none;
      font-family: inherit;
    }
    .cal-day:hover { background: rgba(255,255,255,0.08); }
    .cal-day.empty { cursor: default; }
    .cal-day.empty:hover { background: none; }
    .cal-time-only {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      padding: 16px 0;
    }
    .cal-time-only label {
      color: rgba(255,255,255,0.6);
      font-size: 12px;
      font-weight: 500;
    }
    .cal-time-only input {
      background: rgba(255,255,255,0.08);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 8px;
      color: #fff;
      font-size: 20px;
      font-family: 'Montserrat', monospace;
      padding: 10px 16px;
      width: 140px;
      text-align: center;
      outline: none;
    }
    .cal-time-only input:focus { border-color: rgba(65,112,255,0.5); }
  `,
  styleConfig: {
    sectors: [
      {
        id: 'styles',
        name: 'Styles',
        open: true,
        properties: [
          {
            id: 'background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: 'rgba(255, 255, 255, 0.12)',
            selector: '.calendar-field'
          },
          {
            id: 'selected-day-bg',
            name: 'Selected Day Background',
            property: 'selected-day-bg',
            type: 'color',
            default: '#4170FF80'
          },
          {
            id: 'current-day-bg',
            name: 'Current Day Background',
            property: 'current-day-bg',
            type: 'color',
            default: '#2d374880'
          }
        ]
      },
      {
        id: 'dimensions',
        name: 'Dimensions',
        open: false,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            units: ['px', 'vw'],
            default: 'fit-content',
            selector: '.calendar-field'
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            units: ['px', 'vw'],
            default: 34,
            selector: '.calendar-container'
          }
        ]
      }
    ]
  },
  script: `
    var MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    var TYPE_LABELS = {'normal':'Normal','with-time':'With Time'};
    var ENABLED_TYPES = ['normal','with-time'];

    function pad(n) { return Number(n) < 10 ? '0' + Number(n) : '' + Number(n); }
    function getTrait(mdl,n) {
      var t = mdl.getTraits && mdl.getTraits().find(function(x){ return x.getName()===n; });
      return t ? t.getValue() : null;
    }
    function setTrait(mdl,n,v) {
      var t = mdl.getTrait ? mdl.getTrait(n) : null;
      if (!t && mdl.getTraits) {
        t = mdl.getTraits().find(function(x){ return x.getName()===n; });
      }
      var traitChanged = false;
      mdl.__calWritingTrait = true;
      try {
        if (t && t.setValue && String(t.getValue ? t.getValue() : '') !== String(v)) {
          t.setValue(v);
          traitChanged = true;
        }
        if (mdl.set && String(mdl.get ? (mdl.get(n) ?? '') : '') !== String(v)) {
          mdl.set(n, v);
          traitChanged = true;
        }
      } finally {
        mdl.__calWritingTrait = false;
      }
      return traitChanged;
    }
    function isValidDate(y,m,d) {
      if (!y || m < 1 || m > 12 || d < 1) return false;
      return d <= new Date(y, m, 0).getDate();
    }
    function isValidTime(h,m,s) {
      return h >= 0 && h <= 23 && m >= 0 && m <= 59 && s >= 0 && s <= 59;
    }
    function todayParts() {
      var now = new Date();
      return {
        y: now.getFullYear(),
        mo: now.getMonth(),
        d: now.getDate(),
        h: now.getHours(),
        m: now.getMinutes(),
        s: now.getSeconds()
      };
    }
    function parseDate(v) {
      var value = String(v || '').trim();
      var m = value.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
      if (m) {
        var iso = {y:Number(m[1]), mo:Number(m[2])-1, d:Number(m[3]), h:0, m:0, s:0};
        return isValidDate(iso.y, iso.mo+1, iso.d) ? iso : null;
      }
      m = value.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
      if (!m) return null;
      var dmy = {y:Number(m[3]), mo:Number(m[2])-1, d:Number(m[1]), h:0, m:0, s:0};
      return isValidDate(dmy.y, dmy.mo+1, dmy.d) ? dmy : null;
    }
    function parseTime(v) {
      var m = String(v || '').trim().match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
      if (!m) return null;
      var time = {h:Number(m[1]), m:Number(m[2]), s:Number(m[3] || 0)};
      return isValidTime(time.h, time.m, time.s) ? time : null;
    }
    function parseDateTime(v) {
      var value = String(v || '').trim();
      var m = value.match(/^(\d{4})-(\d{1,2})-(\d{1,2})[T\s]+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
      if (m) {
        var iso = {y:Number(m[1]), mo:Number(m[2])-1, d:Number(m[3]), h:Number(m[4]), m:Number(m[5]), s:Number(m[6] || 0)};
        return isValidDate(iso.y, iso.mo+1, iso.d) && isValidTime(iso.h, iso.m, iso.s) ? iso : null;
      }
      m = value.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})\s*(?:[-–—,]\s*)?(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
      if (m) {
        var dmy = {y:Number(m[3]), mo:Number(m[2])-1, d:Number(m[1]), h:Number(m[4]), m:Number(m[5]), s:Number(m[6] || 0)};
        return isValidDate(dmy.y, dmy.mo+1, dmy.d) && isValidTime(dmy.h, dmy.m, dmy.s) ? dmy : null;
      }
      var dateOnly = parseDate(value);
      return dateOnly ? dateOnly : null;
    }
    function parseVal(v, ct) {
      if (!v) return null;
      if (ct === 'time') return parseTime(v);
      if (ct === 'with-time') return parseDateTime(v);
      var raw = String(v);
      if (raw.indexOf('T') !== -1) raw = raw.split('T')[0];
      return parseDate(raw);
    }
    function canonical(parts, ct) {
      if (!parts) return '';
      if (ct === 'time') return pad(parts.h)+':'+pad(parts.m)+':'+pad(parts.s || 0);
      var date = parts.y+'-'+pad(parts.mo+1)+'-'+pad(parts.d);
      if (ct === 'with-time') return date+'T'+pad(parts.h || 0)+':'+pad(parts.m || 0)+':'+pad(parts.s || 0);
      return date;
    }
    function defaultValue(ct) {
      return canonical(todayParts(), ct);
    }
    function normalize(v, ct) {
      var parsed = parseVal(v, ct);
      return parsed ? canonical(parsed, ct) : '';
    }
    function fmtDisplay(v, ct) {
      var parsed = parseVal(v, ct);
      if (!parsed) return String(v || defaultValue(ct));
      if (ct === 'time') return pad(parsed.h)+':'+pad(parsed.m)+':'+pad(parsed.s || 0);
      var date = pad(parsed.d)+'.'+pad(parsed.mo+1)+'.'+parsed.y;
      if (ct === 'with-time') return date+' '+pad(parsed.h || 0)+':'+pad(parsed.m || 0);
      return date;
    }
    function convertType(v, fromType, toType) {
      var parsed = parseVal(v, fromType) || parseVal(v, toType) || todayParts();
      if (toType === 'time' && (parsed.h === undefined || parsed.m === undefined)) {
        var now = todayParts();
        parsed.h = now.h; parsed.m = now.m; parsed.s = 0;
      }
      return canonical(parsed, toType);
    }

    var el = this || (model && model.getEl ? model.getEl() : null);
    if (!el || !model) return;

    var dropdown = el.querySelector('.calendar-dropdown');
    var field = el.querySelector('.calendar-field');
    var dateText = el.querySelector('.calendar-date-text');
    if (!dropdown || !field || !dateText) return;

    var doc = el.ownerDocument || document;
    var win = doc.defaultView || window;
    var manager = doc.__dslCalendarManager;
    if (!manager) {
      manager = {
        activeModel: null,
        activeRoot: null,
        outsideBound: false,
        viewportBound: false
      };
      doc.__dslCalendarManager = manager;
    }

    function releaseManager() {
      if (manager.activeModel === model) {
        manager.activeModel = null;
        manager.activeRoot = null;
      }
    }
    function claimManager() {
      if (manager.activeModel && manager.activeModel !== model) {
        var previous = manager.activeModel;
        previous.__calOpen = false;
        if (previous.__renderCalendar) previous.__renderCalendar();
      }
      manager.activeModel = model;
      manager.activeRoot = el;
    }
    function positionDropdown() {
      if (!model.__calOpen || dropdown.style.display === 'none') return;
      dropdown.style.left = '0px';
      dropdown.style.right = 'auto';
      dropdown.style.top = (field.offsetHeight + 6) + 'px';
      dropdown.style.bottom = 'auto';

      var viewportW = doc.documentElement.clientWidth || win.innerWidth || 0;
      var viewportH = doc.documentElement.clientHeight || win.innerHeight || 0;
      var margin = 8;
      var rootRect = el.getBoundingClientRect();
      var fieldRect = field.getBoundingClientRect();
      var dropRect = dropdown.getBoundingClientRect();

      var left = 0;
      if (rootRect.left + dropRect.width > viewportW - margin) {
        left = viewportW - margin - rootRect.left - dropRect.width;
      }
      if (rootRect.left + left < margin) left = margin - rootRect.left;
      dropdown.style.left = Math.round(left) + 'px';

      var belowTop = fieldRect.bottom - rootRect.top + 6;
      var belowBottom = rootRect.top + belowTop + dropRect.height;
      var aboveTop = fieldRect.top - rootRect.top - dropRect.height - 6;
      if (belowBottom > viewportH - margin && fieldRect.top - dropRect.height - 6 >= margin) {
        dropdown.style.top = Math.round(aboveTop) + 'px';
      } else {
        var maxTop = viewportH - margin - rootRect.top - dropRect.height;
        dropdown.style.top = Math.round(Math.max(margin - rootRect.top, Math.min(belowTop, maxTop))) + 'px';
      }
    }
    function setOpen(next) {
      model.__calOpen = !!next;
      if (model.__calOpen) claimManager();
      else releaseManager();
      if (model.__renderCalendar) model.__renderCalendar();
    }
    function notifyUpdate() {
      try {
        if (model && model.trigger) model.trigger('component:update', model);
      } catch (e) {}
      try {
        if (model && model.em && model.em.trigger) {
          model.em.trigger('component:update', model);
        }
      } catch (e) {}
    }
    function syncDateDisplay(displayValue) {
      dateText.textContent = displayValue;
      try {
        var matches = model.find ? model.find('.calendar-date-text') : [];
        var textModel = matches && matches.length ? matches[0] : null;
        if (textModel && textModel.get && textModel.set) {
          var textChildren = textModel.components ? textModel.components() : null;
          var firstTextChild = textChildren && textChildren.models ? textChildren.models[0] : null;
          var currentContent = String(
            (firstTextChild && firstTextChild.get ? firstTextChild.get('content') : null) ||
            textModel.get('content') ||
            ''
          );
          if (currentContent !== String(displayValue)) {
            if (textChildren && textChildren.reset && textModel.append) {
              textChildren.reset();
              textModel.append(String(displayValue));
            } else {
              textModel.set('content', String(displayValue));
            }
            if (textModel.view && textModel.view.render) textModel.view.render();
          }
        }
      } catch (e) {}
    }
    function commitValue(nextValue, type) {
      var normalized = normalize(nextValue, type);
      if (!normalized) return false;
      setTrait(model, 'value', normalized);
      syncDateDisplay(fmtDisplay(normalized, type));
      if (model.addAttributes) {
        var attrs = model.getAttributes ? model.getAttributes() : {};
        model.addAttributes(Object.assign({}, attrs, { 'data-calendar-value': normalized }));
      }
      notifyUpdate();
      return true;
    }

    model.__openCalendar = function() { setOpen(true); };
    model.__closeCalendar = function() { setOpen(false); };
    model.__positionCalendar = positionDropdown;

    function renderCalendar() {
      var calType = getTrait(model,'calendar-type') || 'normal';
      if (ENABLED_TYPES.indexOf(calType) === -1) calType = 'normal';
      var rawVal = getTrait(model,'value');
      var effectiveVal = normalize(rawVal, calType) || defaultValue(calType);
      var pv = parseVal(effectiveVal, calType) || todayParts();
      var selBg = getTrait(model,'selected-day-bg') || '#4170FF80';
      var todBg = getTrait(model,'current-day-bg') || '#2d374880';

      syncDateDisplay(fmtDisplay(effectiveVal, calType));
      dropdown.innerHTML = '';

      if (!model.__calOpen) {
        dropdown.style.display = 'none';
        releaseManager();
        return;
      }

      claimManager();
      dropdown.style.display = 'block';

      if (model.__calViewYear == null || model.__calViewMonth == null) {
        model.__calViewYear = pv.y;
        model.__calViewMonth = pv.mo;
      }
      var vYear = model.__calViewYear;
      var vMonth = model.__calViewMonth;

      var popupHead = doc.createElement('div');
      popupHead.className = 'cal-popup-head';
      var typeRow = doc.createElement('div');
      typeRow.className = 'cal-type-row';
      var typeBtn = doc.createElement('button');
      typeBtn.type = 'button';
      typeBtn.className = 'cal-type-btn';
      typeBtn.innerHTML = '<span>'+(TYPE_LABELS[calType]||'Normal')+'</span><svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M3 5L6 8L9 5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      var typeMenu = doc.createElement('div');
      typeMenu.className = 'cal-type-menu';
      ENABLED_TYPES.forEach(function(tp) {
        var item = doc.createElement('button');
        item.type = 'button';
        item.className = 'cal-type-item' + (tp===calType?' active':'');
        item.textContent = TYPE_LABELS[tp];
        item.addEventListener('mousedown', function(e) {
          e.stopPropagation();
          e.preventDefault();
          var converted = convertType(effectiveVal, calType, tp);
          model.__calOpen = true;
          setTrait(model,'calendar-type',tp);
          setTrait(model,'value',converted);
          var convertedParts = parseVal(converted, tp) || todayParts();
          model.__calViewYear = convertedParts.y;
          model.__calViewMonth = convertedParts.mo;
          notifyUpdate();
          if (model.__renderCalendar) model.__renderCalendar();
        });
        typeMenu.appendChild(item);
      });
      typeBtn.addEventListener('mousedown', function(e) {
        e.stopPropagation();
        e.preventDefault();
        typeMenu.style.display = typeMenu.style.display==='block'?'none':'block';
      });
      typeRow.appendChild(typeBtn);
      typeRow.appendChild(typeMenu);

      var closeBtn = doc.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'cal-close';
      closeBtn.setAttribute('aria-label', 'Close calendar');
      closeBtn.setAttribute('title', 'Close');
      closeBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M3 3L11 11M11 3L3 11" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';
      closeBtn.addEventListener('mousedown', function(e) {
        e.stopPropagation();
        e.preventDefault();
        setOpen(false);
      });

      popupHead.appendChild(typeRow);
      popupHead.appendChild(closeBtn);
      dropdown.appendChild(popupHead);

      if (calType === 'time') {
        var tw = doc.createElement('div');
        tw.className = 'cal-time-only';
        var tl = doc.createElement('label');
        tl.textContent = 'Select time';
        var ti = doc.createElement('input');
        ti.type = 'time';
        ti.step = '1';
        ti.value = pad(pv.h)+':'+pad(pv.m)+':'+pad(pv.s || 0);
        ti.addEventListener('mousedown', function(e) { e.stopPropagation(); });
        ti.addEventListener('change', function(e) {
          e.stopPropagation();
          var parsedTime = parseTime(ti.value);
          if (!parsedTime) return;
          model.__calOpen = true;
          commitValue(canonical(parsedTime, 'time'), 'time');
        });
        tw.appendChild(tl);
        tw.appendChild(ti);
        dropdown.appendChild(tw);
      } else {
        var nav = doc.createElement('div');
        nav.className = 'cal-nav';
        var monthLbl = doc.createElement('span');
        monthLbl.className = 'cal-month';
        monthLbl.textContent = MONTHS[vMonth] + ' ' + vYear;
        var navRight = doc.createElement('div');
        navRight.className = 'cal-nav-right';

        if (calType === 'with-time') {
          var tInp = doc.createElement('input');
          tInp.className = 'cal-time-inline';
          tInp.type = 'time';
          tInp.step = '60';
          tInp.value = pad(pv.h)+':'+pad(pv.m);
          tInp.addEventListener('mousedown', function(e) { e.stopPropagation(); });
          tInp.addEventListener('change', function(e) {
            e.stopPropagation();
            var time = parseTime(tInp.value);
            if (!time) return;
            var current = parseVal(getTrait(model,'value'), 'with-time') || pv;
            var nv = current.y+'-'+pad(current.mo+1)+'-'+pad(current.d)+'T'+pad(time.h)+':'+pad(time.m)+':00';
            model.__calOpen = true;
            commitValue(nv, 'with-time');
          });
          navRight.appendChild(tInp);
        }

        var prevBtn = doc.createElement('button');
        prevBtn.type = 'button';
        prevBtn.className = 'cal-arrow';
        prevBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 4L6 8L10 12" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        prevBtn.addEventListener('mousedown', function(e) {
          e.stopPropagation();
          e.preventDefault();
          model.__calViewMonth--;
          if (model.__calViewMonth < 0) { model.__calViewMonth = 11; model.__calViewYear--; }
          renderCalendar();
        });
        var nextBtn = doc.createElement('button');
        nextBtn.type = 'button';
        nextBtn.className = 'cal-arrow';
        nextBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M6 4L10 8L6 12" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        nextBtn.addEventListener('mousedown', function(e) {
          e.stopPropagation();
          e.preventDefault();
          model.__calViewMonth++;
          if (model.__calViewMonth > 11) { model.__calViewMonth = 0; model.__calViewYear++; }
          renderCalendar();
        });
        navRight.appendChild(prevBtn);
        navRight.appendChild(nextBtn);
        nav.appendChild(monthLbl);
        nav.appendChild(navRight);
        dropdown.appendChild(nav);

        var wk = doc.createElement('div');
        wk.className = 'cal-weekdays';
        ['M','T','W','T','F','S','S'].forEach(function(d) {
          var s = doc.createElement('span');
          s.textContent = d;
          wk.appendChild(s);
        });
        dropdown.appendChild(wk);

        var grid = doc.createElement('div');
        grid.className = 'cal-days';
        var fd = new Date(vYear, vMonth, 1).getDay();
        var off = (fd+6)%7;
        var dim = new Date(vYear, vMonth+1, 0).getDate();
        var now = todayParts();
        var todStr = now.y+'-'+pad(now.mo+1)+'-'+pad(now.d);
        for (var i=0; i<off; i++) {
          var em = doc.createElement('span');
          em.className = 'cal-day empty';
          grid.appendChild(em);
        }
        for (var dd=1; dd<=dim; dd++) {
          var c = doc.createElement('button');
          c.type = 'button';
          c.className = 'cal-day';
          c.textContent = dd;
          var cDate = vYear+'-'+pad(vMonth+1)+'-'+pad(dd);
          var isToday = cDate === todStr;
          var isSelected = pv && pv.y===vYear && pv.mo===vMonth && pv.d===dd;
          if (isToday) {
            c.className += ' current-day';
            c.style.background = todBg;
          }
          if (isSelected) {
            c.className += ' selected-day';
            c.style.background = selBg;
          }
          if (isToday && isSelected) c.style.boxShadow = 'inset 0 0 0 1px rgba(255,255,255,0.85)';
          c.setAttribute('data-calendar-date', cDate);
          (function(dayButton, selectedDate) {
            // The outer editor bridge commits on pointerdown in Constructor.
            // Keep a target-level click fallback so Calendar also remains
            // interactive in runtimes where no editor bridge is mounted.
            dayButton.addEventListener('click', function(e) {
              e.stopPropagation();
              e.preventDefault();
              var currentType = getTrait(model,'calendar-type') || 'normal';
              if (ENABLED_TYPES.indexOf(currentType) === -1) currentType = 'normal';
              var current = parseVal(getTrait(model,'value'), currentType) || pv || todayParts();
              var nv = selectedDate;
              if (currentType === 'with-time') {
                nv += 'T'+pad(current.h || 0)+':'+pad(current.m || 0)+':'+pad(current.s || 0);
              }
              model.__calViewYear = vYear;
              model.__calViewMonth = vMonth;
              // Close before any changeProp write can synchronously re-run the
              // component script. This guarantees the popup never gets stuck.
              model.__calOpen = false;
              releaseManager();
              try { commitValue(nv, currentType); } catch (err) {}
              try { renderCalendar(); } catch (err) { dropdown.style.display = 'none'; }
            });
          })(c, cDate);
          grid.appendChild(c);
        }
        dropdown.appendChild(grid);
      }

      win.setTimeout(positionDropdown, 0);
    }

    model.__renderCalendar = renderCalendar;

    // Keep an already mounted Calendar synchronized with changes coming from
    // the right sidebar/configuration. GrapesJS does not guarantee that the
    // component script is re-executed for every trait value change, so relying
    // on script re-mounting made Calendar Type/Value appear stale in runtime.
    if (model.__calModelCleanup) {
      try { model.__calModelCleanup(); } catch (e) {}
    }
    (function bindCalendarModel() {
      var bindings = [];
      var lastType = getTrait(model, 'calendar-type') || 'normal';

      function bind(target, eventName, handler) {
        if (!target || !target.on || !target.off) return;
        target.on(eventName, handler);
        bindings.push(function() { target.off(eventName, handler); });
      }

      function syncFromTraits() {
        if (model.__calWritingTrait || model.__calSyncingTraits) return;
        model.__calSyncingTraits = true;
        try {
          var nextType = getTrait(model, 'calendar-type') || 'normal';
          if (ENABLED_TYPES.indexOf(nextType) === -1) nextType = 'normal';

          if (nextType !== lastType) {
            var converted = convertType(getTrait(model, 'value'), lastType, nextType);
            setTrait(model, 'value', converted);
            var convertedParts = parseVal(converted, nextType);
            if (convertedParts && nextType !== 'time') {
              model.__calViewYear = convertedParts.y;
              model.__calViewMonth = convertedParts.mo;
            }
            lastType = nextType;
          } else {
            var currentParts = parseVal(getTrait(model, 'value'), nextType);
            if (currentParts && nextType !== 'time' && !model.__calOpen) {
              model.__calViewYear = currentParts.y;
              model.__calViewMonth = currentParts.mo;
            }
          }

          renderCalendar();
        } finally {
          model.__calSyncingTraits = false;
        }
      }

      ['calendar-type', 'value', 'selected-day-bg', 'current-day-bg'].forEach(function(name) {
        var trait = model.getTraits && model.getTraits().find(function(x) { return x.getName() === name; });
        bind(trait, 'change:value', syncFromTraits);
        bind(model, 'change:' + name, syncFromTraits);
      });

      var cleanup = function() {
        bindings.splice(0).forEach(function(unbind) {
          try { unbind(); } catch (e) {}
        });
        if (manager.activeModel === model) releaseManager();
      };
      model.__calModelCleanup = cleanup;
      bind(model, 'removed', cleanup);
      bind(model, 'remove', cleanup);
    })();

    if (!field.__calFieldBound) {
      field.__calFieldBound = true;
      field.addEventListener('mousedown', function(e) {
        e.stopPropagation();
        e.preventDefault();
        model.__calViewYear = null;
        model.__calViewMonth = null;
        setOpen(!model.__calOpen);
      });
    }
    if (!dropdown.__calDropdownBound) {
      dropdown.__calDropdownBound = true;
      dropdown.addEventListener('mousedown', function(e) { e.stopPropagation(); });
    }
    if (!manager.outsideBound) {
      manager.outsideBound = true;
      doc.addEventListener('mousedown', function(e) {
        var activeModel = manager.activeModel;
        var activeRoot = manager.activeRoot;
        if (!activeModel || !activeRoot) return;
        if (activeRoot.contains(e.target)) return;
        activeModel.__calOpen = false;
        manager.activeModel = null;
        manager.activeRoot = null;
        if (activeModel.__renderCalendar) activeModel.__renderCalendar();
      });
    }
    if (!manager.viewportBound) {
      manager.viewportBound = true;
      var repositionActive = function() {
        var activeModel = manager.activeModel;
        if (activeModel && activeModel.__positionCalendar) {
          activeModel.__positionCalendar();
        }
      };
      win.addEventListener('resize', repositionActive);
      doc.addEventListener('scroll', repositionActive, true);
    }

    renderCalendar();
  `
};
