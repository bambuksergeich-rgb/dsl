import { ComponentConfig } from '../elements';

export const LabelText: ComponentConfig = {
  id: 'label-text',
  type: 'label-text',
  label: 'Label Text',
  category: 'Main',
  content: {
    tagName: 'div',
    attributes: {
      class: 'label-text',
      data_type: 'String',
      data: 'Label'
    },
    content: 'Label',
    editable: false,
    droppable: false,
    selectable: true,
    hoverable: true
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.01899 7.55196L7.31199 6.84496M10.98 20.194L3.68199 12.896C3.31199 12.526 3.10199 12.026 3.09499 11.504L2.99999 4.01496C2.99825 3.88119 3.02331 3.74842 3.0737 3.62448C3.12409 3.50055 3.19879 3.38796 3.29339 3.29336C3.38799 3.19876 3.50058 3.12406 3.62451 3.07367C3.74845 3.02328 3.88122 2.99822 4.01499 2.99996L11.504 3.09496C12.0268 3.10166 12.5263 3.31229 12.896 3.68196L20.194 10.98C20.868 11.653 21.386 12.939 20.618 13.707L13.708 20.617C12.939 21.386 11.653 20.867 10.98 20.194Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  traits: [
    {
      id: 'text',
      name: 'text',
      label: 'Text',
      type: 'text',
      changeProp: true,
      value: 'Label'
    },
    {
      id: 'color',
      name: 'color',
      label: 'Color',
      type: 'color',
      changeProp: true,
      value: '#FFFFFF'
    },
    {
      id: 'borderColor',
      name: 'borderColor',
      label: 'Border Color',
      type: 'color',
      changeProp: true,
      value: '#6B7280'
    }
  ],
  styles: `
      .label-text {
        display: block !important;
        min-width: 120px;
        min-height: 40px;
        width: 100%;
        height: 100%;
        font-size: 16px;
        color: #FFFFFF;
        padding: 10px 12px;
        border: 1px solid transparent;
        border-radius: 2px;
        background-color: transparent;
        box-sizing: border-box;
        overflow: auto;
        white-space: normal;
        overflow-wrap: anywhere;
        line-height: 1.35;
        font-family: 'Montserrat', sans-serif;
        text-align: left;
      }

      .label-text[data-label-editing='true'] {
        cursor: text;
        user-select: text;
      }

      .label-text-rte-toolbar {
        position: fixed;
        display: none;
        align-items: stretch;
        height: 32px;
        z-index: 2147483000;
        background: #E50914;
        border-radius: 2px;
        overflow: hidden;
        box-shadow: 0 3px 12px rgba(0, 0, 0, .35);
        font-family: 'Montserrat', sans-serif;
      }

      .label-text-rte-toolbar[data-open='true'] {
        display: flex;
      }

      .label-text-rte-toolbar button,
      .label-text-rte-toolbar select {
        min-width: 32px;
        height: 32px;
        padding: 0 8px;
        border: 0;
        border-right: 1px solid rgba(255,255,255,.2);
        outline: 0;
        color: #FFFFFF;
        background: #E50914;
        font-size: 16px;
        line-height: 32px;
        cursor: pointer;
      }

      .label-text-rte-toolbar select {
        min-width: 54px;
        font-size: 13px;
        appearance: none;
        text-align: left;
      }

      .label-text-rte-toolbar button:hover,
      .label-text-rte-toolbar select:hover,
      .label-text-rte-toolbar button[data-active='true'] {
        background: #B80B12;
      }

      .label-text-rte-toolbar .label-rte-bold { font-weight: 700; }
      .label-text-rte-toolbar .label-rte-italic { font-style: italic; }
      .label-text-rte-toolbar .label-rte-underline { text-decoration: underline; }
      .label-text-rte-toolbar .label-rte-strike { text-decoration: line-through; }
      .label-text-rte-toolbar svg {
        width: 15px;
        height: 15px;
        display: block;
        pointer-events: none;
      }
    `,
  script: `
      function initLabelText(model, element) {
        if (!model || !element) return;

        if (typeof model.__labelTextCleanup === 'function') {
          model.__labelTextCleanup();
        }

        var doc = element.ownerDocument;
        var win = doc && doc.defaultView;
        if (!doc || !win) return;

        model.set('editable', false);

        var editing = false;
        var savedRange = null;
        var toolbar = null;
        var resizeObserver = null;
        var disposed = false;
        var syncing = false;

        function plainFromHtml(html) {
          var holder = doc.createElement('div');
          holder.innerHTML = String(html == null ? '' : html);
          return String(holder.textContent || '').replace(/\\u00a0/g, ' ');
        }

        function escapeHtml(text) {
          var holder = doc.createElement('div');
          holder.textContent = String(text == null ? '' : text);
          return holder.innerHTML;
        }

        function safeHref(value) {
          var href = String(value || '').trim();
          if (!href) return '';
          if (/^(https?:|mailto:|tel:|#|\\/)/i.test(href)) return href;
          return 'https://' + href;
        }

        function sanitizeHtml(html) {
          var holder = doc.createElement('div');
          holder.innerHTML = String(html == null ? '' : html);
          var allowed = {
            B: true, STRONG: true, I: true, EM: true, U: true,
            S: true, STRIKE: true, A: true, BR: true,
            DIV: true, P: true, SPAN: true,
            H1: true, H2: true, H3: true,
            UL: true, OL: true, LI: true
          };

          var nodes = Array.prototype.slice.call(holder.querySelectorAll('*'));
          nodes.forEach(function(node) {
            var tag = String(node.tagName || '').toUpperCase();
            if (!allowed[tag]) {
              var parent = node.parentNode;
              if (!parent) return;
              while (node.firstChild) parent.insertBefore(node.firstChild, node);
              parent.removeChild(node);
              return;
            }

            Array.prototype.slice.call(node.attributes || []).forEach(function(attr) {
              var name = String(attr.name || '').toLowerCase();
              if (tag === 'A' && (name === 'href' || name === 'target' || name === 'rel')) {
                return;
              }
              node.removeAttribute(attr.name);
            });

            if (tag === 'A') {
              var href = safeHref(node.getAttribute('href'));
              if (href) node.setAttribute('href', href);
              else node.removeAttribute('href');
              node.setAttribute('target', '_blank');
              node.setAttribute('rel', 'noopener noreferrer');
            }
          });
          return holder.innerHTML;
        }

        function getTextTrait() {
          return model.getTrait && model.getTrait('text');
        }

        function getTraitValue(name, fallback) {
          var trait = model.getTrait && model.getTrait(name);
          if (!trait) return fallback;
          var value = trait.getValue();
          return value == null || value === '' ? fallback : value;
        }

        function setTraitPlainText(plain) {
          var trait = getTextTrait();
          if (!trait) return;
          var current = String(trait.getValue() == null ? '' : trait.getValue());
          if (current === plain) return;
          trait.setValue(plain);
        }

        function renderHtml(html) {
          var safe = sanitizeHtml(html || 'Label') || 'Label';
          if (element.innerHTML !== safe) element.innerHTML = safe;
          return safe;
        }

        function syncChildrenModel(html) {
          if (!model.components) return;
          try {
            model.components(html);
          } catch (_) {}
        }

        function persistFromDom(syncChildren) {
          if (syncing || disposed) return;
          syncing = true;
          try {
            var html = sanitizeHtml(element.innerHTML || 'Label') || 'Label';
            var plain = plainFromHtml(html) || 'Label';
            if (model.get('labelHtml') !== html) model.set('labelHtml', html);
            var attrs = model.getAttributes ? model.getAttributes() : {};
            if (attrs.data !== plain) {
              model.setAttributes(Object.assign({}, attrs, { data: plain }));
            }
            setTraitPlainText(plain);
            if (syncChildren) syncChildrenModel(html);
          } finally {
            syncing = false;
          }
        }

        function syncFromModel() {
          if (syncing || editing || disposed) return;
          syncing = true;
          try {
            var stored = String(model.get('labelHtml') || '');
            var trait = getTextTrait();
            var traitText = String(trait && trait.getValue() != null ? trait.getValue() : 'Label');
            var currentHtml = stored || element.innerHTML || escapeHtml(traitText || 'Label');
            var currentPlain = plainFromHtml(currentHtml);

            if (traitText && traitText !== currentPlain) {
              currentHtml = escapeHtml(traitText);
              model.set('labelHtml', currentHtml);
            } else if (!stored) {
              model.set('labelHtml', currentHtml);
            }

            currentHtml = renderHtml(currentHtml);
            var plain = plainFromHtml(currentHtml) || 'Label';
            var attrs = model.getAttributes ? model.getAttributes() : {};
            if (attrs.data !== plain) {
              model.setAttributes(Object.assign({}, attrs, { data: plain }));
            }
            if (trait && String(trait.getValue() || '') !== plain) {
              trait.setValue(plain);
            }
            syncChildrenModel(currentHtml);
          } finally {
            syncing = false;
          }
        }

        function syncVisualTraits() {
          var color = String(getTraitValue('color', '#FFFFFF'));
          var borderColor = String(getTraitValue('borderColor', '#6B7280'));
          element.style.color = color;
          element.style.borderColor = borderColor;
        }

        function saveSelection() {
          if (!editing) return;
          var selection = win.getSelection && win.getSelection();
          if (!selection || !selection.rangeCount) return;
          var range = selection.getRangeAt(0);
          var container = range.commonAncestorContainer;
          var owner = container.nodeType === 1 ? container : container.parentElement;
          if (owner && element.contains(owner)) savedRange = range.cloneRange();
        }

        function restoreSelection() {
          if (!savedRange) return;
          try {
            var selection = win.getSelection();
            selection.removeAllRanges();
            selection.addRange(savedRange);
          } catch (_) {}
        }

        function positionToolbar() {
          if (!toolbar || !editing) return;
          var rect = element.getBoundingClientRect();
          var toolbarHeight = toolbar.offsetHeight || 32;
          var toolbarWidth = toolbar.offsetWidth || 260;
          var top = rect.top - toolbarHeight;
          if (top < 4) top = Math.min(win.innerHeight - toolbarHeight - 4, rect.bottom);
          var left = Math.max(4, Math.min(rect.left, win.innerWidth - toolbarWidth - 4));
          toolbar.style.left = Math.round(left) + 'px';
          toolbar.style.top = Math.round(top) + 'px';
        }

        function updateToolbarState() {
          if (!toolbar || !editing) return;
          ['bold', 'italic', 'underline', 'strikeThrough'].forEach(function(command) {
            var button = toolbar.querySelector('[data-command="' + command + '"]');
            if (!button) return;
            var active = false;
            try { active = !!doc.queryCommandState(command); } catch (_) {}
            button.setAttribute('data-active', active ? 'true' : 'false');
          });
        }

        function runCommand(command, value) {
          if (!editing) return;
          element.focus();
          restoreSelection();
          try {
            doc.execCommand(command, false, value == null ? null : value);
          } catch (_) {}
          saveSelection();
          persistFromDom(false);
          updateToolbarState();
        }

        function makeButton(text, command, className) {
          var button = doc.createElement('button');
          button.type = 'button';
          button.textContent = text;
          button.className = className || '';
          button.setAttribute('data-command', command);
          button.addEventListener('mousedown', function(event) {
            event.preventDefault();
            event.stopPropagation();
          });
          button.addEventListener('click', function(event) {
            event.preventDefault();
            event.stopPropagation();
            if (command === 'createLink') {
              var href = safeHref(win.prompt('URL', 'https://') || '');
              if (href) runCommand('createLink', href);
              return;
            }
            runCommand(command);
          });
          return button;
        }

        function makeIconButton(svg, command, ariaLabel) {
          var button = makeButton('', command, '');
          button.innerHTML = svg;
          button.setAttribute('aria-label', ariaLabel || command);
          button.setAttribute('title', ariaLabel || command);
          return button;
        }

        function ensureToolbar() {
          if (toolbar && toolbar.isConnected) return toolbar;
          toolbar = doc.createElement('div');
          toolbar.className = 'label-text-rte-toolbar';
          toolbar.setAttribute('data-label-rte-ui', 'true');
          toolbar.setAttribute('data-open', 'false');

          var format = doc.createElement('select');
          ['DIV', 'P', 'H1', 'H2', 'H3'].forEach(function(tag) {
            var option = doc.createElement('option');
            option.value = tag;
            option.textContent = tag.charAt(0) + tag.slice(1).toLowerCase();
            format.appendChild(option);
          });
          format.addEventListener('mousedown', function(event) {
            event.stopPropagation();
          });
          format.addEventListener('change', function(event) {
            event.preventDefault();
            event.stopPropagation();
            runCommand('formatBlock', '<' + format.value.toLowerCase() + '>');
          });
          toolbar.appendChild(format);
          toolbar.appendChild(makeButton('B', 'bold', 'label-rte-bold'));
          toolbar.appendChild(makeButton('I', 'italic', 'label-rte-italic'));
          toolbar.appendChild(makeButton('U', 'underline', 'label-rte-underline'));
          toolbar.appendChild(makeIconButton(
            '<svg viewBox="0 0 24 24" fill="none"><path d="M10.6 13.4a4 4 0 0 0 5.66 0l2.14-2.14a4 4 0 1 0-5.66-5.66L11.5 6.84" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M13.4 10.6a4 4 0 0 0-5.66 0L5.6 12.74a4 4 0 1 0 5.66 5.66l1.24-1.24" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
            'createLink',
            'Link'
          ));
          toolbar.appendChild(makeIconButton(
            '<svg viewBox="0 0 24 24" fill="none"><path d="M9 6h11M9 12h11M9 18h11" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="4" cy="6" r="1.25" fill="currentColor"/><circle cx="4" cy="12" r="1.25" fill="currentColor"/><circle cx="4" cy="18" r="1.25" fill="currentColor"/></svg>',
            'insertUnorderedList',
            'Bulleted list'
          ));
          toolbar.appendChild(makeButton('S', 'strikeThrough', 'label-rte-strike'));

          doc.body.appendChild(toolbar);
          return toolbar;
        }

        function startEditing(event) {
          if (model.get('selectable') === false) return;
          if (event) {
            event.preventDefault();
            event.stopPropagation();
          }
          if (editing) return;
          editing = true;
          element.setAttribute('contenteditable', 'true');
          element.setAttribute('data-label-editing', 'true');
          element.focus();
          ensureToolbar().setAttribute('data-open', 'true');
          positionToolbar();
          if (!resizeObserver && typeof win.ResizeObserver === 'function') {
            resizeObserver = new win.ResizeObserver(positionToolbar);
            resizeObserver.observe(element);
          }
          saveSelection();
          updateToolbarState();
        }

        function finishEditing() {
          if (!editing) return;
          persistFromDom(true);
          editing = false;
          savedRange = null;
          element.removeAttribute('contenteditable');
          element.removeAttribute('data-label-editing');
          if (toolbar) toolbar.setAttribute('data-open', 'false');
          if (resizeObserver) {
            resizeObserver.disconnect();
            resizeObserver = null;
          }
        }

        function onBlur() {
          win.setTimeout(function() {
            if (!editing) return;
            if (toolbar && toolbar.contains(doc.activeElement)) return;
            finishEditing();
          }, 0);
        }

        function onKeyDown(event) {
          if (event.key === 'Escape') {
            event.preventDefault();
            finishEditing();
            return;
          }
          if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'b') {
            event.preventDefault();
            runCommand('bold');
          }
          if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'i') {
            event.preventDefault();
            runCommand('italic');
          }
          if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'u') {
            event.preventDefault();
            runCommand('underline');
          }
        }

        function onPaste(event) {
          if (!editing) return;
          event.preventDefault();
          var text = '';
          try { text = event.clipboardData.getData('text/plain'); } catch (_) {}
          try { doc.execCommand('insertText', false, text); } catch (_) {}
          persistFromDom(false);
        }

        function onDocumentPointerDown(event) {
          if (!editing) return;
          var target = event.target;
          if (element.contains(target)) return;
          if (toolbar && toolbar.contains(target)) return;
          finishEditing();
        }

        function onInput() { persistFromDom(false); }
        function onMouseUp() { saveSelection(); updateToolbarState(); }

        element.addEventListener('dblclick', startEditing);
        element.addEventListener('input', onInput);
        element.addEventListener('blur', onBlur);
        element.addEventListener('keydown', onKeyDown);
        element.addEventListener('keyup', saveSelection);
        element.addEventListener('mouseup', onMouseUp);
        element.addEventListener('paste', onPaste);
        doc.addEventListener('selectionchange', saveSelection);
        doc.addEventListener('pointerdown', onDocumentPointerDown, true);
        win.addEventListener('resize', positionToolbar);
        win.addEventListener('scroll', positionToolbar, true);

        function onTextChange() { syncFromModel(); }
        function onHtmlChange() { syncFromModel(); }
        function onColorChange() { syncVisualTraits(); }
        model.on('change:text', onTextChange);
        model.on('change:labelHtml', onHtmlChange);
        model.on('change:color', onColorChange);
        model.on('change:borderColor', onColorChange);
        model.on('change:traits', onColorChange);

        syncFromModel();
        syncVisualTraits();

        model.__labelTextCleanup = function() {
          try { finishEditing(); } catch (_) {}
          disposed = true;
          element.removeEventListener('dblclick', startEditing);
          element.removeEventListener('input', onInput);
          element.removeEventListener('blur', onBlur);
          element.removeEventListener('keydown', onKeyDown);
          element.removeEventListener('keyup', saveSelection);
          element.removeEventListener('mouseup', onMouseUp);
          element.removeEventListener('paste', onPaste);
          doc.removeEventListener('selectionchange', saveSelection);
          doc.removeEventListener('pointerdown', onDocumentPointerDown, true);
          win.removeEventListener('resize', positionToolbar);
          win.removeEventListener('scroll', positionToolbar, true);
          if (resizeObserver) {
            resizeObserver.disconnect();
            resizeObserver = null;
          }
          model.off('change:text', onTextChange);
          model.off('change:labelHtml', onHtmlChange);
          model.off('change:color', onColorChange);
          model.off('change:borderColor', onColorChange);
          model.off('change:traits', onColorChange);
          if (toolbar && toolbar.parentNode) toolbar.parentNode.removeChild(toolbar);
          toolbar = null;
        };
      }

      if (typeof model !== 'undefined') {
        initLabelText(model, this);
      }
    `,
  styleConfig: {
    target: '.label-text',
    sectors: []
  }
};
