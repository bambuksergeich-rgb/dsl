import { ComponentConfig } from '../elements';

export const News: ComponentConfig = {
  id: 'news',
  type: 'news',
  label: 'News',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: { class: 'news-wrapper' },
    components: [
      {
        tagName: 'h2',
        attributes: { class: 'news-header' },
        content: 'Scrollable medium',
        droppable: false,
        draggable: false,
        selectable: true,
        hidden: true
      },
      {
        tagName: 'div',
        attributes: { class: 'news-content' },
        components: [
          ...Array(6).map((_, i) => ({
            type: 'news-item',
            attributes: { class: 'news-item', 'data-item-index': `${i}` },
            components: [
              {
                tagName: 'img',
                attributes: {
                  src: 'https://via.placeholder.com/150',
                  alt: `News ${i + 1}`
                },
                droppable: true,
                draggable: false
              },
              {
                tagName: 'h3',
                content: `News ${i + 1}`,
                droppable: true,
                draggable: false
              },
              {
                tagName: 'p',
                content: 'Description',
                droppable: true,
                draggable: false
              }
            ]
          }))
        ],
        droppable: false,
        draggable: false,
        selectable: true
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M21.2727 24H2.72727C2.00396 24 1.31026 23.7252 0.7988 23.2359C0.287337 22.7467 0 22.0832 0 21.3913V0.521739C0 0.383365 0.0574673 0.250659 0.15976 0.152814C0.262052 0.0549688 0.400791 0 0.545455 0H19.0909C19.2356 0 19.3743 0.0549688 19.4766 0.152814C19.5789 0.250659 19.6364 0.383365 19.6364 0.521739V7.82609H23.4545C23.5992 7.82609 23.7379 7.88106 23.8402 7.9789C23.9425 8.07675 24 8.20945 24 8.34783V21.3913C24 22.0832 23.7127 22.7467 23.2012 23.2359C22.6897 23.7252 21.996 24 21.2727 24ZM18.5455 21.3913V1.04348H1.09091V21.3913C1.09091 21.8064 1.26331 22.2045 1.57019 22.4981C1.87707 22.7916 2.29328 22.9565 2.72727 22.9565H19.1029C18.7432 22.5071 18.5474 21.9573 18.5455 21.3913ZM22.9091 8.86957H19.6364V21.3913C19.6364 21.8064 19.8088 22.2045 20.1156 22.4981C20.4225 22.7916 20.8387 22.9565 21.2727 22.9565C21.7067 22.9565 22.1229 22.7916 22.4298 22.4981C22.7367 22.2045 22.9091 21.8064 22.9091 21.3913V8.86957ZM2.72727 20.3478C2.72727 20.2095 2.78474 20.0767 2.88703 19.9789C2.98933 19.8811 3.12806 19.8261 3.27273 19.8261H8.18182C8.32648 19.8261 8.46522 19.8811 8.56751 19.9789C8.66981 20.0767 8.72727 20.2095 8.72727 20.3478C8.72727 20.4862 8.66981 20.6189 8.56751 20.7168C8.46522 20.8146 8.32648 20.8696 8.18182 20.8696H3.27273C3.12806 20.8696 2.98933 20.8146 2.88703 20.7168C2.78474 20.6189 2.72727 20.4862 2.72727 20.3478ZM5.27236 11.8513C5.2235 11.9011 5.16467 11.941 5.09937 11.9686C5.03407 11.9962 4.96364 12.011 4.89225 12.0121C4.82086 12.0132 4.74998 12.0005 4.6838 11.9749C4.61763 11.9492 4.55751 11.9111 4.50703 11.8628C4.45654 11.8146 4.41671 11.7571 4.38991 11.6938C4.36311 11.6305 4.34988 11.5627 4.35101 11.4944C4.35213 11.4261 4.36759 11.3587 4.39646 11.2963C4.42534 11.2338 4.46704 11.1775 4.51909 11.1308L7.74 8.04991C7.75471 8.0235 7.77206 7.99851 7.79182 7.9753C7.8976 7.88071 8.03701 7.82809 8.18182 7.82809C8.32663 7.82809 8.46603 7.88071 8.57182 7.9753C8.59139 7.99864 8.60873 8.02361 8.62364 8.04991L10.9091 10.236L12.1036 9.09339C12.1183 9.06698 12.1357 9.04199 12.1555 9.01878C12.2074 8.95721 12.2745 8.9089 12.3507 8.87816C12.4269 8.84741 12.5099 8.83519 12.5923 8.84258C12.6747 8.84997 12.7538 8.87673 12.8227 8.9205C12.8917 8.96426 12.9482 8.02366 12.9873 9.09339L15.1173 11.1308C15.1693 11.1775 15.211 11.2338 15.2399 11.2963C15.2688 11.3587 15.2842 11.4261 15.2854 11.4944C15.2865 11.5627 15.2733 11.6305 15.2465 11.6938C15.2196 11.7571 15.1798 11.8146 15.1293 11.8628C15.0789 11.9111 15.0187 11.9492 14.9526 11.9749C14.8864 12.0005 14.8155 12.0132 14.7441 12.0121C14.6727 12.011 14.6023 11.9962 14.537 11.9686C14.4717 11.941 14.4129 11.9011 14.364 11.8513L12.5455 10.1118L11.6624 10.9565L11.8445 11.1308C11.8966 11.1775 11.9383 11.2338 11.9672 11.2963C11.996 11.3587 12.0115 11.4261 12.0126 11.4944C12.0138 11.5627 12.0005 11.6305 11.9737 11.6938C11.9469 11.7571 11.9071 11.8146 11.8566 11.8628C11.8061 11.9111 11.746 11.9492 11.6798 11.9749C11.6137 12.0005 11.5428 12.0132 11.4714 12.0121C11.4 12.011 11.3296 11.9962 11.2643 11.9686C11.199 11.941 11.1401 11.9011 11.0913 11.8513L8.18182 9.06835L5.27236 11.8513ZM11.4545 14.6087H16.3636C16.5083 14.6087 16.647 14.6637 16.7493 14.7615C16.8516 14.8594 16.9091 14.9921 16.9091 15.1304C16.9091 15.2688 16.8516 15.4015 16.7493 15.4994C16.647 15.5972 16.5083 15.6522 16.3636 15.6522H11.4545C11.3099 15.6522 11.1711 15.5972 11.0689 15.4994C10.9666 15.4015 10.9091 15.2688 10.9091 15.1304C10.9091 14.9921 10.9666 14.8594 11.0689 14.7615C11.1711 14.6637 11.3099 14.6087 11.4545 14.6087ZM11.4545 17.2174H16.3636C16.5083 17.2174 16.647 17.2724 16.7493 17.3702C16.8516 17.4681 16.9091 17.6008 16.9091 17.7391C16.9091 17.8775 16.8516 18.0102 16.7493 18.1081C16.647 18.2059 16.5083 18.2609 16.3636 18.2609H11.4545C11.3099 18.2609 11.1711 18.2059 11.0689 18.1081C10.9666 18.0102 10.9091 17.8775 10.9091 17.7391C10.9091 17.6008 10.9666 17.4681 11.0689 17.3702C11.1711 17.2724 11.3099 17.2174 11.4545 17.2174ZM11.4545 19.8261H16.3636C16.5083 19.8261 16.647 19.8811 16.7493 19.9789C16.8516 20.0767 16.9091 20.2095 16.9091 20.3478C16.9091 20.4862 16.8516 20.6189 16.7493 20.7168C16.647 20.8146 16.5083 20.8696 16.3636 20.8696H11.4545C11.3099 20.8696 11.1711 20.8146 11.0689 20.7168C10.9666 20.6189 10.9091 20.4862 10.9091 20.3478C10.9091 20.2095 10.9666 20.0767 11.0689 19.9789C11.1711 19.8811 11.3099 19.8261 11.4545 19.8261ZM12 7.56522C12 7.72 11.952 7.87131 11.8621 8.00001C11.7722 8.12871 11.6444 8.22902 11.4949 8.28825C11.3454 8.34749 11.1809 8.36299 11.0222 8.33279C10.8635 8.30259 10.7177 8.22806 10.6033 8.1186C10.4889 8.00916 10.4109 7.86971 10.3794 7.7179C10.3478 7.56609 10.364 7.40873 10.4259 7.26573C10.4878 7.12272 10.5927 7.0005 10.7273 6.9145C10.8618 6.82851 11.02 6.78261 11.1818 6.78261C11.3988 6.78261 11.6069 6.86506 11.7604 7.01183C11.9138 7.1586 12 7.35766 12 7.56522ZM13.6364 4.69565H6C5.85534 4.69565 5.7166 4.64068 5.61431 4.54284C5.51201 4.44499 5.45455 4.31229 5.45455 4.17391C5.45455 4.03554 5.51201 3.90283 5.61431 3.80499C5.7166 3.70714 5.85534 3.65217 6 3.65217H13.6364C13.781 3.65217 13.9198 3.70714 14.0221 3.80499C14.1244 3.90283 14.1818 4.03554 14.1818 4.17391C14.1818 4.31229 14.1244 4.44499 14.0221 4.54284C13.9198 4.64068 13.781 4.69565 13.6364 4.69565ZM3.27273 17.2174H8.18182C8.32648 17.2174 8.46522 17.2724 8.56751 17.3702C8.66981 17.4681 8.72727 17.6008 8.72727 17.7391C8.72727 17.8775 8.66981 18.0102 8.56751 18.1081C8.46522 18.2059 8.32648 18.2609 8.18182 18.2609H3.27273C3.12806 18.2609 2.98933 18.2059 2.88703 18.1081C2.78474 18.0102 2.72727 17.8775 2.72727 17.7391C2.72727 17.6008 2.78474 17.4681 2.88703 17.3702C2.98933 17.2724 3.12806 17.2174 3.27273 17.2174ZM8.72727 15.1304C8.72727 15.2688 8.66981 15.4015 8.56751 15.4994C8.46522 15.5972 8.32648 15.6522 8.18182 15.6522H3.27273C3.12806 15.6522 2.98933 15.5972 2.88703 15.4994C2.78474 15.4015 2.72727 15.2688 2.72727 15.1304C2.72727 14.9921 2.78474 14.8594 2.88703 14.7615C2.98933 14.6637 3.12806 14.6087 3.27273 14.6087H8.18182C8.32648 14.6087 8.46522 14.6637 8.56751 14.7615C8.66981 14.8594 8.72727 14.9921 8.72727 15.1304Z" fill="white"/>
  </svg>`,
  traits: [
    {
      id: 'cards',
      name: 'cards',
      label: 'News Cards',
      type: 'json',
      changeProp: true,
      value: JSON.stringify([
        ...Array(6).map((_, i) => ({
          title: `News ${i + 1}`,
          description: 'Description',
          image: 'https://via.placeholder.com/150'
        }))
      ])
    },
    {
      id: 'scrollable',
      name: 'scrollable',
      type: 'checkbox',
      label: 'Scrollable',
      value: false,
      changeProp: true
    },
    {
      id: 'page',
      name: 'page',
      label: 'Full Page',
      type: 'checkbox',
      changeProp: true,
      value: false
    },
    {
      id: 'header',
      name: 'header',
      label: 'Header',
      type: 'text',
      changeProp: true,
      value: 'Scrollable medium'
    },
    {
      id: 'pageType',
      name: 'pageType',
      label: 'Page Type',
      type: 'select',
      changeProp: true,
      value: 'Home',
      options: [
        {
          value: 'Home',
          label: 'Home',
          id: '',
          name: ''
        },
        {
          value: 'Blog',
          label: 'Blog',
          id: '',
          name: ''
        },
        {
          value: 'About',
          label: 'About',
          id: '',
          name: ''
        },
        {
          value: 'Contact',
          label: 'Contact',
          id: '',
          name: ''
        }
      ]
    },
    {
      id: 'addItem',
      name: 'addItem',
      label: 'Add Item',
      type: 'button',
      command: 'add-news-item'
    },
    {
      id: 'removeLastItem',
      name: 'removeLastItem',
      label: 'Remove Last Item',
      type: 'button',
      command: 'remove-last-news-item'
    }
  ],
  styleConfig: {
    sectors: [
      {
        id: 'Style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'border-color',
            name: 'Border Color',
            property: 'border-color',
            type: 'color',
            default: '#3D3AB8'
          },
          {
            id: 'background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: '#10161C80'
          },
          {
            id: 'border-width',
            name: 'Border Width',
            property: 'border-width',
            type: 'number',
            default: '2',
            units: ['px']
          },
          {
            id: 'border-style',
            name: 'Border Type',
            property: 'border-style',
            type: 'select',
            default: 'solid',
            options: [
              {
                value: 'solid',
                label: 'Solid',
                id: '',
                name: ''
              },
              {
                value: 'dashed',
                label: 'Dashed',
                id: '',
                name: ''
              },
              {
                value: 'dotted',
                label: 'Dotted',
                id: '',
                name: ''
              },
              {
                value: 'none',
                label: 'None',
                id: '',
                name: ''
              }
            ]
          },
          {
            id: 'item-border-color',
            name: 'Item Border Color',
            property: '--item-border-color',
            type: 'color',
            default: '#FFFFFF26'
          },
          {
            id: 'item-border-width',
            name: 'Item Border Width',
            property: '--item-border-width',
            type: 'number',
            default: '1',
            units: ['px']
          },
          {
            id: 'item-border-style',
            name: 'Item Border Type',
            property: '--item-border-style',
            type: 'select',
            default: 'solid',
            options: [
              {
                value: 'solid',
                label: 'Solid',
                id: '',
                name: ''
              },
              {
                value: 'dashed',
                label: 'Dashed',
                id: '',
                name: ''
              },
              {
                value: 'dotted',
                label: 'Dotted',
                id: '',
                name: ''
              },
              {
                value: 'none',
                label: 'None',
                id: '',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'Dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            default: '50%',
            units: ['px', '%']
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            default: '752px',
            units: ['px', '%']
          }
        ]
      },
      {
        id: 'Item Text',
        name: 'Item Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: '--item-font-size',
            type: 'number',
            default: '16',
            units: ['px']
          },
          {
            id: 'item-text-color',
            name: 'Text Color',
            property: '--item-text-color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  },
  styles: `
    .news-wrapper {
      width: var(--width, auto);
      min-width: var(--min-width, 50%);
      max-width: var(--max-width, 752px);
      padding: 0;
      background-color: var(--background-color, #10161C80);
      border: var(--border-width, 2px) var(--border-style, solid) var(--border-color, #3D3AB8);
      border-radius: 12px;
      text-align: left;
      display: flex;
      flex-direction: column;
      overflow-Y: var(--scrollable, hidden);
      overflow-x: visible !important;
      -webkit-overflow-scrolling: touch; /* Плавная прокрутка на мобильных */
      scrollbar-width: none; /* Для Firefox */
      -ms-overflow-style: none; /* Для IE/Edge */
    }

    .news-wrapper::-webkit-scrollbar {
          display: none;
        }

    .news-wrapper.full-page {
      width: 100%;
      min-width: 100%;
      max-width: 100%;
    }
    .news-header {
      padding: 16px;
      margin: 0;
      font-size: 24px;
      color: var(--item-text-color, #FFFFFF);
      display: none;
      text-align:center;
    }
    .news-content {
      padding: 16px;
      flex: 1;
      overflow-y: var(--scrollable, auto);
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .news-item {
      background-color: #10161C80;
      border: var(--item-border-width, 1px) var(--item-border-style, solid) var(--item-border-color, #FFFFFF26);
      border-radius: 8px;
      padding: 16px;
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 16px;
      min-height: 100px;
    }
    .news-item img {
      width: 100px;
      height: 100px;
      object-fit: cover;
      border-radius: 4px;
    }
    .news-item h3 {
      margin: 0;
      font-size: var(--item-font-size, 16px);
      color: var(--item-text-color, #FFFFFF26);
    }
    .news-item p {
      margin: 8px 0 0;
      color: var(--item-text-color, #FFFFFF26);
      font-size: calc(var(--item-font-size, 16px) - 2px);
    }
    @media (max-width: 600px) {
      .news-wrapper {
        min-width: 100%;
        width: 100%;
        max-width: none;
      }
      .news-item {
        flex-direction: column;
        align-items: flex-start;
        text-align: left;
      }
      .news-item img {
        width: 100%;
        height: auto;
      }
    }
  `,
  script: `
    function updateNews(model, editor) {
      console.log('updateNews called:', model.changed);
      if (!model || !model.getEl() || !editor) {
        console.error('No model, editor, or wrapper element:', { model, editor, el: model?.getEl() });
        return;
      }
      const wrapper = model.getEl();
      const traits = model.getTraits();
      try {
        const contentEl = wrapper.querySelector('.news-content');
        const headerEl = wrapper.querySelector('.news-header');
        if (!contentEl) {
          console.error('Missing news-content element');
          return;
        }
        const cardsTrait = traits.find(t => t.getName() === 'cards');
        const scrollable = model.getTrait('scrollable')?.getValue() ? 'auto' : 'hidden';
        const page = traits.find(t => t.getName() === 'page')?.getValue() || false;
        const header = traits.find(t => t.getName() === 'header')?.getValue() || 'Scrollable medium';
        const pageType = traits.find(t => t.getName() === 'pageType')?.getValue() || 'Home';

        // Устанавливаем стили и атрибуты
        wrapper.style.overflowY = scrollable;
        wrapper.setAttribute('data-page-type', pageType);
        if (page) {
          wrapper.classList.add('full-page');
        } else {
          wrapper.classList.remove('full-page');
        }

        // Обновляем заголовок
        if (headerEl) {
          headerEl.textContent = header;
          headerEl.style.display = header ? 'block' : 'none';
        }

        // Устанавливаем стили из styleConfig
        const styles = model.getStyle() || {};
        wrapper.style.setProperty('--width', page ? '100%' : (styles.width || 'auto'));
        wrapper.style.setProperty('--min-width', page ? '100%' : (styles['min-width'] || '50%'));
        wrapper.style.setProperty('--max-width', page ? '100%' : (styles['max-width'] || '752px'));
        wrapper.style.setProperty('--background-color', styles['background-color'] || '#10161C80');
        wrapper.style.setProperty('--border-color', styles['border-color'] || '#3D3AB8');
        wrapper.style.setProperty('--border-width', styles['border-width'] || '2px');
        wrapper.style.setProperty('--border-style', styles['border-style'] || 'solid');
        wrapper.style.setProperty('--item-border-color', styles['--item-border-color'] || '#FFFFFF26');
        wrapper.style.setProperty('--item-border-width', styles['--item-border-width'] || '1px');
        wrapper.style.setProperty('--item-border-style', styles['--item-border-style'] || 'solid');
        wrapper.style.setProperty('--item-font-size', styles['--item-font-size'] || '16px');
        wrapper.style.setProperty('--item-text-color', styles['--item-text-color'] || '#FFFFFF26');

        // Получаем текущее содержимое элементов
        let cardsData = [];
        try {
          cardsData = cardsTrait?.getValue() ? JSON.parse(cardsTrait.getValue()) : [
            ...Array.from({ length: 6 }, (_, i) => ({
              title: \`News \${i + 1}\`,
              description: 'Description',
              image: 'https://via.placeholder.com/150'
            }))
          ];
        } catch (e) {
          console.error('Invalid JSON in cards trait:', e);
          cardsData = [
            ...Array.from({ length: 6 }, (_, i) => ({
              title: \`News \${i + 1}\`,
              description: 'Description',
              image: 'https://via.placeholder.com/150'
            }))
          ];
        }

        // Проверяем текущее содержимое DOM
        const existingItems = Array.from(wrapper.querySelectorAll('.news-item')).map(itemEl => {
          const imgEl = itemEl.querySelector('img');
          const h3El = itemEl.querySelector('h3');
          const pEl = itemEl.querySelector('p');
          return {
            image: imgEl?.src || 'https://via.placeholder.com/150',
            title: h3El?.textContent || '',
            description: pEl?.textContent || ''
          };
        });

        // Обновляем только если данные изменились
        if (JSON.stringify(existingItems) !== JSON.stringify(cardsData)) {
          console.log('Cards data changed, updating DOM');
          contentEl.innerHTML = '';
          model.find('.news-content')[0].components().reset();

          cardsData.forEach((item, index) => {
            model.find('.news-content')[0].append({
              type: 'news-item',
              attributes: { class: 'news-item', 'data-item-index': index },
              components: [
                {
                  tagName: 'img',
                  attributes: {
                    src: item.image || 'https://via.placeholder.com/150',
                    alt: item.title || \`News \${index + 1}\`
                  },
                  droppable: true,
                  draggable: false
                },
                {
                  tagName: 'h3',
                  content: item.title || \`News \${index + 1}\`,
                  droppable: true,
                  draggable: false
                },
                {
                  tagName: 'p',
                  content: item.description || 'Description',
                  droppable: true,
                  draggable: false
                }
              ],
              droppable: true,
              draggable: false
            });
          });
        } else {
          console.log('No changes in cards data, skipping DOM update');
        }

        console.log('News updated:', { cardsData, scrollable, page, header, pageType });
      } catch (e) {
        console.error('Error updating news:', e);
      }
    }

    // Регистрируем обработчики событий один раз
    editor.Commands.add('add-news-item', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component || component.get('type') !== 'news') {
          editor.Modal.open({ title: 'Ошибка', content: 'Выберите компонент News.' });
          return;
        }
        const cardsTrait = component.getTrait('cards');
        let cardsData = [];
        try {
          cardsData = JSON.parse(cardsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing cards JSON:', e);
        }
        if (cardsData.length >= 20) {
          editor.Modal.open({ title: 'Ошибка', content: 'Максимум 20 элементов.' });
          return;
        }
        cardsData.push({
          title: \`News \${cardsData.length + 1}\`,
          description: 'Description',
          image: 'https://via.placeholder.com/150'
        });
        cardsTrait.setValue(JSON.stringify(cardsData));
        console.log('Card added:', cardsData);
        updateNews(component, editor);
        editor.Modal.open({ title: 'Успех', content: 'Элемент успешно добавлен!' });
      }
    });

    editor.Commands.add('remove-last-news-item', {
      run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component || component.get('type') !== 'news') {
          editor.Modal.open({ title: 'Ошибка', content: 'Выберите компонент News.' });
          return;
        }
        const cardsTrait = component.getTrait('cards');
        let cardsData = [];
        try {
          cardsData = JSON.parse(cardsTrait.getValue() || '[]');
        } catch (e) {
          console.error('Error parsing cards JSON:', e);
        }
        if (cardsData.length <= 1) {
          editor.Modal.open({ title: 'Ошибка', content: 'Должен остаться хотя бы один элемент.' });
          return;
        }
        cardsData.pop();
        cardsTrait.setValue(JSON.stringify(cardsData));
        console.log('Last card removed:', cardsData);
        updateNews(component, editor);
        editor.Modal.open({ title: 'Успех', content: 'Последний элемент успешно удален!' });
      }
    });

    // Регистрируем обработчики событий один раз при инициализации
    if (model && model.getEl()) {
      console.log('Initial updateNews call');
      const cardsTrait = model.getTrait('cards');
      editor.off('component:add component:remove component:update');
      editor.on('component:add component:remove component:update', (component) => {
        if (component.closest('.news-content')) {
          const wrapper = model.getEl();
          const updatedCards = [];
          wrapper.querySelectorAll('.news-item').forEach((itemEl, i) => {
            const imgEl = itemEl.querySelector('img');
            const h3El = itemEl.querySelector('h3');
            const pEl = itemEl.querySelector('p');
            updatedCards.push({
              image: imgEl?.src || 'https://via.placeholder.com/150',
              title: h3El?.textContent || \`News \${i + 1}\`,
              description: pEl?.textContent || 'Description'
            });
          });
          cardsTrait.setValue(JSON.stringify(updatedCards));
          console.log('Cards data updated:', updatedCards);
          updateNews(model, editor);
        }
      });

      editor.off('trait:change');
      editor.on('trait:change', (trait) => {
        if (trait.getName() === 'cards') {
          let cardsData = [];
          try {
            cardsData = JSON.parse(trait.getValue() || '[]');
            if (cardsData.length > 20) {
              cardsData = cardsData.slice(0, 20);
              editor.Modal.open({ title: 'Предупреждение', content: 'Максимум 20 элементов.' });
              trait.setValue(JSON.stringify(cardsData));
            }
          } catch (e) {
            console.error('Error parsing cards JSON:', e);
          }
        }
        updateNews(model, editor);
        console.log('Trait updated:', trait.getName());
      });

      updateNews(model, editor);
    }

    model.on('change', () => {
      console.log('Model changed:', model.changed);
      updateNews(model, editor);
    });
  `
};
