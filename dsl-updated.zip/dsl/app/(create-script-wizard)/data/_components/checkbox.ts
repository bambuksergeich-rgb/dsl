import { ComponentConfig } from '../elements';

export const Checkbox: ComponentConfig = {
  id: 'single-checkbox',
  type: 'single-checkbox',
  label: 'Checkbox',
  category: 'Form',
  content: {
    tagName: 'div',
    attributes: {
      class: 'checkbox-wrapper axis-horizontal checkbox-position-left',
      'data-values': '["Check-box"]',
      'data-checked': 'true',
      data_type: 'Array',
      data: '["Check-box"]',
      text: 'Check-box'
    },
    components: [
      {
        tagName: 'div',
        attributes: {
          class: 'checkbox-option',
          'data-checkbox-value': 'Check-box'
        },
        components: [
          {
            tagName: 'input',
            attributes: {
              type: 'checkbox',
              class: 'checkbox-input',
              value: 'Check-box',
              checked: 'checked'
            },
            selectable: false,
            hoverable: false,
            highlightable: false,
            draggable: false,
            droppable: false,
            editable: false,
            resizable: false,
            layerable: false
          },
          {
            tagName: 'label',
            attributes: { class: 'checkbox-label' },
            content: 'Check-box',
            selectable: false,
            hoverable: false,
            highlightable: false,
            draggable: false,
            droppable: false,
            editable: false,
            resizable: false,
            layerable: false
          }
        ],
        selectable: false,
        hoverable: false,
        highlightable: false,
        draggable: false,
        droppable: false,
        editable: false,
        resizable: false,
        layerable: false
      }
    ],
    droppable: false,
    editable: false,
    selectable: true
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 12L11 15L16 9M4 16.8002V7.2002C4 6.08009 4 5.51962 4.21799 5.0918C4.40973 4.71547 4.71547 4.40973 5.0918 4.21799C5.51962 4 6.08009 4 7.2002 4H16.8002C17.9203 4 18.4796 4 18.9074 4.21799C19.2837 4.40973 19.5905 4.71547 19.7822 5.0918C20 5.5192 20 6.07899 20 7.19691V16.8036C20 17.9215 20 18.4805 19.7822 18.9079C19.5905 19.2842 19.2837 19.5905 18.9074 19.7822C18.48 20 17.921 20 16.8031 20H7.19691C6.07899 20 5.5192 20 5.0918 19.7822C4.71547 19.5905 4.40973 19.2842 4.21799 18.9079C4 18.4801 4 17.9203 4 16.8002Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  traits: [
    {
      id: 'options',
      name: 'options',
      label: 'Options',
      type: 'list',
      changeProp: true,
      value: JSON.stringify([{ value: 'Check-box', label: 'Check-box' }])
    },
    {
      id: 'axis',
      name: 'axis',
      label: 'Axis',
      type: 'select',
      changeProp: true,
      value: 'horizontal',
      options: [
        { id: 'horizontal', name: 'Horizontal', value: 'horizontal' },
        { id: 'vertical', name: 'Vertical', value: 'vertical' }
      ]
    },
    {
      id: 'button-position',
      name: 'buttonPosition',
      label: 'Button Position',
      type: 'select',
      changeProp: true,
      value: 'left',
      options: [
        { id: 'left', name: 'Left', value: 'left' },
        { id: 'right', name: 'Right', value: 'right' },
        { id: 'top', name: 'Top', value: 'top' },
        { id: 'bottom', name: 'Bottom', value: 'bottom' }
      ]
    }
  ],
  styles: `
    .checkbox-wrapper {
      width: fit-content;
      min-width: 32px;
      min-height: 32px;
      height: fit-content;
      box-sizing: border-box;
      display: inline-flex;
      align-items: flex-start;
      gap: 10px;
      font-family: 'Montserrat', sans-serif;
      --checkbox-color: #4170FF;
      --checkbox-width: 20px;
      --checkbox-height: 20px;
      --label-color: #FFFFFF;
      --font-size: 14px;
    }
    .checkbox-wrapper.axis-horizontal {
      flex-direction: row;
      flex-wrap: wrap;
    }
    .checkbox-wrapper.axis-vertical {
      flex-direction: column;
    }
    .checkbox-option {
      display: inline-flex;
      align-items: center;
      justify-content: flex-start;
      gap: 8px;
      min-height: 28px;
      min-width: 0;
      box-sizing: border-box;
    }
    .checkbox-wrapper.checkbox-position-left .checkbox-option {
      flex-direction: row;
    }
    .checkbox-wrapper.checkbox-position-right .checkbox-option {
      flex-direction: row-reverse;
    }
    .checkbox-wrapper.checkbox-position-top .checkbox-option {
      flex-direction: column;
      align-items: flex-start;
    }
    .checkbox-wrapper.checkbox-position-bottom .checkbox-option {
      flex-direction: column-reverse;
      align-items: flex-start;
    }
    .checkbox-input {
      position: relative;
      margin: 0;
      cursor: pointer;
      width: var(--checkbox-width, 20px);
      height: var(--checkbox-height, 20px);
      min-width: 16px;
      min-height: 16px;
      max-width: 24px;
      max-height: 24px;
      appearance: none;
      -webkit-appearance: none;
      pointer-events: none;
      background: transparent;
      border: 2px solid var(--checkbox-color, #4170FF);
      border-radius: 4px;
      box-sizing: border-box;
      flex-shrink: 0;
    }
    .checkbox-input:checked {
      background: var(--checkbox-color, #4170FF);
      border-color: var(--checkbox-color, #4170FF);
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='none'%3E%3Cpath d='M3.5 8.5L6.5 11.5L12.5 4.5' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: center;
      background-size: 12px 12px;
    }
    .checkbox-input:focus-visible {
      outline: 2px solid rgba(65, 112, 255, .35);
      outline-offset: 2px;
    }
    .checkbox-label {
      cursor: pointer;
      user-select: none;
      white-space: nowrap;
      font-size: var(--font-size, 14px);
      line-height: 1.25;
      color: var(--label-color, #FFFFFF);
    }
  `,
  script: `
function normalizeCheckboxOptions(rawOptions) {
  if (!Array.isArray(rawOptions) || !rawOptions.length) {
    return [{ value: 'Check-box', label: 'Check-box' }];
  }
  return rawOptions
    .map(function(option, index) {
      if (option == null) return null;
      if (typeof option !== 'object') {
        const text = String(option).trim();
        return text ? { value: text, label: text } : null;
      }
      const label = String(option.label != null ? option.label : option.value != null ? option.value : '').trim();
      if (!label) return null;
      const value = String(option.value != null && option.value !== '' ? option.value : label).trim();
      return { value: value || label || ('Checkbox ' + (index + 1)), label: label };
    })
    .filter(Boolean);
}

function parseCheckboxOptions(raw) {
  if (Array.isArray(raw)) return normalizeCheckboxOptions(raw);
  if (typeof raw !== 'string' || !raw.trim()) return normalizeCheckboxOptions([]);
  try {
    return normalizeCheckboxOptions(JSON.parse(raw));
  } catch (e) {
    return normalizeCheckboxOptions([]);
  }
}

function readCheckboxOptions(model) {
  const trait = model.getTrait && model.getTrait('options');
  const fromTrait = parseCheckboxOptions(trait && trait.getValue ? trait.getValue() : '');
  if (fromTrait.length) return fromTrait;
  const attrs = model.getAttributes ? model.getAttributes() : {};
  const legacyText = String(attrs.text || '').trim();
  return normalizeCheckboxOptions(legacyText ? [legacyText] : []);
}

function normalizeSelectedCheckboxValues(raw, options) {
  let values = [];
  if (Array.isArray(raw)) {
    values = raw.map(function(item) { return String(item); });
  } else if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (trimmed) {
      try {
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) values = parsed.map(function(item) { return String(item); });
        else if (parsed === true && options[0]) values = [options[0].value];
      } catch (e) {
        if (trimmed === 'true' && options[0]) values = [options[0].value];
        else if (trimmed !== 'false') values = [trimmed];
      }
    }
  } else if ((raw === true || raw === 1) && options[0]) {
    values = [options[0].value];
  }
  const allowed = new Set(options.map(function(option) { return option.value; }));
  return values.filter(function(value, index, array) {
    return allowed.has(value) && array.indexOf(value) === index;
  });
}

function readSelectedCheckboxValues(model, options) {
  const attrs = model.getAttributes ? model.getAttributes() : {};
  const fromModel = model.get && model.get('checkboxValues');
  if (Array.isArray(fromModel)) return normalizeSelectedCheckboxValues(fromModel, options);
  if (attrs['data-values'] != null && attrs['data-values'] !== '') {
    return normalizeSelectedCheckboxValues(attrs['data-values'], options);
  }
  if (attrs.data != null && attrs.data !== '') {
    const selected = normalizeSelectedCheckboxValues(attrs.data, options);
    if (selected.length || String(attrs.data).trim() === '[]') return selected;
  }
  if (attrs['data-checked'] != null) {
    return normalizeSelectedCheckboxValues(attrs['data-checked'], options);
  }
  return [];
}

function writeSelectedCheckboxValues(model, values) {
  const options = readCheckboxOptions(model);
  const normalized = normalizeSelectedCheckboxValues(values, options);
  if (model.get && model.set) {
    const current = model.get('checkboxValues');
    if (JSON.stringify(current || []) !== JSON.stringify(normalized)) {
      model.set('checkboxValues', normalized);
    }
  }
  if (model.addAttributes) {
    const serialized = JSON.stringify(normalized);
    model.addAttributes({
      'data-values': serialized,
      'data-checked': normalized.length ? 'true' : 'false',
      data: serialized,
      data_type: 'Array'
    });
  }
  return normalized;
}

function checkboxOptionDefinition(option) {
  return {
    tagName: 'div',
    attributes: {
      class: 'checkbox-option',
      'data-checkbox-value': option.value
    },
    components: [
      {
        tagName: 'input',
        attributes: {
          type: 'checkbox',
          class: 'checkbox-input',
          value: option.value
        },
        selectable: false,
        hoverable: false,
        highlightable: false,
        draggable: false,
        droppable: false,
        editable: false,
        resizable: false,
        layerable: false
      },
      {
        tagName: 'label',
        attributes: { class: 'checkbox-label' },
        content: option.label,
        selectable: false,
        hoverable: false,
        highlightable: false,
        draggable: false,
        droppable: false,
        editable: false,
        resizable: false,
        layerable: false
      }
    ],
    selectable: false,
    hoverable: false,
    highlightable: false,
    draggable: false,
    droppable: false,
    editable: false,
    resizable: false,
    layerable: false
  };
}

function ensureCheckboxOptionChildren(optionModel, option) {
  if (!optionModel) return;
  const attrs = optionModel.getAttributes ? optionModel.getAttributes() : {};
  optionModel.addAttributes && optionModel.addAttributes({
    ...attrs,
    class: 'checkbox-option',
    'data-checkbox-value': option.value
  });
  optionModel.set && optionModel.set({
    selectable: false,
    hoverable: false,
    highlightable: false,
    draggable: false,
    droppable: false,
    editable: false,
    resizable: false,
    layerable: false
  });

  const children = optionModel.components && optionModel.components();
  let inputModel = optionModel.find && optionModel.find('.checkbox-input')[0];
  let labelModel = optionModel.find && optionModel.find('.checkbox-label')[0];
  if (!inputModel || !labelModel) {
    if (children && children.reset) {
      const def = checkboxOptionDefinition(option);
      children.reset(def.components || []);
      inputModel = optionModel.find && optionModel.find('.checkbox-input')[0];
      labelModel = optionModel.find && optionModel.find('.checkbox-label')[0];
    }
  }
  if (inputModel) {
    const inputAttrs = inputModel.getAttributes ? inputModel.getAttributes() : {};
    inputModel.addAttributes && inputModel.addAttributes({
      ...inputAttrs,
      type: 'checkbox',
      class: 'checkbox-input',
      value: option.value
    });
    inputModel.set && inputModel.set({
      selectable: false,
      hoverable: false,
      highlightable: false,
      draggable: false,
      droppable: false,
      editable: false,
      resizable: false,
      layerable: false
    });
  }
  if (labelModel) {
    if (String(labelModel.get && labelModel.get('content') || '') !== option.label) {
      labelModel.set && labelModel.set('content', option.label);
    }
    labelModel.set && labelModel.set({
      selectable: false,
      hoverable: false,
      highlightable: false,
      draggable: false,
      droppable: false,
      editable: false,
      resizable: false,
      layerable: false
    });
  }
}

function syncCheckboxChildren(model, options) {
  const collection = model.components && model.components();
  if (!collection) return;
  let current = collection.models ? collection.models.slice() : [];

  // Migrate the previous one-input layout once. After migration the option
  // models are reconciled in place, so editing the list does not recreate the
  // entire Checkbox component or lose GrapesJS selection.
  if (current.length && current.some(function(child) {
    const attrs = child && child.getAttributes ? child.getAttributes() : {};
    return !String(attrs.class || '').split(/\\s+/).includes('checkbox-option');
  })) {
    current.forEach(function(child) {
      if (child && child.remove) child.remove();
      else if (collection.remove) collection.remove(child);
    });
  }

  options.forEach(function(option, index) {
    let child = collection.models && collection.models[index];
    if (!child) {
      if (model.append) model.append(checkboxOptionDefinition(option));
      child = collection.models && collection.models[index];
    }
    ensureCheckboxOptionChildren(child, option);
  });

  current = collection.models ? collection.models.slice() : [];
  for (let index = current.length - 1; index >= options.length; index -= 1) {
    const child = current[index];
    if (child && child.remove) child.remove();
    else if (collection.remove) collection.remove(child);
  }
}

function applyCheckboxLayout(model) {
  const wrapper = model.getEl && model.getEl();
  if (!wrapper) return;
  const axisTrait = model.getTrait && model.getTrait('axis');
  const positionTrait = model.getTrait && model.getTrait('buttonPosition');
  const axis = String(axisTrait && axisTrait.getValue ? axisTrait.getValue() : 'horizontal');
  const position = String(positionTrait && positionTrait.getValue ? positionTrait.getValue() : 'left');

  wrapper.classList.toggle('axis-vertical', axis === 'vertical');
  wrapper.classList.toggle('axis-horizontal', axis !== 'vertical');
  ['left', 'right', 'top', 'bottom'].forEach(function(item) {
    wrapper.classList.toggle('checkbox-position-' + item, position === item);
  });

  const styles = model.getStyle ? model.getStyle() || {} : {};
  const color = styles['checkbox-color'] || (model.getAttributes && model.getAttributes()['data-color']) || '#4170FF';
  wrapper.style.setProperty('--checkbox-color', color);
  wrapper.style.setProperty('--font-size', styles['font-size'] || '14px');
  wrapper.style.setProperty('--label-color', styles['text-color'] || '#FFFFFF');
}

function paintCheckboxes(model, options) {
  const wrapper = model.getEl && model.getEl();
  if (!wrapper) return;
  const selected = writeSelectedCheckboxValues(model, readSelectedCheckboxValues(model, options));
  const selectedSet = new Set(selected);
  wrapper.querySelectorAll('.checkbox-option').forEach(function(optionEl) {
    const value = String(optionEl.getAttribute('data-checkbox-value') || '');
    const input = optionEl.querySelector('.checkbox-input');
    const checked = selectedSet.has(value);
    optionEl.classList.toggle('active', checked);
    if (input) {
      input.checked = checked;
      if (checked) input.setAttribute('checked', 'checked');
      else input.removeAttribute('checked');
    }
  });
}

function updateCheckboxField(model, syncChildren) {
  if (!model || model.__updatingCheckboxField) return;
  model.__updatingCheckboxField = true;
  try {
    const options = readCheckboxOptions(model);
    if (syncChildren !== false) syncCheckboxChildren(model, options);
    applyCheckboxLayout(model);
    paintCheckboxes(model, options);
  } finally {
    model.__updatingCheckboxField = false;
  }
}

updateCheckboxField(model, true);

if (!model.__checkboxFieldBound) {
  model.__checkboxFieldBound = true;
  model.on('change:options', function() { updateCheckboxField(model, true); });
  model.on('change:axis change:buttonPosition change:styles change:style', function() {
    updateCheckboxField(model, false);
  });
  model.on('change:checkboxValues change:attributes', function() {
    updateCheckboxField(model, false);
  });
}

const checkboxRoot = model.getEl && model.getEl();
if (checkboxRoot && !checkboxRoot.__checkboxClickBound) {
  checkboxRoot.__checkboxClickBound = true;

  const stopEditorGesture = function(event) {
    const optionEl = event.target && event.target.closest && event.target.closest('.checkbox-option');
    if (!optionEl || !checkboxRoot.contains(optionEl)) return;
    event.stopPropagation();
  };
  checkboxRoot.addEventListener('pointerdown', stopEditorGesture);
  checkboxRoot.addEventListener('mousedown', stopEditorGesture);

  checkboxRoot.addEventListener('click', function(event) {
    const optionEl = event.target && event.target.closest && event.target.closest('.checkbox-option');
    if (!optionEl || !checkboxRoot.contains(optionEl)) return;
    const value = String(optionEl.getAttribute('data-checkbox-value') || '');
    if (!value) return;

    event.preventDefault();
    event.stopPropagation();
    const options = readCheckboxOptions(model);
    const current = readSelectedCheckboxValues(model, options);
    const selected = new Set(current);
    if (selected.has(value)) selected.delete(value);
    else selected.add(value);
    writeSelectedCheckboxValues(model, Array.from(selected));
    paintCheckboxes(model, options);
    try {
      const EventCtor = checkboxRoot.ownerDocument?.defaultView?.Event || Event;
      checkboxRoot.dispatchEvent(new EventCtor('input', { bubbles: true }));
      checkboxRoot.dispatchEvent(new EventCtor('change', { bubbles: true }));
    } catch (e) {}
  });
}
`,
  styleConfig: {
    sectors: [
      {
        id: 'checkbox-dimension',
        name: 'Checkbox Dimension',
        open: true,
        properties: [
          {
            id: 'checkbox-width',
            name: 'Box Width',
            property: 'checkbox-width',
            type: 'number',
            default: 20,
            units: ['px']
          },
          {
            id: 'checkbox-height',
            name: 'Box Height',
            property: 'checkbox-height',
            type: 'number',
            default: 20,
            units: ['px']
          }
        ]
      },
      {
        id: 'checkbox-text',
        name: 'Checkbox Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: 14,
            units: ['px']
          },
          {
            id: 'text-color',
            name: 'Text Color',
            property: 'text-color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  }
};
