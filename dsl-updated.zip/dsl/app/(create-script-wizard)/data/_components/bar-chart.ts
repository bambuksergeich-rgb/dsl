import { ComponentConfig } from '../elements';

export const BarChart: ComponentConfig = {
  id: 'bar-chart',
  type: 'bar-chart',
  label: 'Bar Chart',
  category: 'Charts',
  content: {
    tagName: 'div',
    attributes: {
      class: 'bar-chart-container w-full h-auto',
      'data-component-id': 'bar-chart',
      'data-chart-type': 'bar',
      'data-title': 'My Bar Chart'
    },
    components: [
      {
        tagName: 'canvas',
        attributes: {
          class: 'bar-chart-canvas',
          'data-chart-element': 'true'
        }
      }
    ],
    droppable: false,
    editable: true,
    selectable: true,
    resizable: {
      cr: true,
      bc: true,
      minDim: 200,
      maxDim: 1200,
      updateTarget: (el, rect, component) => {
        const canvas = el.querySelector('canvas');
        if (canvas) {
          canvas.style.maxWidth = `${rect.w}px`;
          canvas.style.maxHeight = `${rect.h}px`;
        }
      }
    }
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M10 4H14V20H10V4Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M14 9H18V20H14V9Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M6 13H10V20H6V13Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3 20H21" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`,
  traits: [
    {
      id: 'chart-type',
      name: 'chart-type',
      label: 'Chart Type',
      type: 'select',
      changeProp: true,
      options: [
        { id: 'bar', name: 'Vertical Bar', value: 'bar' },
        { id: 'horizontal', name: 'Horizontal Bar', value: 'horizontal' },
        {
          id: 'bar-stacked',
          name: 'Reversed Chart Multiple',
          value: 'bar-stacked'
        },
        {
          id: 'bar-table',
          name: 'Bar Chart  for Table',
          value: 'bar-table'
        }
      ],
      value: 'bar'
    },
    {
      id: 'title',
      name: 'title',
      label: 'Header',
      type: 'text',
      changeProp: true,
      value: 'My Bar Chart'
    },
    {
      id: 'sub-title',
      name: 'sub-title',
      label: 'Sub Header',
      type: 'text',
      changeProp: true,
      value: 'Values'
    },
    {
      id: 'chart-data',
      name: 'chart-data',
      label: 'Chart Data',
      type: 'json',
      changeProp: true,
      value: JSON.stringify([
        {
          id: 'layer-1',
          name: 'Layer 1',
          color: '#4170FF',
          points: [
            { label: 'Jan', value: 40, color: '#4170FF' },
            { label: 'Feb', value: 30, color: '#4170FF' },
            { label: 'Mar', value: 50, color: '#4170FF' }
          ]
        },
        {
          id: 'layer-2',
          name: 'Layer 2',
          color: '#FF6B6B',
          points: [
            { label: 'Jan', value: 20, color: '#FF6B6B' },
            { label: 'Feb', value: 25, color: '#FF6B6B' },
            { label: 'Mar', value: 15, color: '#FF6B6B' }
          ]
        }
      ])
    },
    {
      id: 'add-layer',
      name: 'add-layer',
      label: 'Add Layer',
      type: 'button',
      command: 'bar-chart:add-layer'
    },
    {
      id: 'remove-layer',
      name: 'remove-layer',
      label: 'Remove Layer',
      type: 'button',
      command: 'bar-chart:remove-layer'
    },
    {
      id: 'add-point',
      name: 'add-point',
      label: 'Add Point',
      type: 'button',
      command: 'bar-chart:add-point'
    },
    {
      id: 'remove-point',
      name: 'remove-point',
      label: 'Remove Point',
      type: 'button',
      command: 'bar-chart:remove-point'
    },
    {
      id: 'points-manager',
      name: 'points-manager',
      label: 'Points',
      type: 'custom-points',
      changeProp: false
    }
  ],
  styles: `
  .bar-chart-container {
    background-color: #10161C;
    border: 1px solid #4a5568;
    border-radius: 8px;
    padding: 20px;
    box-sizing: border-box;
    width: 100%;
    height: auto;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    font-family: 'Montserrat', sans-serif;
    overflow: hidden;

    /* CSS Variables */
    --chart-header-color: #ffffff;
    --chart-header-size: 16px;
    --chart-subheader-color: #a0aec0;
    --chart-subheader-size: 14px;
    --chart-grid-color: #ffffff;
    --chart-grid-size: 12px;
    --chart-info-color: #ffffff;
    --chart-info-size: 24px;
  }
  .bar-chart-canvas {
    width: 100% !important;
    height: 300px !important;
    min-width:100% !important;
    max-width: 100% !important;
  }
  /* Для Table-типов убираем фон через CSS-класс (добавляется скриптом или вручную, но лучше скрипт обработает стиль inline) */
  .bar-chart-container[data-chart-type="bar-table"],
  .bar-chart-container[data-chart-type="bar-line-table"] {
    background-color: transparent !important;
    border: none !important;
    box-shadow: none !important;
  }

  .gjs-resizer {
    background-color: #FF2D55 !important;
    border: 2px solid #FFD700 !important;
    z-index: 1000 !important;
    width: 16px !important;
    height: 16px !important;
    cursor: move !important;
    opacity: 1 !important;
    display: block !important;
  }
  @media (max-width: 600px) {
    .bar-chart-container { padding: 12px; }
    .bar-chart-canvas { height: 250px !important; }
  }
`,
  script: `
const loadScripts = [{ src: 'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js', global: 'Chart', fallback: 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.3/chart.umd.min.js' }];
let scriptsLoaded = false;
let chartInstance = null;

function getDefaultBarChartData() {
  return [
    { id: 'layer-1', name: 'Layer 1', color: '#4170FF', points: [{ label: 'Jan', value: 40, color: '#4170FF' }, { label: 'Feb', value: 30, color: '#4170FF' }, { label: 'Mar', value: 50, color: '#4170FF' }] },
    { id: 'layer-2', name: 'Layer 2', color: '#FF6B6B', points: [{ label: 'Jan', value: 20, color: '#FF6B6B' }, { label: 'Feb', value: 25, color: '#FF6B6B' }, { label: 'Mar', value: 15, color: '#FF6B6B' }] }
  ];
}

function loadScript(s) {
  return new Promise((res, rej) => {
    if (window[s.global]) { res(); return; }
    const e = document.createElement('script');
    e.src = s.src; e.async = true;
    e.onload = () => res();
    e.onerror = () => {
      if (s.fallback) {
        e.src = s.fallback; e.onload = () => res(); e.onerror = () => rej(new Error('Failed'));
        document.head.appendChild(e);
      } else { rej(new Error('Failed')); }
    };
    document.head.appendChild(e);
  });
}

function loadLibraries() {
  if (scriptsLoaded) return Promise.resolve();
  return Promise.all(loadScripts.map(loadScript)).then(() => { scriptsLoaded = true; });
}

function initBarChartEditor(model) {
  const container = model.getEl();
  if (!container) return;
  const canvas = container.querySelector('canvas');
  if (!canvas) return;

  const traits = model.getTraits();
  const chartType = traits.find(t => t.getName() === 'chart-type')?.getValue() || 'bar';
  const title = traits.find(t => t.getName() === 'title')?.getValue() || 'My Bar Chart';
  const subTitle = traits.find(t => t.getName() === 'sub-title')?.getValue() || 'Values';

  let chartData = [];
  try {
    const chartDataTrait = traits.find(t => t.getName() === 'chart-data');
    const chartDataValue = chartDataTrait?.getValue();
    chartData = JSON.parse(chartDataValue || '[]');
    if (!chartData.length) {
        chartData = getDefaultBarChartData();
        if (chartDataTrait) chartDataTrait.setValue(JSON.stringify(chartData));
    }
  } catch (e) { chartData = getDefaultBarChartData(); }

  container.setAttribute('data-chart-type', chartType);
  container.setAttribute('data-title', title);
  container.setAttribute('data-sub-title', subTitle);
  container.setAttribute('data-chart-data', JSON.stringify(chartData));
  canvas.setAttribute('data-chart-type', chartType);
  canvas.setAttribute('data-title', title);
  canvas.setAttribute('data-chart-data', JSON.stringify(chartData));

  loadLibraries().then(() => {
    renderBarChart(canvas, chartData, chartType, title, subTitle, container);
  }).catch(err => console.error(err));
}
  
function renderBarChart(canvas, chartData, chartType, title, subTitle, container) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  if (chartInstance) { chartInstance.destroy(); chartInstance = null; }

  const validLayers = chartData.filter(l => l.points && l.points.length > 0);
  if (validLayers.length === 0) return;

  const isHorizontal = chartType === 'horizontal';
  const isStacked = chartType === 'bar-stacked';
  const isTableStyle = chartType === 'bar-table';

  // --- Стили контейнера (прозрачность для table) ---
  if (isTableStyle) {
      container.style.backgroundColor = 'transparent';
      container.style.border = 'none';
      container.style.boxShadow = 'none';
  } else {
      container.style.backgroundColor = '';
      container.style.border = '';
      container.style.boxShadow = '';
  }

  const style = getComputedStyle(container);
  const headerColor = style.getPropertyValue('--chart-header-color').trim() || '#ffffff';
  const headerSize = parseInt(style.getPropertyValue('--chart-header-size').trim() || '16', 10);
  const subHeaderColor = style.getPropertyValue('--chart-subheader-color').trim() || '#a0aec0';
  const subHeaderSize = parseInt(style.getPropertyValue('--chart-subheader-size').trim() || '14', 10);
  const gridColor = style.getPropertyValue('--chart-grid-color').trim() || '#ffffff';
  const gridSize = parseInt(style.getPropertyValue('--chart-grid-size').trim() || '12', 10);

  const labels = validLayers[0].points.map(p => p.label);
  
  const datasets = validLayers.map(layer => ({
    label: layer.name,
    data: layer.points.map(p => p.value),
    backgroundColor: layer.points.map(p => (p.color || layer.color) + '80'),
    borderColor: layer.color,
    borderWidth: 0,
    borderRadius: 4,
    borderSkipped: false
  }));

  const config = {
    type: 'bar', 
    data: { labels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: isHorizontal ? 'y' : 'x',
      layout: isTableStyle ? { padding: 0 } : {},

      interaction: {
          mode: 'nearest',
          intersect: true, // Только при точном наведении
          axis: isHorizontal ? 'y' : 'x'
      },
      
      plugins: {
        title: {
          display: !isTableStyle, 
          text: title, color: headerColor, font: { size: headerSize, weight: 'bold' }
        },
        legend: {
          display: !isTableStyle,
          position: 'bottom', align: 'start',
          labels: { color: gridColor, usePointStyle: true, padding: 40, font: { size: gridSize } }
        },
        tooltip: {
            mode: isStacked ? 'index' : 'nearest',
            intersect: true, 
            enabled: true 
        }
      },
      scales: {
        x: {
          display: !isTableStyle,
          stacked: isStacked,
          ticks: { color: gridColor, font: { size: gridSize } },
          grid: { display: false, color: '#4a5568' }
        },
        y: {
          display: !isTableStyle,
          stacked: isStacked,
          ticks: { color: gridColor, font: { size: gridSize }, stepSize: 10 },
          grid: { color: '#4a5568', drawBorder: false },
          beginAtZero: true,
          title: {
            display: !isTableStyle && !!subTitle,
            text: subTitle, color: subHeaderColor,
            font: { size: subHeaderSize, weight: 'normal' }, padding: { bottom: 10 }
          }
        }
      },
      elements: { bar: { borderRadius: 4 } }
    }
  };
  
  // Доп. настройки для горизонтального режима (если не таблица)
  if (isHorizontal && !isTableStyle) {
      config.options.scales.y.grid.display = false;
      config.options.scales.x.grid = { color: '#4a5568', drawBorder: false };
      config.options.scales.x.title = config.options.scales.y.title;
      config.options.scales.y.title = { display: false };
      config.options.scales.x.ticks = { color: gridColor, font: { size: gridSize }, stepSize: 10 };
  }
  
  if (isTableStyle) {
      config.options.maintainAspectRatio = false;
  }

  try {
    chartInstance = new window.Chart(ctx, config);
  } catch (error) { console.error('Error creating bar chart:', error); }
}

function initBarChartRuntime(container) {
  const canvas = container.querySelector('canvas');
  if (!canvas) return;

  const chartType = container.getAttribute('data-chart-type') || 'bar';
  const title = container.getAttribute('data-title') || 'My Bar Chart';
  const subTitle = container.getAttribute('data-sub-title') || ''; 
  const chartDataAttr = container.getAttribute('data-chart-data');

  let chartData = [];
  if (!chartDataAttr) { chartData = getDefaultBarChartData(); } 
  else {
      try {
        const decodedData = chartDataAttr.replace(/&quot;/g, '"').replace(/&amp;/g, '&');
        chartData = JSON.parse(decodedData);
        if(!chartData.length) chartData = getDefaultBarChartData();
      } catch (e) { chartData = getDefaultBarChartData(); }
  }

  loadLibraries().then(() => {
    renderBarChart(canvas, chartData, chartType, title, subTitle, container); 
  }).catch(err => {});
}

function generatePointLabel(existingPoints) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  if (existingPoints.length > 0) {
    const usedMonths = existingPoints.map(p => p.label);
    const availableMonth = months.find(m => !usedMonths.includes(m));
    return availableMonth || 'New';
  }
  return 'Jan';
}

if (typeof editor !== 'undefined') {
  editor.Commands.add('bar-chart:add-layer', {
    run: (editor, sender, options = {}) => {
      const component = options.component || editor.getSelected();
      if (!component || component.get('type') !== 'bar-chart') return;
      const chartDataTrait = component.getTrait('chart-data');
      let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
      if (!chartData.length) chartData = getDefaultBarChartData();
      if (chartData.length >= 5) return;
      
      const basePoints = chartData[0].points;
      const newLayerColor = getSequentialColor(chartData.length);
      const newPoints = basePoints.map(point => ({ label: point.label, value: 30, color: newLayerColor }));
      chartData.push({ id: 'layer-' + (chartData.length + 1), name: 'Layer ' + (chartData.length + 1), color: newLayerColor, points: newPoints });
      chartDataTrait.setValue(JSON.stringify(chartData));
      initBarChartEditor(component);
    }
  });

  editor.Commands.add('bar-chart:remove-layer', {
    run: (editor, sender, options = {}) => {
      const component = options.component || editor.getSelected();
      if (!component || component.get('type') !== 'bar-chart') return;
      const chartDataTrait = component.getTrait('chart-data');
      let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
      if (chartData.length <= 1) return;
      chartData.pop();
      chartDataTrait.setValue(JSON.stringify(chartData));
      initBarChartEditor(component);
    }
  });

  editor.Commands.add('bar-chart:add-point', {
    run: (editor, sender, options = {}) => {
      const component = options.component || editor.getSelected();
      if (!component || component.get('type') !== 'bar-chart') return;
      const chartDataTrait = component.getTrait('chart-data');
      let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
      if (!chartData.length) return;
      if (chartData[0].points.length >= 12) return;
      const newLabel = generatePointLabel(chartData[0].points);
      chartData.forEach(layer => { layer.points.push({ label: newLabel, value: 30, color: layer.color }); });
      chartDataTrait.setValue(JSON.stringify(chartData));
      initBarChartEditor(component);
    }
  });

  editor.Commands.add('bar-chart:remove-point', {
    run: (editor, sender, options = {}) => {
      const component = options.component || editor.getSelected();
      if (!component || component.get('type') !== 'bar-chart') return;
      const chartDataTrait = component.getTrait('chart-data');
      let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
      let canRemove = chartData.every(l => l.points.length > 1);
      if (!canRemove) return;
      chartData.forEach(layer => { layer.points.pop(); });
      chartDataTrait.setValue(JSON.stringify(chartData));
      initBarChartEditor(component);
    }
  });

  function getSequentialColor(index) {
    const colors = ['#4170FF', '#FF6B6B', '#4ECDC4', '#FFD166', '#06D6A0'];
    return colors[index % colors.length];
  }
}

if (typeof model !== 'undefined') {
  if (model.getEl()) {
    setTimeout(() => initBarChartEditor(model), 100);
    model.on('change:traits', () => setTimeout(() => initBarChartEditor(model), 50));
    model.on('change:attributes', () => setTimeout(() => initBarChartEditor(model), 50));
    model.on('change:style', () => setTimeout(() => initBarChartEditor(model), 10));
  }
} else {
  const container = this;
  if (container && container.getAttribute('data-component-id') === 'bar-chart') {
    setTimeout(() => initBarChartRuntime(container), 100);
  }
}
`,
  styleConfig: {
    target: '.bar-chart-container',
    sectors: [
      {
        id: 'style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: '#10161C'
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '100',
            units: ['%', 'px', 'vw']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto']
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: 'min-width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vw', 'auto']
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: 'min-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto']
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: 'max-width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vw', 'auto']
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: 'max-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto']
          }
        ]
      },
      {
        id: 'info_text',
        name: 'Info',
        open: false,
        properties: [
          {
            id: 'info-fs',
            name: 'Font Size',
            property: '--chart-info-size',
            type: 'number',
            default: 24,
            units: ['px']
          },
          {
            id: 'info-color',
            name: 'Color',
            property: '--chart-info-color',
            type: 'color',
            default: '#ffffff'
          }
        ]
      },
      {
        id: 'header_text',
        name: 'Header Text',
        open: true,
        properties: [
          {
            id: 'header-fs',
            name: 'Font Size',
            property: '--chart-header-size',
            type: 'number',
            default: 16,
            units: ['px']
          },
          {
            id: 'header-color',
            name: 'Color',
            property: '--chart-header-color',
            type: 'color',
            default: '#ffffff'
          }
        ]
      },
      {
        id: 'subheader_text',
        name: 'Sub Header Text',
        open: true,
        properties: [
          {
            id: 'subheader-fs',
            name: 'Font Size',
            property: '--chart-subheader-size',
            type: 'number',
            default: 14,
            units: ['px']
          },
          {
            id: 'subheader-color',
            name: 'Color',
            property: '--chart-subheader-color',
            type: 'color',
            default: '#a0aec0'
          }
        ]
      },
      {
        id: 'grid_text',
        name: 'Grid Text',
        open: true,
        properties: [
          {
            id: 'grid-fs',
            name: 'Font Size',
            property: '--chart-grid-size',
            type: 'number',
            default: 12,
            units: ['px']
          },
          {
            id: 'grid-color',
            name: 'Color',
            property: '--chart-grid-color',
            type: 'color',
            default: '#ffffff'
          }
        ]
      }
    ]
  }
};
