import { ComponentConfig } from '../elements';

export const List: ComponentConfig = {
  id: 'list',
  type: 'list',
  label: 'List',
  category: 'Content',
  content: {
    tagName: 'div',
    attributes: { class: 'list-wrapper' },
    components: [
      {
        tagName: 'ul',
        attributes: { class: 'list-content' },
        components: [
          {
            tagName: 'li',
            content: 'Item 1',
            droppable: false,
            attributes: { 'data-value': 'item1' }
          },
          {
            tagName: 'li',
            content: 'Item 2',
            droppable: false,
            attributes: { 'data-value': 'item2' }
          },
          {
            tagName: 'li',
            content: 'Option 3',
            droppable: false,
            attributes: { 'data-value': 'option3' }
          }
        ]
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_47_4612)">
      <path d="M3.47396 7.4467C4.21034 7.4467 4.80729 6.84974 4.80729 6.11336C4.80729 5.37698 4.21034 4.78003 3.47396 4.78003C2.73758 4.78003 2.14062 5.37698 2.14062 6.11336C2.14062 6.84974 2.73758 7.4467 3.47396 7.4467Z" fill="white"/>
      <path d="M3.47396 12.7799C4.21034 12.7799 4.80729 12.183 4.80729 11.4466C4.80729 10.7102 4.21034 10.1133 3.47396 10.1133C2.73758 10.1133 2.14062 10.7102 2.14062 11.4466C2.14062 12.183 2.73758 12.7799 3.47396 12.7799Z" fill="white"/>
      <path d="M3.47396 18.1134C4.21034 18.1134 4.80729 17.5165 4.80729 16.7801C4.80729 16.0437 4.21034 15.4468 3.47396 15.4468C2.73758 15.4468 2.14062 16.0437 2.14062 16.7801C2.14062 17.5165 2.73758 18.1134 3.47396 18.1134Z" fill="white"/>
      <path d="M21.6127 5.99992C21.6127 5.82311 21.5424 5.65354 21.4174 5.52851C21.2924 5.40349 21.1228 5.33325 20.946 5.33325H6.66602V6.66659H20.946C21.1228 6.66659 21.2924 6.59635 21.4174 6.47132C21.5424 6.3463 21.6127 6.17673 21.6127 5.99992Z" fill="white"/>
      <path d="M20.946 10.6667H6.66602V12.0001H20.946C21.1228 12.0001 21.2924 11.9298 21.4174 11.8048C21.5424 11.6798 21.6127 11.5102 21.6127 11.3334C21.6127 11.1566 21.5424 10.987 21.4174 10.862C21.2924 10.737 21.1228 10.6667 20.946 10.6667Z" fill="white"/>
      <path d="M20.946 16H6.66602V17.3333H20.946C21.1228 17.3333 21.2924 17.2631 21.4174 17.1381C21.5424 17.013 21.6127 16.8435 21.6127 16.6667C21.6127 16.4899 21.5424 16.3203 21.4174 16.1953C21.2924 16.0702 21.1221 16 20.946 16Z" fill="white"/>
    </g>
    <defs>
      <clipPath id="clip0_47_4612">
        <rect width="24" height="24" fill="white"/>
      </clipPath>
    </defs>
  </svg>`,
  traits: [
    {
      id: 'items',
      name: 'items',
      label: 'Items',
      type: 'list',
      changeProp: true,
      value: JSON.stringify([
        { value: 'item1', label: 'Item 1' },
        { value: 'item2', label: 'Item 2' },
        { value: 'option3', label: 'Option 3' }
      ])
    },
    {
      id: 'type',
      name: 'type',
      label: 'List Type',
      type: 'select',
      options: [
        { value: 'ul', name: 'Unordered', id: 'Unordered' },
        { value: 'ol', name: 'Ordered', id: 'Ordered' }
      ],
      changeProp: true,
      value: 'ul'
    }
  ],
  styles: `
    .list-wrapper {
      max-width: 400px;
      padding: 16px;
      border-radius: 4px;
      text-align: left;
    }
    .list-content {
      padding-left: 20px;
      margin: 0;
      color: var(--color, #FFFFFF);
      font-size: var(--font-size, 16px);
    }
    .list-content li {
      margin-bottom: 8px;
    }
    .list-content ul {
      list-style-type: disc;
    }
    .list-content ul li::marker {
      color: var(--marker-color, #4170FF);
    }
    .list-content ol {
      list-style-type: decimal;
    }
    .list-content ol li::marker {
      color: var(--marker-color, #4170FF);
    }
  `,
  styleConfig: {
    sectors: [
      {
        id: 'Dimension',
        name: 'Dimension',
        open: false,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '400px',
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 'auto',
            units: ['px']
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            default: '300px',
            units: ['px', '%']
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            default: '100px',
            units: ['px']
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            default: 'none',
            units: ['px', '%']
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            default: 'none',
            units: ['px']
          }
        ]
      },
      {
        id: 'header-text',
        name: 'Header Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: '16px',
            units: ['px']
          },
          {
            id: 'color',
            name: 'Text Color',
            property: 'color',
            type: 'color',
            default: '#FFFFFF'
          },
          {
            id: 'marker-color',
            name: 'Marker Color',
            property: 'marker-color',
            type: 'color',
            default: '#4170FF'
          }
        ]
      }
    ]
  },
  script: `
    function updateList(model) {
      // Проверяем, что скрипт не выполняется на сервере
      if (typeof window === 'undefined') {
        console.warn('updateList: Skipping execution on server-side');
        return;
      }

      console.log('updateList called:', model?.changed);
      if (!model || !model.getEl?.()) {
        console.error('No model or wrapper element');
        return;
      }
      const wrapper = model.getEl();
      const traits = model.getTraits?.() || [];
      try {
        const listEl = wrapper.querySelector('.list-content');
        if (!listEl) {
          console.error('No .list-content found');
          return;
        }

        // Получаем значения трейтов
        const type = traits.find(t => t.getName?.() === 'type')?.getValue?.() || 'ul';
        const itemsTrait = traits.find(t => t.getName?.() === 'items');
        let items = [];
        try {
          items = itemsTrait?.getValue?.() ? JSON.parse(itemsTrait.getValue()) : [];
        } catch (e) {
          console.error('Invalid JSON in items trait:', e);
          items = [
            { value: 'item1', label: 'Item 1' },
            { value: 'item2', label: 'Item 2' },
            { value: 'option3', label: 'Option 3' }
          ];
        }

        // Синхронизируем items с начальной структурой, если пусто
        if (items.length === 0) {
          items = [
            { value: 'item1', label: 'Item 1' },
            { value: 'item2', label: 'Item 2' },
            { value: 'option3', label: 'Option 3' }
          ];
          if (itemsTrait) {
            model.set('attributes', {
              ...model.getAttributes?.(),
              'data-items': JSON.stringify(items)
            });
            itemsTrait.setValue(JSON.stringify(items));
            console.log('Initialized items trait:', items);
          }
        }

        // Сравниваем текущие элементы с новыми
        const currentItems = Array.from(listEl.children).map(li => ({
          value: li.getAttribute('data-value') || li.textContent,
          label: li.textContent
        }));
        if (JSON.stringify(items) !== JSON.stringify(currentItems)) {
          while (listEl.firstChild) {
            listEl.removeChild(listEl.firstChild);
          }
          items.forEach(item => {
            const li = document.createElement('li');
            li.textContent = item.label;
            li.setAttribute('data-value', item.value);
            li.setAttribute('droppable', 'false');
            listEl.appendChild(li);
          });
          console.log('List items updated:', items);
        }

        // Обновляем тип списка (ul/ol)
        if (listEl.tagName.toLowerCase() !== type) {
          const newListEl = document.createElement(type);
          newListEl.className = 'list-content';
          Array.from(listEl.children).forEach(child => newListEl.appendChild(child));
          listEl.parentNode.replaceChild(newListEl, listEl);
          console.log('List type updated to:', type);
        }

        // Устанавливаем дефолтные стили, если они не заданы
        const currentStyles = model.getStyle?.() || {};
        if (Object.keys(currentStyles).length === 0) {
          const defaultStyles = {
            'color': '#FFFFFF',
            'marker-color': '#4170FF',
            'font-size': '16px',
            'width': '400px',
            'min-width': '300px',
            'max-width': 'none',
            'height': 'auto',
            'min-height': '100px',
            'max-height': 'none'
          };
          model.setStyle?.(defaultStyles);
          console.log('Default styles set:', defaultStyles);
        }

        // Обновляем стили из styleConfig
        const styles = model.getStyle?.() || {};
        wrapper.style.setProperty('--font-size', styles['font-size'] || '16px');
        wrapper.style.setProperty('--color', styles['color'] || '#FFFFFF');
        wrapper.style.setProperty('--marker-color', styles['marker-color'] || '#4170FF');
        wrapper.style.setProperty('width', styles['width'] || '400px');
        wrapper.style.setProperty('min-width', styles['min-width'] || '300px');
        wrapper.style.setProperty('max-width', styles['max-width'] || 'none');
        wrapper.style.setProperty('height', styles['height'] || 'auto');
        wrapper.style.setProperty('min-height', styles['min-height'] || '100px');
        wrapper.style.setProperty('max-height', styles['max-height'] || 'none');
        console.log('List updated:', { items, type, styles });
      } catch (e) {
        console.error('Error updating list:', e);
      }
    }

    // Инициализация
    if (typeof window !== 'undefined' && model && model.getEl?.()) {
      console.log('Initializing list');
      updateList(model);
      // Подписка на события модели
      model.on?.('change', () => {
        console.log('Model changed:', model.changed);
        updateList(model);
      });
      model.on?.('change:style', () => {
        console.log('Style changed');
        updateList(model);
      });
      model.on?.('load', () => {
        console.log('Model loaded');
        updateList(model);
      });
    } else {
      console.error('Model or element not available during initialization');
    }
  `
};
