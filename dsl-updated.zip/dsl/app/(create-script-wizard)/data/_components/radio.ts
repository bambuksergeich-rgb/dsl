import { ComponentConfig } from '../elements';

export const Radio: ComponentConfig = {
  id: 'single-radio',
  type: 'single-radio',
  label: 'Radio',
  category: 'Form',
  content: {
    tagName: 'div',
    attributes: {
      class: 'radio-wrapper axis-horizontal radio-position-left',
      'data-value': 'Radio'
    },
    components: [
      {
        tagName: 'div',
        attributes: {
          class: 'radio-option',
          'data-radio-value': 'Radio'
        },
        components: [
          {
            tagName: 'input',
            attributes: {
              type: 'radio',
              class: 'radio-input',
              value: 'Radio',
              checked: 'checked'
            },
            selectable: false,
            hoverable: false,
            highlightable: false,
            draggable: false,
            droppable: false,
            editable: false,
            resizable: false,
            layerable: false
          },
          {
            tagName: 'label',
            attributes: { class: 'radio-label' },
            content: 'Radio',
            selectable: false,
            hoverable: false,
            highlightable: false,
            draggable: false,
            droppable: false,
            editable: false,
            resizable: false,
            layerable: false
          }
        ],
        selectable: false,
        hoverable: false,
        highlightable: false,
        draggable: false,
        droppable: false,
        editable: false,
        resizable: false,
        layerable: false
      }
    ],
    droppable: false,
    editable: false,
    selectable: true
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="12" cy="12" r="8.25" stroke="white" stroke-width="1.5"/>
<circle cx="12" cy="12" r="4" fill="white"/>
</svg>`,
  traits: [
    {
      id: 'options',
      name: 'options',
      label: 'Options',
      type: 'list',
      changeProp: true,
      value: JSON.stringify([{ value: 'Radio', label: 'Radio' }])
    },
    {
      id: 'axis',
      name: 'axis',
      label: 'Axis',
      type: 'select',
      changeProp: true,
      value: 'horizontal',
      options: [
        { id: 'horizontal', name: 'Horizontal', value: 'horizontal' },
        { id: 'vertical', name: 'Vertical', value: 'vertical' }
      ]
    },
    {
      id: 'radio-position',
      name: 'buttonPosition',
      label: 'Button Position',
      type: 'select',
      changeProp: true,
      value: 'left',
      options: [
        { id: 'left', name: 'Left', value: 'left' },
        { id: 'right', name: 'Right', value: 'right' },
        { id: 'top', name: 'Top', value: 'top' },
        { id: 'bottom', name: 'Bottom', value: 'bottom' }
      ]
    }
  ],
  styles: `
    .radio-wrapper {
      max-width: var(--max-width, none);
      width: fit-content;
      height: fit-content;
      min-width: 32px;
      min-height: 32px;
      max-height: var(--max-height, none);
      border-radius: 4px;
      box-sizing: border-box;
      display: inline-flex;
      align-items: flex-start;
      gap: 10px;
      font-family: 'Montserrat', sans-serif;
      --label-color: #FFFFFF;
      --radio-color: #4170FF;
      --radio-width: 20px;
      --radio-height: 20px;
      --radio-min-width: 16px;
      --radio-min-height: 16px;
      --radio-max-width: 24px;
      --radio-max-height: 24px;
      --radio-border-radius: 50%;
    }
    .radio-wrapper.axis-horizontal {
      flex-direction: row;
      flex-wrap: wrap;
    }
    .radio-wrapper.axis-vertical {
      flex-direction: column;
    }
    .radio-option {
      display: inline-flex;
      align-items: center;
      justify-content: flex-start;
      gap: 8px;
      min-height: 28px;
      min-width: 0;
      box-sizing: border-box;
    }
    .radio-wrapper.radio-position-left .radio-option {
      flex-direction: row;
    }
    .radio-wrapper.radio-position-right .radio-option {
      flex-direction: row-reverse;
    }
    .radio-wrapper.radio-position-top .radio-option {
      flex-direction: column;
    }
    .radio-wrapper.radio-position-bottom .radio-option {
      flex-direction: column-reverse;
    }
    .radio-label {
      font-size: var(--font-size, 14px);
      font-weight: 400;
      color: var(--label-color);
      cursor: pointer;
      line-height: 1.25;
      white-space: nowrap;
      user-select: none;
    }
    .radio-input {
      margin: 0;
      cursor: pointer;
      width: var(--radio-width, 20px);
      height: var(--radio-height, 20px);
      min-width: var(--radio-min-width, 16px);
      min-height: var(--radio-min-height, 16px);
      max-width: var(--radio-max-width, 24px);
      max-height: var(--radio-max-height, 24px);
      border-radius: var(--radio-border-radius, 50%);
      appearance: none;
      -webkit-appearance: none;
      background: transparent;
      border: 2px solid var(--radio-color, #4170FF);
      box-shadow: none;
      flex-shrink: 0;
      position: relative;
      box-sizing: border-box;
    }
    .radio-input:checked {
      border-color: var(--radio-color, #4170FF);
      background:
        radial-gradient(circle at center, var(--radio-color, #4170FF) 0 40%, transparent 43% 100%);
    }
    .radio-input:focus-visible {
      outline: 2px solid color-mix(in srgb, var(--radio-color, #4170FF) 45%, transparent);
      outline-offset: 2px;
    }
  `,
  script: `
function normalizeRadioOptions(rawOptions) {
  if (!Array.isArray(rawOptions) || !rawOptions.length) {
    return [{ value: 'Radio', label: 'Radio' }];
  }
  return rawOptions
    .map(function(option, index) {
      if (option == null) return null;
      if (typeof option !== 'object') {
        const text = String(option).trim();
        return text ? { value: text, label: text } : null;
      }
      const label = String(option.label != null ? option.label : option.value != null ? option.value : '').trim();
      if (!label) return null;
      const value = String(option.value != null && option.value !== '' ? option.value : label).trim();
      return { value: value || label || ('Radio ' + (index + 1)), label: label };
    })
    .filter(Boolean);
}

function parseRadioOptions(raw) {
  if (Array.isArray(raw)) return normalizeRadioOptions(raw);
  if (typeof raw !== 'string' || !raw.trim()) return normalizeRadioOptions([]);
  try {
    return normalizeRadioOptions(JSON.parse(raw));
  } catch (e) {
    return normalizeRadioOptions([]);
  }
}

function readRadioOptions(model) {
  const trait = model.getTrait && model.getTrait('options');
  return parseRadioOptions(trait && trait.getValue ? trait.getValue() : '');
}

function readSelectedRadio(model, options) {
  const attrs = model.getAttributes ? model.getAttributes() : {};
  const fromModel = model.get && model.get('radioValue');
  const fromAttrs = attrs && attrs['data-value'];
  const candidate = fromModel != null && fromModel !== '' ? String(fromModel) : fromAttrs != null ? String(fromAttrs) : '';
  if (candidate && options.some(function(option) { return option.value === candidate || option.label === candidate; })) {
    const match = options.find(function(option) { return option.value === candidate || option.label === candidate; });
    return match ? match.value : candidate;
  }
  return options[0] ? options[0].value : '';
}

function writeSelectedRadio(model, value) {
  const next = value == null ? '' : String(value);
  if (model.get && model.set && model.get('radioValue') !== next) {
    model.set('radioValue', next);
  }
  if (model.addAttributes) {
    const attrs = model.getAttributes ? model.getAttributes() : {};
    if (String(attrs['data-value'] || '') !== next) {
      model.addAttributes({ 'data-value': next });
    }
  }
}

function radioOptionDefinition(option, index, groupName) {
  return {
    tagName: 'div',
    attributes: {
      class: 'radio-option',
      'data-radio-value': option.value
    },
    components: [
      {
        tagName: 'input',
        attributes: {
          type: 'radio',
          class: 'radio-input',
          name: groupName,
          value: option.value
        },
        selectable: false,
        hoverable: false,
        highlightable: false,
        draggable: false,
        droppable: false,
        editable: false,
        resizable: false,
        layerable: false
      },
      {
        tagName: 'label',
        attributes: { class: 'radio-label' },
        content: option.label,
        selectable: false,
        hoverable: false,
        highlightable: false,
        draggable: false,
        droppable: false,
        editable: false,
        resizable: false,
        layerable: false
      }
    ],
    selectable: false,
    hoverable: false,
    highlightable: false,
    draggable: false,
    droppable: false,
    editable: false,
    resizable: false,
    layerable: false
  };
}

function ensureRadioOptionChildren(optionModel, option, groupName) {
  if (!optionModel) return;
  const attrs = optionModel.getAttributes ? optionModel.getAttributes() : {};
  optionModel.addAttributes && optionModel.addAttributes({
    ...attrs,
    class: 'radio-option',
    'data-radio-value': option.value
  });
  optionModel.set && optionModel.set({
    selectable: false,
    hoverable: false,
    highlightable: false,
    draggable: false,
    droppable: false,
    editable: false,
    resizable: false,
    layerable: false
  });

  const children = optionModel.components && optionModel.components();
  let inputModel = optionModel.find && optionModel.find('.radio-input')[0];
  let labelModel = optionModel.find && optionModel.find('.radio-label')[0];
  if (!inputModel || !labelModel) {
    if (children && children.reset) {
      const def = radioOptionDefinition(option, 0, groupName);
      children.reset(def.components || []);
      inputModel = optionModel.find && optionModel.find('.radio-input')[0];
      labelModel = optionModel.find && optionModel.find('.radio-label')[0];
    }
  }

  if (inputModel) {
    const inputAttrs = inputModel.getAttributes ? inputModel.getAttributes() : {};
    inputModel.addAttributes && inputModel.addAttributes({
      ...inputAttrs,
      type: 'radio',
      class: 'radio-input',
      name: groupName,
      value: option.value
    });
    inputModel.set && inputModel.set({
      selectable: false,
      hoverable: false,
      highlightable: false,
      draggable: false,
      droppable: false,
      editable: false,
      resizable: false,
      layerable: false
    });
  }
  if (labelModel) {
    if (String(labelModel.get && labelModel.get('content') || '') !== option.label) {
      labelModel.set && labelModel.set('content', option.label);
    }
    labelModel.set && labelModel.set({
      selectable: false,
      hoverable: false,
      highlightable: false,
      draggable: false,
      droppable: false,
      editable: false,
      resizable: false,
      layerable: false
    });
  }
}

function syncRadioChildren(model, options) {
  const collection = model.components && model.components();
  if (!collection) return;
  const groupName = 'radio-' + String(model.cid || model.getId && model.getId() || 'group');
  let current = collection.models ? collection.models.slice() : [];

  // Migrate the old single input + label structure once. From that point on,
  // reconcile options in place so editing the list does not make the component
  // disappear or lose GrapesJS selection.
  if (current.length && current.some(function(child) {
    const attrs = child && child.getAttributes ? child.getAttributes() : {};
    return !String(attrs.class || '').split(/\\s+/).includes('radio-option');
  })) {
    current.forEach(function(child) {
      if (child && child.remove) child.remove();
      else if (collection.remove) collection.remove(child);
    });
    current = [];
  }

  options.forEach(function(option, index) {
    let child = collection.models && collection.models[index];
    if (!child) {
      if (model.append) model.append(radioOptionDefinition(option, index, groupName));
      child = collection.models && collection.models[index];
    }
    ensureRadioOptionChildren(child, option, groupName);
  });

  current = collection.models ? collection.models.slice() : [];
  for (let index = current.length - 1; index >= options.length; index -= 1) {
    const child = current[index];
    if (child && child.remove) child.remove();
    else if (collection.remove) collection.remove(child);
  }
}

function applyRadioLayout(model) {
  const wrapper = model.getEl && model.getEl();
  if (!wrapper) return;
  const axisTrait = model.getTrait && model.getTrait('axis');
  const positionTrait = model.getTrait && model.getTrait('buttonPosition');
  const axis = String(axisTrait && axisTrait.getValue ? axisTrait.getValue() : 'horizontal');
  const position = String(positionTrait && positionTrait.getValue ? positionTrait.getValue() : 'left');

  wrapper.classList.toggle('axis-vertical', axis === 'vertical');
  wrapper.classList.toggle('axis-horizontal', axis !== 'vertical');
  ['left', 'right', 'top', 'bottom'].forEach(function(item) {
    wrapper.classList.toggle('radio-position-' + item, position === item);
  });

  const styles = model.getStyle ? model.getStyle() || {} : {};
  const color = styles['radio-color'] || (model.getAttributes && model.getAttributes()['data-color']) || '#4170FF';
  wrapper.style.setProperty('--radio-color', color);
  wrapper.style.setProperty('--font-size', styles['font-size'] || '14px');
  wrapper.style.setProperty('--label-color', styles['text-color'] || '#FFFFFF');
  wrapper.style.setProperty('--radio-width', styles['radio-width'] || '20px');
  wrapper.style.setProperty('--radio-height', styles['radio-height'] || '20px');
  wrapper.style.setProperty('--radio-min-width', styles['radio-min-width'] || '16px');
  wrapper.style.setProperty('--radio-min-height', styles['radio-min-height'] || '16px');
  wrapper.style.setProperty('--radio-max-width', styles['radio-max-width'] || '24px');
  wrapper.style.setProperty('--radio-max-height', styles['radio-max-height'] || '24px');
  wrapper.style.setProperty('--radio-border-radius', styles['radio-border-radius'] || '50%');
}

function paintRadio(model, options) {
  const wrapper = model.getEl && model.getEl();
  if (!wrapper) return;
  const selected = readSelectedRadio(model, options);
  writeSelectedRadio(model, selected);
  const optionEls = wrapper.querySelectorAll('.radio-option');
  optionEls.forEach(function(optionEl) {
    const value = String(optionEl.getAttribute('data-radio-value') || '');
    const input = optionEl.querySelector('.radio-input');
    const checked = value === selected;
    optionEl.classList.toggle('active', checked);
    if (input) {
      input.checked = checked;
      if (checked) input.setAttribute('checked', 'checked');
      else input.removeAttribute('checked');
    }
  });
}

function updateRadioField(model, syncChildren) {
  if (!model || model.__updatingRadioField) return;
  model.__updatingRadioField = true;
  try {
    const options = readRadioOptions(model);
    if (syncChildren !== false) syncRadioChildren(model, options);
    applyRadioLayout(model);
    paintRadio(model, options);
  } finally {
    model.__updatingRadioField = false;
  }
}

updateRadioField(model, true);

if (!model.__radioFieldBound) {
  model.__radioFieldBound = true;
  model.on('change:options', function() { updateRadioField(model, true); });
  model.on('change:axis change:buttonPosition change:styles change:style', function() {
    updateRadioField(model, false);
  });
  model.on('change:radioValue change:attributes', function() {
    updateRadioField(model, false);
  });
}

const radioRoot = model.getEl && model.getEl();
if (radioRoot && !radioRoot.__radioClickBound) {
  radioRoot.__radioClickBound = true;
  radioRoot.addEventListener('click', function(event) {
    const optionEl = event.target && event.target.closest && event.target.closest('.radio-option');
    if (!optionEl || !radioRoot.contains(optionEl)) return;
    const value = String(optionEl.getAttribute('data-radio-value') || '');
    if (!value) return;
    event.preventDefault();
    writeSelectedRadio(model, value);
    paintRadio(model, readRadioOptions(model));
    try {
      radioRoot.dispatchEvent(new Event('input', { bubbles: true }));
      radioRoot.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (e) {}
  });
}
`,
  styleConfig: {
    sectors: [
      {
        id: 'radio-dimension',
        name: 'Radio Dimension',
        open: true,
        properties: [
          {
            id: 'radio-width',
            name: 'Box Width',
            property: 'radio-width',
            type: 'number',
            default: 20,
            units: ['px']
          },
          {
            id: 'radio-height',
            name: 'Box Height',
            property: 'radio-height',
            type: 'number',
            default: 20,
            units: ['px']
          },
          {
            id: 'radio-min-width',
            name: 'Min-Width',
            property: 'radio-min-width',
            type: 'number',
            default: 16,
            units: ['px']
          },
          {
            id: 'radio-min-height',
            name: 'Min-Height',
            property: 'radio-min-height',
            type: 'number',
            default: 16,
            units: ['px']
          },
          {
            id: 'radio-max-width',
            name: 'Max-Width',
            property: 'radio-max-width',
            type: 'number',
            default: 24,
            units: ['px']
          },
          {
            id: 'radio-max-height',
            name: 'Max-Height',
            property: 'radio-max-height',
            type: 'number',
            default: 24,
            units: ['px']
          },
          {
            id: 'radio-border-radius',
            name: 'Radius',
            property: 'radio-border-radius',
            type: 'number',
            default: 50,
            units: ['%']
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: 100,
            units: ['px', '%', 'vw']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: '34px',
            units: ['px', '%', 'vh']
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: 'min-width',
            type: 'number',
            default: 150,
            units: ['px', '%', 'vw']
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: 'min-height',
            type: 'number',
            default: 50,
            units: ['px', '%', 'vh']
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: 'max-width',
            type: 'number',
            default: 300,
            units: ['px', '%', 'vw']
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: 'max-height',
            type: 'number',
            default: 0,
            units: ['px', '%', 'vh']
          }
        ]
      },
      {
        id: 'radio-text',
        name: 'Radio Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: 14,
            units: ['px']
          },
          {
            id: 'text-color',
            name: 'Text Color',
            property: 'text-color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  }
};
