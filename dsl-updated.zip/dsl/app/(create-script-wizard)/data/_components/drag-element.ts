import { ComponentConfig } from '../elements';

export const DragElement: ComponentConfig = {
  id: 'drag-element',
  type: 'drag-element',
  label: 'Drag Element',
  category: 'Basic',
  content: {
    tagName: 'div',
    attributes: { class: 'drag-element', draggable: 'true' },
    components: [
      {
        tagName: 'img',
        attributes: {
          class: 'icon-element',
          src: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIzMCIgY3k9IjMwIiByPSIyNSIgc3Ryb2tlPSIjNDE3MEZGIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiLz48L3N2Zz4=',
          alt: 'Drag Icon'
        },
        draggable: false
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M14 6H16V8H21C21.2652 8 21.5196 8.10536 21.7071 8.29289C21.8946 8.48043 22 8.73478 22 9V16.5L16 13L16.036 21.062L18.259 18.912L20.041 22H9C8.73478 22 8.48043 21.8946 8.29289 21.7071C8.10536 21.5196 8 21.2652 8 21V16H6V14H8V9C8 8.73478 8.10536 8.48043 8.29289 8.29289C8.48043 8.10536 8.73478 8 9 8H14V6ZM22 17.338V21C22.0001 21.1042 21.9839 21.2078 21.952 21.307L19.992 17.913L22 17.338ZM4 14V16H2V14H4ZM4 10V12H2V10H4ZM4 6V8H2V6H4ZM4 2V4H2V2H4ZM8 2V4H6V2H8ZM12 2V4H10V2H12ZM16 2V4H14V2H16Z" fill="white"/>
  </svg>
  `,
  traits: [
    {
      id: 'selectImage',
      name: 'selectImage',
      label: 'Dragging Element',
      type: 'select-icon',
      changeProp: true,
      value:
        'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIzMCIgY3k9IjMwIiByPSIyNSIgc3Ryb2tlPSIjNDE3MEZGIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiLz48L3N2Zz4='
    }
  ],
  styles: `
    .drag-element {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 128px;
      height: 113px;
      cursor: move;
      transition: all 0.2s;
    }
    .drag-element.dragging {
      opacity: 0.5;
    }
    .drag-element.drag-ghost {
      transform: scale(1.1);
      border: 2px solid #ffffff;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
      background-color: #f0f0f0;
    }
    .icon-element {
      display: inline-block;
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
  `,
  script: `
    function updateDragElement(model) {
      console.log('updateDragElement called:', model.changed);
      if (!model || !model.getEl()) {
        console.error('No model or wrapper element');
        return;
      }
      const dragEl = model.getEl();
      try {
        const imgEl = dragEl.querySelector('.icon-element');
        const selectImageTrait = model.getTrait('selectImage');
        if (imgEl && selectImageTrait && selectImageTrait.getValue()) {
          const src = selectImageTrait.getValue();
          if (typeof src === 'string' && src.startsWith('data:image')) {
            imgEl.src = src;
            console.log('Image updated with data URL:', src);
          } else {
            console.error('Invalid image source:', src);
          }
        }
        console.log('Drag Element updated:', {
          src: selectImageTrait?.getValue()
        });
      } catch (e) {
        console.error('Error updating drag element:', e);
      }
    }

    function handleDragStart(event, model) {
      const dragEl = model.getEl();
      dragEl.classList.add('dragging');

      const ghostEl = dragEl.cloneNode(true);
      ghostEl.classList.add('drag-ghost');
      ghostEl.style.position = 'absolute';
      ghostEl.style.top = '-9999px';
      document.body.appendChild(ghostEl);

      event.dataTransfer.setDragImage(ghostEl, 64, 56.5);
      event.dataTransfer.setData('text/plain', model.getId());

      setTimeout(() => {
        document.body.removeChild(ghostEl);
      }, 0);
    }

    function handleDragEnd(event, model) {
      const dragEl = model.getEl();
      dragEl.classList.remove('dragging');
    }

    if (model && model.getEl()) {
      updateDragElement(model);
      const dragEl = model.getEl();
      dragEl.addEventListener('dragstart', (event) => handleDragStart(event, model));
      dragEl.addEventListener('dragend', (event) => handleDragEnd(event, model));
    } else {
      console.error('Model or element not available');
    }

    model.on('change', () => {
      console.log('Model changed:', model.changed);
      updateDragElement(model);
    });
  `,
  styleConfig: { sectors: [] }
};
