import { ComponentConfig } from '../elements';

export const Basket: ComponentConfig = {
  id: 'basket',
  type: 'basket',
  label: 'Basket',
  category: 'Form',
  content: {
    tagName: 'div',
    attributes: {
      class: 'basket-wrapper',
      'data-basket-state': '',
      'data-basket-object': ''
    },
    components: [
      {
        tagName: 'section',
        attributes: { class: 'basket-section basket-section-available' },
        draggable: false,
        components: [
          {
            tagName: 'div',
            attributes: { class: 'basket-section-title basket-available-title' },
            draggable: false,
            content: 'Section_name'
          },
          {
            tagName: 'div',
            attributes: { class: 'basket-list basket-available-list' },
            draggable: false
          }
        ]
      },
      {
        tagName: 'section',
        attributes: { class: 'basket-section basket-section-selected' },
        draggable: false,
        components: [
          {
            tagName: 'div',
            attributes: { class: 'basket-section-title basket-selected-title' },
            draggable: false,
            content: 'Section_name'
          },
          {
            tagName: 'div',
            attributes: { class: 'basket-list basket-selected-list' },
            draggable: false
          }
        ]
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4 7H20L19 19H5L4 7Z" stroke="white" stroke-width="1.5" stroke-linejoin="round"/>
<path d="M8 7V5C8 3.89543 8.89543 3 10 3H14C15.1046 3 16 3.89543 16 5V7" stroke="white" stroke-width="1.5"/>
</svg>`,
  traits: [
    {
      id: 'addSectionName',
      name: 'addSectionName',
      label: 'Add Section Name',
      type: 'text',
      changeProp: true,
      value: 'Section_name',
      placeholder: 'Enter text'
    },
    {
      id: 'deleteSectionName',
      name: 'deleteSectionName',
      label: 'Delete Section Name',
      type: 'text',
      changeProp: true,
      value: 'Section_name',
      placeholder: 'Enter text'
    }
  ],
  styles: `
    .basket-wrapper {
      width: 100%;
      min-width: 220px;
      min-height: 190px;
      box-sizing: border-box;
      padding: 14px;
      border-radius: 2px;
      background: #211621;
      color: #fff;
      font-family: Montserrat, Arial, sans-serif;
      font-size: 12px;
      overflow: hidden;
    }
    .basket-section + .basket-section {
      margin-top: 14px;
    }
    .basket-section-title {
      margin-bottom: 7px;
      color: rgba(255,255,255,0.86);
      font-size: 11px;
      line-height: 14px;
    }
    .basket-list {
      min-height: 42px;
      border: 1px solid rgba(78, 92, 214, 0.32);
      border-radius: 2px;
      background: #342449;
      padding: 7px;
      box-sizing: border-box;
    }
    .basket-row {
      min-height: 30px;
      display: grid;
      grid-template-columns: minmax(0, 1fr) 28px;
      gap: 7px;
      align-items: center;
    }
    .basket-row + .basket-row {
      margin-top: 5px;
    }
    .basket-row-label {
      min-width: 0;
      height: 28px;
      display: flex;
      align-items: center;
      border-radius: 2px;
      background: #4a3c61;
      padding: 0 8px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: #fff;
    }
    .basket-row-action {
      width: 28px;
      height: 28px;
      border: 0;
      border-radius: 2px;
      background: #4558d9;
      color: #fff;
      font-size: 18px;
      line-height: 28px;
      padding: 0;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .basket-empty {
      height: 30px;
      display: flex;
      align-items: center;
      color: rgba(255,255,255,0.45);
      padding: 0 5px;
      font-size: 11px;
    }
  `,
  script: `
    const root = model?.getEl?.();
    if (!root) return;

    if (typeof model.__stage17BasketCleanup === 'function') {
      model.__stage17BasketCleanup();
    }

    const cleanup = [];
    let dynamicCleanup = [];
    const on = (target, event, handler, options) => {
      if (!target?.addEventListener) return;
      target.addEventListener(event, handler, options);
      cleanup.push(() => target.removeEventListener(event, handler, options));
    };
    const onDynamic = (target, event, handler, options) => {
      if (!target?.addEventListener) return;
      target.addEventListener(event, handler, options);
      dynamicCleanup.push(() => target.removeEventListener(event, handler, options));
    };

    const clone = (value) => {
      try { return JSON.parse(JSON.stringify(value)); } catch { return value; }
    };

    const normalizePlusserState = (state) => {
      const source = state && typeof state === 'object' ? state : {};
      const conf = source.conf && typeof source.conf === 'object' ? source.conf : {};
      const values = Array.isArray(source.values) ? source.values : [];
      return { conf: clone(conf), values: clone(values) };
    };

    const normalizeBasketItem = (item, index) => {
      if (!item || typeof item !== 'object') {
        return {
          id: 'basket-item-' + (index + 1),
          sourceDraftId: '',
          name: String(item || 'Name' + (index + 1)),
          conf: {},
          values: []
        };
      }
      return {
        ...item,
        id: String(item.id || item.sourceDraftId || 'basket-item-' + (index + 1)),
        sourceDraftId: String(item.sourceDraftId || item.draftId || ''),
        name: String(item.name || item.label || 'Name' + (index + 1)),
        conf: item.conf && typeof item.conf === 'object' ? clone(item.conf) : {},
        values: Array.isArray(item.values) ? clone(item.values) : []
      };
    };

    const normalizeState = (raw) => {
      const source = raw && typeof raw === 'object' ? raw : {};
      const conf = source.conf && typeof source.conf === 'object' ? source.conf : {};
      return {
        conf: {
          availableTitle: String(conf.availableTitle || 'Section_name'),
          selectedTitle: String(conf.selectedTitle || 'Section_name')
        },
        values: Array.isArray(source.values)
          ? source.values.map(normalizeBasketItem)
          : []
      };
    };

    const readAttributeState = () => {
      const attrs = model.getAttributes?.() || {};
      const raw = attrs['data-basket-state'] || attrs['data-basket-object'];
      if (!raw || typeof raw !== 'string') return null;
      try { return JSON.parse(raw); } catch { return null; }
    };

    let state = normalizeState(model.get?.('basketState') || readAttributeState());
    const available = new Map();

    const registryHost = (() => {
      const view = root.ownerDocument?.defaultView;
      try {
        if (view?.top?.document) return view.top;
      } catch {}
      try {
        if (view?.parent?.document) return view.parent;
      } catch {}
      return view;
    })();
    const registryKey = '__dslPlusserRegistryV1';
    const registry = (() => {
      if (!registryHost) return null;
      const current = registryHost[registryKey];
      if (current?.items instanceof Map && current?.listeners instanceof Set) return current;
      const created = { items: new Map(), listeners: new Set() };
      try { registryHost[registryKey] = created; } catch {}
      return created;
    })();

    const traitText = (name, fallback) => {
      const modelValue = model.get?.(name);
      if (modelValue != null && String(modelValue).trim()) return String(modelValue).trim();
      const traitValue = model.getTrait?.(name)?.getValue?.();
      if (traitValue != null && String(traitValue).trim()) return String(traitValue).trim();
      return fallback;
    };

    const sectionNames = () => ({
      availableTitle: traitText('addSectionName', state.conf.availableTitle || 'Section_name'),
      selectedTitle: traitText('deleteSectionName', state.conf.selectedTitle || 'Section_name')
    });

    const plusserLabel = (entry, fallbackIndex) => {
      const first = entry.state?.values?.[0];
      const label = first && typeof first === 'object'
        ? String(first.label || first.name || '').trim()
        : '';
      return label || 'Name' + (fallbackIndex + 1);
    };

    const scanPlussers = () => {
      const seen = new Set();

      // First collect Plusser instances published by other embedded documents.
      // Drop stale entries whose iframe/component has already been removed.
      if (registry) {
        Array.from(registry.items.entries()).forEach(([key, entry], registryIndex) => {
          const owner = entry?.owner;
          if (owner && owner.isConnected === false) {
            registry.items.delete(key);
            return;
          }
          const draftId = String(entry?.draftId || key || '');
          if (!draftId || draftId === String(model.getAttributes?.()?.['data-draft-id'] || '')) return;
          const normalized = normalizePlusserState(entry?.state);
          available.set(draftId, {
            draftId,
            name: plusserLabel({ state: normalized }, registryIndex),
            state: normalized
          });
          seen.add(draftId);
        });
      }

      // Keep the old same-document scan as a fallback and as support for saved
      // markup that has not run the registry-aware Plusser script yet.
      const nodes = root.ownerDocument?.querySelectorAll?.('.plusser-wrapper') || [];
      Array.from(nodes).forEach((node, index) => {
        const draftId = String(node.getAttribute('data-draft-id') || 'plusser-' + index);
        if (!draftId || draftId === String(model.getAttributes?.()?.['data-draft-id'] || '')) return;
        const raw = node.getAttribute('data-plusser-state');
        let parsed = null;
        if (raw) {
          try { parsed = JSON.parse(raw); } catch {}
        }
        const normalized = normalizePlusserState(parsed);
        available.set(draftId, {
          draftId,
          name: plusserLabel({ state: normalized }, index),
          state: normalized
        });
        seen.add(draftId);
      });
      Array.from(available.keys()).forEach((key) => {
        if (!seen.has(key)) available.delete(key);
      });
    };

    const stopEditorGesture = (event) => event.stopPropagation();

    const persist = (next) => {
      state = normalizeState(next);
      const serialized = JSON.stringify(state);
      model.set?.('basketState', state, { silent: true });
      if (model.getAttributes?.()?.['data-basket-state'] !== serialized) {
        model.addAttributes?.({
          'data-basket-state': serialized,
          'data-basket-object': serialized
        });
      }
      render();
    };

    const makeEmpty = (text) => {
      const empty = root.ownerDocument.createElement('div');
      empty.className = 'basket-empty';
      empty.textContent = text;
      return empty;
    };

    const makeRow = (label, actionLabel, className) => {
      const row = root.ownerDocument.createElement('div');
      row.className = 'basket-row';
      const text = root.ownerDocument.createElement('div');
      text.className = 'basket-row-label';
      text.textContent = label;
      const button = root.ownerDocument.createElement('button');
      button.className = 'basket-row-action ' + className;
      button.type = 'button';
      button.textContent = actionLabel;
      row.appendChild(text);
      row.appendChild(button);
      ['pointerdown', 'mousedown'].forEach((name) => onDynamic(button, name, stopEditorGesture));
      return { row, button };
    };

    const render = () => {
      dynamicCleanup.splice(0).forEach((dispose) => {
        try { dispose(); } catch {}
      });
      scanPlussers();
      const availableTitle = root.querySelector('.basket-available-title');
      const selectedTitle = root.querySelector('.basket-selected-title');
      const availableHost = root.querySelector('.basket-available-list');
      const selectedHost = root.querySelector('.basket-selected-list');
      const names = sectionNames();
      if (availableTitle) availableTitle.textContent = names.availableTitle;
      if (selectedTitle) selectedTitle.textContent = names.selectedTitle;
      if (!availableHost || !selectedHost) return;

      availableHost.innerHTML = '';
      selectedHost.innerHTML = '';

      const selectedSources = new Set(state.values.map((item) => item.sourceDraftId).filter(Boolean));
      const availableEntries = Array.from(available.values()).filter((entry) => !selectedSources.has(entry.draftId));

      if (!availableEntries.length) {
        availableHost.appendChild(makeEmpty('No available items'));
      } else {
        availableEntries.forEach((entry, index) => {
          const { row, button } = makeRow(entry.name || 'Name' + (index + 1), '+', 'basket-add');
          onDynamic(button, 'click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const item = {
              id: 'basket-' + entry.draftId,
              sourceDraftId: entry.draftId,
              name: entry.name || 'Name' + (state.values.length + 1),
              conf: clone(entry.state.conf),
              values: clone(entry.state.values)
            };
            persist({ ...state, values: [...state.values, item] });
          });
          availableHost.appendChild(row);
        });
      }

      if (!state.values.length) {
        selectedHost.appendChild(makeEmpty('Basket is empty'));
      } else {
        state.values.forEach((item, index) => {
          const { row, button } = makeRow(item.name || 'Name' + (index + 1), '×', 'basket-remove');
          onDynamic(button, 'click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            persist({ ...state, values: state.values.filter((_, itemIndex) => itemIndex !== index) });
          });
          selectedHost.appendChild(row);
        });
      }
    };

    const syncSectionNames = () => {
      const names = sectionNames();
      if (
        names.availableTitle === state.conf.availableTitle &&
        names.selectedTitle === state.conf.selectedTitle
      ) {
        render();
        return;
      }
      persist({
        ...state,
        conf: {
          ...state.conf,
          availableTitle: names.availableTitle,
          selectedTitle: names.selectedTitle
        }
      });
    };

    const onPlusserUpdated = (event) => {
      const detail = event?.detail || event || {};
      const draftId = String(detail.draftId || '');
      if (draftId && detail.removed) {
        available.delete(draftId);
        render();
        return;
      }
      if (draftId) {
        const normalized = normalizePlusserState(detail.state);
        const name = plusserLabel({ state: normalized }, available.size);
        available.set(draftId, {
          draftId,
          name,
          state: normalized
        });
        const selectedIndex = state.values.findIndex((item) => item.sourceDraftId === draftId);
        if (selectedIndex >= 0) {
          const nextValues = state.values.map((item, index) =>
            index === selectedIndex
              ? { ...item, name, conf: clone(normalized.conf), values: clone(normalized.values) }
              : item
          );
          if (JSON.stringify(nextValues) !== JSON.stringify(state.values)) {
            persist({ ...state, values: nextValues });
            return;
          }
        }
      }
      render();
    };

    on(root.ownerDocument, 'dsl:plusser:updated', onPlusserUpdated);
    if (registry) {
      const registryListener = (detail) => onPlusserUpdated(detail);
      registry.listeners.add(registryListener);
      cleanup.push(() => registry.listeners.delete(registryListener));
    }

    const MutationObserverCtor = root.ownerDocument?.defaultView?.MutationObserver;
    const observer = MutationObserverCtor
      ? new MutationObserverCtor((mutations) => {
          const relevant = mutations.some((mutation) => {
            const target = mutation.target;
            if (target && root.contains?.(target)) return false;
            if (mutation.type === 'attributes') return true;
            const nodes = [...Array.from(mutation.addedNodes || []), ...Array.from(mutation.removedNodes || [])];
            return nodes.some((node) =>
              node?.nodeType === 1 &&
              (node.matches?.('.plusser-wrapper') || node.querySelector?.('.plusser-wrapper'))
            );
          });
          if (relevant) render();
        })
      : null;
    if (observer && root.ownerDocument?.body) {
      observer.observe(root.ownerDocument.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['data-plusser-state', 'data-draft-id']
      });
      cleanup.push(() => observer.disconnect());
    }

    const onExternalState = () => {
      state = normalizeState(model.get?.('basketState') || readAttributeState());
      render();
    };
    model.on?.('change:basketState', onExternalState);
    cleanup.push(() => model.off?.('change:basketState', onExternalState));
    model.on?.('change:addSectionName', syncSectionNames);
    model.on?.('change:deleteSectionName', syncSectionNames);
    cleanup.push(() => model.off?.('change:addSectionName', syncSectionNames));
    cleanup.push(() => model.off?.('change:deleteSectionName', syncSectionNames));
    model.on?.('change:traits', syncSectionNames);
    cleanup.push(() => model.off?.('change:traits', syncSectionNames));

    model.__stage17BasketCleanup = () => {
      dynamicCleanup.splice(0).forEach((dispose) => {
        try { dispose(); } catch {}
      });
      cleanup.splice(0).forEach((dispose) => {
        try { dispose(); } catch {}
      });
    };

    const addSectionTrait = model.getTrait?.('addSectionName');
    const deleteSectionTrait = model.getTrait?.('deleteSectionName');
    const currentAddSection = String(addSectionTrait?.getValue?.() || '').trim();
    const currentDeleteSection = String(deleteSectionTrait?.getValue?.() || '').trim();
    if ((!currentAddSection || currentAddSection === 'Section_name') && state.conf.availableTitle) {
      addSectionTrait?.setValue?.(state.conf.availableTitle);
    }
    if ((!currentDeleteSection || currentDeleteSection === 'Section_name') && state.conf.selectedTitle) {
      deleteSectionTrait?.setValue?.(state.conf.selectedTitle);
    }

    model.set?.('basketState', state, { silent: true });
    const initialState = JSON.stringify(state);
    root.setAttribute('data-basket-state', initialState);
    root.setAttribute('data-basket-object', initialState);
    render();
    try {
      const EventCtor = root.ownerDocument?.defaultView?.CustomEvent || CustomEvent;
      root.ownerDocument?.dispatchEvent(new EventCtor('dsl:basket:discover'));
    } catch {}
  `
};
