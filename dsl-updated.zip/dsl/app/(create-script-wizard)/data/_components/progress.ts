import { ComponentConfig } from '../elements';

export const Progress: ComponentConfig = {
  id: 'progress-bar',
  type: 'progress-bar',
  label: 'Progress',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: {
      class: 'progress-wrapper',
      'data-progress-type': 'Progress',
      'data-value': '30'
    },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'progress-header' },
        content: 'Progress',
        draggable: false,
        droppable: false,
        selectable: false
      },
      {
        tagName: 'div',
        attributes: { class: 'progress-linear' },
        components: [
          {
            tagName: 'div',
            attributes: { class: 'progress-track' },
            components: [
              {
                tagName: 'div',
                attributes: { class: 'progress-fill' },
                draggable: false,
                droppable: false,
                selectable: false
              }
            ],
            draggable: false,
            droppable: false,
            selectable: false
          },
          {
            tagName: 'span',
            attributes: { class: 'progress-percent' },
            content: '30%',
            draggable: false,
            droppable: false,
            selectable: false
          }
        ],
        draggable: false,
        droppable: false,
        selectable: false
      },
      {
        tagName: 'div',
        attributes: { class: 'progress-circle' },
        components: [
          {
            tagName: 'div',
            attributes: { class: 'progress-circle-inner' },
            components: [
              {
                tagName: 'span',
                attributes: { class: 'progress-circle-percent' },
                content: '30%',
                draggable: false,
                droppable: false,
                selectable: false
              }
            ],
            draggable: false,
            droppable: false,
            selectable: false
          }
        ],
        draggable: false,
        droppable: false,
        selectable: false
      }
    ],
    droppable: false,
    selectable: true
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="12" cy="12" r="9" stroke="white" stroke-width="1.5" stroke-dasharray="4 4"/>
</svg>`,
  traits: [
    {
      id: 'valuePercent',
      name: 'valuePercent',
      label: 'Value Percent',
      type: 'number',
      changeProp: true,
      value: 30,
      min: 0,
      max: 100,
      step: 1
    },
    {
      id: 'progressType',
      name: 'progressType',
      label: 'Type',
      type: 'select',
      changeProp: true,
      value: 'Progress',
      options: [
        { id: 'Progress', name: 'Progress', value: 'Progress' },
        { id: 'Circle', name: 'Circle', value: 'Circle' }
      ]
    },
    {
      id: 'header',
      name: 'header',
      label: 'Header',
      type: 'text',
      changeProp: true,
      value: 'Progress'
    }
  ],
  styles: `
    .progress-wrapper {
      --progress-angle: 108deg;
      --progress-color: #4170FF;
      --progress-track: rgba(255, 255, 255, 0.16);
      display: inline-flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: flex-start;
      width: 260px;
      max-width: 100%;
      min-width: 160px;
      min-height: 54px;
      box-sizing: border-box;
      padding: 0;
      margin: 0;
      background: transparent;
      border: none;
      color: #FFFFFF;
      font-family: Montserrat, Arial, sans-serif;
      line-height: 1.2;
    }

    .progress-header {
      display: block;
      width: 100%;
      margin: 0 0 10px;
      color: #FFFFFF;
      font-size: 14px;
      font-weight: 500;
      line-height: 1.25;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .progress-linear {
      display: flex;
      align-items: center;
      gap: 12px;
      width: 100%;
      min-width: 0;
      box-sizing: border-box;
    }

    .progress-track {
      position: relative;
      display: block;
      flex: 1 1 auto;
      min-width: 40px;
      height: 8px;
      overflow: hidden;
      background: var(--progress-track);
      border-radius: 999px;
    }

    .progress-fill {
      display: block;
      width: 30%;
      height: 100%;
      background: var(--progress-color);
      border-radius: inherit;
      transition: width 0.18s ease;
    }

    .progress-percent,
    .progress-circle-percent {
      color: #4170FF;
      font-size: 14px;
      font-weight: 500;
      white-space: nowrap;
      font-variant-numeric: tabular-nums;
    }

    .progress-circle {
      display: none;
      align-items: center;
      justify-content: center;
      width: 92px;
      height: 92px;
      flex: 0 0 92px;
      border-radius: 50%;
      background: conic-gradient(
        var(--progress-color) var(--progress-angle),
        var(--progress-track) 0
      );
      box-sizing: border-box;
      padding: 7px;
    }

    .progress-circle-inner {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background: #171C23;
      box-sizing: border-box;
    }

    .progress-wrapper[data-progress-type="Circle"] {
      width: 92px;
      min-width: 92px;
      min-height: 116px;
    }

    .progress-wrapper[data-progress-type="Circle"] .progress-linear {
      display: none;
    }

    .progress-wrapper[data-progress-type="Circle"] .progress-circle {
      display: flex;
    }
  `,
  script: `
function stage23ProgressNumber(raw, fallback) {
  const parsed = Number(raw);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(0, Math.min(100, parsed));
}

function stage23ProgressType(raw) {
  const normalized = String(raw == null ? '' : raw).trim().toLowerCase();
  return normalized === 'circle' ? 'Circle' : 'Progress';
}

function stage23ProgressValue(model, name, fallback) {
  // Prefer the trait itself. In some GrapesJS flows the trait value is updated
  // before the changeProp mirror on the component model, which previously made
  // Type read the stale Progress model value for one render and look broken.
  const trait = model && model.getTrait ? model.getTrait(name) : null;
  const traitValue = trait && trait.getValue ? trait.getValue() : undefined;
  if (traitValue !== undefined && traitValue !== null && traitValue !== '') return traitValue;

  const direct = model && model.get ? model.get(name) : undefined;
  if (direct !== undefined && direct !== null && direct !== '') return direct;

  return fallback;
}

function stage23UpdateProgress(model) {
  if (!model || !model.getEl || !model.getEl()) return;
  const wrapper = model.getEl();
  const attrs = model.getAttributes ? model.getAttributes() : {};

  const value = stage23ProgressNumber(
    stage23ProgressValue(
      model,
      'valuePercent',
      attrs['data-value'] != null ? attrs['data-value'] : 30
    ),
    30
  );
  const type = stage23ProgressType(
    stage23ProgressValue(
      model,
      'progressType',
      attrs['data-progress-type'] || 'Progress'
    )
  );

  wrapper.style.setProperty('--progress-angle', value * 3.6 + 'deg');
  wrapper.setAttribute('data-value', String(value));
  wrapper.setAttribute('data-progress-type', type);

  if (model.get && model.set) {
    if (model.get('valuePercent') !== value) model.set('valuePercent', value, { silent: true });
    if (model.get('progressType') !== type) model.set('progressType', type, { silent: true });
  }

  const header = String(stage23ProgressValue(model, 'header', 'Progress') || '');
  const headerEl = wrapper.querySelector('.progress-header');
  if (headerEl) {
    headerEl.textContent = header;
    headerEl.style.display = header ? 'block' : 'none';
  }

  const percentText = Math.round(value * 100) / 100 + '%';
  const percentEl = wrapper.querySelector('.progress-percent');
  const circlePercentEl = wrapper.querySelector('.progress-circle-percent');
  const fillEl = wrapper.querySelector('.progress-fill');

  if (percentEl) percentEl.textContent = percentText;
  if (circlePercentEl) circlePercentEl.textContent = percentText;
  if (fillEl) fillEl.style.width = value + '%';

  const previousType = model.__stage23ProgressType;
  if (type === 'Circle') {
    if (previousType !== 'Circle') {
      const currentStyle = model.getStyle ? model.getStyle() : {};
      model.__stage23ProgressLinearSize = {
        width: currentStyle.width || wrapper.style.width || '',
        height: currentStyle.height || wrapper.style.height || ''
      };
    }
    model.addStyle && model.addStyle({
      width: '92px',
      height: '116px',
      'min-width': '92px',
      'min-height': '116px'
    });
  } else if (previousType === 'Circle') {
    const saved = model.__stage23ProgressLinearSize || {};
    model.addStyle && model.addStyle({
      width: saved.width || '260px',
      height: saved.height || '54px',
      'min-width': '160px',
      'min-height': '54px'
    });
  }

  model.__stage23ProgressType = type;
}

function stage23BindProgress(model) {
  if (!model) return;
  if (model.__stage23ProgressCleanup) {
    try { model.__stage23ProgressCleanup(); } catch (_) {}
  }

  const update = function() { stage23UpdateProgress(model); };
  const traitBindings = [];
  ['header', 'valuePercent', 'progressType'].forEach(function(name) {
    const trait = model.getTrait ? model.getTrait(name) : null;
    if (trait && trait.on && trait.off) {
      trait.on('change:value', update);
      traitBindings.push(function() { trait.off('change:value', update); });
    }
  });

  model.on('change:header', update);
  model.on('change:valuePercent', update);
  model.on('change:progressType', update);
  model.on('change:traits', update);
  model.on('change:attributes', update);

  model.__stage23ProgressCleanup = function() {
    traitBindings.splice(0).forEach(function(unbind) {
      try { unbind(); } catch (_) {}
    });
    model.off('change:header', update);
    model.off('change:valuePercent', update);
    model.off('change:progressType', update);
    model.off('change:traits', update);
    model.off('change:attributes', update);
  };

  update();
}

stage23BindProgress(model);
  `,
  styleConfig: {
    sectors: []
  }
};
