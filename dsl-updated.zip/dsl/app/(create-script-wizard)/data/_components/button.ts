import { ComponentConfig } from '../elements';

export const SingleButtonConfig: ComponentConfig = {
  id: 'button',
  type: 'custom-button-item',
  label: 'Single Button',
  category: 'Children',
  content: {
    tagName: 'button',
    content: 'Button',
    attributes: {
      class: 'component-button',
      type: 'button',
      value: 'Button',
      disabled: 'false',
      name: 'Button',
      data: 'Купить',
      'data-type': 'Boolean',
      'data-table-role': 'true',
      'aria-pressed': 'false',
      'data-value': 'false'
    },
    components: [
      {
        type: 'image-icon',
        tagName: 'img',
        attributes: {
          class: 'button-icon',
          src: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSI5IiBjeT0iOSIgcj0iNy41IiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjEuNSIvPjxwYXRoIGQ9Ik01LjUgOUw4IDExLjVMMTIuNSA2LjUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48L3N2Zz4='
        },
        droppable: false,
        editable: false,
        selectable: false,
        hoverable: false,
        highlightable: false,
        badgable: false,
        layerable: false,
        copyable: false,
        draggable: false
      },
      {
        tagName: 'span',
        attributes: { class: 'button-label' },
        content: 'Button',
        droppable: false,
        editable: false,
        selectable: false,
        hoverable: false,
        highlightable: false,
        badgable: false,
        layerable: false,
        copyable: false,
        draggable: false
      }
    ],
    droppable: true,
    editable: true,
    selectable: true
  },
  script: `
  function updateButton(model) {
    if (!model || typeof model.getEl !== 'function') return;

    const buttonEl = model.getEl();
    if (!buttonEl) return;

    const traits = model.getTraits();

    try {
      // === 1. TEXT UPDATE ===
      const labelComp = model.find('.button-label')?.[0];

      if (labelComp) {
        // Проверяем текст в трейтах, если пусто — берем из атрибутов (актуально для первой кнопки)
        const textTrait = traits.find(t => t.getName() === 'text');
        const textValue = textTrait ? textTrait.getValue() : null;
        const attrValue =
          model.getAttributes().value ||
          model.getAttributes().text ||
          model.getAttributes()['data-text'];

        const text = textValue || attrValue || 'Button';

        // Обновляем визуальное представление в DOM
        const labelEl = labelComp.getEl();
        if (labelEl && labelEl.textContent !== text) {
          labelEl.textContent = text;
        }

        // Обновляем модель компонентов GrapesJS для корректного экспорта HTML
        const currentContent = labelComp.components().models[0]?.get('content');
        if (currentContent !== text) {
           labelComp.components().reset();
           labelComp.append(text);
        }

        // Синхронизируем атрибуты родительской модели (без повторного триггера, если значение то же)
        if (model.getAttributes().value !== text) {
          model.setAttributes({
            ...model.getAttributes(),
            value: text,
            'data-text': text
          });
        }
      }

      // === 2. ICON UPDATE ===
      const iconEl = buttonEl.querySelector('.button-icon');
      const iconTrait = traits.find(t => t.getName() === 'selectIcon');
      const attrs = model.getAttributes() || {};
      const selectedIcon =
        iconTrait?.getValue?.() ||
        attrs.selectIcon ||
        attrs['data-select-icon'] ||
        attrs['data-icon'] ||
        '';
      const defaultIcon = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSI5IiBjeT0iOSIgcj0iNy41IiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjEuNSIvPjxwYXRoIGQ9Ik01LjUgOUw4IDExLjVMMTIuNSA2LjUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48L3N2Zz4=';
      const iconSrc = selectedIcon || defaultIcon;

      if (iconEl && (iconSrc.startsWith('data:image') || iconSrc.startsWith('http'))) {
        if (iconEl.getAttribute('src') !== iconSrc) {
          iconEl.setAttribute('src', iconSrc);
        }

        const iconComp = model.findType('image-icon')?.[0];
        if (iconComp) {
          const iconAttrs = iconComp.getAttributes?.() || {};
          if (iconAttrs.src !== iconSrc) {
            iconComp.setAttributes({ ...iconAttrs, src: iconSrc });
            iconComp.set?.('src', iconSrc);
            iconComp.view?.render?.();
          }
        }
      }

      if (selectedIcon && attrs['data-icon'] !== selectedIcon) {
        model.addAttributes({ 'data-icon': selectedIcon }, { silent: true });
      }

      // === 3. COLOR UPDATE ===
      const colorTrait = traits.find(t => t.getName() === 'color');
      const selectedColor =
        colorTrait?.getValue?.() ||
        attrs.color ||
        attrs['data-color'] ||
        '#4170FF';
      if (selectedColor) {
        buttonEl.style.setProperty('--bg', selectedColor);
        const currentStyle = model.getStyle?.() || {};
        if (currentStyle['--bg'] !== selectedColor) {
          model.addStyle?.({ '--bg': selectedColor });
        }
        if (attrs['data-color'] !== selectedColor) {
          model.addAttributes({ 'data-color': selectedColor }, { silent: true });
        }
      }

      // === 4. BOOLEAN BUTTON STATE ===
      // Button interaction is boolean; keep it separate from labels in metadata.items.
      const pressedRaw = attrs['data-value'] ?? attrs['aria-pressed'] ?? false;
      const pressed = pressedRaw === true || String(pressedRaw).toLowerCase() === 'true';
      buttonEl.setAttribute('aria-pressed', pressed ? 'true' : 'false');
      buttonEl.setAttribute('data-value', pressed ? 'true' : 'false');
      buttonEl.setAttribute('data-type', 'Boolean');
      buttonEl.setAttribute('type', 'button');

      // === 5. FLEX DIRECTION ===
      const isColumn = traits.find(t => t.getName() === 'axis')?.getValue() === 'column';
      const buttonPosition = traits.find(t => t.getName() === 'buttonPosition')?.getValue() || 'left';

      let dir = 'row';
      if (isColumn) {
        dir = buttonPosition === 'left' ? 'column' : 'column-reverse';
      } else {
        dir = buttonPosition === 'left' ? 'row' : 'row-reverse';
      }

      const styles = model.getStyle();
      const gapX = styles['--gap-x'] || '10px';
      const gapY = styles['--gap-y'] || '10px';

      model.addStyle({
        'display': 'flex',
        'flex-direction': dir,
        '--gap-x': gapX,
        '--gap-y': gapY
      });

    } catch (e) {
      console.error('Button update error:', e);
    }
  }

  function init() {
    if (typeof model === 'undefined' || !model) return;

    // Первоначальная синхронизация
    setTimeout(() => updateButton(model), 0);

    if (!model.__buttonRuntimeBound) {
      model.__buttonRuntimeBound = true;

      let updateTimeout;
      const debouncedUpdate = () => {
        clearTimeout(updateTimeout);
        updateTimeout = setTimeout(() => updateButton(model), 10);
      };

      model.on('change:traits', debouncedUpdate);
      model.on('change:attributes', debouncedUpdate);
      model.on('change:style', debouncedUpdate);
      model.on('component:update', debouncedUpdate);

      const iconComp = model.findType('image-icon')?.[0];
      if (iconComp && !iconComp.__buttonIconRuntimeBound) {
        iconComp.__buttonIconRuntimeBound = true;
        iconComp.on('change:attributes', debouncedUpdate);
      }
    }

    // The model can be initialized before GrapesJS has mounted its element.
    // Therefore DOM listeners are bound independently from model listeners and
    // retried every time the runtime script runs from view.onRender().
    const buttonEl = model.getEl && model.getEl();
    if (buttonEl && !buttonEl.__booleanButtonBound) {
      buttonEl.__booleanButtonBound = true;
      buttonEl.addEventListener('click', function () {
        const currentAttrs = model.getAttributes ? model.getAttributes() : {};
        const disabledRaw = currentAttrs.disabled;
        const disabled =
          disabledRaw === true || String(disabledRaw).toLowerCase() === 'true';
        if (disabled) return;

        const currentRaw =
          buttonEl.getAttribute('data-value') ??
          currentAttrs['data-value'] ??
          currentAttrs['aria-pressed'] ??
          false;
        const current =
          currentRaw === true || String(currentRaw).toLowerCase() === 'true';
        const next = !current;

        buttonEl.setAttribute('data-value', next ? 'true' : 'false');
        buttonEl.setAttribute('aria-pressed', next ? 'true' : 'false');
        buttonEl.setAttribute('data-type', 'Boolean');
        model.addAttributes({
          'data-value': next ? 'true' : 'false',
          'aria-pressed': next ? 'true' : 'false',
          'data-type': 'Boolean'
        });

        // Consumers of DSL components listen to normal control events. Keep
        // Button compatible with the same input/change pipeline while the
        // actual payload remains the Boolean value in data-value.
        try {
          const EventCtor = buttonEl.ownerDocument?.defaultView?.Event || Event;
          buttonEl.dispatchEvent(new EventCtor('input', { bubbles: true }));
          buttonEl.dispatchEvent(new EventCtor('change', { bubbles: true }));
        } catch (e) {}
      });
    }
  }

  init();
`,
  styles: `
      @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap');

      .component-button {
        /* --- CSS VARIABLES --- */

        /* Basic Styles */
        --bg: #4170FF;
        --bc: #4170FF;
        --bw: 0px;
        --color: #FFFFFF;
        --fs: 16px;
        --gap-x: 8px;
        --gap-y: 8px;

        --width: auto;
        --height: 40px;
        --min-width: 72px;
        --min-height: 34px;

        /* Flex Children Vars */
        --order: 0;
        --flex-grow: 0;
        --flex-shrink: 1;
        --flex-basis: auto;
        --align-self: auto;

        /* Grid Children Vars */
        --grid-column-start: auto;
        --grid-column-end: auto;
        --grid-row-start: auto;
        --grid-row-end: auto;
        --justify-self: start;

        /* Position Vars */
        --text-align: center;
        --position: relative; /* Default for buttons usually relative or static */
        --top: auto;
        --right: auto;
        --bottom: auto;
        --left: auto;
        --z-index: auto;

        /* --- APPLY VARIABLES --- */

        /* Flex Item Props */
        order: var(--order);
        flex-grow: var(--flex-grow);
        flex-shrink: var(--flex-shrink);
        flex-basis: var(--flex-basis);
        align-self: var(--align-self);

        /* Grid Item Props */
        grid-column-start: var(--grid-column-start);
        grid-column-end: var(--grid-column-end);
        grid-row-start: var(--grid-row-start);
        grid-row-end: var(--grid-row-end);
        justify-self: var(--justify-self);

        /* Positioning Props */
        text-align: var(--text-align);
        position: var(--position);
        top: var(--top);
        right: var(--right);
        bottom: var(--bottom);
        left: var(--left);
        z-index: var(--z-index);

        /* Dimensions & Box Model */
        width: var(--width);
        height: var(--height);
        min-width: var(--min-width);
        min-height: var(--min-height);
        padding: 7px 14px;

        /* Layout */
        display: flex;
        align-items: center;
        justify-content: center;
        column-gap: var(--gap-x, 10px);
        row-gap: var(--gap-y, 10px);
        line-height: 1;
        appearance: none;
        -webkit-appearance: none;

        /* Visuals */
        background-color: var(--bg);
        color: var(--color);
        font-size: var(--fs);

        border-style: solid;
        border-top-width: var(--bw, 0px);
        border-right-width: var(--bw, 0px);
        border-bottom-width: var(--bw, 0px);
        border-left-width: var(--bw, 0px);

        border-top-color: var(--bc, #3182ce);
        border-right-color: var(--bc, #3182ce);
        border-bottom-color: var(--bc, #3182ce);
        border-left-color: var(--bc, #3182ce);
        border-radius: 8px;

        cursor: pointer;
        box-sizing: border-box;
        font-family: 'Montserrat', sans-serif;
        transition: background-color 0.2s;
      }

      .component-button:hover {
        filter: brightness(0.9);
      }

      .component-button[aria-pressed="true"] {
        filter: brightness(0.92);
        box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.45);
      }

      .button-icon {
        outline: none !important;
        box-shadow: none !important;
        object-fit: contain;
        display: block;
        width: 18px;
        height: 18px;
        flex: 0 0 18px;
        pointer-events: none;
        vertical-align: middle;
        transform: translateY(2px);
      }

      .button-label {
        outline: none !important;
        box-shadow: none !important;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 18px;
        margin: 0;
        padding: 0;
        line-height: 18px;
        vertical-align: middle;
        transform: translateY(2px);
        pointer-events: none;
      }
    `,
  styleConfig: {
    target: '.component-button',
    sectors: [
      {
        id: 'flex-children',
        name: 'Flex-Children',
        open: true,
        properties: [
          {
            id: 'flex-order-type',
            name: 'Flex Order Type',
            property: 'order-type', // UI Only
            type: 'radio',
            default: '0',
            options: [
              { id: 'type1', label: 'Type 1', name: '', value: '' },
              { id: 'type2', label: 'Type 2', name: '', value: '' }
            ]
          },
          {
            id: 'order',
            name: 'Order',
            property: '--order',
            type: 'number',
            default: '0'
          },
          {
            id: 'flex-grow-shrink-group',
            name: 'Flex Shrink/Grow',
            type: 'composite',
            property: 'flex-group',
            properties: [
              {
                id: 'flex-basis',
                name: 'Basis',
                property: '--flex-basis',
                type: 'number',
                default: 'auto'
              },
              {
                id: 'flex-shrink',
                name: 'Shrink',
                property: '--flex-shrink',
                type: 'number',
                default: '1'
              },
              {
                id: 'flex-grow',
                name: 'Grow',
                property: '--flex-grow',
                type: 'number',
                default: '0'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align Self',
            property: 'align-self',
            type: 'radio',
            default: 'auto',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'flex-start' },
              { id: 'end', label: 'End', name: '', value: 'flex-end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' }
            ]
          },
          {
            id: 'justify-self',
            name: 'Justify Self',
            property: 'justify-self',
            type: 'radio',
            default: 'start',
            options: [
              { id: 'start', label: 'Start', name: '', value: 'start' },
              { id: 'end', label: 'End', name: '', value: 'end' },
              { id: 'center', label: 'Center', name: '', value: 'center' },
              { id: 'stretch', label: 'Stretch', name: '', value: 'stretch' },
              { id: 'auto', label: 'Auto', name: '', value: 'auto' }
            ]
          },
          {
            id: 'justify-items',
            name: 'Justify Items',
            property: '--justify-items',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'start', name: '' },
              { id: 'end', label: 'End', value: 'end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              { id: 'stretch', label: 'Stretch', value: 'stretch', name: '' },
              { id: 'normal', label: 'Normal', value: 'normal', name: '' }
            ]
          },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: 'justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: 'align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              { id: 'start', label: 'Start', value: 'flex-start', name: '' },
              { id: 'end', label: 'End', value: 'flex-end', name: '' },
              { id: 'center', label: 'Center', value: 'center', name: '' },
              { id: 'stretch', label: 'Stretch', value: 'stretch', name: '' },
              { id: 'baseline', label: 'Baseline', value: 'baseline', name: '' }
            ]
          }
        ]
      },
      {
        id: 'grid-parent',
        name: 'Grid-Parent',
        open: true,
        properties: [
          {
            id: 'grid-template-columns',
            name: 'Columns',
            property: 'grid-template-columns',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-template-rows',
            name: 'Rows',
            property: 'grid-template-rows',
            type: 'text',
            default: '1fr'
          },
          {
            id: 'grid-column-gap',
            name: 'Gap Column',
            property: 'column-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '10px'
          },
          {
            id: 'grid-row-gap',
            name: 'Gap Row',
            property: 'row-gap',
            type: 'number',
            units: ['px', '%', 'rem'],
            default: '10px'
          },
          {
            id: 'justify-items',
            name: 'Justify Items',
            property: 'justify-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'normal',
                label: 'Normal',
                value: 'normal',
                name: ''
              }
            ]
          },
          {
            id: 'justify-content',
            name: 'Justify Content',
            property: 'justify-content',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'space-between',
                label: 'Space Between',
                value: 'space-between',
                name: ''
              },
              {
                id: 'space-around',
                label: 'Space Around',
                value: 'space-around',
                name: ''
              },
              {
                id: 'space-evenly',
                label: 'Space Evenly',
                value: 'space-evenly',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              }
            ]
          },
          {
            id: 'align-items',
            name: 'Align Items',
            property: 'align-items',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-grid',
        name: 'Grid-Children',
        open: true,
        properties: [
          {
            id: 'grid-column-start',
            name: 'Start Column',
            property: '--grid-column-start',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-column-end',
            name: 'End Column',
            property: '--grid-column-end',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-row-start',
            name: 'Start Row',
            property: '--grid-row-start',
            type: 'number',
            default: '1'
          },
          {
            id: 'grid-row-end',
            name: 'End Row',
            property: '--grid-row-end',
            type: 'number',
            default: '1'
          },
          {
            id: 'justify-self',
            name: 'Justify-Self',
            property: '--justify-self',
            type: 'radio',
            default: 'start',
            options: [
              {
                id: 'start',
                label: 'Start',
                name: '',
                value: 'start'
              },
              {
                id: 'end',
                label: 'End',
                name: '',
                value: 'end'
              },
              {
                id: 'stretch',
                label: 'Stretch',
                name: '',
                value: 'stretch'
              },
              {
                id: 'center',
                label: 'Center',
                name: '',
                value: 'center'
              },
              {
                id: 'auto',
                label: 'Auto',
                name: '',
                value: 'auto'
              }
            ]
          },
          {
            id: 'align-self',
            name: 'Align-Self',
            property: '--align-self',
            type: 'radio',
            default: 'stretch',
            options: [
              {
                id: 'start',
                label: 'Start',
                value: 'start',
                name: ''
              },
              {
                id: 'end',
                label: 'End',
                value: 'end',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'stretch',
                label: 'Stretch',
                value: 'stretch',
                name: ''
              },
              {
                id: 'baseline',
                label: 'Baseline',
                value: 'baseline',
                name: ''
              }
            ]
          }
        ]
      },
      {
        id: 'layout-position',
        name: 'Position Settings',
        open: true,
        properties: [
          {
            id: 'text-align',
            name: 'Align',
            property: '--text-align', // ПЕРЕМЕННАЯ
            type: 'radio',
            default: 'center',
            options: [
              {
                id: 'left',
                label: 'Left',
                value: 'left',
                name: ''
              },
              {
                id: 'center',
                label: 'Center',
                value: 'center',
                name: ''
              },
              {
                id: 'right',
                label: 'Right',
                value: 'right',
                name: ''
              }
            ]
          },
          {
            id: 'position',
            name: 'Position',
            property: '--position', // ПЕРЕМЕННАЯ
            type: 'select',
            default: 'relative',
            options: [
              {
                id: 'static',
                label: 'Static',
                value: 'static',
                name: ''
              },
              {
                id: 'relative',
                label: 'Relative',
                value: 'relative',
                name: ''
              },
              {
                id: 'absolute',
                label: 'Absolute',
                value: 'absolute',
                name: ''
              },
              {
                id: 'fixed',
                label: 'Fixed',
                value: 'fixed',
                name: ''
              },
              {
                id: 'sticky',
                label: 'Sticky',
                value: 'sticky',
                name: ''
              }
            ]
          },
          {
            id: 'top',
            name: 'Top',
            property: '--top',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          }, // ПЕРЕМЕННАЯ
          {
            id: 'right',
            name: 'Right',
            property: '--right',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          }, // ПЕРЕМЕННАЯ
          {
            id: 'left',
            name: 'Left',
            property: '--left',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          }, // ПЕРЕМЕННАЯ
          {
            id: 'bottom',
            name: 'Bottom',
            property: '--bottom',
            type: 'number',
            units: ['px', '%'],
            default: 'auto'
          } // ПЕРЕМЕННАЯ
        ]
      },
      {
        id: 'style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'background-color',
            name: 'Color',
            property: '--bg',
            type: 'color',
            default: '#4170FF'
          },
          {
            id: 'border-color',
            name: 'Border Color',
            property: '--bc',
            type: 'color',
            default: '#4170FF'
          },
          {
            id: 'border-width',
            name: 'Border Width',
            property: '--bw',
            type: 'number',
            default: 0,
            units: ['px']
          }
        ]
      },
      {
        id: 'size',
        name: 'Size',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: '--width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'auto', 'vw']
          },
          {
            id: 'height',
            name: 'Height',
            property: '--height',
            type: 'number',
            default: 44,
            units: ['px', '%', 'auto', 'vh']
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: '--min-width',
            type: 'number',
            default: 131,
            units: ['px', '%', 'vw']
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: '--min-height',
            type: 'number',
            default: 40,
            units: ['px', '%', 'vh']
          },
          {
            id: 'display',
            name: 'Display',
            property: 'display',
            type: 'select',
            default: 'flex',
            options: [
              {
                value: 'block',
                name: 'Block',
                id: 'block'
              },
              {
                value: 'flex',
                name: 'Flex',
                id: 'flex'
              },
              {
                value: 'grid',
                name: 'Grid',
                id: 'grid'
              },
              {
                value: 'inline-block',
                name: 'Inline Block',
                id: 'inline-block'
              }
            ]
          }
        ]
      },
      {
        id: 'spacing',
        name: 'Spacing',
        open: true,
        properties: [
          {
            id: 'padding',
            name: 'Padding',
            property: 'padding',
            type: 'text',
            default: '8px 16px'
          },
          {
            id: 'margin',
            name: 'Margin',
            property: 'margin',
            type: 'text',
            default: '0'
          },
          {
            id: 'gap-x',
            name: 'Gap X (icon↔text)',
            property: '--gap-x',
            type: 'number',
            default: 10,
            units: ['px']
          },
          {
            id: 'gap-y',
            name: 'Gap Y (icon↔text)',
            property: '--gap-y',
            type: 'number',
            default: 10,
            units: ['px']
          }
        ]
      },
      {
        id: 'header-text',
        name: 'Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: '--fs',
            type: 'number',
            default: 16,
            units: ['px']
          },
          {
            id: 'color',
            name: 'Color',
            property: '--color',
            type: 'color',
            default: '#FFFFFF'
          }
        ]
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M0 5.33334C0 2.38781 2.38781 0 5.33334 0C8.27885 0 10.6667 2.38781 10.6667 5.33334C10.6667 8.27885 8.27885 10.6667 5.33334 10.6667C2.38781 10.6667 0 8.27885 0 5.33334ZM5.33334 9.33334C3.1242 9.33334 1.33334 7.54248 1.33334 5.33334C1.33334 3.1242 3.1242 1.33334 5.33334 1.33334C7.54248 1.33334 9.33334 3.1242 9.33334 5.33334C9.33334 7.54248 7.54248 9.33334 5.33334 9.33334ZM0 24V13.3334H10.6667V24H0ZM1.33334 22.6666V14.6666H9.33334V22.6666H1.33334ZM24 10.6667L18 0L12 10.6667H24ZM21.7203 9.33334L18 2.71964L14.2797 9.33334H21.7203ZM17.3334 24V19.3334H12.6666V18H17.3334V13.3334H18.6666V18H23.3334V19.3334H18.6666V24H17.3334Z" fill="white"/>
    </svg>`,
  traits: [
    {
      id: 'text',
      type: 'text',
      name: 'text',
      label: 'Text',
      value: 'Button',
      changeProp: true
    },
    {
      id: 'selectIcon',
      type: 'select-icon',
      name: 'selectIcon',
      label: 'Icon',
      value: '',
      changeProp: true
    },
    {
      id: 'color',
      type: 'color',
      name: 'color',
      label: 'Color',
      value: '#4170FF',
      changeProp: true
    }
  ]
};
