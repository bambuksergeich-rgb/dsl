import { ComponentConfig } from '../elements';

export const ChoiceChips: ComponentConfig = {
  id: 'choice-chips',
  type: 'custom-choice-chips',
  label: 'Choice Chips',
  category: 'Components',
  content: {
    tagName: 'div',
    components: [
      {
        tagName: 'button',
        content: 'Option1',
        attributes: {
          class: 'choice-chip active',
          type: 'button',
          'data-component-id': 'choice-chip-1',
          'data-choice-id': 'option1',
          'aria-pressed': 'true'
        },
        droppable: false,
        editable: false,
        selectable: false,
        hoverable: false,
        draggable: false,
        resizable: false
      }
    ],
    attributes: {
      class: 'choice-chips-container',
      'data-component-id': 'choice-chips',
      'data-checked': 'true',
      'data-active-choice': 'option1',
      'data-value': 'true',
      'aria-checked': 'true'
    },
    droppable: false,
    editable: false,
    selectable: true
  },
  styleConfig: {
    sectors: [
      {
        id: 'chip-style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: 'transparent',
            selector: '.choice-chip:not(.active)'
          },
          {
            id: 'border-color',
            name: 'Border Color',
            property: 'border-color',
            type: 'color',
            default: '#4170FF',
            selector: '.choice-chip:not(.active)'
          },
          {
            id: 'border-width',
            name: 'Border Width',
            property: 'border-width',
            type: 'number',
            default: 1,
            units: ['px'],
            selector: '.choice-chip:not(.active)'
          },
          {
            id: 'border-style',
            name: 'Border Type',
            property: 'border-style',
            type: 'select',
            default: 'solid',
            options: [
              {
                value: 'solid',
                label: 'Solid',
                id: '',
                name: ''
              },
              {
                value: 'dashed',
                label: 'Dashed',
                id: '',
                name: ''
              },
              {
                value: 'dotted',
                label: 'Dotted',
                id: '',
                name: ''
              },
              {
                value: 'none',
                label: 'None',
                id: '',
                name: ''
              }
            ],
            selector: '.choice-chip:not(.active)'
          }
        ]
      },
      {
        id: 'chip-active-style',
        name: 'Active Style',
        open: true,
        properties: [
          {
            id: 'active-background-color',
            name: 'Active Background Color',
            property: 'background-color',
            type: 'color',
            default: '#4170FF',
            selector: '.choice-chip.active'
          },
          {
            id: 'active-border-color',
            name: 'Active Border Color',
            property: 'border-color',
            type: 'color',
            default: '#4170FF',
            selector: '.choice-chip.active'
          },
          {
            id: 'active-border-width',
            name: 'Active Border Width',
            property: 'border-width',
            type: 'number',
            default: 1,
            units: ['px'],
            selector: '.choice-chip.active'
          },
          {
            id: 'active-border-style',
            name: 'Active Border Type',
            property: 'border-style',
            type: 'select',
            default: 'solid',
            options: [
              {
                value: 'solid',
                label: 'Solid',
                id: '',
                name: ''
              },
              {
                value: 'dashed',
                label: 'Dashed',
                id: '',
                name: ''
              },
              {
                value: 'dotted',
                label: 'Dotted',
                id: '',
                name: ''
              },
              {
                value: 'none',
                label: 'None',
                id: '',
                name: ''
              }
            ],
            selector: '.choice-chip.active'
          }
        ]
      },
      {
        id: 'chip-dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'chip-width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'auto', 'vw'],
            selector: '.choice-chip'
          },
          {
            id: 'chip-height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 36,
            units: ['px', '%', 'auto', 'vh'],
            selector: '.choice-chip'
          },
          {
            id: 'chip-min-width',
            name: 'Min-Width',
            property: 'min-width',
            type: 'number',
            default: 'fit-content',
            units: ['px', '%', 'vw'],
            selector: '.choice-chip'
          },
          {
            id: 'chip-min-height',
            name: 'Min-Height',
            property: 'min-height',
            type: 'number',
            default: 36,
            units: ['px', '%', 'vh'],
            selector: '.choice-chip'
          },
          {
            id: 'chip-max-width',
            name: 'Max-Width',
            property: 'max-width',
            type: 'number',
            default: 'none',
            units: ['px', '%', 'vw', 'none'],
            selector: '.choice-chip'
          },
          {
            id: 'chip-max-height',
            name: 'Max-Height',
            property: 'max-height',
            type: 'number',
            default: 'none',
            units: ['px', '%', 'vh', 'none'],
            selector: '.choice-chip'
          }
        ]
      },
      {
        id: 'chip-text',
        name: 'Text',
        open: true,
        properties: [
          {
            id: 'font-size',
            name: 'Font Size',
            property: 'font-size',
            type: 'number',
            default: 14,
            units: ['px', '%', 'vw'],
            selector: '.choice-chip'
          },
          {
            id: 'text-color',
            name: 'Color',
            property: 'color',
            type: 'color',
            default: '#4170FF',
            selector: '.choice-chip:not(.active)'
          },
          {
            id: 'active-text-color',
            name: 'Active Color',
            property: 'color',
            type: 'color',
            default: '#FFFFFF',
            selector: '.choice-chip.active'
          }
        ]
      }
    ]
  },
  traits: [
    {
      id: 'text',
      name: 'text',
      type: 'text',
      label: 'Text',
      changeProp: true,
      value: 'Option1'
    },
    {
      id: 'options',
      name: 'options',
      type: 'list',
      label: 'Options',
      changeProp: true,
      value: JSON.stringify([{ value: 'option1', label: 'Option1' }])
    },
    {
      id: 'checked',
      name: 'checked',
      type: 'checkbox',
      label: 'Active',
      changeProp: true,
      value: true
    }
  ],
  styles: `
    .choice-chips-container {
      display: flex;
      flex-direction: column;
      gap: 8px;
      align-items: flex-start;
      box-sizing: border-box;
      background-color: transparent !important;
      border: none !important;
      min-width: 80px;
      min-height: 36px;
      overflow: visible;
      user-select: none;
    }
    .choice-chip {
      padding: 8px 16px;
      border-radius: 20px;
      display: inline-flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      transition: all 0.2s ease;
      font-size: 14px;
      width: auto;
      min-width: fit-content;
      min-height: 36px;
      height: 36px;
      background-color: transparent;
      border: 1px solid #4170FF;
      color: #4170FF;
      box-sizing: border-box;
      font-family: 'Montserrat', sans-serif;
      max-width: 100%;
      touch-action: manipulation;
    }
    .choice-chip.active {
      background-color: #4170FF;
      border: 1px solid #4170FF;
      color: #FFFFFF;
    }
    .choice-chip:hover {
      filter: brightness(1.2);
    }
  `,
  script: `
    function normalizeOptions(rawOptions) {
      if (!Array.isArray(rawOptions) || !rawOptions.length) {
        return [{ value: 'option1', label: 'Option1' }];
      }
      return rawOptions.map((option, index) => {
        const value =
          option && option.value != null && option.value !== ''
            ? String(option.value)
            : 'option' + (index + 1);
        const label =
          option && option.label != null && option.label !== ''
            ? String(option.label)
            : 'Option1';
        return { value, label };
      });
    }

    function parseOptions(raw) {
      if (Array.isArray(raw)) return normalizeOptions(raw);
      if (typeof raw !== 'string' || !raw.trim()) {
        return [{ value: 'option1', label: 'Option1' }];
      }
      try {
        return normalizeOptions(JSON.parse(raw));
      } catch (e) {
        return [{ value: 'option1', label: 'Option1' }];
      }
    }

    function isCheckedValue(raw) {
      if (raw === true || raw === 1 || raw === '1') return true;
      if (typeof raw === 'string') {
        const value = raw.trim().toLowerCase();
        return value === 'true' || value === 'checked' || value === 'yes';
      }
      return false;
    }

    function readChecked(model) {
      const checkedTrait = model.getTrait && model.getTrait('checked');
      if (checkedTrait) {
        const traitValue = checkedTrait.getValue();
        if (traitValue != null && traitValue !== '') return isCheckedValue(traitValue);
      }
      if (typeof model.get === 'function' && model.get('choiceChecked') != null) {
        return isCheckedValue(model.get('choiceChecked'));
      }
      const attrs = model.getAttributes ? model.getAttributes() : {};
      if (attrs['data-checked'] != null) return isCheckedValue(attrs['data-checked']);
      if (attrs['data-selected'] != null) return isCheckedValue(attrs['data-selected']);
      return false;
    }

    function writeChecked(model, checked, activeChoice) {
      const checkedTrait = model.getTrait && model.getTrait('checked');
      if (checkedTrait && checkedTrait.setValue) {
        const current = checkedTrait.getValue();
        if (String(current) !== String(checked)) checkedTrait.setValue(checked);
      }
      if (typeof model.set === 'function' && model.get('choiceChecked') !== checked) {
        model.set('choiceChecked', checked);
      }
      if (model.addAttributes) {
        model.addAttributes({
          'data-checked': checked ? 'true' : 'false',
          'data-active-choice': checked && activeChoice ? String(activeChoice) : ''
        });
      }
    }

    function readText(model) {
      const trait = model.getTrait && model.getTrait('text');
      const raw = trait && trait.getValue ? trait.getValue() : '';
      return raw == null ? '' : String(raw).trim();
    }

    function readOptions(model) {
      const optionsTrait = model.getTrait && model.getTrait('options');
      const raw = optionsTrait && optionsTrait.getValue ? optionsTrait.getValue() : '';
      const options = parseOptions(raw);
      const text = readText(model);

      // The options trait is the source of truth once it has been edited. Only migrate
      // the legacy single-option shape where the list still has its untouched
      // default label but the older text trait already contains user data.
      if (
        text &&
        options.length === 1 &&
        options[0].label === 'Option1' &&
        text !== 'Option1'
      ) {
        return [{ ...options[0], label: text }];
      }
      return options;
    }

    function writeOptions(model, options) {
      const trait = model.getTrait && model.getTrait('options');
      if (!trait || !trait.setValue) return;
      const next = JSON.stringify(options);
      const current = String(trait.getValue ? trait.getValue() : '');
      if (current !== next) trait.setValue(next);
    }

    function syncTextToOptions(model) {
      const text = readText(model);
      if (!text) return;
      const options = readOptions(model);
      if (!options.length) {
        writeOptions(model, [{ value: 'option1', label: text }]);
        return;
      }
      if (options[0].label === text) return;
      writeOptions(model, [{ ...options[0], label: text }, ...options.slice(1)]);
    }

    function chipDefinition(opt, index) {
      return {
        tagName: 'button',
        content: opt.label,
        attributes: {
          class: 'choice-chip',
          type: 'button',
          'data-component-id': 'choice-chip-' + (index + 1),
          'data-choice-id': opt.value,
          'aria-pressed': 'false'
        },
        selectable: false,
        hoverable: false,
        highlightable: false,
        draggable: false,
        droppable: false,
        editable: false,
        resizable: false,
        layerable: false
      };
    }

    function syncChipChildren(model, options) {
      const collection = model.components && model.components();
      if (!collection) return;

      // Do not reset the complete GrapesJS child collection here. A reset
      // destroys and recreates DOM nodes while the root is selected/resized and
      // was the main reason Choice Chips could visually disappear after a click
      // or resize. Reconcile the existing children in place instead.
      for (let index = 0; index < options.length; index += 1) {
        const opt = options[index];
        let child = collection.models && collection.models[index];

        if (!child) {
          if (model.append) model.append(chipDefinition(opt, index));
          continue;
        }

        const attrs = child.getAttributes ? child.getAttributes() : {};
        if (String(child.get && child.get('content') || '') !== opt.label) {
          child.set && child.set('content', opt.label);
        }
        child.addAttributes && child.addAttributes({
          ...attrs,
          class: 'choice-chip',
          type: 'button',
          'data-component-id': 'choice-chip-' + (index + 1),
          'data-choice-id': opt.value
        });
        child.set && child.set({
          selectable: false,
          hoverable: false,
          highlightable: false,
          draggable: false,
          droppable: false,
          editable: false,
          resizable: false,
          layerable: false
        });
      }

      const current = collection.models ? collection.models.slice() : [];
      for (let index = current.length - 1; index >= options.length; index -= 1) {
        const child = current[index];
        if (child && child.remove) child.remove();
        else if (collection.remove) collection.remove(child);
      }
    }

    function paintChips(model) {
      const container = model.getEl && model.getEl();
      if (!container) return;
      const checked = readChecked(model);
      const attrs = model.getAttributes ? model.getAttributes() : {};
      const activeChoice = String(attrs['data-active-choice'] || '');
      const chips = container.querySelectorAll('.choice-chip');
      const choiceIds = Array.from(chips).map(function(chip) {
        return String(chip.getAttribute('data-choice-id') || '');
      });
      const resolvedActiveChoice =
        activeChoice && choiceIds.indexOf(activeChoice) !== -1
          ? activeChoice
          : (choiceIds[0] || '');
      chips.forEach(function (chip, index) {
        const choiceId = String(chip.getAttribute('data-choice-id') || '');
        const active = checked && (resolvedActiveChoice ? choiceId === resolvedActiveChoice : index === 0);
        chip.classList.toggle('active', active);
        chip.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
      container.setAttribute('data-checked', checked ? 'true' : 'false');
      container.setAttribute('data-value', checked ? 'true' : 'false');
      container.setAttribute('aria-checked', checked ? 'true' : 'false');
    }

    function updateChoiceChips(model, syncChildren) {
      if (!model || model.__updatingChoiceChips) return;
      model.__updatingChoiceChips = true;
      try {
        const options = readOptions(model);
        if (syncChildren !== false) syncChipChildren(model, options);
        paintChips(model);
      } finally {
        model.__updatingChoiceChips = false;
      }
    }

    updateChoiceChips(model, true);

    if (!model.__choiceChipsBound) {
      model.__choiceChipsBound = true;
      model.on('change:options', function () {
        updateChoiceChips(model, true);
      });
      model.on('change:text', function () {
        if (model.__updatingChoiceChips) return;
        syncTextToOptions(model);
        updateChoiceChips(model, true);
      });
      model.on('change:checked change:choiceChecked change:attributes', function () {
        updateChoiceChips(model, false);
      });
    }

    const container = model.getEl && model.getEl();
    // Keep pointerdown bubbling to GrapesJS so the root remains selectable and
    // draggable. Blocking pointerdown made Choice Chips clicks feel "stuck" and
    // could leave the editor in an inconsistent selection state.
    if (container && !container.__choiceChipsClickBound) {
      container.__choiceChipsClickBound = true;
      container.addEventListener('click', function (event) {
        const chip = event.target && event.target.closest && event.target.closest('.choice-chip');
        if (!chip || !container.contains(chip)) return;
        // Inline label editing (remark 18) owns pointer/keyboard interaction
        // while contenteditable is active; do not toggle the chip underneath it.
        if (chip.getAttribute && chip.getAttribute('contenteditable') === 'true') return;
        event.preventDefault();
        const checked = readChecked(model);
        const attrs = model.getAttributes ? model.getAttributes() : {};
        const activeChoice = String(attrs['data-active-choice'] || '');
        const choiceId = String(chip.getAttribute('data-choice-id') || '');
        const isCurrentChoice = checked && (!activeChoice || activeChoice === choiceId);
        const next = !isCurrentChoice;
        writeChecked(model, next, choiceId);
        paintChips(model);

        // Configuration/runtime consumers listen to regular control events.
        // Emit them from the logical control after the model is already synced.
        try {
          container.dispatchEvent(new Event('input', { bubbles: true }));
          container.dispatchEvent(new Event('change', { bubbles: true }));
        } catch (e) {}
      });
    }
  `,
  block: true,
  icon: `<svg width="28" height="16" viewBox="0 0 28 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.37921 1.5C11.4322 1.81232 16.4972 1.5 21.5524 1.5C24.0047 1.5 25.7457 4.48417 25.9072 6.27099C26.0686 8.0578 26.451 13.1265 22.5926 13.9136C18.7342 14.7006 8.58808 14.5715 6.60803 14.2426C4.62798 13.9136 2 13.1884 2 8.0578C2 2.92717 4.41064 1.66072 4.84328 1.66072" stroke="white" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`
};
