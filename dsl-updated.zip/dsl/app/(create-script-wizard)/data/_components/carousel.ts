import { ComponentConfig } from '../elements';

export const Carousel: ComponentConfig = {
  id: 'carousel',
  type: 'carousel',
  label: 'Carusel',
  category: 'Interactive',
  content: {
    tagName: 'div',
    attributes: { class: 'carousel-wrapper' },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'carousel-slides' },
        components: [
          {
            tagName: 'div',
            attributes: { class: 'carousel-slide active' },
            content: 'Slide 1'
          },
          {
            tagName: 'div',
            attributes: { class: 'carousel-slide' },
            content: 'Slide 2'
          }
        ]
      },
      {
        tagName: 'button',
        attributes: { class: 'carousel-next' },
        content:
          '<svg width="16" height="16" viewBox="0 0 16 16" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M6 2l6 6-6 6"/></svg>'
      },
      {
        tagName: 'button',
        attributes: { class: 'carousel-prev' },
        content:
          '<svg width="16" height="16" viewBox="0 0 16 16" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M10 2L4 8l6 6"/></svg>'
      }
    ]
  },
  block: true,
  icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16.5 19.5H7.5C7.10218 19.5 6.72064 19.342 6.43934 19.0607C6.15804 18.7794 6 18.3978 6 18V6C6 5.60218 6.15804 5.22064 6.43934 4.93934C6.72064 4.65804 7.10218 4.5 7.5 4.5H16.5C16.8978 4.5 17.2794 4.65804 17.5607 4.93934C17.842 5.22064 18 5.60218 18 6V18C18 18.3978 17.842 18.7794 17.5607 19.0607C17.2794 19.342 16.8978 19.5 16.5 19.5ZM7.5 6V18H16.5V6H7.5ZM3 18H0V16.5H3V7.5H0V6H3C3.39782 6 3.77936 6.15804 4.06066 6.43934C4.34196 6.72064 4.5 7.10218 4.5 7.5V16.5C4.5 16.8978 4.34196 17.2794 4.06066 17.5607C3.77936 17.842 3.39782 18 3 18ZM24 18H21C20.6022 18 20.2206 17.842 19.9393 17.5607C19.658 17.2794 19.5 16.8978 19.5 16.5V7.5C19.5 7.10218 19.658 6.72064 19.9393 6.43934C20.2206 6.15804 20.6022 6 21 6H24V7.5H21V16.5H24V18Z" fill="white"/>
</svg>`,
  traits: [
    {
      id: 'slideCount',
      name: 'slideCount',
      label: 'Number of Slides',
      type: 'number',
      changeProp: true,
      value: 2,
      min: 1,
      max: 25
    },
    {
      id: 'minMax',
      name: 'minMax',
      type: 'select',
      label: 'Size',
      options: [
        { id: 'min', name: 'min', value: 'min' },
        { id: 'max', name: 'max', value: 'max' }
      ],
      value: 'min',
      changeProp: true
    }
  ],
  styles: `
    .carousel-wrapper {
      width: var(--slide-width, 852px);
      padding: 16px;
      border: 2px solid var(--border-color, #e2e8f0);
      border-radius: 4px;
      position: relative;
      box-sizing: border-box;
      overflow: visible;
    }
    .carousel-slides {
      position: relative;
      overflow: hidden;
      width: var(--slide-width, 852px);
      height: 238px;
      margin:0 auto;
    }
    .carousel-slide {
      position: absolute;
      top: 0;
      left: 0;
      width: var(--slide-width, 852px);
      height: 238px;
      border: 2px solid #3D3AB8;
      border-radius: 4px;
      text-align: center;
      line-height: 238px;
      color: #4a5568;
      opacity: 0;
      transform: translateX(100%);
      transition: opacity 0.3s ease, transform 0.3s ease;
    }
    .carousel-slide.active {
      opacity: 1;
      transform: translateX(0);
    }
    .carousel-slide.exiting {
      opacity: 0;
      transform: translateX(-100%);
    }
    .carousel-prev {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      width: 32px;
      height: 32px;
      background-color: #10161C80;
      border: 2px solid #3D3AB8;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background-color 0.2s;
      z-index: 10;
    }
    .carousel-next {
      position: absolute;
      right: 16px;
      top: 50%;
      transform: translateY(-50%);
      width: 32px;
      height: 32px;
      background-color: #10161C80;
      border: 2px solid #3D3AB8;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background-color 0.2s;
      z-index: 10;
    }
    .carousel-prev:hover, .carousel-next:hover {
      background-color: #10161C;
    }
  `,
  script: `
    function updateCarousel(model, editor) {
      console.log('updateCarousel called:', model.changed);
      if (!model || !model.getEl() || !editor) {
        console.error('No model, editor, or wrapper element');
        return;
      }
      const wrapper = model.getEl();
      const traits = model.getTraits();
      try {
        const slidesEl = wrapper.querySelector('.carousel-slides');
        const prevButton = wrapper.querySelector('.carousel-prev');
        const nextButton = wrapper.querySelector('.carousel-next');
        console.log('Prev button found:', prevButton);
        console.log('Next button found:', nextButton);
        if (slidesEl && prevButton && nextButton) {
          const slideCountTrait = traits.find(t => t.getName() === 'slideCount');
          const minMaxTrait = traits.find(t => t.getName() === 'minMax');
          const borderColor = traits.find(t => t.getName() === 'borderColor')?.getValue() || '#e2e8f0';
          let slideCount = slideCountTrait ? parseInt(slideCountTrait.getValue(), 10) : 2;
          const minMax = minMaxTrait ? minMaxTrait.getValue() : 'min';
          const slideWidth = minMax === 'min' ? 250 : 500;
          // Ограничиваем количество слайдов
          if (isNaN(slideCount) || slideCount < 1) {
            slideCount = 2;
            slideCountTrait.setValue(2);
          } else if (slideCount > 25) {
            slideCount = 25;
            slideCountTrait.setValue(25);
            editor.Modal.open({ title: 'Warning', content: 'Maximum 10 slides allowed.' });
          }
          // Устанавливаем ширину слайдов
          wrapper.style.setProperty('--slide-width', \`\${slideWidth}px\`);
          // Генерируем слайды
          slidesEl.innerHTML = Array.from({ length: slideCount }, (_, i) => 
            \`<div class="carousel-slide\${i === 0 ? ' active' : ''}">Slide \${i + 1}</div>\`
          ).join('');
          wrapper.style.setProperty('--border-color', borderColor);
          let currentIndex = 0;
          const slideEls = slidesEl.querySelectorAll('.carousel-slide');
          function showSlide(newIndex, direction) {
            if (slideCount <= 1) return; // Не пролистываем, если 1 слайд или меньше
            if (newIndex < 0) newIndex = slideCount - 1;
            if (newIndex >= slideCount) newIndex = 0;
            if (currentIndex === newIndex) return;
            const currentSlide = slideEls[currentIndex];
            const newSlide = slideEls[newIndex];
            if (currentSlide && newSlide) {
              currentSlide.classList.remove('active');
              currentSlide.classList.add('exiting');
              newSlide.classList.remove('exiting');
              newSlide.classList.add('active');
              if (direction === 'next') {
                newSlide.style.transform = 'translateX(100%)';
                newSlide.style.opacity = '0';
                setTimeout(() => {
                  newSlide.style.transition = 'transform 0.3s ease, opacity 0.3s ease';
                  newSlide.style.transform = 'translateX(0)';
                  newSlide.style.opacity = '1';
                  currentSlide.style.transition = 'transform 0.3s ease, opacity 0.3s ease';
                  currentSlide.style.transform = 'translateX(-100%)';
                  currentSlide.style.opacity = '0';
                }, 10);
              } else {
                newSlide.style.transform = 'translateX(-100%)';
                newSlide.style.opacity = '0';
                setTimeout(() => {
                  newSlide.style.transition = 'transform 0.3s ease, opacity 0.3s ease';
                  newSlide.style.transform = 'translateX(0)';
                  newSlide.style.opacity = '1';
                  currentSlide.style.transition = 'transform 0.3s ease, opacity 0.3s ease';
                  currentSlide.style.transform = 'translateX(100%)';
                  currentSlide.style.opacity = '0';
                }, 10);
              }
              setTimeout(() => {
                currentSlide.classList.remove('exiting');
                currentSlide.style.transition = '';
                currentSlide.style.transform = '';
                currentSlide.style.opacity = '';
              }, 300);
              currentIndex = newIndex;
              console.log('Slide shown:', newIndex);
            }
          }
          prevButton.addEventListener('click', () => {
            showSlide(currentIndex - 1, 'prev');
          });
          nextButton.addEventListener('click', () => {
            showSlide(currentIndex + 1, 'next');
          });
          // Перехватываем изменение трейта slideCount
          editor.on('trait:change:slideCount', () => {
            let slideCount = parseInt(slideCountTrait.getValue(), 10);
            if (isNaN(slideCount) || slideCount < 2) {
              slideCount = 2;
              slideCountTrait.setValue(2);
            } else if (slideCount > 25) {
              slideCount = 25;
              slideCountTrait.setValue(25);
              editor.Modal.open({ title: 'Warning', content: 'Maximum 10 slides allowed.' });
            }
            updateCarousel(model, editor);
            console.log('Slide count updated:', slideCount);
          });
          // Перехватываем изменение трейта minMax
          editor.on('trait:change:minMax', () => {
            const minMax = minMaxTrait.getValue();
            const slideWidth = minMax === 'min' ? 250 : 500;
            wrapper.style.setProperty('--slide-width', \`\${slideWidth}px\`);
            updateCarousel(model, editor);
            console.log('Slide width updated:', slideWidth);
          });
          console.log('Carousel updated:', { slideCount, slideWidth, borderColor });
        } else {
          console.error('Missing carousel elements:', { slidesEl, prevButton, nextButton });
        }
      } catch (e) {
        console.error('Error updating carousel:', e);
      }
    }
    if (model && model.getEl()) {
      updateCarousel(model, editor);
    } else {
      console.error('Model or element not available');
    }
    model.on('change', () => {
      console.log('Model changed:', model.changed);
      updateCarousel(model, editor);
    });
  `,
  styleConfig: {
    sectors: [
      {
        id: 'Dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          },
          {
            id: 'min-width',
            name: 'Min Width',
            property: 'min-width',
            type: 'number',
            default: '50%',
            units: ['px', '%']
          },
          {
            id: 'min-height',
            name: 'Min Height',
            property: 'min-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          },
          {
            id: 'max-width',
            name: 'Max Width',
            property: 'max-width',
            type: 'number',
            default: '752px',
            units: ['px', '%']
          },
          {
            id: 'max-height',
            name: 'Max Height',
            property: 'max-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%']
          }
        ]
      }
    ]
  }
};
