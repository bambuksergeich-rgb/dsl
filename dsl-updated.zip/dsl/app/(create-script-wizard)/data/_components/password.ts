import { ComponentConfig } from '../elements';

const PASSWORD_EYE_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgdmlld0JveD0iMCAwIDIwIDIwIiBmaWxsPSJub25lIj48cGF0aCBkPSJNMS44IDEwczIuOC01IDguMi01IDguMiA1IDguMiA1LTIuOCA1LTguMiA1LTguMi01LTguMi01WiIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIxLjUiLz48Y2lyY2xlIGN4PSIxMCIgY3k9IjEwIiByPSIyLjUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMS41Ii8+PC9zdmc+';

export const Password: ComponentConfig = {
  id: 'password',
  type: 'password',
  label: 'Password',
  category: 'Inputs',
  content: {
    tagName: 'div',
    attributes: { class: 'password-input-container' },
    components: [
      {
        tagName: 'div',
        attributes: { class: 'password-input-wrapper' },
        draggable: false,
        components: [
          {
            tagName: 'input',
            attributes: { type: 'password', class: 'password-input', placeholder: 'Enter text', autocomplete: 'current-password' },
            draggable: false
          },
          {
            tagName: 'button',
            attributes: { type: 'button', class: 'password-toggle', 'aria-label': 'Show password' },
            draggable: false,
            components: [{ tagName: 'img', attributes: { class: 'password-toggle-icon', src: PASSWORD_EYE_ICON }, draggable: false }]
          }
        ]
      },
      {
        tagName: 'a',
        attributes: { class: 'password-footer-link', href: '#', target: '_self' },
        content: 'Forget Password?',
        draggable: false
      }
    ]
  },
  block: true,
  icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3.5" y="6" width="17" height="12" rx="3" stroke="white" stroke-width="1.5"/><circle cx="8" cy="12" r="1.25" fill="white"/><circle cx="12" cy="12" r="1.25" fill="white"/><circle cx="16" cy="12" r="1.25" fill="white"/></svg>',
  traits: [
    { id: 'showIcon', name: 'showIcon', label: 'Show Icon', type: 'checkbox', changeProp: true, value: true },
    { id: 'placeholder', name: 'placeholder', label: 'Placeholder', type: 'text', placeholder: 'Enter text', changeProp: true, value: 'Enter text' },
    { id: 'footerLink', name: 'footerLink', label: 'Footer Link', type: 'text', placeholder: 'URL', changeProp: true, value: '' },
    { id: 'selectImage', name: 'selectImage', label: 'Image', type: 'select-icon', changeProp: true, value: '' }
  ],
  styles: `
/* Standard single-line control height from the editor design. */
.password-input-wrapper .password-input { height: 34px !important; min-height: 34px !important; max-height: 34px !important; line-height: 20px !important; }
[data-draft-id].password-input-wrapper, .password-input-wrapper { height: 34px !important; min-height: 34px !important; max-height: 34px !important; }

    .password-input-container {
      position: relative;
      display: inline-flex;
      flex-direction: column;
      align-items: center;
      width: 280px;
      min-width: 180px;
      min-height: 76px;
      overflow: visible;
      box-sizing: border-box;
      font-family: Montserrat, Arial, sans-serif;
    }
    .password-input-wrapper {
      position: relative;
      width: 100%;
      height: 48px;
      min-height: 48px;
      flex: 0 0 48px;
      box-sizing: border-box;
    }
    .password-input {
      display: block;
      width: 100%;
      height: 48px !important;
      min-height: 48px !important;
      padding: 0 48px 0 16px;
      border: 1px solid transparent;
      border-radius: 4px;
      background: #5B5D5F;
      color: #FFFFFF;
      font: 400 16px/48px Montserrat, Arial, sans-serif;
      box-sizing: border-box;
    }
    .password-input::placeholder { color: rgba(255,255,255,.42); }
    .password-input:hover { border-color: rgba(255,255,255,.12); }
    .password-input:focus { outline: none; border-color: rgba(255,255,255,.28); }
    .password-toggle {
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      width: 28px;
      height: 28px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0;
      border: 0;
      background: transparent;
      cursor: pointer;
    }
    .password-toggle-icon { width: 20px; height: 20px; object-fit: contain; pointer-events: none; }
    .password-footer-link {
      margin-top: 10px;
      color: #4170FF;
      font: 500 14px/18px Montserrat, Arial, sans-serif;
      text-decoration: none;
      text-align: center;
    }
  `,
  script: `
    (function () {
      if (!model || !model.getEl()) return;
      const root = model.getEl();
      const input = root.querySelector('.password-input');
      const toggle = root.querySelector('.password-toggle');
      const icon = root.querySelector('.password-toggle-icon');
      const footer = root.querySelector('.password-footer-link');
      const traitValue = function (name, fallback) {
        const trait = model.getTrait && model.getTrait(name);
        const value = trait && trait.getValue ? trait.getValue() : undefined;
        return value === undefined || value === null || value === '' ? fallback : value;
      };
      const asBool = function (value) { return value === true || value === 'true' || value === 1 || value === '1'; };
      const render = function () {
        if (!input) return;
        input.placeholder = String(traitValue('placeholder', 'Enter text'));
        const attrs = model.getAttributes ? model.getAttributes() : {};
        if (attrs['data-value'] != null && input.value !== String(attrs['data-value'])) input.value = String(attrs['data-value']);
        const showIcon = asBool(traitValue('showIcon', true));
        if (toggle) toggle.style.display = showIcon ? 'inline-flex' : 'none';
        const src = String(traitValue('selectImage', '') || '${PASSWORD_EYE_ICON}');
        if (icon && src) icon.src = src;
        const href = String(traitValue('footerLink', '') || '#');
        if (footer) footer.setAttribute('href', href);

        const inputComponent = model.find && model.find('.password-input')[0];
        if (inputComponent && inputComponent.getAttributes) {
          const inputAttrs = inputComponent.getAttributes();
          if (inputAttrs.placeholder !== input.placeholder) {
            inputComponent.addAttributes({ placeholder: input.placeholder });
          }
        }
        const iconComponent = model.find && model.find('.password-toggle-icon')[0];
        if (iconComponent && iconComponent.getAttributes) {
          const iconAttrs = iconComponent.getAttributes();
          if (iconAttrs.src !== src) iconComponent.addAttributes({ src: src });
        }
        const footerComponent = model.find && model.find('.password-footer-link')[0];
        if (footerComponent && footerComponent.getAttributes) {
          const footerAttrs = footerComponent.getAttributes();
          if (footerAttrs.href !== href) footerComponent.addAttributes({ href: href });
        }
      };
      if (input) {
        input.oninput = function (event) {
          event.stopPropagation();
          model.addAttributes({ 'data-value': input.value });
        };
        input.onpointerdown = function (event) { event.stopPropagation(); };
      }
      if (toggle) {
        toggle.onclick = function (event) {
          event.preventDefault();
          event.stopPropagation();
          if (!input) return;
          input.type = input.type === 'password' ? 'text' : 'password';
          toggle.setAttribute('aria-label', input.type === 'password' ? 'Show password' : 'Hide password');
        };
        toggle.onpointerdown = function (event) { event.stopPropagation(); };
      }
      if (footer) footer.onclick = function (event) { event.stopPropagation(); };

      if (model.__stage13PasswordCleanup) model.__stage13PasswordCleanup();
      const onUpdate = function () { render(); };
      model.on('change:traits', onUpdate);
      model.on('change:attributes', onUpdate);
      model.on('active', onUpdate);
      model.__stage13PasswordCleanup = function () {
        model.off('change:traits', onUpdate);
        model.off('change:attributes', onUpdate);
        model.off('active', onUpdate);
      };
      render();
    })();
  `
};
