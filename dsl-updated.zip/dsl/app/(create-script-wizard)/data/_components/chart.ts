import { ComponentConfig } from '../elements';

export const Chart: ComponentConfig = {
  id: 'chart',
  type: 'chart',
  label: 'Chart',
  category: 'Main',
  content: {
    tagName: 'div',
    attributes: {
      class: 'chart-container w-full h-auto',
      'data-component-id': 'chart',
      'data-chart-type': 'line',
      'data-title': 'My Chart',
      'data-sub-title': 'Values',
      'data-info-text': 'Info',
      'data-chart-data': JSON.stringify([
        {
          id: 'layer-1',
          name: 'Layer 1',
          color: '#4170FF',
          points: [
            { label: 'Jan', value: 5, color: '#4170FF' },
            { label: 'Feb', value: 7, color: '#4170FF' },
            { label: 'Mar', value: 9, color: '#4170FF' },
            { label: 'Apr', value: 12, color: '#4170FF' },
            { label: 'May', value: 20, color: '#4170FF' },
            { label: 'Jun', value: 26, color: '#4170FF' },
            { label: 'Jul', value: 25.5, color: '#4170FF' },
            { label: 'Aug', value: 23, color: '#4170FF' },
            { label: 'Sep', value: 15, color: '#4170FF' },
            { label: 'Oct', value: 8, color: '#4170FF' },
            { label: 'Nov', value: 5, color: '#4170FF' },
            { label: 'Dec', value: 3, color: '#4170FF' }
          ]
        }
      ]),
      // Новые атрибуты
      x_axis: JSON.stringify({
        name: 'Values',
        data_type: 'Integer/Date',
        data: [
          'Jan',
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
          'Nov',
          'Dec'
        ]
      }),
      y_axis: JSON.stringify({
        name: 'My Chart',
        data_type: 'Integer/Float',
        data: [5, 7, 9, 12, 20, 26, 25.5, 23, 15, 8, 5, 3]
      }),
      points: JSON.stringify([
        {
          name: 'Layer 1',
          data_type: 'Array',
          data: [
            ['Jan', 5],
            ['Feb', 7],
            ['Mar', 9],
            ['Apr', 12],
            ['May', 20],
            ['Jun', 26],
            ['Jul', 25.5],
            ['Aug', 23],
            ['Sep', 15],
            ['Oct', 8],
            ['Nov', 5],
            ['Dec', 3]
          ],
          table_role: false
        }
      ])
    },
    components: [
      {
        tagName: 'canvas',
        attributes: { class: 'chart-canvas', 'data-chart-element': 'true' }
      }
    ],
    droppable: false,
    editable: true,
    selectable: true,
    resizable: {
      cr: true,
      bc: true,
      minDim: 200,
      maxDim: 1200,
      updateTarget: (el, rect) => {
        const c = el.querySelector('canvas');
        if (c) {
          c.style.maxWidth = `${rect.w}px`;
          c.style.maxHeight = `${rect.h}px`;
        }
      }
    }
  },
  block: true,
  icon: '<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.76 19.24L11.56 10.6L16.36 15.4L23.08 3.88M1 1V25H25" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  traits: [
    {
      id: 'chart-type',
      name: 'chart-type',
      label: 'Chart Type',
      type: 'select',
      changeProp: true,
      options: [
        { id: 'line', name: 'Line Chart with Text', value: 'line' },
        { id: 'table', name: 'Chart with Values', value: 'table' },
        { id: 'bar-bg', name: 'Background Chart', value: 'bar-bg' },
        { id: 'bar', name: 'Chart for Main Text', value: 'bar-val' },
        { id: 'main-text', name: 'Chart for Table', value: 'main-text' }
      ],
      value: 'line'
    },
    {
      id: 'title',
      name: 'title',
      label: 'Header',
      type: 'text',
      changeProp: true,
      value: 'My Chart'
    },
    {
      id: 'sub-title',
      name: 'sub-title',
      label: 'Sub Header',
      type: 'text',
      changeProp: true,
      value: 'Values'
    },
    {
      id: 'chart-data',
      name: 'chart-data',
      label: 'Chart Data',
      type: 'json',
      changeProp: true,
      value: JSON.stringify([
        {
          id: 'layer-1',
          name: 'Layer 1',
          color: '#4170FF',
          points: [
            { label: 'Jan', value: 5, color: '#4170FF' },
            { label: 'Feb', value: 7, color: '#4170FF' },
            { label: 'Mar', value: 9, color: '#4170FF' },
            { label: 'Apr', value: 12, color: '#4170FF' },
            { label: 'May', value: 20, color: '#4170FF' },
            { label: 'Jun', value: 26, color: '#4170FF' },
            { label: 'Jul', value: 25.5, color: '#4170FF' },
            { label: 'Aug', value: 23, color: '#4170FF' },
            { label: 'Sep', value: 15, color: '#4170FF' },
            { label: 'Oct', value: 8, color: '#4170FF' },
            { label: 'Nov', value: 5, color: '#4170FF' },
            { label: 'Dec', value: 3, color: '#4170FF' }
          ]
        }
      ])
    },
    {
      id: 'add-layer',
      name: 'add-layer',
      label: 'Add Layer',
      type: 'button',
      command: 'chart:add-layer'
    },
    {
      id: 'remove-layer',
      name: 'remove-layer',
      label: 'Remove Layer',
      type: 'button',
      command: 'chart:remove-layer'
    },
    {
      id: 'add-point',
      name: 'add-point',
      label: 'Add Point',
      type: 'button',
      command: 'chart:add-point'
    },
    {
      id: 'remove-point',
      name: 'remove-point',
      label: 'Remove Point',
      type: 'button',
      command: 'chart:remove-point'
    },
    {
      id: 'points-manager',
      name: 'points-manager',
      label: 'Points',
      type: 'custom-points',
      changeProp: false
    },
    {
      id: 'info-text',
      name: 'info-text',
      label: 'Info Text',
      type: 'text',
      changeProp: true,
      value: 'Info' // Дефолтное значение
    }
  ],
  styles: `
  .chart-container {
    background-color: #10161C;
    border: 1px solid #FFFFFF26;
    border-radius: 8px;
    padding: 20px;
    box-sizing: border-box;
    width: 100%;
    height: auto;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    font-family: 'Montserrat', sans-serif;
    overflow: hidden;
    
    --chart-header-color: #ffffff;
    --chart-header-size: 16px;
    --chart-subheader-color: #a0aec0;
    --chart-subheader-size: 14px;
    --chart-grid-color: #ffffff;
    --chart-grid-size: 12px;
  }
  .chart-canvas {
    width: 100% !important; 
    height: 300px !important;   
    min-width:100% !important;
    max-width: 100% !important; 
  }
  
  /* Стили для табличного типа */
  .chart-container[data-chart-type="main-text"] {
    background-color: transparent !important;
    border: none !important;
    box-shadow: none !important;
    padding: 0 !important;
  }

  .gjs-resizer { background-color: #FF2D55 !important; border: 2px solid #FFD700 !important; z-index: 1000 !important; width: 16px !important; height: 16px !important; cursor: move !important; opacity: 1 !important; display: block !important; }
  @media (max-width: 600px) { .chart-container { padding: 12px; } .chart-canvas { height: 250px !important; } }
`,
  script: `
const loadScripts = [{ src: 'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js', global: 'Chart', fallback: 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.3/chart.umd.min.js' }];
let scriptsLoaded = false;
let chartInstance = null;

function getDefaultChartData() {
  return [{
    id: 'layer-default', name: 'Layer 1', color: '#4170FF',
    points: [
      { label: 'Jan', value: 5, color: '#4170FF' }, { label: 'Feb', value: 7, color: '#4170FF' },
      { label: 'Mar', value: 9, color: '#4170FF' }, { label: 'Apr', value: 12, color: '#4170FF' },
      { label: 'May', value: 20, color: '#4170FF' }, { label: 'Jun', value: 26, color: '#4170FF' },
      { label: 'Jul', value: 25.5, color: '#4170FF' }, { label: 'Aug', value: 23, color: '#4170FF' },
      { label: 'Sep', value: 15, color: '#4170FF' }, { label: 'Oct', value: 8, color: '#4170FF' },
      { label: 'Nov', value: 5, color: '#4170FF' }, { label: 'Dec', value: 3, color: '#4170FF' }
    ]
  }];
}

function loadScript(s){return new Promise((res,rej)=>{if(window[s.global]){res();return}const e=document.createElement('script');e.src=s.src;e.async=true;e.onload=()=>res();e.onerror=()=>{if(s.fallback){e.src=s.fallback;e.onload=()=>res();e.onerror=()=>rej(new Error('Failed'));document.head.appendChild(e)}else{rej(new Error('Failed'))}};document.head.appendChild(e)})}
function loadLibraries(){if(scriptsLoaded)return Promise.resolve();return Promise.all(loadScripts.map(loadScript)).then(()=>{scriptsLoaded=true})}

function initChartEditor(model) {
  const container = model.getEl();
  if (!container) return;
  const canvas = container.querySelector('canvas');
  if (!canvas) return;

  const traits = model.getTraits();
  const chartType = traits.find(t => t.getName() === 'chart-type')?.getValue() || 'line';
  const title = traits.find(t => t.getName() === 'title')?.getValue() || 'My Chart';
  const subTitle = traits.find(t => t.getName() === 'sub-title')?.getValue() || 'Values';
  const infoText = traits.find(t => t.getName() === 'info-text')?.getValue() || 'Total Balance';

  let chartData = [];
  try {
    const traitVal = traits.find(t => t.getName() === 'chart-data')?.getValue();
    chartData = JSON.parse(traitVal || '[]');
    if (!chartData.length) chartData = getDefaultChartData();
  } catch (e) { chartData = getDefaultChartData(); }

  // --- СИНХРОНИЗАЦИЯ АТРИБУТОВ (x_axis, y_axis, points) ---
  if (chartData.length > 0) {
    const firstLayer = chartData[0];
    const labels = firstLayer.points.map(p => p.label);
    const values = firstLayer.points.map(p => p.value);

    // 1. Формируем x_axis
    const xAxisObj = {
      name: subTitle || 'Values',
      data_type: 'Integer/Date',
      data: labels
    };

    // 2. Формируем y_axis
    const yAxisObj = {
      name: title || 'My Chart',
      data_type: 'Integer/Float',
      data: values
    };

    // 3. Формируем points
    const pointsObj = chartData.map(layer => ({
      name: layer.name,
      data_type: 'Array',
      data: layer.points.map(p => [p.label, p.value]),
      table_role: false
    }));

    // Обновляем модель
    const currentAttrs = model.get('attributes');
    model.set('attributes', {
      ...currentAttrs,
      'x_axis': JSON.stringify(xAxisObj),
      'y_axis': JSON.stringify(yAxisObj),
      'points': JSON.stringify(pointsObj),
      'data-chart-type': chartType,
      'data-title': title,
      'data-sub-title': subTitle,
      'data-info-text': infoText, 
      'data-chart-data': JSON.stringify(chartData)
    });
  } else {
      container.setAttribute('data-chart-type', chartType);
      container.setAttribute('data-title', title);
      container.setAttribute('data-sub-title', subTitle);
      container.setAttribute('data-info-text', infoText); 
      container.setAttribute('data-chart-data', JSON.stringify(chartData));
  }
  
  loadLibraries().then(() => {
    renderChart(canvas, chartData, chartType, title, subTitle, infoText, container);
  }).catch(err => console.error(err));
}
  
function renderChart(canvas, chartData, chartType, title, subTitle, infoText, container) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  if (chartInstance) { chartInstance.destroy(); chartInstance = null; }

  const validLayers = chartData.filter(l => l.points && l.points.length > 0);
  if (validLayers.length === 0) return;
  
  const isTableChart = chartType === 'main-text';

  if (isTableChart) {
      container.style.backgroundColor = 'transparent';
      container.style.border = 'none';
      container.style.boxShadow = 'none';
  } else {
      container.style.backgroundColor = '';
      container.style.border = '';
      container.style.boxShadow = '';
  }

  const style = getComputedStyle(container);
  const headerColor = style.getPropertyValue('--chart-header-color').trim() || '#ffffff';
  const headerSize = parseInt(style.getPropertyValue('--chart-header-size').trim() || '16', 10);
  const subHeaderColor = style.getPropertyValue('--chart-subheader-color').trim() || '#a0aec0';
  const subHeaderSize = parseInt(style.getPropertyValue('--chart-subheader-size').trim() || '14', 10);
  const gridColor = style.getPropertyValue('--chart-grid-color').trim() || '#ffffff';
  const gridSize = parseInt(style.getPropertyValue('--chart-grid-size').trim() || '12', 10);
  
  const infoColor = style.getPropertyValue('--chart-info-color').trim() || '#ffffff';
  const infoSize = parseInt(style.getPropertyValue('--chart-info-size').trim() || '24', 10);
  const infoWeight = style.getPropertyValue('--chart-info-weight').trim() || '700';

  const labels = validLayers[0].points.map(p => p.label);
  let jsChartType = 'line'; 

  let totalSum = 0;
  if (chartType === 'bar-val') {
      validLayers.forEach(layer => { layer.points.forEach(p => { totalSum += (Number(p.value) || 0); }); });
      totalSum = totalSum.toLocaleString(); 
  }

  const datasets = validLayers.map(layer => {
    let backgroundColor = layer.color + '40'; 
    let borderColor = layer.color;
    let borderWidth = 3;
    let pointRadius = 3;
    let fill = true;
    let tension = 0.4;

    if (chartType === 'line') {
        fill = false; backgroundColor = 'transparent'; tension = 0.4;
    } 
    else if (chartType === 'bar-val') {
        fill = true; borderWidth = 0; pointRadius = 0; backgroundColor = layer.color + '80'; tension = 0.1; 
    }
    else if (chartType === 'bar-bg' || chartType === 'main-text') {
        fill = true; borderWidth = 0; pointRadius = 0; backgroundColor = layer.color + '40'; tension = 0.4;
    }
    else if (chartType === 'table') {
        fill = true; borderWidth = 3; pointRadius = 3; tension = 0.4;
    }

    return {
        label: layer.name,
        data: layer.points.map(p => p.value),
        backgroundColor: backgroundColor,
        borderColor: borderColor,
        borderWidth: borderWidth,
        fill: fill,
        tension: tension,
        pointRadius: pointRadius,
        pointBackgroundColor: layer.points.map(p => p.color || layer.color),
        pointBorderColor: '#ffffff',
        pointBorderWidth: pointRadius > 0 ? 2 : 0,
        pointHoverRadius: pointRadius > 0 ? 6 : 0,
        originalBorderColor: borderColor,
        originalBackgroundColor: backgroundColor
    };
  });

  const showScales = chartType !== 'bar-bg' && chartType !== 'main-text';
  const showLegend = chartType !== 'table' && chartType !== 'main-text' && chartType !== 'bar-bg' && chartType !== 'bar-val';

  const totalLabelPlugin = {
    id: 'totalLabel',
    beforeDraw: (chart) => {
       if (chartType !== 'bar-val') return; 
       const { ctx, width, height } = chart;
       ctx.save();
       const xPos = width / 2; const yPos = height / 2; 
       ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
       ctx.fillStyle = subHeaderColor; ctx.font = 'normal 16px Montserrat, sans-serif'; ctx.fillText(infoText, xPos, yPos - 15); 
       ctx.fillStyle = infoColor; ctx.font = infoWeight + ' ' + infoSize + 'px Montserrat, sans-serif'; ctx.fillText(totalSum, xPos, yPos + 15); 
       ctx.restore();
    }
  };

  const config = {
    type: jsChartType,
    data: { labels, datasets },
    plugins: [totalLabelPlugin], 
    options: {
      responsive: true, maintainAspectRatio: false,
      layout: isTableChart ? { padding: 0 } : {},
      interaction: { mode: 'nearest', axis: 'xy', intersect: true },
      onHover: (event, activeElements, chart) => {
         if (chartType !== 'line') return; 
         if (activeElements && activeElements.length > 0) {
            const activeDatasetIndex = activeElements[0].datasetIndex;
            chart.data.datasets.forEach((dataset, i) => {
               if (i === activeDatasetIndex) { dataset.borderColor = dataset.originalBorderColor; dataset.borderWidth = 4; } 
               else { dataset.borderColor = dataset.originalBorderColor + '20'; dataset.borderWidth = 3; }
            });
         } else {
            chart.data.datasets.forEach(dataset => { dataset.borderColor = dataset.originalBorderColor; dataset.borderWidth = 3; });
         }
         chart.update('none');
      },
      plugins: {
        title: { 
            display: !isTableChart, 
            text: title, color: headerColor, font: { size: headerSize, weight: 'bold' } 
        },
        legend: {
          display: showLegend, position: 'bottom', align: 'start',
          labels: { 
              color: gridColor, usePointStyle: true, padding: 30, font: { size: gridSize },
              generateLabels: function(chart) {
                  const originalLabels = Chart.defaults.plugins.legend.labels.generateLabels(chart);
                  return originalLabels.map(label => {
                      const dataset = chart.data.datasets[label.datasetIndex];
                      if(dataset && dataset.originalBorderColor) { label.fillStyle = dataset.originalBorderColor; label.strokeStyle = 'transparent'; }
                      return label;
                  });
              }
          } 
        }
      },
      scales: {
        x: {
          display: showScales,
          ticks: { color: gridColor, font: { size: gridSize } },
          grid: { display: false, color: '#FFFFFF26' }
        },
        y: {
          display: showScales,
          ticks: { color: gridColor, font: { size: gridSize }, stepSize: 10 },
          grid: { color: '#FFFFFF26', drawBorder: false },
          title: {
            display: showScales && !!subTitle,
            text: subTitle, color: subHeaderColor, font: { size: subHeaderSize, weight: 'normal' },
            padding: { bottom: 10 }
          }
        }
      }
    }
  };
  
  if (isTableChart) {
      config.options.maintainAspectRatio = false;
  }
  
  try { chartInstance = new window.Chart(ctx, config); } catch (e) { console.error(e); }
}

function initChartRuntime(container) {
  const canvas = container.querySelector('canvas');
  if (!canvas) return;
  const chartType = container.getAttribute('data-chart-type') || 'line';
  const title = container.getAttribute('data-title') || 'My Chart';
  const subTitle = container.getAttribute('data-sub-title') || ''; 
  const infoText = container.getAttribute('data-info-text') || 'Total Balance'; 
  const chartDataAttr = container.getAttribute('data-chart-data');
  
  let chartData = [];
  if (!chartDataAttr) { chartData = getDefaultChartData(); } 
  else {
      try { 
          const decodedData = chartDataAttr.replace(/&quot;/g, '"').replace(/&amp;/g, '&');
          chartData = JSON.parse(decodedData);
          if (!chartData.length) chartData = getDefaultChartData();
      } catch (e) { chartData = getDefaultChartData(); }
  }
  loadLibraries().then(() => { renderChart(canvas, chartData, chartType, title, subTitle, infoText, container); }).catch(err => {});
}

// --- COMMANDS SECTION ---
if (typeof editor !== 'undefined') {
    // 1. ADD LAYER
    editor.Commands.add('chart:add-layer', { run: (editor, sender, options = {}) => { 
        const component = options.component || editor.getSelected(); 
        if (!component) return; 
        const chartDataTrait = component.getTrait('chart-data'); 
        let chartData = JSON.parse(chartDataTrait.getValue() || '[]'); 
        if (!chartData.length) chartData = getDefaultChartData();
        
        const basePoints = chartData[0].points; 
        const newLayerColor = options.color || '#FF6B6B'; 
        const newLayerName = options.name || ('Layer ' + (chartData.length + 1));
        const values = basePoints.map(p => p.value);
        const minVal = Math.min(...values);
        const maxVal = Math.max(...values);

        const newPoints = basePoints.map(point => {
            const randomVal = Math.floor(Math.random() * (maxVal - minVal + 1)) + minVal;
            return { label: point.label, value: randomVal, color: newLayerColor };
        }); 
        
        chartData.push({ id: crypto.randomUUID(), name: newLayerName, color: newLayerColor, points: newPoints }); 
        chartDataTrait.setValue(JSON.stringify(chartData)); 
        initChartEditor(component); 
    }});

    // 2. REMOVE LAYER
    editor.Commands.add('chart:remove-layer', { run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component) return;
        const chartDataTrait = component.getTrait('chart-data');
        let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
        
        if (chartData.length > 1) {
            chartData.pop(); 
            chartDataTrait.setValue(JSON.stringify(chartData));
            initChartEditor(component); 
        } else {
            console.warn('Cannot remove the last layer');
        }
    }});

    // 3. ADD POINT (Ключевая команда для обновления x_axis и y_axis)
    editor.Commands.add('chart:add-point', { run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component) return;
        const chartDataTrait = component.getTrait('chart-data');
        let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
        if (!chartData.length) return;

        const currentPointsCount = chartData[0].points.length;
        const newLabel = 'P' + (currentPointsCount + 1);

        chartData.forEach(layer => {
            const lastVal = layer.points.length > 0 ? layer.points[layer.points.length - 1].value : 10;
            const randomDelta = Math.floor(Math.random() * 10) - 5;
            let newVal = lastVal + randomDelta;
            if (newVal < 0) newVal = 0;

            layer.points.push({
                label: newLabel,
                value: newVal,
                color: layer.color
            });
        });

        chartDataTrait.setValue(JSON.stringify(chartData));
        initChartEditor(component); 
    }});

    // 4. REMOVE POINT
    editor.Commands.add('chart:remove-point', { run: (editor, sender, options = {}) => {
        const component = options.component || editor.getSelected();
        if (!component) return;
        const chartDataTrait = component.getTrait('chart-data');
        let chartData = JSON.parse(chartDataTrait.getValue() || '[]');
        if (!chartData.length) return;

        if (chartData[0].points.length <= 1) return;

        chartData.forEach(layer => {
            layer.points.pop();
        });

        chartDataTrait.setValue(JSON.stringify(chartData));
        initChartEditor(component); 
    }});
}

if (typeof model !== 'undefined') {
  if (model.getEl()) {
    setTimeout(() => initChartEditor(model), 100);
    model.on('change:traits', () => setTimeout(() => initChartEditor(model), 50));
    model.on('change:attributes', () => setTimeout(() => initChartEditor(model), 50));
    model.on('change:style', () => setTimeout(() => initChartEditor(model), 10));
  }
} else {
  const container = this;
  if (container && container.getAttribute('data-component-id') === 'chart') {
    setTimeout(() => initChartRuntime(container), 100);
  }
}
`,

  styleConfig: {
    target: '.chart-container',
    sectors: [
      {
        id: 'style',
        name: 'Style',
        open: true,
        properties: [
          {
            id: 'background-color',
            name: 'Background Color',
            property: 'background-color',
            type: 'color',
            default: '#10161C'
          }
        ]
      },
      {
        id: 'dimension',
        name: 'Dimension',
        open: true,
        properties: [
          {
            id: 'width',
            name: 'Width',
            property: 'width',
            type: 'number',
            default: '100',
            units: ['%', 'px', 'vw']
          },
          {
            id: 'height',
            name: 'Height',
            property: 'height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto']
          },
          {
            id: 'min-width',
            name: 'Min-Width',
            property: 'min-width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vw', 'auto']
          },
          {
            id: 'min-height',
            name: 'Min-Height',
            property: 'min-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto']
          },
          {
            id: 'max-width',
            name: 'Max-Width',
            property: 'max-width',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vw', 'auto']
          },
          {
            id: 'max-height',
            name: 'Max-Height',
            property: 'max-height',
            type: 'number',
            default: 'auto',
            units: ['px', '%', 'vh', 'auto']
          }
        ]
      },
      {
        id: 'info_text',
        name: 'Info',
        open: false,
        properties: [
          {
            id: 'info-fs',
            name: 'Font Size',
            property: '--chart-info-size',
            type: 'number',
            default: 24,
            units: ['px']
          },
          {
            id: 'info-color',
            name: 'Color',
            property: '--chart-info-color',
            type: 'color',
            default: '#ffffff'
          }
        ]
      },
      {
        id: 'header_text',
        name: 'Header Text',
        open: true,
        properties: [
          {
            id: 'header-fs',
            name: 'Font Size',
            property: '--chart-header-size',
            type: 'number',
            default: 16,
            units: ['px']
          },
          {
            id: 'header-color',
            name: 'Color',
            property: '--chart-header-color',
            type: 'color',
            default: '#ffffff'
          }
        ]
      },
      {
        id: 'subheader_text',
        name: 'Sub Header Text',
        open: true,
        properties: [
          {
            id: 'subheader-fs',
            name: 'Font Size',
            property: '--chart-subheader-size',
            type: 'number',
            default: 14,
            units: ['px']
          },
          {
            id: 'subheader-color',
            name: 'Color',
            property: '--chart-subheader-color',
            type: 'color',
            default: '#a0aec0'
          }
        ]
      },
      {
        id: 'grid_text',
        name: 'Grid Text',
        open: true,
        properties: [
          {
            id: 'grid-fs',
            name: 'Font Size',
            property: '--chart-grid-size',
            type: 'number',
            default: 12,
            units: ['px']
          },
          {
            id: 'grid-color',
            name: 'Color',
            property: '--chart-grid-color',
            type: 'color',
            default: '#ffffff'
          }
        ]
      }
    ]
  }
};
