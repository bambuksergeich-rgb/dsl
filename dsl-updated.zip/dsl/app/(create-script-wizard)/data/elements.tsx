import { Editor } from 'grapesjs';

import { Container } from './_components/container';
import { Section } from './_components/section';
import { Row } from './_components/row';
import { Column } from './_components/column';
import { Grid } from './_components/grid';
import { SingleButtonConfig } from './_components/button';
import { ChoiceChips } from './_components/choice-chips';
import { Select } from './_components/select';
import { Number } from './_components/number';
import { Link } from './_components/link';
import { Download } from './_components/download';
import { Upload } from './_components/upload';
import { Chart } from './_components/chart';
import { Table } from './_components/table';
import { PieChart } from './_components/pie-chart';
import { BarChart } from './_components/bar-chart';
import { Counter } from './_components/counter';
import { Icon } from './_components/icon';
import { Password } from './_components/password';
import { Email } from './_components/email';
import { Phone } from './_components/phone';
import { Range } from './_components/range';
import { Radio } from './_components/radio';
import { Checkbox } from './_components/checkbox';
import { Switch } from './_components/switch';
import { CircleImage } from './_components/circle-image';
import { ButtonIcon } from './_components/button-icon';
import { Iframe } from './_components/iframe';
import { DragElement } from './_components/drag-element';
import { DragArea } from './_components/drag-area';
import { News } from './_components/news';
import { Form } from './_components/form';
import { Chat } from './_components/chat';
import { List } from './_components/list';
import { Tree } from './_components/tree';
import { Carousel } from './_components/carousel';
import { Drawer } from './_components/drawer';
import { Panel } from './_components/panel';
import { Badge } from './_components/badge';
import { LabelText } from './_components/label-text';
import { TextInput } from './_components/text-input';
import { TextRedactor } from './_components/text-redactor';
import { Grouper } from './_components/grouper';
import { Tabs } from './_components/tabs';
import { Calendar } from './_components/calendar';
import { CheckboxGroup } from './_components/checkbox-group';
import { mappableTypes } from '../editor/utils/codeGenerators';
import { Button } from './_components/button-group';
import { Login } from './_components/login';
import { Progress } from './_components/progress';
import { Plusser } from './_components/plusser';
import { Basket } from './_components/basket';
import { Tooltip } from './_components/tooltip';

interface BaseStyleProperty {
  id: string;
  name: string;
  property: string;
  selector?: string;
  media?: {
    name: string;
    maxWidth: string | null;
    default?: number | string;
  }[];
}

interface ColorProperty extends BaseStyleProperty {
  type: 'color';
  default?: string;
}

interface NumberProperty extends BaseStyleProperty {
  type: 'number';
  units?: string[];
  default?: number | string;
}

interface CompositeProperty extends BaseStyleProperty {
  type: 'composite';
  properties: StyleProperty[];
  default?: string;
}

interface SelectProperty extends BaseStyleProperty {
  type: 'select';
  options: {
    id: string;
    name: string;
    value: string;
    label?: string;
    icon?: string;
  }[];
  default?: string;
}

interface TextProperty extends BaseStyleProperty {
  type: 'text';
  default?: string;
}

interface RadioStylePropety extends BaseStyleProperty {
  type: 'radio';
  options: {
    id: string;
    name: string;
    value: string;
    label?: string;
    icon?: string;
  }[];
  default?: string;
}

export type StyleProperty =
  | ColorProperty
  | NumberProperty
  | CompositeProperty
  | SelectProperty
  | TextProperty
  | RadioStylePropety;

export interface StyleSector {
  id: string;
  name: string;
  open?: boolean;
  properties: StyleProperty[];
}

interface BaseTrait {
  id: string;
  name: string;
  label: string;
  changeProp?: boolean;
  placeholder?: string;
  default?: string;
}

interface Points extends BaseTrait {
  type: 'custom-points';
}

interface TextTrait extends BaseTrait {
  type: 'text';
  value?: string;
}

interface NumberTrait extends BaseTrait {
  type: 'number';
  value?: number;
  min?: number;
  step?: number;
  max?: number;
  units?: string[];
}

interface CheckboxTrait extends BaseTrait {
  type: 'checkbox';
  value?: boolean;
}

interface SwitchTrait extends BaseTrait {
  type: 'switch';
  value?: boolean;
}

interface SelectTrait extends BaseTrait {
  type: 'select';
  options: {
    id: string;
    name: string;
    value: string;
    label?: string;
    icon?: string;
    item?: any[];
  }[];
  value?: string;
}

interface FileTrait extends BaseTrait {
  type: 'file';
  value?: string;
  accept?: string;
}

interface ListTrait extends BaseTrait {
  type: 'list';
  value?: string;
  options?: {
    id: string;
    name: string;
    value: string;
    label?: string;
    item?: Trait[];
  }[];
  default?: string;
}

interface IconTrait extends BaseTrait {
  type: 'select-icon';
  value?: string;
}

interface ColorTrait extends BaseTrait {
  type: 'color';
  value?: string;
}

interface ButtonTrait extends BaseTrait {
  type: 'button';
  command: string;
}

interface JSONTrait extends BaseTrait {
  type: 'json';
  value?: string;
}

interface RepeaterTrait {
  id?: string;
  type: 'repeater';
  name: string;
  label: string;
  changeProp?: boolean;
  placeholder?: string;
  default?: string;
  value?: unknown[];
  itemId?: string;
  itemLabel?: string;
  itemIcon?: string;
  itemColor?: string;
  defaultLabel?: string;
  defaultColor?: string;
}

export type Trait =
  | TextTrait
  | NumberTrait
  | CheckboxTrait
  | SelectTrait
  | FileTrait
  | ColorTrait
  | ButtonTrait
  | IconTrait
  | SwitchTrait
  | ListTrait
  | JSONTrait
  | RepeaterTrait
  | Points;

export interface ComponentContent {
  type?: string;
  tagName?: string;
  attributes?: Record<string, string>;
  content?: string;
  styles?: string;
  droppable?: boolean;
  draggable?: boolean | string;
  components?: ComponentContent[];
  editable?: boolean;
  selectable?: boolean;
  hidden?: boolean;
  hoverable?: boolean;
  badgable?: boolean;
  copyable?: boolean;
  highlightable?: boolean;
  layerable?: boolean;
  resizable?:
    | false
    | {
        tl?: boolean;
        tc?: boolean;
        tr?: boolean;
        cl?: boolean;
        cr?: boolean;
        bl?: boolean;
        bc?: boolean;
        br?: boolean;
        minDim?: number;
        maxDim?: number;
        updateTarget?: (
          el: HTMLElement,
          rect: {
            w: string;
            h: string;
            width: number;
            height: number;
          },
          options: any
        ) => void;
      };
}

export interface ComponentConfig {
  id: string;
  label: string;
  category: string;
  type: string;
  content: ComponentContent;
  styleConfig?: {
    target?: string;
    sectors: StyleSector[];
  };
  traits: Trait[];
  styles?: string;
  tagName?: string;
  block?: boolean;
  icon?: string;
  script?: string;
  attributes?: Record<string, string>;
}

export function isComponentContent(
  content: unknown
): content is ComponentContent {
  if (!content || typeof content !== 'object') {
    return false;
  }

  const obj = content as Record<string, unknown>;

  return (
    (typeof obj.tagName === 'string' && obj.tagName !== '') ||
    (Array.isArray(obj.components) &&
      obj.components.every((item) => isComponentContent(item)))
  );
}

export const components: ComponentConfig[] = [
  SingleButtonConfig,
  Calendar,
  Container,
  Section,
  Row,
  Column,
  Grid,
  Button,
  ChoiceChips,
  Select,
  Number,
  Link,
  Download,
  Upload,
  Chart,
  Table,
  PieChart,
  BarChart,
  Counter,
  Icon,
  Password,
  Email,
  Phone,
  TextInput,
  Range,
  Radio,
  Checkbox,
  CheckboxGroup,
  Switch,
  CircleImage,
  ButtonIcon,
  Login,
  Progress,
  Plusser,
  Basket,
  Tooltip,
  Iframe,
  DragElement,
  DragArea,
  News,
  Form,
  Chat,
  List,
  Tree,
  Carousel,
  Drawer,
  Panel,
  Badge,
  LabelText,
  TextRedactor,
  Grouper,
  Tabs
];

const executeScript = (model: any, script: any, context = model.view?.el) => {
  if (!script) return;
  try {
    new Function('model', script).call(context, model);
  } catch (error) {
    console.error(`Script error in ${model.get('type')}:`, error);
  }
};

export function registerComponents(editor: Editor) {
  const registeredTypes = new Set();

  // ✅ ДОБАВЬТЕ ПРОВЕРКУ КАСТОМНОГО TRAIT ТИПА
  const traitManager = editor.TraitManager;
  const hasSelectIcon = traitManager.getType('select-icon');

  if (!hasSelectIcon) {
    console.warn('⚠️ Custom trait type "select-icon" is not registered!');
    console.warn('Please register it before calling registerComponents()');
  }

  const updateStyleTarget = (
    componentId: string,
    selector: string,
    styleProp: string,
    value: any,
    defaultTarget?: string
  ) => {
    const cssComposer = editor.Css;

    if (typeof styleProp !== 'string') {
      console.error(
        '❌ updateStyleTarget error: styleProp is not a string!',
        styleProp
      );
      return;
    }

    const isRoot =
      !selector ||
      (defaultTarget && selector === defaultTarget) ||
      selector === '';

    const finalSelector = isRoot
      ? `#${componentId}`
      : `#${componentId} ${selector}`;

    let rule = cssComposer.getRule(finalSelector);
    if (!rule) {
      rule = cssComposer.setRule(finalSelector, {});
    }

    rule.addStyle({ [styleProp]: value });
    editor.refresh();
  };

  const applyDefaults = (model: any, config: any) => {
    if (!config.styleConfig) return;
    const id = model.getId();
    const skipProps = new Set([
      'width',
      'height',
      'min-width',
      'min-height',
      'max-width',
      'max-height',
      'top',
      'left',
      'right',
      'bottom'
    ]);
    const isDimensionVar = (property: string) =>
      /^--(?:[a-z0-9-]*(?:width|height|min-w|max-w|min-h|max-h)[a-z0-9-]*)$/i.test(
        property
      );

    config.styleConfig.sectors.forEach((sector: any) => {
      sector.properties.forEach((prop: any) => {
        if (prop.default === undefined) return;
        if (skipProps.has(prop.property)) return;
        if (isDimensionVar(prop.property)) return;

        if (!prop.property || typeof prop.property !== 'string') {
          console.error('🚨 НАЙДЕНА ОШИБКА В КОНФИГЕ! Свойство сломано:', prop);
          console.error('Сектор:', sector.name);
          return;
        }

        let val = prop.default;
        if (prop.type === 'number' && prop.units && typeof val === 'number') {
          val = val + prop.units[0];
        }

        const selector = prop.selector || config.styleConfig.target;

        updateStyleTarget(
          id,
          selector,
          prop.property,
          val,
          config.styleConfig.target
        );
      });
    });
  };

  // ✅ НОВОЕ: Функция создания компонентов слоёв для chart
  const createChartLayerComponents = (model: any, chartId: string) => {
    const attributes = model.getAttributes();
    const chartDataAttr = attributes['data-chart-data'];

    if (!chartDataAttr) return;

    try {
      const chartData = JSON.parse(chartDataAttr);
      const existingComponents = model.components();

      if (Array.isArray(chartData) && chartData.length > 0) {
        chartData.forEach((layer: any, index: number) => {
          const layerId = layer.id || `layer-${index + 1}`;
          const layerName = layer.name || `Layer ${index + 1}`;

          // Проверяем что компонент для этого слоя ещё не создан
          const hasLayerComponent = existingComponents.find(
            (c: any) => c.getAttributes()['data-layer-id'] === layerId
          );

          if (!hasLayerComponent) {
            model.append({
              type: 'chart-layer',
              tagName: 'div',
              attributes: {
                'data-chart-id': chartId,
                'data-layer-id': layerId,
                'data-layer-name': layerName,
                'data-component-type': 'chart-layer',
                class: `chart-layer-virtual chart-layer-${layerId}`,
                style: 'display: none;'
              },
              draggable: false,
              droppable: false,
              selectable: false,
              layerable: false,
              hoverable: false
            });
          }
        });
      }
    } catch (e) {
      console.warn('⚠️ [Chart] Failed to parse data-chart-data:', e);
    }
  };

  // ✅ КРИТИЧНО: Генерация data-component-type при добавлении компонента
  editor.on('component:add', (model) => {
    const componentType = model.get('type');
    const attributes = model.getAttributes();

    // ✅ ОБНОВЛЕНО: Для chart создаём дочерние компоненты для осей и слоёв
    if (componentType === 'chart') {
      const chartId = model.getId();
      const existingComponents = model.components();

      // Проверяем что X и Y компоненты ещё не созданы
      const hasXComponent = existingComponents.find(
        (c: any) => c.get('type') === 'chart-axis-x'
      );
      const hasYComponent = existingComponents.find(
        (c: any) => c.get('type') === 'chart-axis-y'
      );

      if (!hasXComponent) {
        model.append({
          type: 'chart-axis-x',
          tagName: 'div',
          attributes: {
            'data-chart-id': chartId,
            'data-axis': 'X',
            'data-component-type': 'chart-axis-x',
            class: 'chart-axis-x-virtual',
            style: 'display: none;'
          },
          draggable: false,
          droppable: false,
          selectable: false,
          layerable: false,
          hoverable: false
        });
      }

      if (!hasYComponent) {
        model.append({
          type: 'chart-axis-y',
          tagName: 'div',
          attributes: {
            'data-chart-id': chartId,
            'data-axis': 'Y',
            'data-component-type': 'chart-axis-y',
            class: 'chart-axis-y-virtual',
            style: 'display: none;'
          },
          draggable: false,
          droppable: false,
          selectable: false,
          layerable: false,
          hoverable: false
        });
      }

      createChartLayerComponents(model, chartId);

      if (!attributes['data-component-type']) {
        model.addAttributes({
          'data-component-type': 'chart'
        });
        model.append({
          type: 'points',
          tagName: 'div',
          attributes: {
            'data-chart-id': chartId,
            'data-component-type': 'points',
            style: 'display: none;'
          },
          draggable: false,
          droppable: false,
          selectable: false,
          layerable: false,
          hoverable: false
        });
      }
    }
    // Проверяем что это компонент для WZ маппинга
    else if (componentType && mappableTypes.includes(componentType)) {
      if (!attributes['data-component-type']) {
        model.addAttributes({
          'data-component-type': componentType
        });
      }
    }

    // Стандартная проверка ID
    if (!attributes.id) {
      model.addAttributes({ id: model.getId() });
    }
  });

  // ✅ НОВОЕ: Отслеживаем изменения в data-chart-data для обновления слоёв
  editor.on('component:update', (model) => {
    const componentType = model.get('type');

    if (componentType === 'chart') {
      const chartId = model.getId();
      const attributes = model.getAttributes();
      const chartDataAttr = attributes['data-chart-data'];

      if (!chartDataAttr) return;

      try {
        const chartData = JSON.parse(chartDataAttr);
        const existingComponents = model.components();

        // Получаем существующие layer компоненты
        const existingLayers = existingComponents.filter(
          (c: any) => c.get('type') === 'chart-layer'
        );

        const existingLayerIds = existingLayers.map(
          (c: any) => c.getAttributes()['data-layer-id']
        );

        // Добавляем новые слои
        if (Array.isArray(chartData)) {
          chartData.forEach((layer: any, index: number) => {
            const layerId = layer.id || `layer-${index + 1}`;
            const layerName = layer.name || `Layer ${index + 1}`;

            if (!existingLayerIds.includes(layerId)) {
              model.append({
                type: 'chart-layer',
                tagName: 'div',
                attributes: {
                  'data-chart-id': chartId,
                  'data-layer-id': layerId,
                  'data-layer-name': layerName,
                  'data-component-type': 'chart-layer',
                  class: `chart-layer-virtual chart-layer-${layerId}`,
                  style: 'display: none;'
                },
                draggable: false,
                droppable: false,
                selectable: false,
                layerable: false,
                hoverable: false
              });
            }
          });

          // Удаляем слои которых больше нет в data-chart-data
          const currentLayerIds = chartData.map(
            (l: any, idx: number) => l.id || `layer-${idx + 1}`
          );

          existingLayers.forEach((layerComp: any) => {
            const layerId = layerComp.getAttributes()['data-layer-id'];

            if (!currentLayerIds.includes(layerId)) {
              layerComp.remove();
            }
          });
        }
      } catch (e) {
        console.warn('⚠️ [Chart] Failed to update layers:', e);
      }
    }
  });

  editor.on('component:hover', (cmp) => {
    const el =
      cmp && typeof cmp.getEl === 'function'
        ? (cmp.getEl() as HTMLElement | null)
        : null;
    if (!el) return;

    const cs = getComputedStyle(el);
    const gap = cs.gap || cs.rowGap || '0px';
    const rowGap = cs.rowGap || '0px';
    const colGap = cs.columnGap || '0px';

    el.style.setProperty('--gjs-gap', gap);
    el.style.setProperty('--gjs-row-gap', rowGap);
    el.style.setProperty('--gjs-column-gap', colGap);

    Array.from(el.children).forEach((child, idx, arr) => {
      const ch = child as HTMLElement;
      if (idx < arr.length - 1) {
        ch.classList.add('gjs-gap-highlight');
      }
    });
  });

  editor.on('component:unhover', (cmp) => {
    const el =
      cmp && typeof cmp.getEl === 'function'
        ? (cmp.getEl() as HTMLElement | null)
        : null;
    if (!el) return;

    el.style.removeProperty('--gjs-gap');
    el.style.removeProperty('--gjs-row-gap');
    el.style.removeProperty('--gjs-column-gap');

    Array.from(el.children).forEach((child) => {
      (child as HTMLElement).classList.remove('gjs-gap-highlight');
    });
  });

  // ✅ НОВОЕ: Регистрируем типы для chart-axis-x, chart-axis-y, chart-layer
  editor.Components.addType('chart-axis-x', {
    isComponent: (el) =>
      el.tagName === 'DIV' && el.classList.contains('chart-axis-x-virtual'),
    model: {
      defaults: {
        type: 'chart-axis-x',
        tagName: 'div',
        draggable: false,
        droppable: false,
        selectable: false,
        layerable: false,
        hoverable: false
      }
    }
  });

  editor.Components.addType('chart-axis-y', {
    isComponent: (el) =>
      el.tagName === 'DIV' && el.classList.contains('chart-axis-y-virtual'),
    model: {
      defaults: {
        type: 'chart-axis-y',
        tagName: 'div',
        draggable: false,
        droppable: false,
        selectable: false,
        layerable: false,
        hoverable: false
      }
    }
  });

  editor.Components.addType('chart-layer', {
    isComponent: (el) =>
      el.tagName === 'DIV' && el.classList.contains('chart-layer-virtual'),
    model: {
      defaults: {
        type: 'chart-layer',
        tagName: 'div',
        draggable: false,
        droppable: false,
        selectable: false,
        layerable: false,
        hoverable: false
      }
    }
  });

  editor.Components.addType('counter-value', {
    isComponent: (el) =>
      el.tagName === 'SPAN' && el.classList.contains('counter-value'),
    model: {
      defaults: {
        type: 'counter-value',
        tagName: 'span',
        attributes: { class: 'counter-value' },
        draggable: false,
        droppable: false,
        selectable: false,
        hoverable: false,
        layerable: false
      }
    }
  });

  editor.Components.addType('counter-increment', {
    isComponent: (el) =>
      el.tagName === 'BUTTON' && el.classList.contains('counter-increment'),
    model: {
      defaults: {
        type: 'counter-increment',
        tagName: 'button',
        attributes: { class: 'counter-increment', 'data-action': 'increment' },
        draggable: false,
        droppable: false,
        selectable: false,
        hoverable: false,
        layerable: false
      }
    }
  });

  editor.Components.addType('counter-decrement', {
    isComponent: (el) =>
      el.tagName === 'BUTTON' && el.classList.contains('counter-decrement'),
    model: {
      defaults: {
        type: 'counter-decrement',
        tagName: 'button',
        attributes: { class: 'counter-decrement', 'data-action': 'decrement' },
        draggable: false,
        droppable: false,
        selectable: false,
        hoverable: false,
        layerable: false
      }
    }
  });

  editor.Components.addType('counter-controls', {
    isComponent: (el) =>
      el.tagName === 'div' && el.classList.contains('counter-controls'),
    model: {
      defaults: {
        type: 'counter-controls',
        tagName: 'div',
        attributes: { class: 'counter-controls flex items-center space-x-2' },
        draggable: false,
        droppable: false,
        selectable: false,
        hoverable: false,
        layerable: false
      }
    }
  });

  const normalizeLinkHref = (value: unknown) => {
    const raw = String(value ?? '').trim();
    if (!raw) return '#';

    if (
      raw === '#' ||
      raw.startsWith('/') ||
      raw.startsWith('./') ||
      raw.startsWith('../') ||
      raw.startsWith('#') ||
      /^[^\s/]+\.html(?:[?#].*)?$/i.test(raw)
    ) {
      return raw;
    }

    if (/^[a-z][a-z0-9+.-]*:/i.test(raw)) return raw;

    if (
      /^(?:localhost|(?:[a-z0-9-]+\.)+[a-z]{2,})(?::\d+)?(?:[/?#].*)?$/i.test(
        raw
      )
    ) {
      return `https://${raw}`;
    }

    return raw;
  };

  const getLinkPageOptions = () => {
    const currentPage = editor.Pages.getSelected();
    return [
      { id: '', name: 'Custom URL', value: '' },
      ...editor.Pages.getAll().map((page: any) => {
        const name = page.getName() || page.getId();
        const id = page.getId();
        const isCurrent = page === currentPage;
        return {
          id,
          value: id,
          name: isCurrent ? `📍 ${name} (Current)` : name
        };
      })
    ];
  };

  const syncLinkDomAttributes = (model: any) => {
    if (!model || model.get('type') !== 'mui-link') return;
    const href = normalizeLinkHref(
      model.getTrait('href')?.getValue?.() || model.getAttributes?.()?.href || '#'
    );
    const target =
      model.getTrait('target')?.getValue?.() === '_blank' ? '_blank' : '_self';
    const name =
      String(model.getTrait('name')?.getValue?.() || 'Link').trim() || 'Link';
    const attrs = model.getAttributes?.() || {};
    model.addAttributes?.({
      href,
      target,
      rel: 'noopener noreferrer',
      'data-href': href
    });
    if (!attrs['data-page-id']) {
      const currentText = model.getEl?.()?.textContent?.trim?.() || '';
      if (currentText !== name) model.components?.(name);
    }
  };

  const bindLinkPreviewClick = (model: any) => {
    if (!model || model.get('type') !== 'mui-link') return;
    const el = model.getEl?.() as HTMLAnchorElement | undefined;
    if (!el) return;
    el.onclick = (event: MouseEvent) => {
      const attrs = model.getAttributes?.() || {};
      const pageId = attrs['data-page-id'];
      if (pageId) {
        event.preventDefault();
        event.stopPropagation();
        const page = editor.Pages.get(pageId);
        if (page) editor.Pages.select(page);
        return;
      }

      const href = normalizeLinkHref(
        attrs.href || model.getTrait('href')?.getValue?.() || ''
      );
      if (!href || href === '#') {
        event.preventDefault();
        return;
      }

      // Do not navigate the GrapesJS iframe away from the editor.
      // The generated HTML keeps the real href/target, while editor click opens a safe preview tab.
      event.preventDefault();
      event.stopPropagation();
      window.open(href, '_blank', 'noopener,noreferrer');
    };
  };

  // Bind the preview click as soon as the DOM node exists. Without this, a link
  // added to the canvas but not yet re-selected behaves like a plain editor node.
  editor.on('component:mount', (model) => {
    if (model.get('type') !== 'mui-link') return;
    const pageTrait = model.getTrait('page-link');
    pageTrait?.set?.('options', getLinkPageOptions());
    syncLinkDomAttributes(model);
    bindLinkPreviewClick(model);
  });

  // 1. Обработчик выбора компонента - обновляет список страниц в трейте
  editor.on('component:selected', (model) => {
    if (model.get('type') !== 'mui-link') return;

    const trait = model.getTrait('page-link');
    if (!trait) return;

    trait.set('options', getLinkPageOptions());
    syncLinkDomAttributes(model);
    bindLinkPreviewClick(model);
  });

  // 2. Обработчик изменения page-link - генерирует правильный URL
  editor.on('component:update:page-link', (model) => {
    if (model.get('type') !== 'mui-link') return;

    const pageLinkTrait = model.getTrait('page-link');
    const hrefTrait = model.getTrait('href');
    const pageId = pageLinkTrait?.getValue();

    if (pageId) {
      const pages = editor.Pages.getAll();
      const page = pages.find((p: any) => p.getId() === pageId);
      const currentPage = editor.Pages.getSelected();

      if (page) {
        const pageName = page.getName() || page.getId();
        const isCurrentPage = page === currentPage;

        let finalUrl: string;
        if (isCurrentPage) {
          finalUrl = 'index.html';
        } else {
          const slug = pageName.toLowerCase().trim().replace(/\s+/g, '-');
          finalUrl = `${slug}.html`;
        }

        model.__syncingPageHref = true;
        if (hrefTrait) {
          hrefTrait.setValue(finalUrl);
        }
        model.__syncingPageHref = false;

        const nameTrait = model.getTrait('name');
        if (nameTrait?.setValue) nameTrait.setValue(pageName);

        model.addAttributes({
          href: finalUrl,
          target:
            model.getTrait('target')?.getValue?.() === '_blank'
              ? '_blank'
              : '_self',
          rel: 'noopener noreferrer',
          'data-href': finalUrl,
          'data-page-id': pageId
        });

        model.components(pageName);
        bindLinkPreviewClick(model);
      }
    } else {
      model.addAttributes({ 'data-page-id': '', 'data-href': '' });
      const currentHref = model.getAttributes().href;
      const currentName =
        String(model.getTrait('name')?.getValue?.() || 'Link').trim() || 'Link';
      if (!currentHref || currentHref === '#') {
        model.components(currentName);
      }
      syncLinkDomAttributes(model);
      bindLinkPreviewClick(model);
    }
  });

  editor.on('component:update:href', (model) => {
    if (model.get('type') !== 'mui-link') return;
    if (!model.__syncingPageHref) {
      const pageTrait = model.getTrait('page-link');
      if (pageTrait?.getValue?.()) pageTrait.setValue('');
      model.addAttributes({ 'data-page-id': '' });
    }
    syncLinkDomAttributes(model);
    bindLinkPreviewClick(model);
  });

  editor.on('component:update:target', (model) => {
    if (model.get('type') !== 'mui-link') return;
    syncLinkDomAttributes(model);
    bindLinkPreviewClick(model);
  });

  editor.on('component:update:name', (model) => {
    if (model.get('type') !== 'mui-link') return;
    const name =
      String(model.getTrait('name')?.getValue?.() || 'Link').trim() || 'Link';
    model.components(name);
    bindLinkPreviewClick(model);
  });

  // 3. КРИТИЧНО: Обработчик переключения страниц в GrapesJS
  editor.on('page:select', (newPage, prevPage) => {
    const allPages = editor.Pages.getAll();

    allPages.forEach((page: any) => {
      const pageComponent = page.getMainComponent();
      const allLinks = pageComponent
        .find('*')
        .filter((comp: any) => comp.get('type') === 'mui-link');

      allLinks.forEach((linkModel: any) => {
        const pageId = linkModel.getAttributes()['data-page-id'];

        if (pageId) {
          const targetPage = editor.Pages.get(pageId);

          if (targetPage) {
            const pageName = targetPage.getName() || targetPage.getId();
            const isCurrentPage = targetPage === newPage;

            let finalUrl: string;
            if (isCurrentPage) {
              finalUrl = 'index.html';
            } else {
              const slug = pageName.toLowerCase().trim().replace(/\s+/g, '-');
              finalUrl = `${slug}.html`;
            }

            const hrefTrait = linkModel.getTrait('href');
            linkModel.__syncingPageHref = true;
            if (hrefTrait) {
              hrefTrait.setValue(finalUrl);
            }
            linkModel.__syncingPageHref = false;

            linkModel.addAttributes({
              href: finalUrl,
              'data-href': finalUrl
            });
          }
        }
      });
    });

    const selectedComponent = editor.getSelected();
    if (selectedComponent && selectedComponent.get('type') === 'mui-link') {
      const trait = selectedComponent.getTrait('page-link');
      if (trait) {
        trait.set('options', getLinkPageOptions());
        bindLinkPreviewClick(selectedComponent);
      }
    }
  });

  // 4. Обработчик добавления новой страницы
  editor.on('page:add', (page) => {
    setTimeout(() => {
      const allPages = editor.Pages.getAll();
      const currentPage = editor.Pages.getSelected();

      allPages.forEach((p: any) => {
        const pageComponent = p.getMainComponent();
        const allLinks = pageComponent
          .find('*')
          .filter((comp: any) => comp.get('type') === 'mui-link');

        allLinks.forEach((linkModel: any) => {
          const trait = linkModel.getTrait('page-link');
          if (trait) {
            trait.set('options', getLinkPageOptions());
            bindLinkPreviewClick(linkModel);
          }
        });
      });
    }, 100);
  });

  // 5. Обработчик удаления страницы
  editor.on('page:remove', (page) => {
    const removedPageId = page.getId();
    const allPages = editor.Pages.getAll();

    allPages.forEach((p: any) => {
      const pageComponent = p.getMainComponent();
      const allLinks = pageComponent
        .find('*')
        .filter((comp: any) => comp.get('type') === 'mui-link');

      allLinks.forEach((linkModel: any) => {
        const pageId = linkModel.getAttributes()['data-page-id'];

        if (pageId === removedPageId) {
          linkModel.addAttributes({
            href: '#',
            'data-href': '',
            'data-page-id': ''
          });

          const pageLinkTrait = linkModel.getTrait('page-link');
          if (pageLinkTrait) {
            pageLinkTrait.setValue('');
          }

          const nameTrait = linkModel.getTrait('name');
          if (nameTrait?.setValue) nameTrait.setValue('Link');
          linkModel.components('Link');
          bindLinkPreviewClick(linkModel);
        }
      });
    });
  });

  components.forEach((config) => {
    if (registeredTypes.has(config.type)) {
      console.warn(
        `Component type ${config.type} already registered, skipping.`
      );
      return;
    }

    // ✅ ИСПРАВЛЕНО: Глубокое копирование traits
    const traits: Trait[] = config.traits
      ? JSON.parse(JSON.stringify(config.traits))
      : [];

    editor.Components.addType(config.type, {
      isComponent: (el) => {
        const tagName = isComponentContent(config.content)
          ? config.content.tagName?.toUpperCase()
          : 'DIV';
        const className = isComponentContent(config.content)
          ? config.content.attributes?.class
          : config.type;

        return (
          el.tagName === tagName &&
          el.classList.contains(className || config.type)
        );
      },
      model: {
        defaults: {
          type: config.type,
          tagName: isComponentContent(config.content)
            ? config.content.tagName
            : 'div',
          draggable:
            config.content.draggable ||
            '.container-wrapper, div, button, .component-button, th, td, h3',
          droppable: config.content.droppable || false,
          attributes: isComponentContent(config.content)
            ? config.content.attributes || { class: config.type }
            : { class: config.type },
          components: isComponentContent(config.content)
            ? (config.content.components as any)
            : undefined,
          stylable: config.styleConfig
            ? config.styleConfig.sectors.flatMap((s) =>
                s.properties.map((p) => p.property)
              )
            : true,
          traits: traits,
          styles: config.styles,
          // ComponentConfig.script is editor runtime code executed manually via
          // executeScript(model, config.script, ...). Do not expose it through
          // GrapesJS' reserved `script` property: CanvasView would execute it a
          // second time inside the iframe without our `model` argument.
          script: '',
          'script-props': traits
            .map((trait) => trait.name || trait.id)
            .filter(Boolean),
          // User-facing constructor components are draggable only.
          // Persisted dimensions are rendered, but manual resize is disabled.
          resizable: false,
          icon: config.icon
        },

        init() {
          const sm = editor.StyleManager;
          if (config.styleConfig) {
            applyDefaults(this, config);
          }

          this.on('change:componentId', () => {
            const newId = this.getTrait('componentId')?.getValue();
            if (newId) {
              this.addAttributes({ 'data-component-id': newId });
            }
          });

          this.on('active', () => {
            if (!config.styleConfig || !sm) return;

            const currentId = this.getId();
            sm.getSectors().reset();

            config.styleConfig.sectors.forEach((sector) => {
              sm.addSector(
                sector.id,
                {
                  name: sector.name,
                  open: sector.open,
                  properties: sector.properties.map((prop) => ({
                    ...prop,
                    ...(prop.default !== undefined
                      ? { default: String(prop.default) }
                      : {}),
                    change: (props: any) => {
                      let val = props.value !== undefined ? props.value : props;
                      if (
                        prop.type === 'number' &&
                        prop.units &&
                        !isNaN(parseFloat(val))
                      ) {
                        val = parseFloat(val) + prop.units[0];
                      }
                      const isVariable = prop.property.startsWith('--');
                      const selector = isVariable ? '' : prop.selector || '';
                      if (typeof prop.property === 'string') {
                        updateStyleTarget(
                          currentId,
                          selector,
                          prop.property,
                          val,
                          config.styleConfig?.target
                        );
                      } else {
                        console.error('❌ BAD PROPERTY:', prop);
                      }
                    }
                  })) as any
                },
                { at: 0 }
              );
            });
          });

          traits.forEach((trait) => {
            if (trait.changeProp) {
              this.on(`change:${trait.name}`, () => {
                const attrName = `data-${trait.name.replace(/([A-Z])/g, '-$1').toLowerCase()}`;
                const traitValue = this.getTrait(trait.name)?.getValue();

                let cleanedValue = traitValue;
                if (typeof traitValue === 'string') {
                  cleanedValue = traitValue
                    .replace(/[\r\n\t\f\v]/g, '')
                    .replace(/\s{2,}/g, ' ')
                    .trim();
                }

                this.addAttributes({ [attrName]: cleanedValue });
                const model = this as any;
                if (model.__updateTableFromTraits) {
                  model.__updateTableFromTraits();
                } else {
                  executeScript(model, config.script, model.view?.el);
                }
                if (model.__initSortListeners) {
                  model.__initSortListeners();
                }
              });
            }
          });

          executeScript(this, config.script, this.view?.el);
        }
      },

      view: {
        onRender() {
          const model = this.model as any;
          if (model.__updateTableFromTraits) {
            model.__updateTableFromTraits();
            this.renderChildren();
          } else {
            executeScript(model, config.script, this.el);
          }
          if (model.__initSortListeners) {
            model.__initSortListeners();
          }
        },
        onRemove() {}
      }
    });

    if (config.block !== false) {
      editor.BlockManager.add(config.id, {
        label: config.label,
        content: {
          type: config.type,
          attributes: isComponentContent(config.content)
            ? config.content.attributes
            : { class: config.type }
        },
        category: config.category,
        media: config.icon,
        select: true
      });
    }

    registeredTypes.add(config.type);
  });

  editor.on('component:add', (component: any) => {
    try {
      const type = component.get('type');
      if (type === 'mui-link') {
        syncLinkDomAttributes(component);
        bindLinkPreviewClick(component);
      }
      const classes = component.getClasses?.() || [];
      const isWrapper =
        classes.includes('table-wrapper') ||
        component.getAttributes?.()?.class?.includes?.('table-wrapper');
      if (type === 'table' && isWrapper) {
        component.set('type', 'wz-table');
      }
    } catch (e) {
      console.error('Failed to migrate legacy table component', e);
    }
  });
}
