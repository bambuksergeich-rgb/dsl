// app/(script-wizard)/layout.tsx
import { ReactNode } from 'react';

export default function ScriptWizardLayout({
  children
}: {
  children: ReactNode;
}) {
  return <>{children}</>;
}
