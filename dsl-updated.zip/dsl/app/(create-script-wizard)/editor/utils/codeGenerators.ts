import type { Component } from 'grapesjs';
import { HANDLER_TEMPLATES, DEFAULT_HANDLER } from './componentHeandlers';

export interface CanvasComponent {
  id: string;
  type: string;
  tagName: string;
  selector: string;
  componentId: string;
  traits: string[];
  attributes: Record<string, any>;
  classes: string[];
  innerHTML?: string;
}

export const mappableTypes = [
  'label-text',
  'text-input',
  'custom-button',
  'number',
  'select',
  'email',
  'phone',
  'password',
  'checkbox',
  'checkbox-group',
  'radio',
  'switch',
  'range',
  'chart',
  'pie-chart',
  'bar-chart',
  'wz-table',
  'table',
  'counter',
  'text-redactor',
  'tabs',
  'th',
  'chart-layer',
  'container'
];

export function generateChartJS(
  hasChartComponents: boolean,
  hasBarChartComponents: boolean,
  hasPieChartComponents: boolean
): string {
  return `
function initCharts() {
  // Initialize regular charts
  ${hasChartComponents ? `initChartComponents('chart');` : ''}

  // Initialize bar charts
  ${hasBarChartComponents ? `initChartComponents('bar-chart');` : ''}

  // Initialize pie charts
  ${hasPieChartComponents ? `initChartComponents('pie-chart-json');` : ''}
}

// Generic chart initialization function
function initChartComponents(componentId) {
  const chartContainers = document.querySelectorAll('[data-component-id="' + componentId + '"]');

  chartContainers.forEach(container => {
    const canvas = container.querySelector('canvas');
    if (!canvas) {
      console.warn('[Chart] Canvas not found in container');
      return;
    }

    // Get chart data from attributes
    const chartType = container.getAttribute('data-chart-type') || getDefaultChartType(componentId);
    const title = container.getAttribute('data-title') || getDefaultTitle(componentId);
    const subTitle = container.getAttribute('data-sub-title') || '';
    const infoText = container.getAttribute('data-info-text') || '';
    const chartDataAttr = container.getAttribute('data-chart-data');

    if (!chartDataAttr) {
      console.warn('[Chart] No chart data found');
      return;
    }

    try {
      // Decode HTML entities
      const decodedData = chartDataAttr
        .replace(/&quot;/g, '"')
        .replace(/&amp;/g, '&');
      const chartData = JSON.parse(decodedData);

      if (!chartData.length) {
        return;
      }

      renderChart(canvas, chartData, chartType, title, subTitle, infoText, container);

    } catch (error) {
      console.error('[Chart] Error creating ' + componentId + ':', error);
    }
  });
}

function getDefaultChartType(componentId) {
  const types = {
    'chart': 'line',
    'bar-chart': 'bar',
    'pie-chart-json': 'pie'
  };
  return types[componentId] || 'line';
}

function getDefaultTitle(componentId) {
  const titles = {
    'chart': 'My Chart',
    'bar-chart': 'My Bar Chart',
    'pie-chart-json': 'My Pie Chart'
  };
  return titles[componentId] || 'My Chart';
}

// ✅ НОВОЕ: Функция создания HTML точек
function createHTMLPoints(container, chartData, chartInstance) {
  if (!container || !chartData || !chartInstance) {
    console.warn('⚠️ [Points] Missing data for HTML points');
    return;
  }

  // Ищем или создаём контейнер для точек
  let pointsContainer = container.querySelector('.chart-points-layer');

  if (!pointsContainer) {
    pointsContainer = document.createElement('div');
    pointsContainer.className = 'chart-points-layer';
    pointsContainer.style.cssText = \`
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 10;
    \`;
    container.style.position = 'relative';
    container.appendChild(pointsContainer);
  }

  // Очищаем старые точки
  pointsContainer.innerHTML = '';

  console.log('📍 [Points] Creating HTML points for', chartData.length, 'series');

  // Получаем метаданные из Chart.js для точного позиционирования
  const meta = chartInstance.getDatasetMeta(0);
  if (!meta || !meta.data || meta.data.length === 0) {
    console.warn('⚠️ [Points] No Chart.js metadata available');
    return;
  }

  const canvasRect = chartInstance.canvas.getBoundingClientRect();
  const chartArea = chartInstance.chartArea;

  if (!chartArea) {
    console.warn('⚠️ [Points] Chart area not available');
    return;
  }

  // Создаём HTML точки для каждой серии
  chartData.forEach((series, seriesIdx) => {
    if (!series.points || series.points.length === 0) return;

    const datasetMeta = chartInstance.getDatasetMeta(seriesIdx);
    if (!datasetMeta || !datasetMeta.data) return;

    series.points.forEach((pointData, pointIdx) => {
      const chartPoint = datasetMeta.data[pointIdx];
      if (!chartPoint || chartPoint.skip) return;

      // Получаем координаты из Chart.js
      const x = chartPoint.x;
      const y = chartPoint.y;

      // Создаём HTML элемент точки
      const pointEl = document.createElement('div');
      pointEl.className = 'chart-point';
      pointEl.setAttribute('data-series-index', seriesIdx);
      pointEl.setAttribute('data-point-index', pointIdx);
      pointEl.setAttribute('data-series-id', series.id || 'series-' + seriesIdx);
      pointEl.setAttribute('data-value', pointData.value);
      pointEl.setAttribute('data-label', pointData.label);

      // Позиционирование на основе Chart.js координат
      pointEl.style.cssText = \`
        position: absolute;
        left: \${x}px;
        top: \${y}px;
        width: 12px;
        height: 12px;
        background-color: \${pointData.color || series.color};
        border: 2px solid white;
        border-radius: 50%;
        transform: translate(-50%, -50%);
        cursor: pointer;
        pointer-events: auto;
        transition: all 0.2s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        z-index: 10;
      \`;

      // Tooltip
      pointEl.title = \`\${series.name}: \${pointData.label} = \${pointData.value}\`;

      // Обработчики событий
      pointEl.addEventListener('click', function(e) {
        e.stopPropagation();
        console.log('🔍 [Point Clicked]', {
          series: series.name,
          seriesId: series.id,
          point: pointData,
          index: pointIdx
        });

        // Подсветка выбранной точки
        document.querySelectorAll('.chart-point').forEach(p => {
          p.style.transform = 'translate(-50%, -50%) scale(1)';
          p.style.zIndex = '10';
        });
        this.style.transform = 'translate(-50%, -50%) scale(1.8)';
        this.style.zIndex = '100';

        // Эмит события в WZ
        if (window.WZ && typeof window.WZ.emitEvent === 'function') {
          window.WZ.emitEvent('POINT_CLICK', {
            seriesIndex: seriesIdx,
            seriesId: series.id,
            seriesName: series.name,
            pointIndex: pointIdx,
            pointData: pointData
          });
        }

        // Кастомное событие для других компонентов
        const customEvent = new CustomEvent('chartPointClick', {
          detail: {
            series: series,
            point: pointData,
            element: this
          },
          bubbles: true
        });
        container.dispatchEvent(customEvent);
      });

      // Hover эффект
      pointEl.addEventListener('mouseenter', function() {
        this.style.transform = 'translate(-50%, -50%) scale(1.6)';
        this.style.boxShadow = '0 4px 12px rgba(0,0,0,0.4)';
        this.style.zIndex = '50';
      });

      pointEl.addEventListener('mouseleave', function() {
        if (this.style.transform !== 'translate(-50%, -50%) scale(1.8)') {
          this.style.transform = 'translate(-50%, -50%) scale(1)';
          this.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
          this.style.zIndex = '10';
        }
      });

      pointsContainer.appendChild(pointEl);
    });
  });

  console.log('✅ [Points] Created', pointsContainer.children.length, 'HTML points');

  // Обновление позиций при ресайзе/анимации
  if (chartInstance.options.onResize) {
    const originalOnResize = chartInstance.options.onResize;
    chartInstance.options.onResize = function(chart, size) {
      originalOnResize.call(this, chart, size);
      setTimeout(() => createHTMLPoints(container, chartData, chartInstance), 100);
    };
  } else {
    chartInstance.options.onResize = function() {
      setTimeout(() => createHTMLPoints(container, chartData, chartInstance), 100);
    };
  }
}

// ✅ ОБНОВЛЕНО: renderChart с поддержкой HTML точек
function renderChart(canvas, chartData, chartType, title, subTitle, infoText, container) {
  console.log('📊 [renderChart] Called with:', {
    chartType: chartType,
    title: title,
    layersCount: chartData.length,
    firstLayerPoints: chartData[0]?.points?.length || 0
  });

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    console.error('❌ [renderChart] Canvas context not available');
    return;
  }

  // Destroy existing chart instance
  if (canvas.chartInstance) {
    console.log('🗑️ [renderChart] Destroying existing chart instance');
    canvas.chartInstance.destroy();
  }

  const validLayers = chartData.filter(layer =>
    layer.points && Array.isArray(layer.points) && layer.points.length > 0
  );

  if (validLayers.length === 0) {
    console.warn('⚠️ [renderChart] No valid data for chart');
    ctx.fillStyle = '#4a5568';
    ctx.font = '16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('No chart data available', canvas.width / 2, canvas.height / 2);
    return;
  }

  console.log('✅ [renderChart] Valid layers:', validLayers.length);

  let config;

  if (container && container.getAttribute('data-component-id') === 'pie-chart-json') {
    const layer = validLayers[0];
    config = {
      type: chartType,
      data: {
        labels: layer.points.map(p => p.label),
        datasets: [{
          data: layer.points.map(p => p.value),
          backgroundColor: layer.points.map(p => p.color || layer.color),
          borderColor: '#ffffff',
          borderWidth: 2,
          hoverOffset: 8
        }]
      },
      options: getPieChartOptions(title)
    };
  } else if (container && container.getAttribute('data-component-id') === 'bar-chart') {
    const labels = validLayers[0].points.map(p => p.label);
    const datasets = validLayers.map(layer => ({
      label: layer.name,
      data: layer.points.map(p => p.value),
      backgroundColor: layer.points.map(p => layer.color + '80'),
      borderColor: layer.color,
      borderWidth: 2,
      borderRadius: 4,
      borderSkipped: false,
    }));

    config = {
      type: 'bar',
      data: { labels, datasets },
      options: getBarChartOptions(title, chartType)
    };
  } else {
    const labels = validLayers[0].points.map(p => p.label);
    const datasets = validLayers.map(layer => {
      console.log('📊 [renderChart] Creating dataset for layer:', layer.name, 'with color:', layer.color);

      return {
        label: layer.name,
        data: layer.points.map(p => p.value),
        backgroundColor: layer.points.map(p =>
          chartType === 'bar-bg' ? (p.color || layer.color) + '80' :
          (chartType === 'bar' ? (p.color || layer.color) + '80' : (p.color || layer.color) + '40')
        ),
        borderColor: layer.color,
        borderWidth: chartType === 'line' ? 3 : 2,
        fill: chartType === 'line' || chartType === 'bar-bg',
        tension: chartType === 'line' ? 0.4 : 0,
        pointBackgroundColor: layer.color,
        pointBorderColor: '#ffffff',
        pointBorderWidth: 2,
        // ✅ ВАЖНО: Скрываем точки Chart.js, используем HTML
        pointRadius: 0,
        pointHoverRadius: 0
      };
    });

    let finalChartType = chartType;
    if (chartType === 'table' || chartType === 'main-text') {
      finalChartType = 'bar';
    }

    config = {
      type: finalChartType === 'line' ? 'line' : 'bar',
      data: { labels, datasets },
      options: getLineChartOptions(title, chartType, finalChartType, subTitle)
    };
  }

  try {
    console.log('🎨 [renderChart] Creating Chart.js instance with', config.data.datasets.length, 'datasets');
    canvas.chartInstance = new Chart(ctx, config);
    console.log('✅ [renderChart] Chart rendered successfully');

    // ✅ КРИТИЧНО: Создаём HTML точки после рендера графика
    if (chartType === 'line' || chartType === 'bar-bg') {
      setTimeout(() => {
        createHTMLPoints(container, validLayers, canvas.chartInstance);
      }, 200);
    }

  } catch (error) {
    console.error('❌ [renderChart] Error creating chart:', error);
  }
}

// ✅ КРИТИЧНО: Экспортируем обе функции глобально
window.renderChart = renderChart;
window.createHTMLPoints = createHTMLPoints;

// Chart options configurations
function getLineChartOptions(title, originalType, finalType, subTitle) {
  const showLegend = originalType !== 'table' && originalType !== 'main-text';
  const showAxes = originalType !== 'table' && originalType !== 'main-text';

  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: title,
        color: '#ffffff',
        font: { size: 16, weight: 'bold' }
      },
      subtitle: subTitle ? {
        display: true,
        text: subTitle,
        color: '#cccccc',
        font: { size: 12 }
      } : undefined,
      legend: {
        display: showLegend,
        position: 'top',
        labels: {
          color: '#ffffff',
          pointStyle: 'circle',
          usePointStyle: true,
          padding: 20,
          font: { size: 12 }
        }
      },
      tooltip: {
        enabled: true,
        mode: 'nearest',
        intersect: false
      }
    },
    scales: {
      x: {
        display: showAxes,
        ticks: { color: '#ffffff' },
        grid: { color: '#4a5568' }
      },
      y: {
        display: showAxes,
        ticks: { color: '#ffffff' },
        grid: { color: '#4a5568' },
        beginAtZero: true
      }
    },
    elements: {
      line: {
        tension: finalType === 'line' ? 0.4 : 0
      }
    },
    interaction: {
      intersect: false,
      mode: 'index'
    },
animations: {
  tension: {
    duration: 1000,
    easing: 'linear',
    onComplete: function() {
      const chart = this;
      const container = chart.canvas.closest('[data-component-id]');

      if (container && typeof window.renderChartPoints === 'function') {
        // Получаем chartData из storage элемента
        const element = container;
        if (element.chartDataStorage) {
          const chartData = []; // Здесь нужна логика преобразования storage в chartData
          window.renderChartPoints(container, chartData, chart);
        }
      }
    }
  }
},
    // ✅ НОВОЕ: Обработчик resize для обновления точек
    onResize: function(chart, size) {
      console.log('📐 [Chart] Resize detected:', size);
    }
  };
}

function getBarChartOptions(title, chartType) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: chartType === 'horizontal' ? 'y' : 'x',
    plugins: {
      title: {
        display: true,
        text: title,
        color: '#ffffff',
        font: { size: 16, weight: 'bold' }
      },
      legend: {
        display: true,
        position: 'top',
        labels: {
          color: '#ffffff',
          pointStyle: 'circle',
          usePointStyle: true,
          padding: 20,
          font: { size: 12 }
        }
      }
    },
    scales: {
      x: {
        display: true,
        ticks: { color: '#ffffff' },
        grid: { color: '#4a5568' }
      },
      y: {
        display: true,
        ticks: { color: '#ffffff' },
        grid: { color: '#4a5568' },
        beginAtZero: true
      }
    },
    elements: {
      bar: {
        borderRadius: 4
      }
    }
  };
}

function getPieChartOptions(title) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: title,
        color: '#ffffff',
        font: { size: 16, weight: 'bold' }
      },
      legend: {
        display: true,
        position: 'top',
        labels: {
          color: '#ffffff',
          padding: 20,
          font: { size: 12 }
        }
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            const label = context.label || '';
            const value = context.parsed;
            const total = context.dataset.data.reduce((a, b) => a + b, 0);
            const percentage = Math.round((value / total) * 100);
            return \`\${label}: \${value} (\${percentage}%)\`;
          }
        }
      }
    }
  };
}

// Initialize charts when everything is ready
function initializeCharts() {
  if (typeof Chart === 'undefined') {
    console.log('⏳ [Chart] Waiting for Chart.js library...');
    setTimeout(initializeCharts, 100);
    return;
  }

  console.log('✅ [Chart] Chart.js loaded, initializing charts...');
  setTimeout(initCharts, 100);
}

// Start chart initialization
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeCharts);
} else {
  initializeCharts();
}`;
}

export function generateWidgetJS(canvasComponents: CanvasComponent[]): string {
  const componentsWithType = canvasComponents.map((comp) => ({
    ...comp,
    attributes: {
      ...comp.attributes,
      'data-component-type': comp.type
    }
  }));

  const componentsJSON = JSON.stringify(componentsWithType);
  const usedTypes = new Set(canvasComponents.map((c) => c.type));
  const handlerEntries: string[] = [];

  usedTypes.forEach((type) => {
    if (HANDLER_TEMPLATES[type as keyof typeof HANDLER_TEMPLATES]) {
      handlerEntries.push(
        `  '${type}': ${HANDLER_TEMPLATES[type as keyof typeof HANDLER_TEMPLATES]}`
      );
    }
  });

  handlerEntries.push(`  'default': ${DEFAULT_HANDLER}`);
  const handlersCode = handlerEntries.join(',\n');

  return `
var canvasComponents = ${componentsJSON};

window.componentsWithActions = window.componentsWithActions || {};
var componentsWithActions = window.componentsWithActions;

// ========================================
// 1. HELPER FUNCTIONS
// ========================================

function copyAllStyles(sourceElement, targetElement) {
  var computedStyles = window.getComputedStyle(sourceElement);
  for (var i = 0; i < computedStyles.length; i++) {
    var propertyName = computedStyles[i];
    var propertyValue = computedStyles.getPropertyValue(propertyName);
    targetElement.style.setProperty(propertyName, propertyValue);
  }
}

function copyAllStylesRecursive(sourceElement, targetElement) {
  if (sourceElement.style.cssText) {
    targetElement.style.cssText = sourceElement.style.cssText;
  }
  var computedStyles = window.getComputedStyle(sourceElement);
  for (var i = 0; i < computedStyles.length; i++) {
    var propertyName = computedStyles[i];
    var propertyValue = computedStyles.getPropertyValue(propertyName);
    if (!propertyName.startsWith('--')) {
      targetElement.style.setProperty(propertyName, propertyValue);
    }
  }
  var cssText = computedStyles.cssText || '';
  var allProps = cssText.split(';');
  allProps.forEach(function(prop) {
    var trimmed = prop.trim();
    if (trimmed.startsWith('--')) {
      var colonIndex = trimmed.indexOf(':');
      if (colonIndex > -1) {
        var varName = trimmed.substring(0, colonIndex).trim();
        var varValue = trimmed.substring(colonIndex + 1).trim();
        targetElement.style.setProperty(varName, varValue);
      }
    }
  });
  var sourceChildren = sourceElement.children;
  var targetChildren = targetElement.children;
  for (var i = 0; i < sourceChildren.length && i < targetChildren.length; i++) {
    copyAllStylesRecursive(sourceChildren[i], targetChildren[i]);
  }
}

function copyAllStylesDeep(sourceElement, targetElement) {
  var excludeProps = ['display', 'visibility'];
  if (sourceElement.style.cssText) {
    var inlineStyles = sourceElement.style.cssText.split(';');
    inlineStyles.forEach(function(style) {
      if (style.trim()) {
        var parts = style.split(':');
        if (parts.length >= 2) {
          var prop = parts[0].trim();
          var val = parts.slice(1).join(':').trim();
          if (prop && val && excludeProps.indexOf(prop) === -1) {
            targetElement.style.setProperty(prop, val);
          }
        }
      }
    });
  }
  var computedStyles = window.getComputedStyle(sourceElement);
  for (var i = 0; i < computedStyles.length; i++) {
    var propName = computedStyles[i];
    if (excludeProps.indexOf(propName) > -1) continue;
    try {
      if (propName !== 'cssText' && propName !== 'length' && propName !== 'parentRule') {
        var propValue = computedStyles.getPropertyValue(propName);
        var propPriority = computedStyles.getPropertyPriority(propName);
        if (propValue) {
          targetElement.style.setProperty(propName, propValue, propPriority);
        }
      }
    } catch (e) { }
  }
  var cssText = computedStyles.cssText || '';
  var allProps = cssText.split(';');
  allProps.forEach(function(prop) {
    var trimmed = prop.trim();
    if (trimmed.startsWith('--')) {
      var colonIndex = trimmed.indexOf(':');
      if (colonIndex > -1) {
        var varName = trimmed.substring(0, colonIndex).trim();
        var varValue = trimmed.substring(colonIndex + 1).trim();
        targetElement.style.setProperty(varName, varValue);
      }
    }
  });
  var sourceChildren = sourceElement.children;
  var targetChildren = targetElement.children;
  for (var j = 0; j < sourceChildren.length && j < targetChildren.length; j++) {
    copyAllStylesDeep(sourceChildren[j], targetChildren[j]);
  }
}

function clearChartClones(chartContainer) {
  var parentContainer = chartContainer.parentElement;
  var existingClones = parentContainer.querySelectorAll('[data-cloned="true"]');
  existingClones.forEach(function(clone) {
    var canvas = clone.querySelector('canvas');
    if (canvas && canvas.chartInstance) {
      canvas.chartInstance.destroy();
    }
    clone.remove();
  });
}

// ========================================
// 2. CHART LOGIC (Render & Points)
// ========================================

function renderChartPoints(element, chartData, chartInstance) {
  if (!chartInstance) return;
  if (element.isRenderingPoints) return;
  element.isRenderingPoints = true;

  if (element.pointsObserver) {
    element.pointsObserver.disconnect();
    element.pointsObserver = null;
    element.pointsSyncEnabled = false;
  }

  var pointsContainer = element.querySelector('[data-component-type="points"]');
  if (!pointsContainer) pointsContainer = element.querySelector('.chart-points-container');

  if (!pointsContainer) {
    pointsContainer = document.createElement('div');
    pointsContainer.className = 'chart-points-container';
    pointsContainer.setAttribute('data-component-type', 'points');
    pointsContainer.style.position = 'absolute';
    pointsContainer.style.top = '0';
    pointsContainer.style.left = '0';
    pointsContainer.style.width = '100%';
    pointsContainer.style.height = '100%';
    pointsContainer.style.pointerEvents = 'none';
    pointsContainer.style.zIndex = '10';
    element.appendChild(pointsContainer);
  }

  var existingPoints = pointsContainer.querySelectorAll('.chart-point');
  existingPoints.forEach(function(point) { point.remove(); });

  if (!chartData || chartData.length === 0) {
    element.isRenderingPoints = false;
    return;
  }

  chartData.forEach(function(series, seriesIdx) {
    if (!series.points || series.points.length === 0) return;
    var datasetMeta = chartInstance.getDatasetMeta(seriesIdx);
    if (!datasetMeta || !datasetMeta.data) return;
    var seriesColor = series.color || '#4170FF';

    series.points.forEach(function(pointData, pointIdx) {
      if (pointData.value == null) return;
      var chartPoint = datasetMeta.data[pointIdx];
      if (!chartPoint || chartPoint.skip) return;

      var point = document.createElement('div');
      point.className = 'chart-point';
      point.setAttribute('data-series-index', seriesIdx);
      point.setAttribute('data-point-index', pointIdx);
      point.setAttribute('data-series-id', series.id || 'series-' + seriesIdx);
      point.setAttribute('data-value', pointData.value);
      point.setAttribute('data-label', pointData.label);

      point.style.position = 'absolute';
      point.style.left = chartPoint.x + 'px';
      point.style.top = chartPoint.y + 'px';
      point.style.width = '12px';
      point.style.height = '12px';
      point.style.backgroundColor = pointData.color || seriesColor;
      point.style.border = '2px solid white';
      point.style.borderRadius = '50%';
      point.style.transform = 'translate(-50%, -50%)';
      point.style.cursor = 'pointer';
      point.style.transition = 'all 0.2s ease';
      point.style.pointerEvents = 'auto';
    point.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
      point.style.zIndex = '10';
      point.title = series.name + ': ' + pointData.label + ' = ' + pointData.value;

     point.addEventListener('click', function(e) {
      e.stopPropagation();
      document.querySelectorAll('.chart-point').forEach(function(p) {
        p.classList.remove('selected');
        p.style.transform = 'translate(-50%, -50%) scale(1)';
        p.style.zIndex = '10';
      });
      this.classList.add('selected');
      this.style.transform = 'translate(-50%, -50%) scale(1.8)';
      this.style.zIndex = '100';

      // Существующий emit (оставляем)
      if (window.WZ && typeof window.WZ.emitEvent === 'function') {
        window.WZ.emitEvent('POINT_CLICK', {
          seriesIndex: seriesIdx, seriesId: series.id, seriesName: series.name,
          pointIndex: pointIdx, pointData: pointData
        });
      }

      var chartId = element.id;
      if (componentsWithActions[chartId]) {
        var actionCompInfo = componentsWithActions[chartId].find(function(comp) {
          return comp.wzComp.action === 'OPEN_DASHBOARD';
        });

        if (actionCompInfo && window.WZ && typeof window.WZ.sendOpenDashboard === 'function') {
          // Собираем mappingValues из dataset точки
          var mappingValues = [];
          var params = actionCompInfo.wzComp.parameters || [];

          params.forEach(function(param) {
            var columnName = param.columnName;
            var value = this.dataset[columnName];

            if (value !== undefined) {
              mappingValues.push({
                dashboardParameterId: param.dashboardParameterId,
                columnName: columnName,
                mappingValueString: value
              });
            }
          }.bind(this));

          // ✅ ПРАВИЛЬНАЯ СИГНАТУРА: dashboardId, type, mappingValues
          window.WZ.sendOpenDashboard(
            actionCompInfo.wzComp.targetId,     // dashboardId
            'OPEN_DASHBOARD',                   // type
            mappingValues                       // mappingValues
          );

          console.log('🚀 Dashboard opened with grapxY =', mappingValues[0]?.value);
        }
      }
    });

      point.addEventListener('mouseenter', function() {
        this.style.transform = 'translate(-50%, -50%) scale(1.6)';
        this.style.boxShadow = '0 4px 12px rgba(0,0,0,0.4)';
        this.style.zIndex = '50';
      });
      point.addEventListener('mouseleave', function() {
        if (!this.classList.contains('selected')) {
          this.style.transform = 'translate(-50%, -50%) scale(1)';
          this.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
          this.style.zIndex = '10';
        }
      });
      pointsContainer.appendChild(point);
    });
  });

  setTimeout(function() {
    element.isRenderingPoints = false;

    // ====== БИНДИМ КОМПОНЕНТЫ ПОСЛЕ СОЗДАНИЯ ТОЧЕК ======
    var chartId = element.id;
    console.log('Points rendered for chart:', chartId);
    console.log('Looking for components with actions...');

    if (componentsWithActions[chartId]) {
      console.log('Found components with actions for this chart:', componentsWithActions[chartId]);

      componentsWithActions[chartId].forEach(function(compInfo) {
        var wzComp = compInfo.wzComp;
        var wzName = compInfo.wzName;

        // Получаем данные маппинга
        WZ.getMappingData(wzName, function(mappingData) {
          console.log('Mapping data for', wzName, ':', mappingData);

          if (mappingData && mappingData.length > 0) {
            var dataContent = mappingData[0].content;
            var columnName = wzComp.parameters && wzComp.parameters[0]
              ? wzComp.parameters[0].columnName
              : 'value';

            var pointsContainer = element.querySelector('[data-component-type="points"]');
            if (!pointsContainer) {
              console.warn('Points container not found');
              return;
            }

            var points = pointsContainer.querySelectorAll('.chart-point');
            console.log('Binding', points.length, 'points with column:', columnName);

            // ДОБАВЛЯЕМ DATASET К КАЖДОЙ ТОЧКЕ
            points.forEach(function(point, index) {
              if (dataContent[index]) {
                var value = Array.isArray(dataContent[index])
                  ? dataContent[index][0]
                  : dataContent[index];

                point.dataset[columnName] = value;
                console.log('Added dataset to point', index, ':', columnName, '=', value);
              }
            });

            // ТЕПЕРЬ БИНДИМ КОМПОНЕНТ
            console.log('Calling WZ.bindComponents for:', wzName);
            WZ.bindComponents(function(boundComponents) {
              console.log('✅ Successfully bound chart point component:', wzName, boundComponents);
            }, [wzComp]);
          }
        });
      });
    } else {
      console.log('No components with actions found for chart:', chartId);
    }
  }, 100);

}

function syncPointsToChart(element, chartInstance) {
  if (!chartInstance || !element) return;
  var pointsContainer = element.querySelector('[data-component-type="points"]');
  if (!pointsContainer) return;

  var observer = new MutationObserver(function(mutations) {
    var needsUpdate = false;
    mutations.forEach(function(mutation) {
      if (mutation.type === 'attributes' && mutation.target.classList.contains('chart-point')) {
        needsUpdate = true;
        var point = mutation.target;
        var seriesIdx = parseInt(point.getAttribute('data-series-index'));
        var pointIdx = parseInt(point.getAttribute('data-point-index'));

        if (mutation.attributeName === 'style' || mutation.attributeName === 'data-value') {
          var newValue = parseFloat(point.getAttribute('data-value'));
          if (!isNaN(newValue) && chartInstance.data.datasets[seriesIdx]) {
            chartInstance.data.datasets[seriesIdx].data[pointIdx] = newValue;
          }
          var newColor = point.style.backgroundColor;
          if (newColor && chartInstance.data.datasets[seriesIdx]) {
            if (!Array.isArray(chartInstance.data.datasets[seriesIdx].backgroundColor)) {
              chartInstance.data.datasets[seriesIdx].backgroundColor = [];
            }
            chartInstance.data.datasets[seriesIdx].backgroundColor[pointIdx] = newColor;
            chartInstance.data.datasets[seriesIdx].borderColor = newColor;
          }
        }
      }
    });
    if (needsUpdate) chartInstance.update('none');
  });

  observer.observe(pointsContainer, {
    attributes: true, attributeFilter: ['style', 'data-value', 'data-label'], subtree: true
  });
  element.pointsObserver = observer;
}

function setupCanvasClickHandler(element, chartInstance, pointsContainer) {
  var canvas = chartInstance.canvas;
  if (canvas.clickHandler) canvas.removeEventListener('click', canvas.clickHandler);

  var clickHandler = function(event) {
    var rect = canvas.getBoundingClientRect();
    var x = event.clientX - rect.left;
    var y = event.clientY - rect.top;
    var clickedPoint = null;
    var clickRadius = 10;

    chartInstance.data.datasets.forEach(function(dataset, seriesIdx) {
      var meta = chartInstance.getDatasetMeta(seriesIdx);
      if (!meta || !meta.data) return;
      meta.data.forEach(function(chartPoint, pointIdx) {
        if (chartPoint.skip) return;
        var dx = x - chartPoint.x;
        var dy = y - chartPoint.y;
        var distance = Math.sqrt(dx * dx + dy * dy);
        if (distance <= clickRadius) {
          clickedPoint = {
            seriesIndex: seriesIdx, pointIndex: pointIdx,
            x: chartPoint.x, y: chartPoint.y, distance: distance
          };
        }
      });
    });

    if (clickedPoint) {
      var selector = '[data-series-index="' + clickedPoint.seriesIndex + '"][data-point-index="' + clickedPoint.pointIndex + '"]';
      var htmlPoint = pointsContainer.querySelector(selector);
      if (htmlPoint) {
        var clickEvent = new MouseEvent('click', {
          bubbles: true, cancelable: true, view: window,
          clientX: event.clientX, clientY: event.clientY
        });
        htmlPoint.dispatchEvent(clickEvent);
      }
    }
  };

  canvas.clickHandler = clickHandler;
  canvas.addEventListener('click', clickHandler);
}

window.updateChartPoint = function(chartElementId, seriesIndex, pointIndex, updates) {
  var chartElement = document.getElementById(chartElementId);
  if (!chartElement) return;
  var pointsContainer = chartElement.querySelector('[data-component-type="points"]');
  if (!pointsContainer) return;
  var selector = '[data-series-index="' + seriesIndex + '"][data-point-index="' + pointIndex + '"]';
  var point = pointsContainer.querySelector(selector);
  if (!point) return;

  if (updates.value !== undefined) point.setAttribute('data-value', updates.value);
  if (updates.label !== undefined) {
    point.setAttribute('data-label', updates.label);
    point.title = point.title.replace(/: .* = /, ': ' + updates.label + ' = ');
  }
  if (updates.color !== undefined) point.style.backgroundColor = updates.color;
  if (updates.size !== undefined) {
    point.style.width = updates.size + 'px';
    point.style.height = updates.size + 'px';
  }
  if (updates.visible !== undefined) point.style.display = updates.visible ? 'block' : 'none';
};
window.renderChartPoints = renderChartPoints;

function renderChartWithLayers(element) {
  var storage = element.chartDataStorage;
  var hasX = storage.X && storage.X.length > 0;
  var hasY = storage.Y && storage.Y.length > 0;
  if (!hasX || !hasY) return;

  function parseAxisData(rawData) {
    if (!rawData) return [];
    if (!Array.isArray(rawData)) return [rawData];
    return rawData.map(function(row) {
      var val = Array.isArray(row) ? row[0] : row;
      if (val == null || val === '') return null;
      var num = Number(String(val).replace(',', '.'));
      return Number.isFinite(num) ? num : String(val);
    }).filter(function(v) { return v !== null; });
  }

  var xLabels = [];
  for (var i = 0; i < storage.X.length; i++) {
    var parsed = parseAxisData(storage.X[i]);
    if (parsed.length > xLabels.length) xLabels = parsed;
  }
  if (xLabels.length === 0) return;

  var chartData = [];
  var colors = ['#4170FF', '#FF6B6B', '#51CF66', '#FCC419', '#845EF7', '#F06595'];

  for (var yIdx = 0; yIdx < storage.Y.length; yIdx++) {
    var yRawData = storage.Y[yIdx];
    if (!yRawData) continue;
    var parsedY = parseAxisData(yRawData);
    var minLen = Math.min(xLabels.length, parsedY.length);
    var points = [];
    var color = colors[yIdx % colors.length];
    for (var i = 0; i < minLen; i++) {
      points.push({ label: String(xLabels[i]), value: parsedY[i] || 0, color: color });
    }
    chartData.push({ id: 'y-axis-' + yIdx, name: 'Series ' + (yIdx + 1), color: color, points: points });
  }

  var layerNames = storage.layerNames || {};
  var layerGroupIndex = 0;
  Object.keys(storage.layers).forEach(function(layerId) {
    var layerSeriesArray = storage.layers[layerId];
    for (var lIdx = 0; lIdx < layerSeriesArray.length; lIdx++) {
      var layerRawData = layerSeriesArray[lIdx];
      if (!layerRawData) continue;
      var parsedLayerY = parseAxisData(layerRawData);
      var minLen = Math.min(xLabels.length, parsedLayerY.length);
      var points = [];
      var colorIndex = (storage.Y.length + layerGroupIndex + lIdx) % colors.length;
      var color = colors[colorIndex];
      for (var i = 0; i < minLen; i++) {
        points.push({ label: String(xLabels[i]), value: parsedLayerY[i] || 0, color: color });
      }
      var uniqueKey = layerId + '_' + lIdx;
      var name = layerNames[uniqueKey] || ('Layer ' + layerId + (lIdx > 0 ? ' (' + (lIdx + 1) + ')' : ''));
      chartData.push({ id: layerId + '-' + lIdx, name: name, color: color, points: points });
    }
    layerGroupIndex++;
  });

  var canvas = element.querySelector('canvas') || element.querySelector('[data-chart-element]');
  if (!canvas && element.shadowRoot) canvas = element.shadowRoot.querySelector('canvas');
  if (!canvas) return;
  if (chartData.length === 0) return;

  var chartType = element.getAttribute('data-chart-type') || 'line';
  var title = element.getAttribute('data-title') || 'Chart';
  var subTitle = element.getAttribute('data-sub-title') || '';
  var infoText = element.getAttribute('data-info-text') || '';

  if (canvas.chartInstance) {
    try {
      if (canvas.clickHandler) canvas.removeEventListener('click', canvas.clickHandler);
      if (canvas.hoverHandler) canvas.removeEventListener('mousemove', canvas.hoverHandler);
      canvas.chartInstance.destroy();
    } catch (e) {}
    canvas.chartInstance = null;
  }

  try {
    if (typeof window.renderChart === 'function') {
      window.renderChart(canvas, chartData, chartType, title, subTitle, infoText, element);
      setTimeout(function() {
        if (canvas.chartInstance) {
          renderChartPoints(element, chartData, canvas.chartInstance);
          var pointsContainer = element.querySelector('[data-component-type="points"]');
          if (pointsContainer) setupCanvasClickHandler(element, canvas.chartInstance, pointsContainer);
          if (!element.pointsSyncEnabled) {
            syncPointsToChart(element, canvas.chartInstance);
            element.pointsSyncEnabled = true;
          }
        }
      }, 300);
    }
  } catch (error) {}
}

// ========================================
// 3. CORE LOGIC (Process, Update, Wait)
// ========================================

var containerState = { processing: {}, initialized: {} };

function isContainerReady(elementId) {
  var container = document.getElementById(elementId);
  if (!container) return false;
  var parent = container.parentElement;
  if (!parent) return false;
  var templateId = container.getAttribute('data-template-id') || elementId;
  var clones = parent.querySelectorAll('[data-cloned-from="' + templateId + '"]');
  return clones.length > 0;
}

function waitForContainer(elementId, callback, maxAttempts) {
  maxAttempts = maxAttempts || 20;
  var attempts = 0;
  function check() {
    attempts++;
    if (isContainerReady(elementId)) callback();
    else if (attempts < maxAttempts) setTimeout(check, 50);
    else callback();
  }
  check();
}

var componentHandlers = {
${handlersCode}
};

var updateQueue = {};
var updateTimers = {};

function debounceUpdate(wzComponentName, callback, delay) {
  delay = delay || 50;
  if (updateTimers[wzComponentName]) clearTimeout(updateTimers[wzComponentName]);
  updateTimers[wzComponentName] = setTimeout(function() {
    callback();
    delete updateTimers[wzComponentName];
  }, delay);
}

// ПЕРЕМЕЩЕНЫ ВВЕРХ, ЧТОБЫ БЫТЬ ДОСТУПНЫМИ ДЛЯ ИНИЦИАЛИЗАЦИИ
function updateComponent(mapping, data) {
    var containerSelector = mapping.containerSelector || mapping.selector;
    var element = null;

    if (mapping.type === 'chart-axis-x' || mapping.type === 'chart-axis-y' || mapping.type === 'chart-layer') {
      var virtualComp = canvasComponents.find(function(c) { return c.id === mapping.id; });
      if (virtualComp && virtualComp.attributes && virtualComp.attributes['data-chart-id']) {
        var chartId = virtualComp.attributes['data-chart-id'];
        element = document.getElementById(chartId);
      } else {
        return;
      }
    } else {
      var elementById = document.getElementById(mapping.id);
      if (elementById) element = elementById;
      else element = document.querySelector(containerSelector);
    }

    if (!element) {
      console.warn('updateComponent: element not found for', mapping.type, mapping.id);
      return;
    }
    if (element.closest('[data-cloned-from]')) return;

    var handler = componentHandlers[mapping.type] || componentHandlers['default'];
    var config = {};

    // --- KEY FIX ---
    if (mapping.columnName) config.columnName = mapping.columnName;
    if (mapping.rawResponseNames) config.rawResponseNames = mapping.rawResponseNames;

    if (mapping.type === 'chart-axis-x') config.axis = 'X';
    else if (mapping.type === 'chart-axis-y') config.axis = 'Y';
    else if (mapping.type === 'chart-layer') {
        var virtualComp = canvasComponents.find(function(c) { return c.id === mapping.id; });
        if (virtualComp && virtualComp.attributes) config.layerId = virtualComp.attributes['data-layer-id'];
    }

    try {
      handler(element, data, config);
    } catch (error) {
      console.error('updateComponent handler error:', error);
    }
}

function clearComponent(mapping) {
    var containerSelector = mapping.containerSelector || mapping.selector;
    var element = document.querySelector(containerSelector);
    if (!element) return;
    if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') element.value = '';
    else element.textContent = '';
}

function processMapping(wzComponentName, filters, mapping) {
    WZ.getMappingDataByFilter(wzComponentName, { filters: filters }, function(response) {
        if (!response || response.length === 0) return;

        var numRows = 0;
        if (response[0] && response[0].content) numRows = response[0].content.length;
        if (numRows === 0) {
            clearComponent(mapping);
            return;
        }

        var processedData = [];
        for (var i = 0; i < numRows; i++) {
            var rowData = [];
            for (var j = 0; j < response.length; j++) {
                var content = response[j].content;
                if (content && content[i]) {
                    var val = Array.isArray(content[i]) ? content[i][0] : content[i];
                    rowData.push(val);
                } else {
                    rowData.push(null);
                }
            }
            processedData.push(rowData);
        }

        var storageId = response[0].storageId;
        // --- KEY FIX ---
        var columnName = response[0].columnName || response[0].label || null;
        var rawResponseNames = null;

        if (response.length > 1) {
            var columnNames = response.map(function(r) { return r.columnName || r.label || 'Column'; });
            if (mapping.type === 'th') columnName = columnNames;
            else columnName = columnNames.join(', ');
            rawResponseNames = columnNames;
        } else {
            rawResponseNames = [columnName];
        }

        if (mapping.type === 'th' && !columnName && storageId) {
            WZ.getStorage(storageId, function(storage) {
                if (storage && storage.columns) {
                    var column = storage.columns.find(function(col) { return col.id === wzComponentName || col.name === wzComponentName; });
                    columnName = column ? column.name : wzComponentName;
                } else {
                    columnName = wzComponentName;
                }
                var extendedMapping = {
                    selector: mapping.selector,
                    containerSelector: mapping.containerSelector,
                    type: mapping.type,
                    id: mapping.id,
                    columnName: columnName,
                    rawResponseNames: [columnName]
                };
                updateComponent(extendedMapping, processedData);
            });
            return;
        }

        var extendedMapping = {
            selector: mapping.selector,
            containerSelector: mapping.containerSelector,
            type: mapping.type,
            id: mapping.id,
            columnName: columnName || wzComponentName,
            rawResponseNames: rawResponseNames
        };
        updateComponent(extendedMapping, processedData);
    });
}

function fetchAndProcess(wzComponentName, filters) {
    filters = filters || [];
    if (typeof window.WZ === 'undefined') return;
    var mapping = wzComponentMap[wzComponentName];
    if (!mapping) return;
    var isContainer = mapping.type === 'container';
    if (isContainer) {
        processMapping(wzComponentName, filters, mapping);
    } else {
        debounceUpdate(wzComponentName, function() {
            processMapping(wzComponentName, filters, mapping);
        }, 100);
    }
}

// ========================================
// 4. INIT & EXECUTION (AT THE BOTTOM)
// ========================================

var wzComponentMap = {};

function waitForWZComponents(callback, attempts = 0) {
  console.log('🔄 Попытка загрузки WZ компонентов:', attempts + 1);

  if (typeof window.WZ === 'undefined' || typeof window.WZ.getComponents !== 'function') {
    if (attempts < 15) {
      setTimeout(() => waitForWZComponents(callback, attempts + 1), 300);
      return;
    }
    console.error('❌ WZ API не инициализирован после 15 попыток');
    return;
  }

  WZ.getComponents(function(wzComponents) {
    console.log('📦 WZ.getComponents вернул:', wzComponents ? wzComponents.length : 'undefined');

    if (!wzComponents || wzComponents.length === 0) {
      if (attempts < 15) {
        console.log('⏳ Компоненты ещё не готовы, повторяем...');
        setTimeout(() => waitForWZComponents(callback, attempts + 1), 300);
        return;
      }
      console.warn('⚠️  WZ.getComponents вернул пустой результат после всех попыток');
      return;
    }

    // ✅ КОМПОНЕНТЫ НАКОНЕЦ ЗАГРУЗИЛСЯ — выполняем mapping
    console.log('✅ Начинаем обработку', wzComponents.length, 'компонентов');
    processComponentsAndBind(wzComponents);
    callback?.(wzComponents);
  });
}

function processComponentsAndBind(wzComponents) {
  // 1️⃣ СОЗДАЁМ МАППИНГ (ваш существующий forEach)
  wzComponents.forEach(function(wzComp, index) {
    var wzName = wzComp.name || wzComp.Name;
    var wzSelector = wzComp.selector;

    console.log('--- WZ Component', index + 1, '---');
    console.log('Name:', wzName);
    console.log('Selector:', wzSelector);
    console.log('Has action:', !!wzComp.action);

    if (!wzSelector) {
      console.warn('No selector for component:', wzName);
      return;
    }

    var wzDomId = wzSelector.replace('#', '');
    var element = document.querySelector(wzSelector);
    var canvasComp = null;

    console.log('Element found:', !!element);

    if (element) {
      var componentType = element.getAttribute('data-component-type');
      console.log('Component type from DOM:', componentType);

      if (wzComp.action && (componentType === 'custom-button' || componentType === 'label-text' ||
          componentType === 'th' || componentType === 'checkbox-label' || element.classList.contains('component-button'))) {
        var wzDomId = wzSelector.replace('#', '');
        if (!componentsWithActions[wzDomId]) {
          componentsWithActions[wzDomId] = [];
        }
        componentsWithActions[wzDomId].push({
          wzComp: wzComp,
          wzName: wzName,
          componentType: componentType
        });
        console.log('✅ Action registered for:', wzDomId);
      }

      // Виртуальные компоненты для чартов
      if (componentType === 'chart-axis-x' || componentType === 'chart-axis-y' || componentType === 'chart-layer') {
        var chartId = element.getAttribute('data-chart-id');
        console.log('Virtual component detected, chart ID:', chartId);

        if (chartId && wzComp.action) {
          console.log('Saving component with action for chart:', chartId);
          if (!componentsWithActions[chartId]) {
            componentsWithActions[chartId] = [];
          }
          componentsWithActions[chartId].push({
            wzComp: wzComp,
            wzName: wzName,
            componentType: componentType
          });
        }

        canvasComp = {
          id: wzDomId,
          type: componentType,
          selector: wzSelector,
          chartId: chartId
        };
      } else if (componentType) {
        canvasComp = { id: wzDomId, type: componentType, selector: wzSelector };
      } else {
        canvasComp = canvasComponents.find(function(c) { return c.id === wzDomId; });
      }
    } else {
      canvasComp = canvasComponents.find(function(c) { return c.id === wzDomId; });
    }

    if (canvasComp) {
      wzComponentMap[wzName] = {
        selector: wzSelector,
        containerSelector: canvasComp.chartId ? '#' + canvasComp.chartId : wzSelector,
        type: canvasComp.type,
        id: canvasComp.id
      };
      console.log('✅ Mapped:', wzName, '→', wzComponentMap[wzName]);
    } else {
      console.warn('❌ Could not map component:', wzName);
    }
  });

  console.log('📋 === Components with actions ===', componentsWithActions);
  console.log('🗺️  === Final wzComponentMap ===', wzComponentMap);

  // 2️⃣ ЗАПУСКАЕМ BINDING ПОСЛЕ МАППИНГА (с небольшой задержкой для DOM)
  setTimeout(() => {
    console.log('🔗 Запускаем WZ.bindComponents...');
    WZ.bindComponents(function(components) {
      console.log('✅ WZ.bindComponents callback:', components);

      if (!components || components.length === 0) {
        console.warn('⚠️  bindComponents вернул пустой список');
        return;
      }

      var containers = [];
      var others = [];

      components.forEach(function(wzComp) {
        var wzName = wzComp.name || wzComp.Name;
        if (wzComponentMap[wzName]) {
          if (wzComponentMap[wzName].type === 'container') {
            containers.push({ name: wzName, id: wzComponentMap[wzName].id });
          } else {
            others.push(wzName);
          }
        }
      });

      // Сортируем контейнеры по вложенности
      containers.sort(function(a, b) {
        var elemA = document.getElementById(a.id);
        var elemB = document.getElementById(b.id);
        if (!elemA || !elemB) return 0;
        if (elemA.contains(elemB)) return -1;
        if (elemB.contains(elemA)) return 1;
        return 0;
      });

      var containerDelay = 0;
      containers.forEach(function(container) {
        setTimeout(function() { fetchAndProcess(container.name); }, containerDelay);
        containerDelay += 100;
      });

      var childrenDelay = containerDelay + 200;
      setTimeout(function() {
        others.forEach(function(wzName) { fetchAndProcess(wzName); });
      }, childrenDelay);
    });
  }, 150);

  // 3️⃣ Глобальный обработчик событий
  WZ.addEventListener('*', function(event) {
    try {
      var eventData = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
      if (eventData.type === "FILTER_MAPPING_DATA") {
        var allComponents = Object.keys(wzComponentMap);
        var containers = allComponents.filter(function(name) { return wzComponentMap[name].type === 'container'; });
        var others = allComponents.filter(function(name) { return wzComponentMap[name].type !== 'container'; });
        var delay = 0;
        containers.forEach(function(name) {
          setTimeout(function() { fetchAndProcess(name, eventData.filters || []); }, delay);
          delay += 100;
        });
        setTimeout(function() {
          others.forEach(function(name) { fetchAndProcess(name, eventData.filters || []); });
        }, delay + 200);
      }
      if (eventData.type === "REFRESH_DATA") {
        var allComponents = Object.keys(wzComponentMap);
        var containers = allComponents.filter(function(name) { return wzComponentMap[name].type === 'container'; });
        var others = allComponents.filter(function(name) { return wzComponentMap[name].type !== 'container'; });
        var delay = 0;
        containers.forEach(function(name) {
          setTimeout(function() { fetchAndProcess(name); }, delay);
          delay += 100;
        });
        setTimeout(function() {
          others.forEach(function(name) { fetchAndProcess(name); });
        }, delay + 200);
      }
    } catch (e) {
      console.error('Event listener error:', e);
    }
  });
}

// ✅ СТАРТ: ждём компоненты
waitForWZComponents(function(wzComponents) {
  console.log('🎉 Инициализация виджета завершена успешно!');
});

WZ.getWidget(function(widget) {});

window.uiRenderComponent = function(config, values) {
    var data = values.map(function(v) { return [v]; });
    updateComponent(config, data);
};
`.trim();
}

export function collectCanvasComponents(
  comp: Component,
  components: CanvasComponent[]
): void {
  const componentType = comp.get('type') || 'component';
  const tagName = comp.get('tagName')?.toLowerCase();
  const componentId = comp.getId();
  if (componentType === 'chart') {
    const rawAttributes = comp.getAttributes() || {};
    const cleanAttributes: Record<string, any> = {};

    Object.keys(rawAttributes).forEach((key) => {
      const value = rawAttributes[key];
      if (typeof value === 'string') {
        cleanAttributes[key] = value
          .replace(/[\r\n\t\f\v]/g, '')
          .replace(/\s{2,}/g, ' ')
          .trim();
      } else if (typeof value === 'object' && value !== null) {
        const stringified = JSON.stringify(value);
        cleanAttributes[key] = stringified
          .replace(/[\r\n\t\f\v]/g, '')
          .replace(/\s{2,}/g, ' ')
          .trim();
      } else {
        cleanAttributes[key] = value;
      }
    });

    components.push({
      id: componentId,
      type: 'chart',
      tagName: 'div',
      selector: `#${componentId}`,
      componentId: 'chart',
      traits: comp.get('traits')?.map((t: any) => t.get('name')) || [],
      attributes: cleanAttributes,
      classes: comp.get('classes')?.map((c: any) => c.getName()) || []
    });

    console.log('✅ [Collect] Added chart component:', componentId);

    const children = comp.components();

    children.forEach((child: Component) => {
      const childType = child.get('type');
      const childId = child.getId();

      if (childType === 'chart-axis-x' || childType === 'chart-axis-y') {
        components.push({
          id: childId,
          type: childType,
          tagName: 'virtual',
          selector: `#${componentId}`,
          componentId: childType,
          traits: [],
          attributes: {
            'data-chart-id': componentId,
            'data-axis': childType === 'chart-axis-x' ? 'X' : 'Y'
          },
          classes: []
        });
        console.log(`✅ [Collect] Added ${childType} for chart:`, componentId);
      }

      if (childType === 'chart-layer') {
        const layerAttrs = child.getAttributes();
        components.push({
          id: childId,
          type: 'chart-layer',
          tagName: 'virtual',
          selector: `#${componentId}`,
          componentId: 'chart-layer',
          traits: [],
          attributes: {
            'data-chart-id': componentId,
            'data-layer-id': layerAttrs['data-layer-id'] || 'unknown-layer'
          },
          classes: []
        });
        console.log(`✅ [Collect] Added chart-layer for chart:`, componentId);
      }
    });
  } else if (componentType === 'checkbox-group') {
    const rawAttributes = comp.getAttributes() || {};
    const cleanAttributes: Record<string, any> = {};

    Object.keys(rawAttributes).forEach((key) => {
      const value = rawAttributes[key];
      if (typeof value === 'string') {
        cleanAttributes[key] = value
          .replace(/[\r\n\t\f\v]/g, '')
          .replace(/\s{2,}/g, ' ')
          .trim();
      } else if (typeof value === 'object' && value !== null) {
        const stringified = JSON.stringify(value);
        cleanAttributes[key] = stringified
          .replace(/[\r\n\t\f\v]/g, '')
          .replace(/\s{2,}/g, ' ')
          .trim();
      } else {
        cleanAttributes[key] = value;
      }
    });

    components.push({
      id: componentId,
      type: 'checkbox-group',
      tagName: 'div',
      selector: `#${componentId}`,
      componentId: 'checkbox-group',
      traits: comp.get('traits')?.map((t: any) => t.get('name')) || [],
      attributes: cleanAttributes,
      classes: comp.get('classes')?.map((c: any) => c.getName()) || []
    });

    console.log('✅ [Collect] Added checkbox-group component:', componentId);

    const labelElement = comp.find('.checkbox-label')[0];
    if (labelElement) {
      const labelId = labelElement.getId();
      components.push({
        id: labelId,
        type: 'checkbox-label',
        tagName: 'virtual',
        selector: `#${componentId}`,
        componentId: 'checkbox-label',
        traits: [],
        attributes: {
          'data-checkbox-group-id': componentId,
          'data-component-type': 'checkbox-label'
        },
        classes: []
      });
      console.log(
        '✅ [Collect] Added checkbox-label for checkbox-group:',
        componentId
      );
    }
  }
  // ========================================
  // ОСТАЛЬНЫЕ КОМПОНЕНТЫ
  // ========================================
  else {
    const isMappable =
      mappableTypes.includes(componentType) || tagName === 'th';

    if (isMappable) {
      const rawAttributes = comp.getAttributes() || {};
      const cleanAttributes: Record<string, any> = {};

      Object.keys(rawAttributes).forEach((key) => {
        const value = rawAttributes[key];
        if (typeof value === 'string') {
          cleanAttributes[key] = value
            .replace(/[\r\n\t\f\v]/g, '')
            .replace(/\s{2,}/g, ' ')
            .trim();
        } else if (typeof value === 'object' && value !== null) {
          const stringified = JSON.stringify(value);
          cleanAttributes[key] = stringified
            .replace(/[\r\n\t\f\v]/g, '')
            .replace(/\s{2,}/g, ' ')
            .trim();
        } else {
          cleanAttributes[key] = value;
        }
      });

      const finalType = tagName === 'th' ? 'th' : componentType.toLowerCase();

      components.push({
        id: componentId,
        type: finalType,
        tagName: (tagName || 'span').toLowerCase(),
        selector: `#${componentId}`,
        componentId: finalType,
        traits: comp.get('traits')?.map((t: any) => t.get('name')) || [],
        attributes: cleanAttributes,
        classes: comp.get('classes')?.map((c: any) => c.getName()) || []
      });

      console.log('✅ [Collect] Added component:', {
        type: finalType,
        id: componentId,
        selector: `#${componentId}`,
        tagName: tagName
      });
    }
  }

  // ========================================
  // РЕКУРСИЯ
  // ========================================
  comp.get('components')?.forEach((child: Component) => {
    const childType = child.get('type');
    // Пропускаем уже обработанные дочерние спец-компоненты
    if (
      childType !== 'chart-axis-x' &&
      childType !== 'chart-axis-y' &&
      childType !== 'chart-layer' &&
      !child.getClasses().includes('checkbox-label')
    ) {
      collectCanvasComponents(child, components);
    }
  });
}
export function normalizeHTMLWithCharts(
  html: string,
  name: string,
  hasAnyChartComponents: boolean,
  availableFiles?: Array<{ name: string; contentType: string }>,
  cssFileName?: string,
  jsFileName?: string
): string {
  if (html.includes('<!DOCTYPE') && html.includes('<head>')) {
    return html;
  }

  let bodyContent = html;
  if (html.includes('<body>')) {
    const bodyMatch = html.match(/<body[^>]*>([\s\S]*)<\/body>/);
    if (bodyMatch) {
      bodyContent = bodyMatch[1];
    }
  }

  const finalCssFileName = cssFileName || 'index.css';
  const finalJsFileName = jsFileName || 'index.js';

  const hasWzJs = availableFiles?.some((f) => f.name === 'wz.js') || false;
  const hasPasswordComponent = /password-input-container/.test(bodyContent);
  const hasTextInputComponent = /text-input-container/.test(bodyContent);
  const hasTabsComponents = /tabs-wrapper/.test(bodyContent);
  const hasNumberComponent = /mui-number-input-wrapper/.test(bodyContent);
  const hasTableComponents = /table-wrapper/.test(bodyContent);

  const numberScript = hasNumberComponent
    ? `<script>
  (function() {
    function initNumberInputs() {
      const wrappers = document.querySelectorAll('.mui-number-input-wrapper');
      if (!wrappers.length) return;

      wrappers.forEach(wrapper => {
        const inputEl = wrapper.querySelector('.mui-number-input');
        const upArrow = wrapper.querySelector('.mui-number-arrow-up');
        const downArrow = wrapper.querySelector('.mui-number-arrow-down');

        // Проверка инициализации
        if (!inputEl || (!upArrow && !downArrow) || wrapper._numberInit) return;
        wrapper._numberInit = true;

        const changeValue = (delta) => {
          if (inputEl.disabled) return;

          // 1. Считываем текущее значение
          let currentVal = parseFloat(inputEl.value);
          if (isNaN(currentVal)) currentVal = 0;

          // 2. Считываем шаг (step)
          const stepAttr = inputEl.getAttribute('step');
          const step = (stepAttr && stepAttr !== '') ? parseFloat(stepAttr) : 1;

          // 3. Считываем min/max с проверкой на пустую строку
          const minAttr = inputEl.getAttribute('min');
          const maxAttr = inputEl.getAttribute('max');

          // Если атрибут пустой или отсутствует, используем бесконечность
          const min = (minAttr !== null && minAttr !== '') ? parseFloat(minAttr) : -Infinity;
          const max = (maxAttr !== null && maxAttr !== '') ? parseFloat(maxAttr) : Infinity;

          // 4. Вычисляем новое значение
          let newVal = currentVal + (delta * step);

          // 5. Ограничиваем
          if (newVal > max) newVal = max;
          if (newVal < min) newVal = min;

          // 6. Исправляем ошибки плавающей точки (0.1 + 0.2)
          newVal = Math.round(newVal * 10000) / 10000;

          // 7. Применяем и вызываем события
          inputEl.value = newVal;
          inputEl.dispatchEvent(new Event('input', { bubbles: true }));
          inputEl.dispatchEvent(new Event('change', { bubbles: true }));
        };

        // Обработчик клика с остановкой всплытия (важно для редактора)
        const handleArrowClick = (e, delta) => {
          e.preventDefault();
          e.stopPropagation(); // Останавливает выделение компонента в редакторе
          changeValue(delta);
        };

        if (upArrow) {
          upArrow.addEventListener('click', (e) => handleArrowClick(e, 1));
        }

        if (downArrow) {
          downArrow.addEventListener('click', (e) => handleArrowClick(e, -1));
        }
      });
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initNumberInputs);
    } else {
      initNumberInputs();
    }
  })();
</script>
`
    : '';

  const tabsScript = hasTabsComponents
    ? `<script>
// Tabs functionality
function initTabsStandalone() {
  const tabWrappers = document.querySelectorAll('.tabs-wrapper');

  tabWrappers.forEach(wrapper => {
    const tabButtons = wrapper.querySelectorAll('.tab-button');
    const tabPanes = wrapper.querySelectorAll('.tab-pane');

    function switchTab(tabId) {
      if (!tabId) return;

      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabPanes.forEach(pane => pane.classList.remove('active'));

      const targetBtn = wrapper.querySelector('.tab-button[data-tab="' + tabId + '"]');
      const targetPane = wrapper.querySelector('.tab-pane[data-tab="' + tabId + '"]');

      if (targetBtn) targetBtn.classList.add('active');
      if (targetPane) targetPane.classList.add('active');
    }

    wrapper.addEventListener('click', function(e) {
      const tabBtn = e.target.closest('.tab-button');
      if (!tabBtn) return;

      const tabId = tabBtn.getAttribute('data-tab');
      switchTab(tabId);

      e.preventDefault();
      e.stopPropagation();
    });

    const hasActive = wrapper.querySelector('.tab-button.active');
    if (!hasActive && tabButtons.length > 0) {
      const firstTabId = tabButtons[0].getAttribute('data-tab');
      switchTab(firstTabId);
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initTabsStandalone);
} else {
  initTabsStandalone();
}
</script>`
    : '';

  const tableScript = hasTableComponents
    ? `<script>
// Table Sorting functionality
function initTableSortStandalone() {
  const tableWrappers = document.querySelectorAll('.table-wrapper');

  tableWrappers.forEach(wrapper => {
    const table = wrapper.querySelector('table');
    if (!table) return;

    const tbody = table.querySelector('tbody');
    if (!tbody) return;

    // Находим все заголовки с кнопками сортировки
    const ths = table.querySelectorAll('th');

    // Функция сравнения
    const compare = (rowA, rowB, index, asc) => {
      const cellA = rowA.children[index] ? rowA.children[index].textContent.trim() : '';
      const cellB = rowB.children[index] ? rowB.children[index].textContent.trim() : '';

      if (!cellA || !cellB) return 0;

      // Пытаемся распарсить как числа (удаляем валюту и пробелы)
      const numA = parseFloat(cellA.replace(/[^0-9.-]+/g,""));
      const numB = parseFloat(cellB.replace(/[^0-9.-]+/g,""));

      if (!isNaN(numA) && !isNaN(numB)) {
        return asc ? numA - numB : numB - numA;
      }

      // Иначе сравниваем как строки
      return asc ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
    };

    ths.forEach((th, index) => {
      const btn = th.querySelector('.sort-btn');
      if (!btn) return;

      // Удаляем старые листенеры через клонирование (на всякий случай)
      const newBtn = btn.cloneNode(true);
      btn.parentNode.replaceChild(newBtn, btn);

      newBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();

        // Сброс состояния других кнопок
        const allBtns = table.querySelectorAll('.sort-btn');
        allBtns.forEach(b => {
          if (b !== newBtn) {
            b.classList.remove('active', 'desc');
          }
        });

        // Переключение направления
        const isAsc = !newBtn.classList.contains('active') || newBtn.classList.contains('desc');

        newBtn.classList.add('active');
        if (isAsc) {
          newBtn.classList.remove('desc');
        } else {
          newBtn.classList.add('desc');
        }

        // Сортировка строк
        const rows = Array.from(tbody.querySelectorAll('tr'));
        rows.sort((a, b) => compare(a, b, index, isAsc));

        // Вставка отсортированных строк обратно в DOM
        rows.forEach(row => tbody.appendChild(row));
      });
    });
  });
}

// Запуск после загрузки DOM
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initTableSortStandalone);
} else {
  initTableSortStandalone();
}
</script>`
    : '';

  const passwordScript = hasPasswordComponent
    ? `<script>
(function() {
  function initPasswordToggles() {
    const containers = document.querySelectorAll('.password-input-container');
    if (!containers.length) return;
    containers.forEach(container => {
      const inputEl = container.querySelector('.password-input');
      const toggleEl = container.querySelector('.password-toggle');
      if (!inputEl || !toggleEl || toggleEl._passwordInit) return;
      toggleEl._passwordInit = true;
      if (container.hasAttribute('data-placeholder')) {
        inputEl.placeholder = container.getAttribute('data-placeholder') || '';
      }
      const footerEl = container.querySelector('.password-footer-link');
      if (footerEl && container.hasAttribute('data-footer-text')) {
        footerEl.textContent = container.getAttribute('data-footer-text') || '';
      }
      const iconEl = container.querySelector('.password-toggle-icon');
      if (iconEl && container.hasAttribute('data-select-image')) {
        iconEl.src = container.getAttribute('data-select-image') || iconEl.src;
      }
      if (container.hasAttribute('data-show-toggle')) {
        toggleEl.style.display = 'inline-block';
      } else {
        toggleEl.style.display = 'none';
      }
      toggleEl.addEventListener('click', () => {
        inputEl.type = inputEl.type === 'password' ? 'text' : 'password';
      });
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPasswordToggles);
  } else {
    initPasswordToggles();
  }
})();
</script>`
    : '';

  const textInputScript = hasTextInputComponent
    ? `<script>
(function() {
  function initTextInput() {
    const containers = document.querySelectorAll('.text-input-container');
    containers.forEach(container => {
      if (container._textInputInit) return;
      container._textInputInit = true;
      const toggleEl = container.querySelector('.text-input-toggle');
      if (!toggleEl) return;
      let inputEl = container.querySelector('.text-input, .text-input-multiline');
      if (!inputEl) return;
      const placeholder = container.getAttribute('data-placeholder') || inputEl.placeholder || 'Enter text';
      const iconSrc = container.getAttribute('data-selectimage');
      const iconEl = toggleEl.querySelector('.text-input-icon');
      if (iconEl && iconSrc) iconEl.src = iconSrc;
      function toggleInputType(e) {
        e.preventDefault();
        e.stopPropagation();
        const currentEl = container.querySelector('.text-input, .text-input-multiline');
        if (!currentEl) return;
        const isTextarea = currentEl.tagName === 'TEXTAREA';
        const newTag = isTextarea ? 'input' : 'textarea';
        const newClass = isTextarea ? 'text-input' : 'text-input-multiline';
        const newEl = document.createElement(newTag);
        newEl.className = newClass;
        newEl.id = currentEl.id;
        if (!isTextarea) { newEl.type = 'text'; }
        newEl.placeholder = placeholder;
        newEl.value = currentEl.value;
        newEl.style.cssText = currentEl.style.cssText;
        currentEl.replaceWith(newEl);
      }
      toggleEl.addEventListener('click', toggleInputType);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTextInput);
  } else {
    initTextInput();
  }
})();
</script>`
    : '';
  const chartScript = hasAnyChartComponents
    ? `<script>
(function() {
  // --- 1. LOADER ---
  const loadScripts = [{ src: 'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js', global: 'Chart', fallback: 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.3/chart.umd.min.js' }];
  let scriptsLoaded = false;
  const activePieCharts = new Map();

  function loadScript(s) {
    return new Promise((res, rej) => {
      if (window[s.global]) { res(); return; }
      const e = document.createElement('script');
      e.src = s.src; e.async = true;
      e.onload = () => res();
      e.onerror = () => {
        if (s.fallback) {
          e.src = s.fallback; e.onload = () => res();
          e.onerror = () => rej(new Error('Failed'));
          document.head.appendChild(e);
        } else { rej(new Error('Failed')); }
      };
      document.head.appendChild(e);
    });
  }

  function loadLibraries() {
    if (scriptsLoaded) return Promise.resolve();
    return Promise.all(loadScripts.map(loadScript)).then(() => { scriptsLoaded = true; });
  }

  // --- HELPER: DOMParser Decode ---
  function safeDecode(str) {
    if (!str) return '[]';
    try {
        const doc = new DOMParser().parseFromString(str, "text/html");
        return doc.documentElement.textContent;
    } catch (e) {
        console.error('Decode error', e);
        return '[]';
    }
  }

  // --- GENERIC POINT CLICK HANDLER ---
  function handlePointClick(event, chart, datasetIndex, index) {
    // Пример: вывести данные точки в консоль
    const label = chart.data.labels[index];
    const value = chart.data.datasets[datasetIndex].data[index];
    const color = chart.data.datasets[datasetIndex].backgroundColor[index] || chart.data.datasets[datasetIndex].backgroundColor;
    console.log('Point clicked:', { label, value, color, datasetIndex, index });
    // Здесь можно добавить свою логику
  }

  // --- INIT ---
  function initializeCharts() {
    loadLibraries().then(() => {
        setTimeout(() => {
            initChartComponents('chart');
            initBarChartComponents('bar-chart');
            initPieChartComponents('pie-chart-json');
        }, 100);
    }).catch(err => console.error('Failed to load Chart.js', err));
  }

  // --- GENERIC CHART INIT ---
  function initChartComponents(componentId) {
    const chartContainers = document.querySelectorAll('[data-component-id="' + componentId + '"]');
    chartContainers.forEach(container => {
      const canvas = container.querySelector('canvas');
      if (!canvas) return;

      const chartType = container.getAttribute('data-chart-type') || 'line';
      const title = container.getAttribute('data-title') || 'My Chart';
      const subTitle = container.getAttribute('data-sub-title') || 'Values';
      const infoText = container.getAttribute('data-info-text') || 'Total Balance';
      const chartDataAttr = container.getAttribute('data-chart-data');

      try {
        const chartData = JSON.parse(safeDecode(chartDataAttr));
        if (!chartData || !chartData.length) return;
        renderChart(canvas, chartData, chartType, title, subTitle, infoText, container);
      } catch (error) {
        console.error('[Chart] Error parsing data for ' + componentId, error);
      }
    });
  }

  // --- BAR CHART INIT ---
  function initBarChartComponents(componentId) {
    const chartContainers = document.querySelectorAll('[data-component-id="' + componentId + '"]');
    chartContainers.forEach(container => {
      const canvas = container.querySelector('canvas');
      if (!canvas) return;

      const chartType = container.getAttribute('data-chart-type') || 'bar';
      const title = container.getAttribute('data-title') || 'My Bar Chart';
      const subTitle = container.getAttribute('data-sub-title') || '';
      const chartDataAttr = container.getAttribute('data-chart-data');

      try {
        const chartData = JSON.parse(safeDecode(chartDataAttr));
        if (!chartData || !chartData.length) return;
        renderBarChart(canvas, chartData, chartType, title, subTitle, container);
      } catch (error) {
        console.error('[Bar Chart] Error parsing data', error);
      }
    });
  }

  // --- RENDER GENERIC CHART ---
  function renderChart(canvas, chartData, chartType, title, subTitle, infoText, container) {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    if (canvas.chartInstance) canvas.chartInstance.destroy();

    const validLayers = chartData.filter(l => l.points && l.points.length > 0);
    if (validLayers.length === 0) return;

    const isTableChart = chartType === 'main-text';

    if (isTableChart) {
        container.style.backgroundColor = 'transparent';
        container.style.border = 'none';
        container.style.boxShadow = 'none';
    } else {
        container.style.backgroundColor = '';
        container.style.border = '';
        container.style.boxShadow = '';
    }

    const style = getComputedStyle(container);
    const headerColor = style.getPropertyValue('--chart-header-color').trim() || '#ffffff';
    const headerSize = parseInt(style.getPropertyValue('--chart-header-size').trim() || '16', 10);
    const subHeaderColor = style.getPropertyValue('--chart-subheader-color').trim() || '#a0aec0';
    const subHeaderSize = parseInt(style.getPropertyValue('--chart-subheader-size').trim() || '14', 10);
    const gridColor = style.getPropertyValue('--chart-grid-color').trim() || '#ffffff';
    const gridSize = parseInt(style.getPropertyValue('--chart-grid-size').trim() || '12', 10);
    const infoColor = style.getPropertyValue('--chart-info-color').trim() || '#ffffff';
    const infoSize = parseInt(style.getPropertyValue('--chart-info-size').trim() || '24', 10);
    const infoWeight = style.getPropertyValue('--chart-info-weight').trim() || '700';

    const labels = validLayers[0].points.map(p => p.label);
    let jsChartType = 'line';
    if (chartType === 'bar-val') jsChartType = 'line';

    let totalSum = 0;
    if (chartType === 'bar-val') {
        validLayers.forEach(layer => { layer.points.forEach(p => { totalSum += (Number(p.value) || 0); }); });
        totalSum = totalSum.toLocaleString();
    }

    const datasets = validLayers.map(layer => {
        let backgroundColor = layer.color + '40'; let borderColor = layer.color;
        let borderWidth = 3; let pointRadius = 3; let fill = true; let tension = 0.4;

        if (chartType === 'line') {
            fill = false; backgroundColor = 'transparent'; tension = 0.4;
        }
        else if (chartType === 'bar-val') {
            fill = true; borderWidth = 0; pointRadius = 0; backgroundColor = layer.color + '80'; tension = 0.1;
        }
        else if (chartType === 'bar-bg' || chartType === 'main-text') {
            fill = true; borderWidth = 0; pointRadius = 0; backgroundColor = layer.color + '40'; tension = 0.4;
        }
        else if (chartType === 'table') {
            fill = true; borderWidth = 3; pointRadius = 3; tension = 0.4;
        }

        return {
            label: layer.name, data: layer.points.map(p => p.value),
            backgroundColor, borderColor, borderWidth, fill, tension, pointRadius,
            pointBackgroundColor: layer.points.map(p => p.color || layer.color),
            pointBorderColor: '#ffffff', pointBorderWidth: pointRadius > 0 ? 2 : 0, pointHoverRadius: pointRadius > 0 ? 6 : 0,
            originalBorderColor: borderColor, originalBackgroundColor: backgroundColor
        };
    });

    const showScales = chartType !== 'bar-bg' && chartType !== 'main-text';
    const showLegend = chartType !== 'table' && chartType !== 'main-text' && chartType !== 'bar-bg' && chartType !== 'bar-val';

    const totalLabelPlugin = {
        id: 'totalLabel',
        beforeDraw: (chart) => {
           if (chartType !== 'bar-val') return;
           const { ctx, width, height } = chart;
           ctx.save();
           const xPos = width / 2; const yPos = height / 2;
           ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
           ctx.fillStyle = subHeaderColor; ctx.font = 'normal 16px Montserrat, sans-serif'; ctx.fillText(infoText, xPos, yPos - 15);
           ctx.fillStyle = infoColor; ctx.font = infoWeight + ' ' + infoSize + 'px Montserrat, sans-serif'; ctx.fillText(totalSum, xPos, yPos + 15);
           ctx.restore();
        }
    };

    const config = {
        type: jsChartType, data: { labels, datasets }, plugins: [totalLabelPlugin],
        options: {
          responsive: true, maintainAspectRatio: false,
          layout: isTableChart ? { padding: 0 } : {},
          interaction: { mode: 'nearest', axis: 'xy', intersect: true },
          onHover: (event, activeElements, chart) => {
             if (chartType !== 'line') return;
             if (activeElements && activeElements.length > 0) {
                const activeDatasetIndex = activeElements[0].datasetIndex;
                chart.data.datasets.forEach((dataset, i) => {
                   if (i === activeDatasetIndex) { dataset.borderColor = dataset.originalBorderColor; dataset.borderWidth = 4; }
                   else { dataset.borderColor = dataset.originalBorderColor + '20'; dataset.borderWidth = 3; }
                });
             } else {
                chart.data.datasets.forEach(dataset => { dataset.borderColor = dataset.originalBorderColor; dataset.borderWidth = 3; });
             }
             chart.update('none');
          },
          onClick: (event, activeElements, chart) => {
             if (activeElements.length > 0) {
                 const index = activeElements[0].index;
                 const datasetIndex = activeElements[0].datasetIndex;
                 handlePointClick(event, chart, datasetIndex, index);
             }
          },
          plugins: {
            title: {
                display: !isTableChart,
                text: title, color: headerColor, font: { size: headerSize, weight: 'bold' }
            },
            legend: {
              display: showLegend, position: 'bottom', align: 'start',
              labels: { color: gridColor, usePointStyle: true, padding: 40, font: { size: gridSize },
                  generateLabels: function(chart) {
                      const originalLabels = Chart.defaults.plugins.legend.labels.generateLabels(chart);
                      return originalLabels.map(label => {
                          const dataset = chart.data.datasets[label.datasetIndex];
                          if(dataset && dataset.originalBorderColor) { label.fillStyle = dataset.originalBorderColor; label.strokeStyle = 'transparent'; }
                          return label;
                      });
                  }
              }
            }
          },
          scales: {
            x: {
                display: showScales,
                ticks: { color: gridColor, font: { size: gridSize } },
                grid: { display: false, color: '#FFFFFF26' }
            },
            y: {
              display: showScales,
              ticks: { color: gridColor, font: { size: gridSize }, stepSize: 10 },
              grid: { color: '#FFFFFF26', drawBorder: false },
              title: {
                  display: showScales && !!subTitle,
                  text: subTitle, color: subHeaderColor, font: { size: subHeaderSize, weight: 'normal' },
                  padding: { bottom: 10 }
              }
            }
          }
        }
    };

    if (isTableChart) {
        config.options.maintainAspectRatio = false;
    }

    try { canvas.chartInstance = new Chart(ctx, config); } catch (error) { console.error(error); }
  }


  // --- RENDER BAR CHART ---
  function renderBarChart(canvas, chartData, chartType, title, subTitle, container) {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    if (canvas.chartInstance) canvas.chartInstance.destroy();

    const validLayers = chartData.filter(l => l.points && l.points.length > 0);
    if (validLayers.length === 0) return;

    const isHorizontal = chartType === 'horizontal';
    const isStacked = chartType === 'bar-stacked';
    const isTableStyle = chartType === 'bar-table';

    if (isTableStyle) {
        container.style.backgroundColor = 'transparent';
        container.style.border = 'none';
        container.style.boxShadow = 'none';
    } else {
        container.style.backgroundColor = '';
        container.style.border = '';
        container.style.boxShadow = '';
    }

    const style = getComputedStyle(container);
    const headerColor = style.getPropertyValue('--chart-header-color').trim() || '#ffffff';
    const headerSize = parseInt(style.getPropertyValue('--chart-header-size').trim() || '16', 10);
    const subHeaderColor = style.getPropertyValue('--chart-subheader-color').trim() || '#a0aec0';
    const subHeaderSize = parseInt(style.getPropertyValue('--chart-subheader-size').trim() || '14', 10);
    const gridColor = style.getPropertyValue('--chart-grid-color').trim() || '#ffffff';
    const gridSize = parseInt(style.getPropertyValue('--chart-grid-size').trim() || '12', 10);

    const labels = validLayers[0].points.map(p => p.label);
    const datasets = validLayers.map(layer => ({
        label: layer.name,
        data: layer.points.map(p => p.value),
        backgroundColor: layer.points.map(p => (p.color || layer.color) + '80'),
        borderColor: layer.color,
        borderWidth: 0,
        borderRadius: 4,
        borderSkipped: false,
    }));

    const config = {
        type: 'bar', data: { labels, datasets },
        options: {
          responsive: true, maintainAspectRatio: false,
          indexAxis: isHorizontal ? 'y' : 'x',
          layout: isTableStyle ? { padding: 0 } : {},
          interaction: {
              mode: 'nearest',
              intersect: true,
              axis: isHorizontal ? 'y' : 'x'
          },
          onClick: (event, activeElements, chart) => {
             if (activeElements.length > 0) {
                 const index = activeElements[0].index;
                 const datasetIndex = activeElements[0].datasetIndex;
                 handlePointClick(event, chart, datasetIndex, index);
             }
          },
          plugins: {
            title: {
              display: !isTableStyle,
              text: title, color: headerColor, font: { size: headerSize, weight: 'bold' }
            },
            legend: {
              display: !isTableStyle,
              position: 'bottom', align: 'start',
              labels: { color: gridColor, usePointStyle: true, padding: 20, font: { size: gridSize } }
            },
            tooltip: {
                mode: isStacked ? 'index' : 'nearest',
                intersect: true,
                enabled: true
            }
          },
          scales: {
            x: {
              display: !isTableStyle,
              stacked: isStacked,
              ticks: { color: gridColor, font: { size: gridSize } },
              grid: { display: false, color: '#4a5568' }
            },
            y: {
              display: !isTableStyle,
              stacked: isStacked,
              ticks: { color: gridColor, font: { size: gridSize }, stepSize: 10 },
              grid: { color: '#4a5568', drawBorder: false },
              beginAtZero: true,
              title: {
                display: !isTableStyle && !!subTitle,
                text: subTitle, color: subHeaderColor,
                font: { size: subHeaderSize, weight: 'normal' }, padding: { bottom: 10 }
              }
            }
          },
          elements: { bar: { borderRadius: 4 } }
        }
    };

    if (isHorizontal && !isTableStyle) {
        config.options.scales.x.display = true; config.options.scales.y.display = true;
        config.options.scales.y.grid.display = false; config.options.scales.x.grid = { color: '#4a5568', drawBorder: false };
        config.options.scales.x.title = config.options.scales.y.title; config.options.scales.y.title = { display: false };
        config.options.scales.x.ticks = { color: gridColor, font: { size: gridSize }, stepSize: 10 };
    }

    if (isTableStyle) {
        config.options.maintainAspectRatio = false;
    }

    try { canvas.chartInstance = new Chart(ctx, config); } catch (error) { console.error(error); }
  }

  // --- PIE CHART INIT ---
  function initPieChartComponents(componentId) {
    const chartContainers = document.querySelectorAll('[data-component-id="' + componentId + '"]');
    chartContainers.forEach(container => {
      const chartType = container.getAttribute('data-chart-type') || 'doughnut';
      const title = container.getAttribute('data-title') || 'Browser Market Share';
      const subTitle = container.getAttribute('data-sub-title') || '';
      const chartDataAttr = container.getAttribute('data-chart-data');

      try {
        const chartData = JSON.parse(safeDecode(chartDataAttr));
        if (!chartData || !chartData.length) return;
        renderPieCharts(container, chartData, chartType, title, subTitle);
      } catch (error) {
        console.error('[Pie Chart] Error parsing data', error);
      }
    });
  }

  // --- RENDER PIE CHARTS ---
  function renderPieCharts(container, chartData, chartTypeRaw, globalTitle, globalSubTitle) {
    if (container._chartInstances) {
        container._chartInstances.forEach(i => i.destroy());
    }
    container._chartInstances = [];
    container.innerHTML = '';

    container.style.backgroundColor = 'transparent';
    container.style.border = 'none';
    container.style.boxShadow = 'none';

    let chartJsType = chartTypeRaw;
    let isTransparentStyle = false;

    if (chartTypeRaw === 'doughnut-transparent') {
        chartJsType = 'doughnut'; isTransparentStyle = true;
    } else if (chartTypeRaw === 'pie-transparent') {
        chartJsType = 'pie'; isTransparentStyle = true;
    }

    const style = getComputedStyle(container);
    const headerColor = style.getPropertyValue('--chart-header-color').trim() || '#ffffff';
    const headerSize = style.getPropertyValue('--chart-header-size').trim() || '16px';
    const subHeaderColor = style.getPropertyValue('--chart-subheader-color').trim() || '#a0aec0';
    const subHeaderSize = style.getPropertyValue('--chart-subheader-size').trim() || '14px';
    const legendColor = style.getPropertyValue('--chart-grid-color').trim() || '#ffffff';
    const legendSize = parseInt(style.getPropertyValue('--chart-grid-size').trim() || '12', 10);

    if (!isTransparentStyle) {
        const headerContainer = document.createElement('div');
        headerContainer.style.width = '100%';
        headerContainer.style.textAlign = 'center';
        headerContainer.style.marginBottom = '20px';

        if (globalTitle) {
            const h2 = document.createElement('h2');
            h2.textContent = globalTitle;
            h2.style.color = headerColor;
            h2.style.fontSize = headerSize;
            h2.style.margin = '0 0 5px 0';
            h2.style.fontWeight = 'bold';
            headerContainer.appendChild(h2);
        }
        if (globalSubTitle) {
            const h4 = document.createElement('h4');
            h4.textContent = globalSubTitle;
            h4.style.color = subHeaderColor;
            h4.style.fontSize = subHeaderSize;
            h4.style.margin = '0';
            h4.style.fontWeight = 'normal';
            headerContainer.appendChild(h4);
        }
        container.appendChild(headerContainer);
    }

    const chartsGrid = document.createElement('div');
    chartsGrid.style.display = 'flex';
    chartsGrid.style.flexWrap = 'wrap';
    chartsGrid.style.justifyContent = 'center';
    chartsGrid.style.gap = '20px';
    chartsGrid.style.width = '100%';
    container.appendChild(chartsGrid);

    const validLayers = chartData.filter(l => l.points && l.points.length > 0);
    if (validLayers.length === 0) return;

    const outerLabelsPlugin = {
      id: 'outerLabels',
      afterDatasetsDraw: (chart) => {
        const { ctx, chartArea: { top, bottom, left, right } } = chart;
        chart.data.datasets.forEach((dataset, i) => {
          const meta = chart.getDatasetMeta(i);
          if (meta.hidden) return;
          const centerX = (left + right) / 2;
          const centerY = (top + bottom) / 2;
          let total = 0; dataset.data.forEach(val => total += val);

          meta.data.forEach((element, index) => {
            const value = dataset.data[index];
            if (!value) return;
            const label = chart.data.labels[index];
            const percentage = Math.round((value / total) * 100) + '%';
            const color = element.options.backgroundColor;

            const outerRadius = element.outerRadius;
            const angle = element.startAngle + (element.endAngle - element.startAngle) / 2;
            const lineStartOffset = 5; const lineLength = 20; const lineBend = 15;
            const startX = centerX + Math.cos(angle) * (outerRadius + lineStartOffset);
            const startY = centerY + Math.sin(angle) * (outerRadius + lineStartOffset);
            const midX = centerX + Math.cos(angle) * (outerRadius + lineStartOffset + lineLength);
            const midY = centerY + Math.sin(angle) * (outerRadius + lineStartOffset + lineLength);
            const alignLeft = midX < centerX;
            const endX = alignLeft ? midX - lineBend : midX + lineBend;
            const endY = midY;

            ctx.save();
            ctx.beginPath(); ctx.moveTo(startX, startY); ctx.lineTo(midX, midY); ctx.lineTo(endX, endY);
            ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.font = 'bold 11px Montserrat, sans-serif'; ctx.fillStyle = '#ffffff';
            ctx.textBaseline = 'middle'; ctx.textAlign = alignLeft ? 'right' : 'left';
            const textX = alignLeft ? endX - 8 : endX + 8;
            ctx.fillText(label + ' ' + percentage, textX, endY);
            ctx.restore();
          });
        });
      }
    };

    validLayers.forEach((layer) => {
        const chartBox = document.createElement('div');
        chartBox.className = 'single-chart-box';
        chartBox.style.flex = '1 1 300px';
        chartBox.style.minWidth = '280px';
        chartBox.style.maxWidth = '600px';
        chartBox.style.position = 'relative';

        const canvas = document.createElement('canvas');
        canvas.style.width = '100%';
        canvas.style.height = 'auto';
        canvas.style.minHeight = '350px';
        chartBox.appendChild(canvas);
        chartsGrid.appendChild(chartBox);

        const ctx = canvas.getContext('2d');
        const labels = layer.points.map(p => p.label);

        const borderWidth = isTransparentStyle ? 0 : 2;
        const borderColor = isTransparentStyle ? 'transparent' : '#10161C';
        const hoverOffset = isTransparentStyle ? 8 : 4;

        const dataset = {
            label: layer.name,
            data: layer.points.map(p => p.value),
            backgroundColor: layer.points.map(p => p.color || layer.color),
            borderColor: borderColor, borderWidth: borderWidth, hoverOffset: hoverOffset, spacing: 0
        };

        const pluginsList = isTransparentStyle ? [] : [outerLabelsPlugin];
        const layoutPadding = isTransparentStyle
            ? { top: 10, bottom: 10, left: 10, right: 10 }
            : { top: 30, bottom: 30, left: 60, right: 60 };

        const config = {
            type: chartJsType, data: { labels, datasets: [dataset] }, plugins: pluginsList,
            options: {
              responsive: true, maintainAspectRatio: false,
              layout: { padding: layoutPadding },
              cutout: (chartJsType === 'doughnut') ? (isTransparentStyle ? '75%' : '50%') : undefined,
              onClick: (event, activeElements, chart) => {
                 if (activeElements.length > 0) {
                     const index = activeElements[0].index;
                     const datasetIndex = activeElements[0].datasetIndex;
                     handlePointClick(event, chart, datasetIndex, index);
                 }
              },
              plugins: {
                title: {
                    display: !isTransparentStyle && validLayers.length > 1,
                    text: layer.name, color: headerColor, font: { size: 14, weight: 'bold' }, padding: { bottom: 10 }
                },
                subtitle: { display: false },
                legend: {
                    display: !isTransparentStyle, position: 'bottom', align: 'center',
                    labels: { color: legendColor, usePointStyle: true, padding: 20, font: { size: legendSize } }
                },
                tooltip: {
                    enabled: true,
                    callbacks: { label: function(c) { return (c.label || '') + ': ' + c.parsed; } }
                }
              }
            }
        };

        try {
            const newChart = new Chart(ctx, config);
            container._chartInstances.push(newChart);
        } catch (error) { console.error(error); }
    });
  }
  window.renderChart = renderChart;
  window.renderBarChart = renderBarChart;
  window.renderPieCharts = renderPieCharts;
  window.initChartComponents = initChartComponents;
  window.initBarChartComponents = initBarChartComponents;
  window.initPieChartComponents = initPieChartComponents;
  window.safeDecode = safeDecode;

  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initializeCharts); }
  else { initializeCharts(); }
})();
</script>`
    : '';

  const cleanedBody = bodyContent
    .replace(/<script>[\s\S]*?var props = \{[\s\S]*?\};[\s\S]*?<\/script>/g, '')
    .replace(/\(function initLabelScript[\s\S]*?\}\(props\[el\.id\]\);/g, '');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${name}</title>
  <link rel="stylesheet" href="${finalCssFileName}">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
</head>
<body>
${cleanedBody}

<!-- Component Scripts -->
${chartScript}
${tabsScript}
${passwordScript}
${textInputScript}
${numberScript}
${tableScript}

<!-- WZ Integration -->
<script src="wz.js"></script>
<script src="${finalJsFileName}"></script>

<script>
  console.log('🎬 [HTML] Page loaded: ${name}');
  console.log('📅 [HTML] Timestamp:', new Date().toISOString());

  if (typeof window.WZ !== 'undefined') {
    console.log('✅ [HTML] WZ library available');
  } else {
    console.warn('⚠️ [HTML] WZ library NOT available');
  }

  window.addEventListener('message', function(event) {
    if (event.data?.type === 'INJECT_WZ_JS' && event.data?.wzJsUrl) {
      if (document.querySelector('script[src*="wz.js"]')) {
        console.log('⚠️ [HTML] wz.js already loaded');
        return;
      }

      const script = document.createElement('script');
      script.src = event.data.wzJsUrl;
      script.async = false;

      script.onload = () => {
        console.log('✅ [HTML] wz.js loaded via injection');
        if (typeof window.WZ !== 'undefined') {
          window.dispatchEvent(new CustomEvent('wz-ready'));
        }
      };

      script.onerror = (error) => {
        console.error('❌ [HTML] Failed to load wz.js:', error);
      };

      document.head.appendChild(script);
    }
  });

</script>
</body>
</html>`;
}

export function hasChartComponents(canvasComponents: CanvasComponent[]): {
  hasAny: boolean;
  hasChart: boolean;
  hasBarChart: boolean;
  hasPieChart: boolean;
} {
  const hasChart = canvasComponents.some(
    (comp) => comp.componentId === 'chart'
  );
  const hasBarChart = canvasComponents.some(
    (comp) => comp.componentId === 'bar-chart'
  );
  const hasPieChart = canvasComponents.some(
    (comp) => comp.componentId === 'pie-chart-json'
  );
  const hasAny = hasChart || hasBarChart || hasPieChart;

  return { hasAny, hasChart, hasBarChart, hasPieChart };
}
