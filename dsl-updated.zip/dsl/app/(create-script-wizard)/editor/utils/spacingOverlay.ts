import type { Component, Editor } from 'grapesjs';
import { components } from '../../data/elements';

const OVERLAY_ID = 'gjs-distance-overlay';
const STYLE_ID = 'gjs-distance-overlay-style';

type Rect = {
  left: number;
  top: number;
  right: number;
  bottom: number;
  width: number;
  height: number;
};

type Neighbor = {
  dist: number;
  from: number;
  to: number;
  crossStart: number;
  crossEnd: number;
};

function toRect(el: HTMLElement): Rect {
  const r = el.getBoundingClientRect();
  return {
    left: r.left,
    top: r.top,
    right: r.right,
    bottom: r.bottom,
    width: r.width,
    height: r.height
  };
}

function overlap(a1: number, a2: number, b1: number, b2: number) {
  return Math.min(a2, b2) - Math.max(a1, b1);
}

function resolveEl(editor: Editor, selected: Component) {
  let el = selected.getEl?.() as HTMLElement | undefined | null;
  if (!el || el.nodeType !== 1) return null;

  const config = components.find((c) => c.type === selected.get('type'));
  const targetSelector = config?.styleConfig?.target;
  if (targetSelector && !el.matches?.(targetSelector)) {
    const nested = el.querySelector(targetSelector) as HTMLElement | null;
    if (nested) el = nested;
  }
  return el;
}

function collectNeighborEls(editor: Editor, selected: Component, selectedEl: HTMLElement) {
  const wrapper = editor.getWrapper();
  if (!wrapper) return [] as HTMLElement[];

  const selectedIds = new Set<string>([selected.getId()]);
  selected.find('*').forEach((child) => selectedIds.add(child.getId()));

  const result: HTMLElement[] = [];

  const walk = (cmp: Component) => {
    cmp.components().forEach((child: Component) => {
      if (selectedIds.has(child.getId())) {
        walk(child);
        return;
      }
      if (child.is?.('wrapper') || child.get('type') === 'wrapper') {
        walk(child);
        return;
      }

      const el = child.getEl?.() as HTMLElement | undefined | null;
      if (el && el !== selectedEl && el.nodeType === 1) {
        const rect = el.getBoundingClientRect();
        if (rect.width >= 2 && rect.height >= 2) {
          result.push(el);
        }
      }
      walk(child);
    });
  };

  walk(wrapper);
  return result;
}

function findNeighbors(selected: Rect, others: Rect[]) {
  let left: Neighbor | null = null;
  let right: Neighbor | null = null;
  let top: Neighbor | null = null;
  let bottom: Neighbor | null = null;

  for (const other of others) {
    const vOverlap = overlap(selected.top, selected.bottom, other.top, other.bottom);
    const hOverlap = overlap(selected.left, selected.right, other.left, other.right);

    if (vOverlap > 0 && other.right <= selected.left + 0.5) {
      const dist = selected.left - other.right;
      if (dist >= 0 && (!left || dist < left.dist)) {
        left = {
          dist,
          from: other.right,
          to: selected.left,
          crossStart: Math.max(selected.top, other.top),
          crossEnd: Math.min(selected.bottom, other.bottom)
        };
      }
    }

    if (vOverlap > 0 && other.left >= selected.right - 0.5) {
      const dist = other.left - selected.right;
      if (dist >= 0 && (!right || dist < right.dist)) {
        right = {
          dist,
          from: selected.right,
          to: other.left,
          crossStart: Math.max(selected.top, other.top),
          crossEnd: Math.min(selected.bottom, other.bottom)
        };
      }
    }

    if (hOverlap > 0 && other.bottom <= selected.top + 0.5) {
      const dist = selected.top - other.bottom;
      if (dist >= 0 && (!top || dist < top.dist)) {
        top = {
          dist,
          from: other.bottom,
          to: selected.top,
          crossStart: Math.max(selected.left, other.left),
          crossEnd: Math.min(selected.right, other.right)
        };
      }
    }

    if (hOverlap > 0 && other.top >= selected.bottom - 0.5) {
      const dist = other.top - selected.bottom;
      if (dist >= 0 && (!bottom || dist < bottom.dist)) {
        bottom = {
          dist,
          from: selected.bottom,
          to: other.top,
          crossStart: Math.max(selected.left, other.left),
          crossEnd: Math.min(selected.right, other.right)
        };
      }
    }
  }

  return { left, right, top, bottom };
}

function lineHtml(axis: 'x' | 'y', n: Neighbor) {
  const px = Math.round(n.dist);
  if (px < 1) return '';

  const midCross = (n.crossStart + n.crossEnd) / 2;
  const color = '#fa000e';

  if (axis === 'x') {
    return `
      <div data-dist="x" style="
        position:fixed;left:${n.from}px;top:${midCross}px;width:${n.dist}px;height:0;
        border-top:1px solid ${color};pointer-events:none;z-index:2147483646;
      ">
        <span style="
          position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);
          background:${color};color:#fff;font:11px/1 monospace;
          padding:2px 5px;border-radius:2px;white-space:nowrap;
        ">${px}px</span>
      </div>`;
  }

  return `
    <div data-dist="y" style="
      position:fixed;left:${midCross}px;top:${n.from}px;width:0;height:${n.dist}px;
      border-left:1px solid ${color};pointer-events:none;z-index:2147483646;
    ">
      <span style="
        position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);
        background:${color};color:#fff;font:11px/1 monospace;
        padding:2px 5px;border-radius:2px;white-space:nowrap;
      ">${px}px</span>
    </div>`;
}

function ensureOverlayRoot(doc: Document, body: HTMLElement) {
  let styleEl = doc.getElementById(STYLE_ID) as HTMLStyleElement | null;
  if (!styleEl) {
    styleEl = doc.createElement('style');
    styleEl.id = STYLE_ID;
    styleEl.textContent = `
      #${OVERLAY_ID} {
        position: fixed;
        inset: 0;
        width: 100%;
        height: 100%;
        overflow: visible;
        pointer-events: none;
        z-index: 2147483646;
      }
    `;
    doc.head.appendChild(styleEl);
  }

  let root = doc.getElementById(OVERLAY_ID);
  if (!root) {
    root = doc.createElement('div');
    root.id = OVERLAY_ID;
    body.appendChild(root);
  } else if (root.parentElement !== body) {
    body.appendChild(root);
  }
  return root;
}

export function clearSpacingOverlay(editor: Editor) {
  try {
    const doc = editor.Canvas.getDocument();
    doc?.getElementById(OVERLAY_ID)?.remove();
    doc?.getElementById('gjs-mp-overlay')?.remove();
  } catch {
    return;
  }
}

export function isOffsetsEnabled(editor: Editor) {
  const config = editor.getConfig() as {
    showOffsets?: boolean;
    showOffsetsSelected?: boolean;
  };
  return config.showOffsets !== false && config.showOffsetsSelected !== false;
}

export function updateSpacingOverlay(editor: Editor) {
  try {
    const doc = editor.Canvas.getDocument();
    const body = editor.Canvas.getBody();
    if (!doc || !body) return;

    if (!isOffsetsEnabled(editor)) {
      clearSpacingOverlay(editor);
      return;
    }

    const selected = editor.getSelected();
    if (
      !selected ||
      selected.is?.('wrapper') ||
      selected.get('type') === 'wrapper'
    ) {
      clearSpacingOverlay(editor);
      return;
    }

    const selectedEl = resolveEl(editor, selected);
    if (!selectedEl) {
      return;
    }

    const selectedRect = toRect(selectedEl);
    if (selectedRect.width < 2 || selectedRect.height < 2) {
      return;
    }

    const neighborRects = collectNeighborEls(editor, selected, selectedEl).map(toRect);
    const { left, right, top, bottom } = findNeighbors(selectedRect, neighborRects);

    const parts = [
      left ? lineHtml('x', left) : '',
      right ? lineHtml('x', right) : '',
      top ? lineHtml('y', top) : '',
      bottom ? lineHtml('y', bottom) : ''
    ].filter(Boolean);

    const root = ensureOverlayRoot(doc, body);
    if (!parts.length) {
      root.innerHTML = '';
      return;
    }
    root.innerHTML = parts.join('');
  } catch {
    return;
  }
}

const rafByEditor = new WeakMap<object, number>();
const settleByEditor = new WeakMap<object, ReturnType<typeof setTimeout>>();

export function scheduleSpacingOverlay(editor: Editor) {
  const key = editor as object;
  const prev = rafByEditor.get(key);
  if (prev) cancelAnimationFrame(prev);

  const id = requestAnimationFrame(() => {
    rafByEditor.delete(key);
    updateSpacingOverlay(editor);
  });
  rafByEditor.set(key, id);
}

export function scheduleSpacingOverlaySettle(editor: Editor) {
  scheduleSpacingOverlay(editor);

  const key = editor as object;
  const prev = settleByEditor.get(key);
  if (prev) clearTimeout(prev);

  const t = setTimeout(() => {
    settleByEditor.delete(key);
    requestAnimationFrame(() => updateSpacingOverlay(editor));
  }, 0);
  settleByEditor.set(key, t);
}

const SPACING_LIVE_EVENTS = [
  'component:selected',
  'component:styleUpdate',
  'component:update',
  'component:drag',
  'component:resize',
  'component:resize:move',
  'component:resize:update',
  'style:property:update',
  'canvas:move',
  'canvas:zoom',
  'canvas:coords',
  'canvas:update',
  'dmode:move',
  'frame:scroll'
] as const;

const SPACING_SETTLE_EVENTS = [
  'component:drag:end',
  'component:resize:end',
  'canvas:move:end',
  'dmode:end'
] as const;

export function bindSpacingOverlay(editor: Editor) {
  const onLive = () => scheduleSpacingOverlay(editor);
  const onSettle = () => scheduleSpacingOverlaySettle(editor);
  const onDeselect = () => clearSpacingOverlay(editor);

  SPACING_LIVE_EVENTS.forEach((ev) => editor.on(ev, onLive));
  SPACING_SETTLE_EVENTS.forEach((ev) => editor.on(ev, onSettle));
  editor.on('component:deselected', onDeselect);

  return () => {
    SPACING_LIVE_EVENTS.forEach((ev) => editor.off(ev, onLive));
    SPACING_SETTLE_EVENTS.forEach((ev) => editor.off(ev, onSettle));
    editor.off('component:deselected', onDeselect);

    const key = editor as object;
    const raf = rafByEditor.get(key);
    if (raf) cancelAnimationFrame(raf);
    rafByEditor.delete(key);
    const settle = settleByEditor.get(key);
    if (settle) clearTimeout(settle);
    settleByEditor.delete(key);
  };
}
