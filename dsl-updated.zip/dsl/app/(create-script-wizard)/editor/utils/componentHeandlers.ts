export const HANDLER_TEMPLATES = {
  container: `function(element, data, config) {
  if (!element || !data) return;

  if (element.hasAttribute('data-cloned-from')) {
      // console.log('🛑 [Container] Skip: element is a clone');
      return;
  }

  // console.log('📦 [Container] Init Repeater for', data.length, 'rows');

  var parent = element.parentElement;
  var templateId = element.getAttribute('data-template-id') || element.id;
  if (!element.id) element.id = templateId;

  // Очистка старых клонов
  var existingClones = parent.querySelectorAll('[data-cloned-from="' + templateId + '"]');
  existingClones.forEach(function(el) {
    var canvases = el.querySelectorAll('canvas');
    canvases.forEach(function(canvas) {
      if (canvas.chartInstance) {
        canvas.chartInstance.destroy();
        canvas.chartInstance = null;
      }
    });
    el.remove();
  });

  if (data.length === 0) {
      element.style.display = 'none';
      return;
  }

  var originalDisplay = window.getComputedStyle(element).display;
  if (originalDisplay === 'none') {
      originalDisplay = 'flex';
  }

  element.style.display = 'none';
  element.setAttribute('data-is-template', 'true');
  element.setAttribute('data-template-id', templateId);

  var fragment = document.createDocumentFragment();

  data.forEach(function(row, index) {
      var clone = element.cloneNode(true);

      clone.removeAttribute('id');
      clone.removeAttribute('data-is-template');
      clone.removeAttribute('data-template-id');
      clone.setAttribute('data-cloned-from', templateId);
      clone.setAttribute('data-row-index', index);

      var cloneId = templateId + '-row-' + index;
      clone.id = cloneId;
      clone.setAttribute('data-component-id', cloneId);

      copyAllStylesDeep(element, clone);
      clone.style.setProperty('display', originalDisplay, 'important');

      var originalWalker = document.createTreeWalker(
          element,
          NodeFilter.SHOW_ELEMENT,
          null,
          false
      );

      var cloneWalker = document.createTreeWalker(
          clone,
          NodeFilter.SHOW_ELEMENT,
          null,
          false
      );

      var originalNode;
      var cloneNode;

      while (originalNode = originalWalker.nextNode()) {
          cloneNode = cloneWalker.nextNode();

          if (originalNode && cloneNode && originalNode.id) {
              var componentType = originalNode.getAttribute('data-component-type');
              if (componentType) {
                  cloneNode.setAttribute('data-original-id', originalNode.id);
                  cloneNode.setAttribute('data-row-index', index);

                  if (cloneNode.tagName === 'CANVAS') {
                      var uniqueId = 'chart-clone-' + templateId + '-row-' + index + '-' + Date.now();
                      cloneNode.id = uniqueId;
                      cloneNode.removeAttribute('data-is-template');

                      if (cloneNode.chartInstance) {
                          cloneNode.chartInstance.destroy();
                          cloneNode.chartInstance = null;
                      }
                  } else {
                      // Генерируем уникальный ID для дочерних компонентов, чтобы избежать конфликтов
                      var newId = (originalNode.id || componentType) + '-row-' + index;
                      cloneNode.id = newId;
                  }
              }
          }
      }

      var childrenWithId = clone.querySelectorAll('[id]');
      childrenWithId.forEach(function(child) {
          if (child.tagName !== 'CANVAS' && !child.hasAttribute('data-component-type')) {
              child.removeAttribute('id');
          }
          if (child.hasAttribute('data-template-id')) {
              child.removeAttribute('data-template-id');
          }
      });

      fragment.appendChild(clone);
  });

  parent.insertBefore(fragment, element);

  // Инициализация событий
  setTimeout(function() {
      var allClones = parent.querySelectorAll('[data-cloned-from="' + templateId + '"]');

      allClones.forEach(function(cloneEl, idx) {

          if (typeof setupComponentEvents === 'function') {
              setupComponentEvents(cloneEl, 'container', cloneEl.id);

              var interactiveChildren = cloneEl.querySelectorAll('[data-component-type]');
              interactiveChildren.forEach(function(child) {
                  var cType = child.getAttribute('data-component-type');
                  setupComponentEvents(child, cType, child.id);
              });
          }

          // Charts re-init
          var chartContainers = cloneEl.querySelectorAll('[data-component-type="chart"]');
          chartContainers.forEach(function(chartContainer) {
              var canvas = chartContainer.querySelector('canvas');
              if (canvas) {
                  if (canvas.chartInstance) {
                      canvas.chartInstance.destroy();
                      canvas.chartInstance = null;
                  }

                  if (typeof window.initChartComponents === 'function') {
                      window.initChartComponents('chart');
                  } else if (typeof window.initChart === 'function') {
                      window.initChart(canvas);
                  }
              }
          });

          // Table re-init
          var tableContainers = cloneEl.querySelectorAll('[data-component-type="wz-table"], [data-component-type="table"], .table-wrapper');
          tableContainers.forEach(function(tableContainer) {
              if (typeof initTableSortStandalone === 'function') {
                  initTableSortStandalone();
              }
          });
      });
  }, 300);
}`,

  'label-text': `function(element, data, config) {
  if (!element || !data || data.length === 0) return;
  if (element.closest('[data-cloned-from]')) return;

  var parentContainer = element.closest('[data-component-type="container"]');

  // Функция для обработки клика и перехода между дашбордами
  function attachDashboardAction(el, originalId) {
    var actions = componentsWithActions[originalId];
    if (!actions) return;

    var actionInfo = actions.find(function(a) { return a.wzComp.action === 'OPEN_DASHBOARD'; });
    if (!actionInfo) return;

    // Делаем текст визуально кликабельным
    el.style.cursor = 'pointer';

    // Очищаем старые слушатели через клонирование (если это не ломает верстку)
    // Либо просто добавляем слушатель, если мы уверены, что el — новый клон
    el.onclick = function(e) {
      e.stopPropagation();
      console.log('🖱️ Label clicked:', originalId);

      if (window.WZ && typeof window.WZ.sendOpenDashboard === 'function') {
        var mappingValues = [];
        var params = actionInfo.wzComp.parameters || [];

        params.forEach(function(param) {
          var colName = param.columnName;
          // Ищем в dataset по точному имени колонки или в data-value
          var value = el.dataset[colName] || el.getAttribute('data-value');

          if (value !== undefined && value !== null) {
            mappingValues.push({
              dashboardParameterId: param.dashboardParameterId,
              columnName: colName,
              mappingValueString: String(value)
            });
          }
        });

        console.log('🚀 Label: Opening dashboard with values:', mappingValues);
        window.WZ.sendOpenDashboard(
          actionInfo.wzComp.targetId,
          'OPEN_DASHBOARD',
          mappingValues
        );
      }
    };
  }

  if (parentContainer) {
    var containerId = parentContainer.id;
    var elementId = element.id;

    waitForContainer(containerId, function() {
      var componentType = element.getAttribute('data-component-type') || 'label-text';
      var repeaterItems = document.querySelectorAll('[data-cloned-from="' + (parentContainer.getAttribute('data-template-id') || containerId) + '"] [data-component-type="' + componentType + '"][data-original-id="' + elementId + '"]');

      if (repeaterItems.length > 0) {
        repeaterItems.forEach(function(item) {
          var container = item.closest('[data-row-index]');
          if (container) {
            var index = parseInt(container.getAttribute('data-row-index'));
            if (data[index] !== undefined) {
              var val = Array.isArray(data[index]) ? data[index][0] : data[index];
              var textVal = val != null ? String(val) : '';
              item.textContent = textVal;

              item.setAttribute('data-value', textVal);
              if (config && config.columnName) {
                item.dataset[config.columnName] = textVal;
              }

              attachDashboardAction(item, elementId);
            }
          }
        });
        return;
      }
      processLabelStandard(element, data, config);
    });
  } else {
    processLabelStandard(element, data, config);
  }

  function processLabelStandard(element, data, config) {
    var container = element.parentElement;
    var isOriginal = !element.hasAttribute('data-cloned');
    var elementId = element.id;

    if (isOriginal && data.length > 1) {
      var existingClones = container.querySelectorAll('[data-cloned="true"]');
      existingClones.forEach(function(clone) { clone.remove(); });

      var originalDisplay = window.getComputedStyle(element).display;
      if (originalDisplay === 'none') originalDisplay = 'inline-flex';

      data.forEach(function(row, index) {
        var val = Array.isArray(row) ? row[0] : row;
        var textVal = val != null ? String(val) : '';
        var clone = element.cloneNode(true);
        clone.setAttribute('data-cloned', 'true');
        clone.setAttribute('data-row-index', index);
        clone.removeAttribute('id');

        copyAllStylesDeep(element, clone);
        clone.style.setProperty('display', originalDisplay, 'important');
        clone.textContent = textVal;

        clone.setAttribute('data-value', textVal);
        if (config && config.columnName) {
          clone.dataset[config.columnName] = textVal;
        }

        container.insertBefore(clone, element.nextSibling);
        attachDashboardAction(clone, elementId);

        if (typeof setupComponentEvents === 'function') setupComponentEvents(clone, 'label-text');
      });

      element.style.display = 'none';
      element.setAttribute('data-template', 'true');
    } else if (isOriginal && data.length === 1) {
      element.style.display = '';
      element.removeAttribute('data-template');
      var val = Array.isArray(data[0]) ? data[0][0] : data[0];
      var textVal = val != null ? String(val) : '';
      element.textContent = textVal;

      element.setAttribute('data-value', textVal);
      if (config && config.columnName) {
        element.dataset[config.columnName] = textVal;
      }

      attachDashboardAction(element, elementId);
    }
  }
}`,

  'text-input': `function(element, data, config) {
    if (!element || !data || data.length === 0) return;

    if (element.closest('[data-cloned-from]')) return;

    var parentContainer = element.closest('[data-component-type="container"]');

    if (parentContainer) {
        var containerId = parentContainer.id;
        var elementId = element.id;

        waitForContainer(containerId, function() {
            var componentType = element.getAttribute('data-component-type') || 'text-input';
            var repeaterItems = document.querySelectorAll('[data-cloned-from] [data-component-type="' + componentType + '"][data-original-id="' + elementId + '"]');

            if (repeaterItems.length > 0) {
                repeaterItems.forEach(function(item) {
                    var container = item.closest('[data-row-index]');
                    if (container) {
                        var index = parseInt(container.getAttribute('data-row-index'));
                        if (data[index] !== undefined) {
                            var val = Array.isArray(data[index]) ? data[index][0] : data[index];
                            var textVal = val != null ? String(val) : '';
                            var inputEl = item.querySelector('input, textarea');
                            if (inputEl) {
                                inputEl.value = textVal;
                                // [TRANSITION DATA]
                                inputEl.setAttribute('data-value', textVal);
                                if (config && config.columnName) {
                                    var safeKey = config.columnName.replace(/[^a-zA-Z0-9_-]/g, '');
                                    inputEl.setAttribute('data-' + safeKey, textVal);
                                    if (inputEl.dataset) inputEl.dataset[safeKey] = textVal;
                                }
                            }
                        }
                    }
                });
                return;
            }
            processInputStandard(element, data, config);
        });
    } else {
        processInputStandard(element, data, config);
    }

    function processInputStandard(element, data, config) {
        var container = element.parentElement;
        var isOriginal = !element.hasAttribute('data-cloned');

        if (isOriginal && data.length > 1) {
          var existingClones = container.querySelectorAll('[data-cloned="true"]');
          existingClones.forEach(function(clone) { clone.remove(); });

          var originalDisplay = window.getComputedStyle(element).display;
          if (originalDisplay === 'none') originalDisplay = 'block';

          var clones = [];
          data.forEach(function(row, index) {
            var val = Array.isArray(row) ? row[0] : row;
            var textVal = val != null ? String(val) : '';
            var clone = element.cloneNode(true);
            clone.setAttribute('data-cloned', 'true');
            clone.setAttribute('data-row-index', index);
            clone.removeAttribute('id');

            copyAllStylesDeep(element, clone);
            clone.style.setProperty('display', originalDisplay, 'important');

            var inputEl = clone.querySelector('input, textarea');
            if (inputEl) {
              inputEl.value = textVal;
              inputEl.removeAttribute('id');
              // [TRANSITION DATA]
              inputEl.setAttribute('data-value', textVal);
              if (config && config.columnName) {
                  var safeKey = config.columnName.replace(/[^a-zA-Z0-9_-]/g, '');
                  inputEl.setAttribute('data-' + safeKey, textVal);
                  if (inputEl.dataset) inputEl.dataset[safeKey] = textVal;
              }
            }
            clones.push(clone);
          });

          element.style.display = 'none';
          element.setAttribute('data-template', 'true');
          clones.forEach(function(clone) {
            container.insertBefore(clone, element.nextSibling);
            if (typeof setupComponentEvents === 'function') setupComponentEvents(clone, 'text-input');
          });
        } else if (isOriginal && data.length === 1) {
          element.style.display = '';
          element.removeAttribute('data-template');
          var val = Array.isArray(data[0]) ? data[0][0] : data[0];
          var textVal = val != null ? String(val) : '';
          var inputEl = element.querySelector('input, textarea');
          if (inputEl) {
             inputEl.value = textVal;
             // [TRANSITION DATA]
             inputEl.setAttribute('data-value', textVal);
             if (config && config.columnName) {
                 var safeKey = config.columnName.replace(/[^a-zA-Z0-9_-]/g, '');
                 inputEl.setAttribute('data-' + safeKey, textVal);
                 if (inputEl.dataset) inputEl.dataset[safeKey] = textVal;
             }
          }
        }
    }
  }`,

  'custom-button': `function(element, data, config) {
  if (!element || !data || data.length === 0) return;
  if (element.closest('[data-cloned-from]')) return;

  var parentContainer = element.closest('[data-component-type="container"]');
  var numColumns = Array.isArray(data[0]) ? data[0].length : 1;

  function attachDashboardAction(btn, originalId) {
    var newBtn = btn.cloneNode(true);
    if (btn.parentNode) btn.parentNode.replaceChild(newBtn, btn);

    newBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      var actions = componentsWithActions[originalId];
      if (!actions) return;

      var actionInfo = actions.find(function(a) { return a.wzComp.action === 'OPEN_DASHBOARD'; });

      if (actionInfo && window.WZ && typeof window.WZ.sendOpenDashboard === 'function') {
        var mappingValues = [];
        var params = actionInfo.wzComp.parameters || [];

        params.forEach(function(param) {
          var colName = param.columnName;
          var value = newBtn.dataset[colName] || newBtn.getAttribute('data-value');

          if (value !== undefined && value !== null) {
            mappingValues.push({
              dashboardParameterId: param.dashboardParameterId,
              columnName: colName,
              mappingValueString: String(value)
            });
          }
        });

        window.WZ.sendOpenDashboard(
          actionInfo.wzComp.targetId,
          'OPEN_DASHBOARD',
          mappingValues
        );
      }
    });
    return newBtn;
  }

  if (parentContainer) {
    var containerId = parentContainer.id;
    var elementId = element.id;

    waitForContainer(containerId, function() {
      var componentType = element.getAttribute('data-component-type') || 'custom-button';
      var repeaterItems = document.querySelectorAll('[data-cloned-from="' + (parentContainer.getAttribute('data-template-id') || containerId) + '"] [data-component-type="' + componentType + '"][data-original-id="' + elementId + '"]');

      if (repeaterItems.length > 0) {
        repeaterItems.forEach(function(item) {
          var container = item.closest('[data-row-index]');
          if (!container) return;
          var index = parseInt(container.getAttribute('data-row-index'));
          if (data[index] === undefined) return;

          // Очищаем старое содержимое ячейки (кроме шаблона)
          var itemParent = item.parentElement;
          item.style.display = 'none';
          item.setAttribute('data-is-template', 'true');
          
          Array.from(itemParent.querySelectorAll('[data-cloned="true"]')).forEach(function(c) { c.remove(); });

          // Создаем кнопки для каждой колонки внутри репитера
          for (var cIdx = 0; cIdx < numColumns; cIdx++) {
            var val = Array.isArray(data[index]) ? data[index][cIdx] : data[index];
            var textVal = val != null ? String(val) : '';
            
            var btnClone = item.cloneNode(true);
            btnClone.removeAttribute('id');
            btnClone.setAttribute('data-cloned', 'true');
            btnClone.style.display = '';
            
            var label = btnClone.querySelector('.button-label');
            if (label) label.textContent = textVal;

            btnClone.setAttribute('data-value', textVal);
            if (config && config.columnName) {
              var colName = Array.isArray(config.columnName) ? config.columnName[cIdx] : config.columnName;
              btnClone.dataset[colName] = textVal;
            }
            
            itemParent.appendChild(btnClone);
            attachDashboardAction(btnClone, elementId);
          }
        });
        return;
      }
      processButtonStandard(element, data, config);
    });
  } else {
    processButtonStandard(element, data, config);
  }

  function processButtonStandard(element, data, config) {
    var elementId = element.id;
    var isGroupContainer = element.classList.contains('button-group-container');
    var mainWrapper = isGroupContainer ? element : element.parentElement;

    // Удаляем старые группы и клоны
    Array.from(mainWrapper.querySelectorAll('.button-column-group, .component-button[data-cloned="true"]'))
         .forEach(function(el) { el.remove(); });

    var templateButton = isGroupContainer 
      ? (element.querySelector('.component-button:not([data-cloned="true"])') || element.querySelector('.component-button[data-is-template="true"]'))
      : element;

    if (!templateButton) return;

    templateButton.style.display = 'none';
    templateButton.setAttribute('data-is-template', 'true');

    // Создаем группы для каждой колонки
    for (var colIdx = 0; colIdx < numColumns; colIdx++) {
      var colName = config && config.columnName ?
        (Array.isArray(config.columnName) ? config.columnName[colIdx] : config.columnName) :
        'Column ' + (colIdx + 1);

      // Создаем элемент группы
      var groupDiv = document.createElement('div');
      groupDiv.className = 'button-column-group';
      groupDiv.setAttribute('data-column-name', colName);
      
      // Стилизация группы (чтобы кнопки внутри колонки шли друг за другом)
      groupDiv.style.display = 'flex';
      groupDiv.style.flexDirection = 'column';
      groupDiv.style.gap = '8px';
      groupDiv.style.flex = '1'; 

      data.forEach(function(row, rowIndex) {
        var val = Array.isArray(row) ? row[colIdx] : row;
        var textVal = String(val != null ? val : '');

        var buttonClone = templateButton.cloneNode(true);
        buttonClone.removeAttribute('id');
        buttonClone.setAttribute('data-cloned', 'true');
        buttonClone.setAttribute('data-row-index', rowIndex);
        buttonClone.setAttribute('data-column-index', colIdx);

        var label = buttonClone.querySelector('.button-label');
        if (label) label.textContent = textVal;

        buttonClone.setAttribute('data-value', textVal);
        if (colName) {
            var safeKey = String(colName).replace(/[^a-zA-Z0-9_-]/g, '');
            buttonClone.dataset[safeKey] = textVal;
        }

        buttonClone.style.display = '';
        copyAllStylesDeep(templateButton, buttonClone);
        
        groupDiv.appendChild(buttonClone);
        attachDashboardAction(buttonClone, elementId);
      });

      mainWrapper.appendChild(groupDiv);
    }
  }
}`,

  'checkbox-label': `function(element, data, config) {
    if (!element || !data || data.length === 0) return;
    var checkboxGroup = element.closest('[data-component-type="checkbox-group"]');
    if (!checkboxGroup) return;
    componentHandlers['checkbox-group'](checkboxGroup, data, config);
  }`,

  'checkbox-group': `function(element, data, config) {
  if (!element || !data || data.length === 0) return;

  var wrapper = element.querySelector('.checkbox-wrapper');
  if (!wrapper) return;

  var container = element;
  var numColumns = Array.isArray(data[0]) ? data[0].length : 1;

  // --- Функция для экшена на Label ---
  function attachLabelAction(labelEl, groupId, cellValue, colName) {
    var actions = componentsWithActions[groupId];
    if (!actions) return;

    // Ищем экшен конкретно для компонента checkbox-label
    var actionInfo = actions.find(function(a) { 
      return a.componentType === 'checkbox-label' && a.wzComp.action === 'OPEN_DASHBOARD'; 
    });

    if (actionInfo && window.WZ && typeof window.WZ.sendOpenDashboard === 'function') {
      labelEl.style.cursor = 'pointer';
      
      labelEl.onclick = function(e) {
        e.stopPropagation();
        var mappingValues = [];
        var params = actionInfo.wzComp.parameters || [];

        params.forEach(function(param) {
          var targetCol = param.columnName;
          // Если параметр совпадает с текущей колонкой - берем текст метки
          // Иначе пытаемся найти в атрибутах
          var value = (targetCol === colName || (config && targetCol === config.columnName))
                      ? cellValue
                      : labelEl.getAttribute('data-' + targetCol);

          if (value !== undefined && value !== null) {
            mappingValues.push({
              dashboardParameterId: param.dashboardParameterId,
              columnName: targetCol,
              mappingValueString: String(value)
            });
          }
        });

        console.log('🚀 Checkbox Label Transition:', mappingValues);
        window.WZ.sendOpenDashboard(actionInfo.wzComp.targetId, 'OPEN_DASHBOARD', mappingValues);
      };
    }
  }

  // --- Очистка ---
  Array.from(container.querySelectorAll('.checkbox-column-group, .checkbox-wrapper[data-cloned="true"]'))
       .forEach(function(el) { el.remove(); });

  wrapper.style.display = 'none';
  wrapper.setAttribute('data-is-template', 'true');

  // --- МУЛЬТИМАППИНГ: Создание колонок ---
  for (var colIdx = 0; colIdx < numColumns; colIdx++) {
    var colName = (config && config.columnName && Array.isArray(config.columnName)) 
                  ? config.columnName[colIdx] 
                  : (config && config.columnName ? config.columnName : 'Column ' + (colIdx + 1));

    // Создаем контейнер для текущей колонки данных
    var groupDiv = document.createElement('div');
    groupDiv.className = 'checkbox-column-group';
    groupDiv.style.display = 'flex';
    groupDiv.style.flexDirection = 'column';
    groupDiv.style.gap = '10px';
    groupDiv.style.marginRight = '20px'; // Отступ между колонками
    groupDiv.setAttribute('data-column-index', colIdx);

    data.forEach(function(row, rowIndex) {
      var cellData = Array.isArray(row) ? row[colIdx] : row;
      var labelText = 'Checkbox';
      var isChecked = false;

      // Обработка данных (строка или объект)
      if (typeof cellData === 'object' && cellData !== null) {
        labelText = cellData.values ? cellData.values[0] : (cellData.value || cellData.name || 'Checkbox');
        isChecked = cellData.checked === true || cellData.value === true || cellData.value === 1;
      } else {
        labelText = cellData != null ? String(cellData) : 'Checkbox';
        isChecked = cellData === true || cellData === 'true' || cellData === 1;
      }

      var textVal = String(labelText);
      var clone = wrapper.cloneNode(true);
      clone.setAttribute('data-cloned', 'true');
      clone.setAttribute('data-row-index', rowIndex);
      clone.setAttribute('data-col-index', colIdx);
      clone.removeAttribute('id');
      clone.style.display = 'flex';

      // Сохраняем значения в атрибуты (для экшенов и CSS)
      clone.setAttribute('data-value', textVal);
      if (colName) {
        var safeKey = String(colName).replace(/[^a-zA-Z0-9_-]/g, '');
        clone.setAttribute('data-' + safeKey, textVal);
      }

      // Настройка Input и Label
      var inputEl = clone.querySelector('.checkbox-input, input[type="checkbox"]');
      var labelEl = clone.querySelector('.checkbox-label, label');

      if (inputEl) {
        inputEl.checked = isChecked;
        var uniqueId = 'chk-' + colIdx + '-' + rowIndex + '-' + Math.floor(Math.random() * 1000);
        inputEl.id = uniqueId;
        inputEl.setAttribute('data-value', textVal);
        
        if (labelEl) {
          labelEl.textContent = textVal;
          labelEl.setAttribute('for', uniqueId);
          
          // ВАЖНО: Привязываем экшен перехода на Label
          attachLabelAction(labelEl, container.id, textVal, colName);
        }
      }

      copyAllStylesDeep(wrapper, clone);
      groupDiv.appendChild(clone);
    });

    container.appendChild(groupDiv);
  }

  // Инициализация стандартных событий клика по чекбоксу (смена состояния)
  if (typeof setupComponentEvents === 'function') {
    container.querySelectorAll('.checkbox-wrapper[data-cloned="true"]').forEach(function(c) {
      setupComponentEvents(c, 'checkbox-group');
    });
  }
}`,

  tabs: `function(element, data, config) {
    if (!element || !data || data.length === 0) return;

    var tabsNav = element.querySelector('.tabs-nav');
    var tabsContent = element.querySelector('.tabs-content');
    if (!tabsNav || !tabsContent) return;

    var existingPanes = tabsContent.querySelectorAll('.tab-pane');
    existingPanes.forEach(function(pane) {
      var canvases = pane.querySelectorAll('canvas');
      canvases.forEach(function(c) { if (c.chartInstance) c.chartInstance.destroy(); });
    });

    var templateContent = null;
    var firstPane = tabsContent.querySelector('.tab-pane');
    if (firstPane) {
      var allChildren = Array.from(firstPane.children);
      templateContent = allChildren.map(function(el) { return el.cloneNode(true); });
    }

    tabsNav.innerHTML = '';
    tabsContent.innerHTML = '';

    data.forEach(function(row, index) {
      var labelText = 'Tab';
      var contentText = '';
      if (Array.isArray(row)) {
        var firstValue = row[0];
        if (typeof firstValue === 'object' && firstValue !== null) labelText = firstValue.values ? firstValue.values[0] : (firstValue.value || 'Tab');
        else labelText = firstValue != null ? String(firstValue) : 'Tab';

        if (row.length > 1) contentText = row[1] != null ? String(row[1]) : '';
      }

      var tabId = 'tab-' + index + '-' + Date.now();
      var isFirst = index === 0;

      var tabButton = document.createElement('button');
      tabButton.className = 'tab-button' + (isFirst ? ' active' : '');
      tabButton.setAttribute('data-tab', tabId);
      tabButton.textContent = labelText;
      tabButton.setAttribute('data-component-type', 'tab-button');

      // [TRANSITION DATA]
      var textVal = labelText;
      tabButton.setAttribute('data-value', textVal);
      if (config && config.columnName) {
          var safeKey = config.columnName.replace(/[^a-zA-Z0-9_-]/g, '');
          tabButton.setAttribute('data-' + safeKey, textVal);
          if (tabButton.dataset) tabButton.dataset[safeKey] = textVal;
      }

      tabsNav.appendChild(tabButton);
      if (typeof setupComponentEvents === 'function') setupComponentEvents(tabButton, 'tab-button');

      var tabPane = document.createElement('div');
      tabPane.className = 'tab-pane' + (isFirst ? ' active' : '');
      tabPane.setAttribute('data-tab', tabId);
      tabPane.setAttribute('data-container', 'true');

      if (templateContent) {
          templateContent.forEach(function(el) {
              var clone = el.cloneNode(true);
              var allElements = [clone].concat(Array.from(clone.querySelectorAll('[id]')));
              allElements.forEach(function(elem) { if(elem.id) elem.id = elem.id + '-tab-' + index; });
              tabPane.appendChild(clone);
          });
      }
      tabsContent.appendChild(tabPane);
    });

    if (typeof initTabsStandalone === 'function') initTabsStandalone();
  }`,

  th: `function(element, data, config) {
  if (!element || !data || data.length === 0) return;

  var th = element.tagName === 'TH' ? element : element.closest('th');
  if (!th) return;

  var table = th.closest('table');
  var tbody = table ? table.querySelector('tbody') : null;
  if (!table || !tbody) return;

  var headerRow = th.parentElement;
  var thId = th.id || th.getAttribute('data-original-id') || th.getAttribute('data-cloned-from');

  // Функция для навешивания клика на ячейку (TD)
  function attachCellAction(td, originalThId, cellValue, colName) {
    var actions = componentsWithActions[originalThId];
    if (!actions) return;

    var actionInfo = actions.find(function(a) { return a.wzComp.action === 'OPEN_DASHBOARD'; });
    if (!actionInfo) return;

    td.style.cursor = 'pointer';
    // Добавляем эффект при наведении для наглядности
    td.onmouseenter = function() { this.style.backgroundColor = 'rgba(65, 112, 255, 0.1)'; };
    td.onmouseleave = function() { this.style.backgroundColor = ''; };

    td.onclick = function(e) {
      e.stopPropagation();
      if (window.WZ && typeof window.WZ.sendOpenDashboard === 'function') {
        var mappingValues = [];
        var params = actionInfo.wzComp.parameters || [];

        params.forEach(function(param) {
          var targetCol = param.columnName;
          // Если параметр экшена совпадает с текущей колонкой — берем значение ячейки
          // Иначе пытаемся найти в атрибутах (если маппинг сложный)
          var value = (targetCol === colName || targetCol === config.columnName)
                      ? cellValue
                      : td.getAttribute('data-' + targetCol);

          if (value !== undefined && value !== null) {
            mappingValues.push({
              dashboardParameterId: param.dashboardParameterId,
              columnName: targetCol,
              mappingValueString: String(value)
            });
          }
        });

        console.log('🚀 Table Cell Click: Opening dashboard', actionInfo.wzComp.targetId, mappingValues);
        window.WZ.sendOpenDashboard(actionInfo.wzComp.targetId, 'OPEN_DASHBOARD', mappingValues);
      }
    };
  }

  var originalColumnIndex = Array.from(headerRow.children).indexOf(th);
  var numColumns = Array.isArray(data[0]) ? data[0].length : 1;

  var existingClones = headerRow.querySelectorAll('[data-cloned-from="' + thId + '"]');
  existingClones.forEach(function(clone) { clone.remove(); });

  th.style.display = 'none';
  th.setAttribute('data-is-template', 'true');

  var createdThs = [];
  for (var colIdx = 0; colIdx < numColumns; colIdx++) {
    var thClone = th.cloneNode(true);
    thClone.removeAttribute('id');
    thClone.setAttribute('data-cloned-from', thId);
    thClone.style.display = '';

    var colName = config && config.columnName ?
      (Array.isArray(config.columnName) ? config.columnName[colIdx] : config.columnName) :
      'Column ' + (colIdx + 1);

    var thContentSpan = thClone.querySelector('.th-content span');
    if (thContentSpan) thContentSpan.textContent = colName;
    else thClone.textContent = colName;

    createdThs.push(thClone);
  }

  var insertReference = th.nextSibling;
  createdThs.forEach(function(thClone) {
    if (insertReference) headerRow.insertBefore(thClone, insertReference);
    else headerRow.appendChild(thClone);
  });

  var rows = Array.from(tbody.querySelectorAll('tr'));
  rows.forEach(function(row) {
    var cells = Array.from(row.querySelectorAll('td'));
    if (cells[originalColumnIndex]) cells[originalColumnIndex].remove();
  });

  for (var colIdx = 0; colIdx < numColumns; colIdx++) {
    var colName = Array.isArray(config.columnName) ? config.columnName[colIdx] : config.columnName;
    var targetColumnIndex = originalColumnIndex + colIdx;

    for (var rowIdx = 0; rowIdx < rows.length; rowIdx++) {
      var targetRow = rows[rowIdx];
      var cellData = data[rowIdx] ? (Array.isArray(data[rowIdx]) ? data[rowIdx][colIdx] : data[rowIdx]) : '-';

      var textVal = '-';
      if (typeof cellData === 'object' && cellData !== null) {
          textVal = cellData.values ? cellData.values[0] : (cellData.value || Object.values(cellData)[0] || '-');
      } else {
          textVal = cellData != null ? String(cellData) : '-';
      }

      var newCell = document.createElement('td');
      newCell.textContent = textVal;

      // СОХРАНЯЕМ ДАННЫЕ В АТРИБУТЫ
      newCell.setAttribute('data-value', textVal);
      if (colName) {
        var safeKey = String(colName).replace(/[^a-zA-Z0-9_-]/g, '');
        newCell.setAttribute('data-' + safeKey, textVal);
      }

      // НАВЕШИВАЕМ ЭКШЕН ПЕРЕХОДА (на базе ID заголовка)
      attachCellAction(newCell, thId, textVal, colName);

      var currentCells = Array.from(targetRow.querySelectorAll('td'));
      if (currentCells[targetColumnIndex]) {
        targetRow.insertBefore(newCell, currentCells[targetColumnIndex]);
      } else {
        targetRow.appendChild(newCell);
      }
    }
  }

  // Стилизация
  var allThs = headerRow.querySelectorAll('th:not([data-is-template="true"])');
  allThs.forEach(function(h) { h.style.minWidth = '100px'; h.style.whiteSpace = 'nowrap'; });
  tbody.querySelectorAll('td').forEach(function(c) { c.style.minWidth = '100px'; c.style.whiteSpace = 'nowrap'; });

  if (typeof initTableSortStandalone === 'function') {
    setTimeout(function() { initTableSortStandalone(); }, 50);
  }
}`,

  table: `function(element, data, config) {
    if (!element || !data || data.length === 0) return;

    var wrapper = element.classList && element.classList.contains('table-wrapper') ? element : element.querySelector('.table-wrapper');
    if (!wrapper) wrapper = element.closest('.table-wrapper');
    if (!wrapper) return;

    var tableHeader = wrapper.querySelector('.table-header');

    if (tableHeader && data.length > 0) {
      var firstValue = Array.isArray(data[0]) ? data[0][0] : data[0];
      var headerText = 'Table';

      if (typeof firstValue === 'object' && firstValue !== null) {
        headerText = firstValue.values ? firstValue.values[0] : (firstValue.value || firstValue.name || Object.values(firstValue)[0] || 'Table');
      } else {
        headerText = firstValue != null ? String(firstValue) : 'Table';
      }
      tableHeader.textContent = headerText;
    }
  }`,

  'wz-table': `function(element, data, config) {
    if (!element || !data || data.length === 0) return;

    var wrapper = element.classList && element.classList.contains('table-wrapper') ? element : element.querySelector('.table-wrapper');
    if (!wrapper) wrapper = element.closest('.table-wrapper');
    if (!wrapper) return;

    var tableHeader = wrapper.querySelector('.table-header');

    if (tableHeader && data.length > 0) {
      var firstValue = Array.isArray(data[0]) ? data[0][0] : data[0];
      var headerText = 'Table';

      if (typeof firstValue === 'object' && firstValue !== null) {
        headerText = firstValue.values ? firstValue.values[0] : (firstValue.value || firstValue.name || Object.values(firstValue)[0] || 'Table');
      } else {
        headerText = firstValue != null ? String(firstValue) : 'Table';
      }
      tableHeader.textContent = headerText;
    }
  }`,

  chart: `function(element, data, config) {
     if (!element.chartDataStorage) element.chartDataStorage = { X: [], Y: [], layers: {}, layerNames: {} };
     var storage = element.chartDataStorage;
     var mappingIndex = (config && typeof config.mappingIndex !== 'undefined') ? config.mappingIndex : 0;

     if (config && config.axis) {
         var axis = config.axis;
         if (!Array.isArray(storage[axis])) storage[axis] = [];
         storage[axis][mappingIndex] = data;
     } else if (config && config.layerId) {
         if (!storage.layers[config.layerId]) storage.layers[config.layerId] = [];
         storage.layers[config.layerId][mappingIndex] = data;
     }

     // Сохраняем имя колонки для handler'а points
     if (config && config.columnName) {
        if (!element.chartConfig) element.chartConfig = {};
        element.chartConfig[config.axis || 'Y'] = config.columnName;
     }

     var hasX = storage.X && storage.X.length > 0;
     var hasY = storage.Y && storage.Y.length > 0;
     if (!hasX || !hasY) return;

     if (element.renderChartTimer) clearTimeout(element.renderChartTimer);
     element.renderChartTimer = setTimeout(function() { renderChartWithLayers(element); }, 50);
  }`,

  'chart-axis-x': `function(element, data, config) {
     var chartHandler = componentHandlers['chart'];
     if (!chartHandler) return;
     if (!element.chartDataStorage) element.chartDataStorage = { X: [], Y: [], layers: {}, layerNames: {} };

     var numColumns = (data.length > 0 && Array.isArray(data[0])) ? data[0].length : 1;
     for (var colIdx = 0; colIdx < numColumns; colIdx++) {
        var columnData = data.map(function(row) { return Array.isArray(row) ? row[colIdx] : row; });
        var mappingIndex = element.chartDataStorage.X.length;
        chartHandler(element, columnData, { axis: 'X', mappingIndex: mappingIndex });
     }
  }`,

  'chart-axis-y': `function(element, data, config) {
     var chartHandler = componentHandlers['chart'];
     if (!chartHandler) return;
     if (!element.chartDataStorage) element.chartDataStorage = { X: [], Y: [], layers: {}, layerNames: {} };

     var numColumns = (data.length > 0 && Array.isArray(data[0])) ? data[0].length : 1;
     for (var colIdx = 0; colIdx < numColumns; colIdx++) {
        var columnData = data.map(function(row) { return Array.isArray(row) ? row[colIdx] : row; });
        var mappingIndex = element.chartDataStorage.Y.length;
        var colName = config && config.columnName ? config.columnName : '';
        if (numColumns > 1 && colName) colName += ' ' + (colIdx + 1);
        chartHandler(element, columnData, { axis: 'Y', mappingIndex: mappingIndex, columnName: colName });
     }
  }`,

  points: `function(element, data, config) {
    if (!element || !data || data.length === 0) return;
    var existingPoints = element.querySelectorAll('.chart-point');
    existingPoints.forEach(function(point) { point.remove(); });

    // Пытаемся получить имя колонки из родительского графика
    var chartEl = element.closest('[data-component-type="chart"]');
    var colName = null;
    if (chartEl && chartEl.chartConfig) colName = chartEl.chartConfig['Y'];

    data.forEach(function(pointData, index) {
      if (!pointData || pointData.value == null) return;
      var point = document.createElement('div');
      point.className = 'chart-point';
      // ... стили (сокращено) ...
      point.style.position = 'absolute';
      point.style.left = (index / data.length * 100) + '%';
      point.style.bottom = (pointData.value / 100 * 80) + '%';
      point.style.width = '12px';
      point.style.height = '12px';
      point.style.backgroundColor = pointData.color || '#4170FF';

      // [TRANSITION DATA]
      point.setAttribute('data-value', pointData.value);
      if (colName) {
          var safeKey = colName.replace(/[^a-zA-Z0-9_-]/g, '');
          point.setAttribute('data-' + safeKey, pointData.value);
          if (point.dataset) point.dataset[safeKey] = pointData.value;
      }

      point.addEventListener('click', function() {
        if (window.WZ && window.WZ.emitEvent) window.WZ.emitEvent('POINT_CLICK', { index: index, data: pointData });
      });
      element.appendChild(point);
    });
  }`
};

export const DEFAULT_HANDLER = `function(element, data, config) {
  if (!element || !data || data.length === 0) return;

  if (element.closest('[data-cloned-from]')) {
      console.log('🛑 [Default] Skip: element is inside cloned container');
      return;
  }

  var parentContainer = element.closest('[data-component-type="container"]');

  if (parentContainer) {
      var containerId = parentContainer.id;
      var elementId = element.id;

      console.log('🔍 [Default] Found parent container:', containerId, 'for element:', elementId);

      waitForContainer(containerId, function() {
          var componentType = element.getAttribute('data-component-type');
          if (componentType) {
              var repeaterItems = document.querySelectorAll('[data-cloned-from] [data-component-type="' + componentType + '"][data-original-id="' + elementId + '"]');
              if (repeaterItems.length > 0) {
                  var updatedCount = 0;
                  repeaterItems.forEach(function(item) {
                      var container = item.closest('[data-row-index]');
                      if (container) {
                          var index = parseInt(container.getAttribute('data-row-index'));
                          if (data[index] !== undefined) {
                              var val = Array.isArray(data[index]) ? data[index][0] : data[index];
                              if (item.tagName === 'INPUT' || item.tagName === 'TEXTAREA') {
                                  item.value = val != null ? String(val) : '';
                              } else {
                                  item.textContent = val != null ? String(val) : '';
                              }
                              updatedCount++;
                          }
                      }
                  });
                  if (updatedCount > 0) {
                      console.log('🔄 [Default] Updated', updatedCount, 'items for element:', elementId);
                      return;
                  }
              }
          }

          processDefaultStandard(element, data);
      });
  } else {
      processDefaultStandard(element, data);
  }

  function processDefaultStandard(element, data) {
      var container = element.parentElement;
      var isOriginal = !element.hasAttribute('data-cloned');

      if (isOriginal && data.length > 1) {
        var existingClones = container.querySelectorAll('[data-cloned="true"]');
        existingClones.forEach(function(clone) { clone.remove(); });

        var originalDisplay = window.getComputedStyle(element).display;
        if (originalDisplay === 'none') originalDisplay = 'block';

        var clones = [];
        data.forEach(function(row, index) {
          var value = Array.isArray(row) ? row[0] : row;
          var clone = element.cloneNode(true);
          clone.setAttribute('data-cloned', 'true');
          clone.setAttribute('data-row-index', index);
          clone.removeAttribute('id');

          copyAllStylesDeep(element, clone);
          clone.style.setProperty('display', originalDisplay, 'important');

          if (clone.tagName === 'INPUT' || clone.tagName === 'TEXTAREA') {
            clone.value = value != null ? String(value) : '';
          } else {
            clone.textContent = value != null ? String(value) : '';
          }
          clones.push(clone);
        });

        element.style.display = 'none';
        element.setAttribute('data-template', 'true');
        clones.forEach(function(clone) {
          container.insertBefore(clone, element.nextSibling);
        });
      } else if (isOriginal && data.length === 1) {
        element.style.display = '';
        element.removeAttribute('data-template');
        var value = Array.isArray(data[0]) ? data[0][0] : data[0];

        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
          element.value = value != null ? String(value) : '';
        } else {
          element.textContent = value != null ? String(value) : '';
        }
      }
  }
}`;
