'use client';

import * as React from 'react';
import { useCallback, useRef } from 'react';
import GjsEditor, {
  AssetsProvider,
  Canvas,
  ModalProvider
} from '@grapesjs/react';
import type { Editor } from 'grapesjs';
import { ThemeProvider } from '@mui/material/styles';
import 'grapesjs-plugin-forms';
import 'grapesjs-tabs';
import { useRouter } from 'next/navigation';
import { Button } from '@mui/material';

import CustomModal from '../components/CustomModal';
import CustomAssetManager from '../components/CustomAssetManager';
import Topbar from '../components/Topbar';
import RightSidebar from '../components/RightSidebar';
import LeftSidebar from '../components/LeftSidebar';
import { gjsOptions, MAIN_BORDER_COLOR, theme } from './editorConfig';
import { useEditorState } from './hooks/useEditorState';
import { useEditorLogic } from './hooks/useEditorLogic';
import { useWidgetSave } from './hooks/useWidgetSave';
import { useCodeGeneration } from './hooks/useCodeGeneration';

import 'grapesjs/dist/css/grapes.min.css';
import CodeEditorModal from '../components/CodeEditorModal';
import {
  generateWidgetJS,
  collectCanvasComponents,
  type CanvasComponent
} from './utils/codeGenerators';
import { sanitizePath } from '@/src/helpers/basePrefix';
import { exportGrapesCode } from '@/src/utils/grapesExport';
import { withAppScrollbarCss } from '@/src/helpers/appScrollbar';
import '@/src/styles/grapes-overrides.css';
import {
  GRAPESJS_RUNTIME_CSS_URL,
  GRAPESJS_RUNTIME
} from '@/src/editor/grapesRuntime';

export default function EditorContent() {
  const editorState = useEditorState();
  const router = useRouter();

  const editorInstanceRef = useRef<Editor | null>(null);

  const codeGeneration = useCodeGeneration();

  const cleanComponentAttributes = (
    components: CanvasComponent[]
  ): CanvasComponent[] => {
    return components.map((comp) => ({
      ...comp,
      attributes: Object.keys(comp.attributes || {}).reduce(
        (acc, key) => {
          const value = comp.attributes[key];
          acc[key] =
            typeof value === 'string'
              ? value
                  .replace(/\r?\n|\r/g, '')
                  .replace(/\s+/g, ' ')
                  .trim()
              : value;
          return acc;
        },
        {} as Record<string, any>
      )
    }));
  };

  const getEditorCode = useCallback(() => {
    if (typeof window === 'undefined') {
      return { html: '', css: '', js: '', pages: [], currentPageId: '' };
    }

    const editor = editorInstanceRef.current;
    if (!editor)
      return { html: '', css: '', js: '', pages: [], currentPageId: '' };

    const selectedPage = editor.Pages.getSelected();
    const currentPageId = selectedPage ? selectedPage.getId() : '';

    const exported = exportGrapesCode(editor);
    const globalCss = exported.css || editor.getCss({ avoidProtected: true }) || '';

    const allCanvasComponents: CanvasComponent[] = [];

    editor.Pages.getAll().forEach((page: any) => {
      const component = page.getMainComponent();
      collectCanvasComponents(component, allCanvasComponents);
    });

    const cleanedComponents = cleanComponentAttributes(allCanvasComponents);
    const templateJs = generateWidgetJS(cleanedComponents);

    const finalJs = templateJs;

    const htmlGenerator = editor.CodeManager.getGenerator('htmljs');

    const getPageSpecificCss = (rootComponent: any) => {
      const cssComposer = editor.Css;
      const allRules = cssComposer.getAll();

      const validSelectors = new Set<string>();

      const traverse = (comp: any) => {
        const id = comp.getId();
        if (id) validSelectors.add(`#${id}`);

        const classes = comp.getClasses();
        classes.forEach((cls: string) => validSelectors.add(`.${cls}`));

        comp.get('components').forEach((child: any) => traverse(child));
      };

      traverse(rootComponent);

      let finalCss = '';

      allRules.forEach((rule: any) => {
        const selectors = rule.get('selectors');
        let shouldInclude = false;

        if (selectors.length === 0) {
          if (rule.toCSS().trim() !== '') shouldInclude = true;
        } else {
          const hasMatch = selectors.some((selector: any) => {
            const name = selector.get('name');
            const type = selector.get('type');

            if (type === 1) return validSelectors.has(`.${name}`);
            if (type === 2) return validSelectors.has(`#${name}`);
            return false;
          });

          if (hasMatch) shouldInclude = true;
        }

        if (shouldInclude) {
          finalCss += rule.toCSS() + '\n';
        }
      });

      return finalCss;
    };

    const pagesData = editor.Pages.getAll().map((page: any) => {
      const component = page.getMainComponent();
      const pageName = page.getName() || 'Untitled';

      let rawPageHtml = '';
      try {
        rawPageHtml = htmlGenerator.build(component);
      } catch (e) {
        console.warn('HTML generation failed', e);
        rawPageHtml = component.toHTML();
      }

      const { html: processedHtml, cssVariables } =
        codeGeneration.processPageContent(
          editor,
          component,
          rawPageHtml,
          pageName
        );

      let pageFullStyles = '';
      try {
        pageFullStyles = getPageSpecificCss(component);
      } catch (e) {
        console.warn(`Manual CSS collection failed for ${pageName}`, e);
        pageFullStyles = globalCss;
      }

      const fullPageCss = withAppScrollbarCss(
        `${cssVariables || ''}\n${pageFullStyles}`
      );

      return {
        id: page.getId(),
        name: pageName,
        html: processedHtml,
        css: fullPageCss
      };
    });

    return {
      html: editor.getHtml(),
      css: globalCss,
      js: finalJs,
      pages: pagesData,
      currentPageId: currentPageId
    };
  }, [codeGeneration, editorState.name]);

  const editorLogic = useEditorLogic({
    isDraftReady: editorState.isDraftReady,
    widgetTemplateDraftId: editorState.widgetTemplateDraftId,
    dispatch: editorState.dispatch,
    setSelectedTab: editorState.setSelectedTab,
    onOpenCode: editorState.handleOpenCodeModal,
    editorRef: editorInstanceRef
  });

  const widgetSave = useWidgetSave({
    departmentId: editorState.departmentId,
    widgetTemplateDraftId: editorState.widgetTemplateDraftId,
    name: editorState.name,
    description: editorState.description,
    widgetTemplateDraft: editorState.widgetTemplateDraft,
    widgetTemplateFiles: editorState.widgetTemplateFiles,
    groups: editorState.groups,
    getEditorCode,
    formatCode: codeGeneration.formatCode,
    setIsSaving: editorState.setIsSaving,
    router
  });

  const handleSaveAndNavigateToDashboard = async (dashboardId: string) => {
    try {
      const dashboardUrl = sanitizePath(
        `/dashboards/${dashboardId}?departmentId=${editorState.departmentId}`
      );
      const widgetData =
        await widgetSave.handleCreateWidgetTemplate(dashboardUrl);

      if (!widgetData) {
        throw new Error('Failed to save widget');
      }

      const finalUrl = sanitizePath(
        `/dashboards/${dashboardId}?departmentId=${editorState.departmentId}&addWidget=true&widgetTemplateDraftId=${widgetData.widgetTemplateId}&widgetName=${encodeURIComponent(widgetData.name)}`
      );

      router.push(finalUrl);
    } catch (error) {
      console.error('Failed to save widget before navigation:', error);
      throw error;
    }
  };


  return (
    <ThemeProvider theme={theme}>
      <div
        id='gjs'
        style={{
          display: 'flex',
          flexDirection: 'column',
          maxHeight: '100vh',
          height: '100vh',
          overflow: 'hidden'
        }}
        className='bg-[rgba(16, 22, 28, 0.5)]'
      >
        <GjsEditor
          className='gjs-custom-editor'
          grapesjs={GRAPESJS_RUNTIME}
          grapesjsCss={GRAPESJS_RUNTIME_CSS_URL}
          options={gjsOptions}
          onEditor={editorLogic.onEditor}
        >
          <Topbar
            onCreateWidgetTemplate={widgetSave.handleCreateWidgetTemplate}
            onOpenTitleModal={editorState.handleOpenTitleModal}
            departmentId={editorState.departmentId}
            isSaving={editorState.isSaving}
            widgetName={editorState.name}
            widgetDescription={editorState.description}
            className='min-h-[48px] bg-[rgba(16, 22, 28, 0.5)]'
          />
          <div
            className={`flex flex-grow ${MAIN_BORDER_COLOR} overflow-hidden`}
          >
            <LeftSidebar
              departmentId={editorState.departmentId}
              onSaveAndNavigateToDashboard={handleSaveAndNavigateToDashboard}
            />
            <div className='gjs-column-m flex flex-col flex-grow h-full overflow-hidden relative min-w-0'>
              <Canvas className='flex-grow gjs-custom-editor-canvas h-full w-full' />
            </div>
            <RightSidebar
              className={`gjs-column-r w-[300px] border-l ${MAIN_BORDER_COLOR} bg-[rgba(16, 22, 28, 0.5)]`}
              activeTab={editorState.selectedTab}
              onTabChange={editorState.setSelectedTab}
            />
          </div>
          <ModalProvider>
            {({ open, title, content, close }) => (
              <CustomModal
                open={open}
                title={title as React.ReactNode}
                close={close}
              >
                {content as React.ReactNode}
              </CustomModal>
            )}
          </ModalProvider>
          <AssetsProvider>
            {({ assets, select, close, Container }) => (
              <Container>
                <CustomAssetManager
                  assets={assets.map((asset) =>
                    typeof asset === 'string'
                      ? asset
                      : (asset as any).getSrc?.() || ''
                  )}
                  select={select}
                  close={close}
                />
              </Container>
            )}
          </AssetsProvider>
          <CodeEditorModal
            open={editorState.isCodeModalOpen}
            onClose={editorState.handleCloseCodeModal}
          />
        </GjsEditor>

        <CustomModal
          open={editorState.isTitleModalOpen}
          title='Edit Widget Template'
          close={editorState.handleCloseTitleModal}
        >
          <div style={{ padding: '20px', minWidth: '400px' }}>
            <div style={{ marginBottom: '16px' }}>
              <label
                htmlFor='widget-name'
                style={{
                  display: 'block',
                  marginBottom: '8px',
                  fontWeight: 'bold',
                  color: '#fff'
                }}
              >
                Title *
              </label>
              <input
                id='widget-name'
                type='text'
                value={editorState.tempName}
                onChange={(e) => editorState.setTempName(e.target.value)}
                placeholder='Enter widget template title'
                style={{
                  width: '100%',
                  padding: '8px 12px',
                  borderRadius: '4px',
                  border: '1px solid #555',
                  backgroundColor: '#333',
                  color: '#fff',
                  fontSize: '14px'
                }}
              />
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label
                htmlFor='widget-description'
                style={{
                  display: 'block',
                  marginBottom: '8px',
                  fontWeight: 'bold',
                  color: '#fff'
                }}
              >
                Description
              </label>
              <textarea
                id='widget-description'
                value={editorState.tempDescription}
                onChange={(e) => editorState.setTempDescription(e.target.value)}
                placeholder='Enter widget template description'
                rows={3}
                style={{
                  width: '100%',
                  padding: '8px 12px',
                  borderRadius: '4px',
                  border: '1px solid #555',
                  backgroundColor: '#333',
                  color: '#fff',
                  fontSize: '14px',
                  resize: 'vertical'
                }}
              />
            </div>

            <div
              style={{
                display: 'flex',
                justifyContent: 'flex-end',
                gap: '8px'
              }}
            >
              <Button
                onClick={editorState.handleCloseTitleModal}
                sx={{
                  color: '#fff',
                  border: '1px solid #555',
                  textTransform: 'none'
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={editorState.handleSaveTitleData}
                variant='contained'
                disabled={!editorState.tempName.trim()}
                sx={{
                  backgroundColor: '#4170FF',
                  textTransform: 'none',
                  '&:hover': {
                    backgroundColor: '#3155CC'
                  }
                }}
              >
                Save
              </Button>
            </div>
          </div>
        </CustomModal>
      </div>
    </ThemeProvider>
  );
}
