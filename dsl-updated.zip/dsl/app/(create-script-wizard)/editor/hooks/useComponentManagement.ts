import { useCallback } from 'react';
import type { Component } from 'grapesjs';

import { store } from '@/src/store/store';
import { createComponentDraft } from '@/src/requests/Components/createComponentDraft';
import { getWidgetTemplateDraftMappings } from '@/src/requests/Mapping/getWidgetTemplateDraftMappings';
import { getComponents } from '@/src/store/actions/Component/getComponents';
import { specialTypes } from '../editorConfig';
import { openSnackBarAction } from '@/src/store/actions/openSnackBar';
import { SnackType } from '@/src/store/counter/snackBarSlice';

interface UseComponentManagementProps {
  componentCreationInProgress: React.MutableRefObject<Set<string>>;
  draftStateRef: React.MutableRefObject<{
    widgetTemplateDraftId: string;
    isDraftReady: boolean;
  }>;
}

// Хелпер для создания всплывающего уведомления (Toast)
const showToast = (message: string, type: 'success' | 'error' = 'success') => {
  // 1. Ищем или создаем контейнер для тостов
  let toastContainer = document.getElementById('gjs-custom-toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'gjs-custom-toast-container';
    Object.assign(toastContainer.style, {
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '12px',
      zIndex: '10000',
      pointerEvents: 'none' // Пропускаем клики сквозь контейнер
    });
    document.body.appendChild(toastContainer);
  }

  // 2. Создаем сам элемент уведомления
  const toast = document.createElement('div');
  Object.assign(toast.style, {
    backgroundColor: type === 'success' ? '#10161C' : '#d32f2f', // Темный фон для успеха (как в вашей теме) или красный для ошибки
    color: '#fff',
    padding: '16px 24px',
    borderRadius: '8px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
    border: '1px solid rgba(255,255,255,0.1)',
    fontFamily: 'Montserrat, sans-serif',
    fontSize: '14px',
    fontWeight: '500',
    opacity: '0',
    transform: 'translateX(100%)', // Выезжает справа
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    pointerEvents: 'auto',
    minWidth: '300px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between'
  });

  // Добавляем текст и иконку (опционально)
  toast.innerHTML = `
    <span>${message}</span>
  `;

  toastContainer.appendChild(toast);

  // 3. Анимация появления
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(0)';
  });

  // 4. Удаление через 3 секунды
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(20px)'; // Уходит чуть вниз при исчезновении

    // Удаляем из DOM после завершения анимации
    setTimeout(() => {
      if (toast.parentNode) {
        toast.remove();
      }
      // Если тостов больше нет, можно удалить контейнер (по желанию)
      if (toastContainer && toastContainer.childNodes.length === 0) {
        toastContainer.remove();
      }
    }, 300);
  }, 3000);
};

export const useComponentManagement = (props: UseComponentManagementProps) => {
  const { componentCreationInProgress, draftStateRef } = props;

  const shouldCreateComponent = useCallback((element: Component): boolean => {
    const type = element.get('type') || element.get('tagName');
    if (!type) return false;

    return specialTypes.includes(type);
  }, []);

  const createComponentFromElement = useCallback(
    async (element: Component, editor: any) => {
      const {
        widgetTemplateDraftId: currentDraftId,
        isDraftReady: currentIsDraftReady
      } = draftStateRef.current;

      const elementId = element.getId();
      if (!elementId) {
        return;
      }

      if (componentCreationInProgress.current.has(elementId)) {
        return;
      }

      if (!currentDraftId || !currentIsDraftReady) {
        return;
      }

      componentCreationInProgress.current.add(elementId);

      try {
        const elementType =
          element.get('type') || element.get('tagName') || 'component';
        const timestamp = Date.now();
        const randomSuffix = Math.random().toString(36).substring(2, 8);
        const uniqueName = `${elementType}_${timestamp}_${randomSuffix}`
          .replace(/-/g, '_')
          .replace(/\b\w/g, (l) => l.toUpperCase());

        const componentData: any = {
          name: uniqueName,
          description: `Auto-generated ${elementType} component (ID: ${elementId})`,
          selector: `#${elementId}`,
          cssClass: element.get('attributes')?.class || '',
          data: JSON.stringify(
            {
              type: elementType,
              elementId: elementId,
              attributes: element.get('attributes') || {},
              traits:
                element.get('traits')?.reduce((acc: any, trait: any) => {
                  acc[trait.get('name')] = trait.get('value');
                  return acc;
                }, {}) || {}
            },
            null,
            2
          )
        };

        const success = await createComponentDraft(
          currentDraftId,
          componentData
        );

        if (success) {
          try {
            await getWidgetTemplateDraftMappings(currentDraftId);
          } catch (mappingError) {
            console.warn('Unable to refresh component mapping', mappingError);
          }

          store.dispatch(getComponents(currentDraftId));

          store.dispatch(
            openSnackBarAction(
              SnackType.success,
              'The component was successfully created',
              true
            )
          );

          // ЗАМЕНЕНО: вместо editor.Modal.open используем тост
          showToast(
            `Component "${uniqueName}" was successfully created`,
            'success'
          );
        } else {
          throw new Error('API returned false - component creation failed');
        }
      } catch (error: any) {
        if (
          error.message?.includes('duplicate_component_name') ||
          (error.response &&
            error.response.data &&
            error.response.data.error === 'duplicate_component_name')
        ) {
          setTimeout(async () => {
            await createComponentFromElement(element, editor);
          }, 500);
          return;
        }

        // ЗАМЕНЕНО: вместо editor.Modal.open используем тост ошибки
        showToast(
          `Failed to create component: ${error.message || 'Unknown error'}`,
          'error'
        );
      } finally {
        setTimeout(() => {
          componentCreationInProgress.current.delete(elementId);
        }, 1000);
      }
    },
    [componentCreationInProgress, draftStateRef]
  );

  const createComponentsRecursively = useCallback(
    async (element: Component, editor: any) => {
      const elementId = element.getId();

      if (elementId && shouldCreateComponent(element)) {
        await createComponentFromElement(element, editor);
      }

      const children = element.get('components');
      if (children && children.length > 0) {
        //@ts-ignore
        for (const child of children) {
          await createComponentsRecursively(child, editor);
        }
      }
    },
    [shouldCreateComponent, createComponentFromElement]
  );

  const handleComponentCreation = useCallback(
    async (component: Component, editor: any) => {
      const elementId = component.getId();
      if (!elementId) return;

      setTimeout(async () => {
        const currentComponent =
          editor.Components?.getById?.(elementId) ??
          editor
            .getComponents()
            .find((c: Component) => c.getId() === elementId);

        if (currentComponent) {
          await createComponentsRecursively(currentComponent, editor);
        }
      }, 1500);
    },
    [createComponentsRecursively]
  );

  const setupComponentEventHandlers = useCallback(
    (editor: any) => {
      const onComponentAdd = (component: Component) => {
        handleComponentCreation(component, editor);
      };

      const onComponentClone = (clonedComponent: Component) => {
        handleComponentCreation(clonedComponent, editor);
      };

      const onBlockDragStop = () => {
        const selected = editor.getSelected();
        if (selected) {
          handleComponentCreation(selected, editor);
        }
      };

      const onComponentUpdateType = (component: Component) => {
        const newType = component.get('type');
        // @ts-ignore GrapesJS custom component types are string based.
        if (!specialTypes.includes(newType)) return;

        setTimeout(() => {
          void createComponentsRecursively(component, editor);
        }, 100);
      };

      const cleanup = () => {
        editor.off('component:add', onComponentAdd);
        editor.off('component:clone', onComponentClone);
        editor.off('block:drag:stop', onBlockDragStop);
        editor.off('component:update:type', onComponentUpdateType);
        editor.off('destroy', cleanup);
      };

      editor.on('component:add', onComponentAdd);
      editor.on('component:clone', onComponentClone);
      editor.on('block:drag:stop', onBlockDragStop);
      editor.on('component:update:type', onComponentUpdateType);
      editor.on('destroy', cleanup);

      return cleanup;
    },
    [handleComponentCreation, createComponentsRecursively]
  );

  return {
    shouldCreateComponent,
    createComponentFromElement,
    createComponentsRecursively,
    handleComponentCreation,
    setupComponentEventHandlers
  };
};
