import { useCallback, useRef, useEffect } from 'react';
import type { Editor, Component } from 'grapesjs';

import { bodyStyleSectors } from '../editorConfig';
import { components, registerComponents } from '../../data/elements';
import { useComponentManagement } from './useComponentManagement';
import { registerEditor } from '@/src/editor/editorRegistry';

interface UseEditorLogicProps {
  isDraftReady: boolean;
  widgetTemplateDraftId: string;
  dispatch: any;
  setSelectedTab: (tab: number) => void;
  onOpenCode?: () => void;
  editorRef: { current: Editor | null };
}

export const useEditorLogic = (props: UseEditorLogicProps) => {
  const componentCreationInProgress = useRef<Set<string>>(new Set());
  const unregisterEditorRef = useRef<(() => void) | null>(null);
  const componentEventsCleanupRef = useRef<(() => void) | null>(null);
  const editorEventsCleanupRef = useRef<(() => void) | null>(null);
  const draftStateRef = useRef({
    widgetTemplateDraftId: props.widgetTemplateDraftId,
    isDraftReady: props.isDraftReady
  });

  const { onOpenCode } = props;

  useEffect(() => {
    draftStateRef.current = {
      widgetTemplateDraftId: props.widgetTemplateDraftId,
      isDraftReady: props.isDraftReady
    };
  }, [props.widgetTemplateDraftId, props.isDraftReady]);

  useEffect(
    () => () => {
      editorEventsCleanupRef.current?.();
      editorEventsCleanupRef.current = null;
      componentEventsCleanupRef.current?.();
      componentEventsCleanupRef.current = null;
      unregisterEditorRef.current?.();
      unregisterEditorRef.current = null;
      props.editorRef.current = null;
    },
    [props.editorRef]
  );

  const componentManagement = useComponentManagement({
    componentCreationInProgress,
    draftStateRef
  });

  const updateStyleManagerSectors = useCallback(
    (selectedComponent: Component | null) => {
      const editor = props.editorRef.current;
      if (!editor) return;

      const sm = editor.StyleManager;

      sm.getSectors().reset();

      if (!selectedComponent) return;

      let sectorsToAdd: any[] = [];

      if (selectedComponent.is('wrapper')) {
        sectorsToAdd = bodyStyleSectors;
      } else {
        const componentType = selectedComponent.get('type');
        const config = components.find((c) => c.type === componentType);
        if (config?.styleConfig?.sectors?.length) {
          sectorsToAdd = config.styleConfig.sectors;
        }
      }

      sectorsToAdd.forEach((s) => {
        sm.addSector(s.id, {
          name: s.name,
          open: s.open ?? false,
          properties: s.properties
        });
      });

      sm.render();
    },
    [props.editorRef]
  );

  const collectScriptsAndTraits = useCallback(
    (
      component: Component,
      result: { scripts: string[]; traits: Record<string, any> }
    ) => {
      const componentType = component.get('type') || component.get('tagName');
      const script = component.get('script');
      if (script) {
        result.scripts.push(`
        // Script for component ${componentType} (ID: ${component.getId()})
        (function() {
          const props = ${
            JSON.stringify(
              component.get('script-props')?.reduce((acc: any, key: string) => {
                const trait = component.getTrait(key);
                acc[key] = trait?.get('value');
                return acc;
              }, {}),
              null,
              2
            ) || '{}'
          };
          try {
            (${typeof script === 'function' ? script.toString() : script})(props);
          } catch (e) {
            console.error('Error executing script for component ${componentType} (ID: ${component.getId()})', e);
          }
        })();
      `);
      } else {
        console.log(
          `No script found for component ${componentType} (ID: ${component.getId()})`
        );
      }

      const traits = component.get('traits');
      if (traits && traits.length) {
        const traitData: Record<string, any> = {};
        traits.forEach((trait: any) => {
          const traitName = trait.get('name');
          const traitValue = trait.get('value');
          if (traitValue !== undefined) {
            traitData[traitName] = traitValue;
          }
        });
        if (Object.keys(traitData).length) {
          result.traits[component.getId()] = {
            type: componentType,
            traits: traitData
          };
        }
      }

      component.get('components')?.forEach((child: Component) => {
        collectScriptsAndTraits(child, result);
      });
    },
    []
  );

  const getTabsScript = () => {
    return `
// Tabs functionality
function initTabsStandalone() {
  const tabWrappers = document.querySelectorAll('.tabs-wrapper');
  
  tabWrappers.forEach(wrapper => {
    const tabButtons = wrapper.querySelectorAll('.tab-button');
    const tabPanes = wrapper.querySelectorAll('.tab-pane');
    
    function switchTab(tabId) {
      if (!tabId) return;
      
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabPanes.forEach(pane => pane.classList.remove('active'));
      
      const targetBtn = wrapper.querySelector('.tab-button[data-tab="' + tabId + '"]');
      const targetPane = wrapper.querySelector('.tab-pane[data-tab="' + tabId + '"]');
      
      if (targetBtn) targetBtn.classList.add('active');
      if (targetPane) targetPane.classList.add('active');
    }
    
    wrapper.addEventListener('click', function(e) {
      const tabBtn = e.target.closest('.tab-button');
      if (!tabBtn) return;
      
      const tabId = tabBtn.getAttribute('data-tab');
      switchTab(tabId);
      
      e.preventDefault();
      e.stopPropagation();
    });
    
    // Активируем первую вкладку, если нет активных
    const hasActive = wrapper.querySelector('.tab-button.active');
    if (!hasActive && tabButtons.length > 0) {
      const firstTabId = tabButtons[0].getAttribute('data-tab');
      switchTab(firstTabId);
    }
  });
}

// Initialize tabs when DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initTabsStandalone);
} else {
  initTabsStandalone();
}
`;
  };
  const collectStyles = useCallback(
    (component: Component, styles: string[]) => {
      const componentType = component.get('type') || component.get('tagName');
      const componentStyles = component.get('styles');
      if (componentStyles) {
        styles.push(componentStyles);
      } else {
        console.log(
          `No styles found for component ${componentType} (ID: ${component.getId()})`
        );
      }
      component.get('components')?.forEach((child: Component) => {
        collectStyles(child, styles);
      });
    },
    []
  );

  const tabsScript = getTabsScript();

  const setupEditorCommands = useCallback(
    (editor: Editor) => {
      editor.Commands.add('core:preview', {
        run: (editor, sender, options = {}) => {
          try {
            const html = editor.getHtml();
            const css = editor.getCss();

            // Добавляем скрипт для вкладок в превью
            const tabsScript = getTabsScript();

            const safeHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Preview</title>
      <style>
        ${css}
        body { 
          margin: 0; 
          padding: 20px; 
          background-color: #3D3AB81A;
          font-family: system-ui, -apple-system, sans-serif;
          height:100%;
        }
        .preview-wrapper {
          max-width: 1200px;
          margin: 0 auto;
          background: white;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
      </style>
    </head>
    <body>
      <div class="preview-wrapper">
        ${html}
      </div>
      <script>
        ${tabsScript}
      </script>
    </body>
    </html>
  `;

            const previewWindow = window.open('', '_blank');
            if (previewWindow) {
              previewWindow.document.write(safeHtml);
              previewWindow.document.close();
            } else {
              editor.Modal.open({
                title: 'Preview Error',
                content: 'Please allow popups to view the preview.'
              });
            }
          } catch (error) {
            editor.Modal.open({
              title: 'Error',
              content: 'Could not generate preview. Please try again.'
            });
          }
        }
      });

      editor.Commands.add('export-code', {
        run: (editor, sender, options = {}) => {
          editor.runCommand('save-chart-attributes');

          const html = editor.getHtml();
          let css = editor.getCss({ avoidProtected: true }) || '';

          const componentStyles: string[] = [];
          editor.getComponents().forEach((comp: Component) => {
            collectStyles(comp, componentStyles);
          });
          css += componentStyles.length
            ? '\n' + componentStyles.join('\n')
            : '';

          const result = {
            scripts: [] as string[],
            traits: {} as Record<string, any>
          };
          editor.getComponents().forEach((comp: Component) => {
            collectScriptsAndTraits(comp, result);
          });

          // Добавляем скрипт для вкладок в основной JS
          const tabsScript = getTabsScript();

          const js = `
// Tabs functionality
function initTabsStandalone() {
  const tabWrappers = document.querySelectorAll('.tabs-wrapper');
  
  tabWrappers.forEach(wrapper => {
    const tabButtons = wrapper.querySelectorAll('.tab-button');
    const tabPanes = wrapper.querySelectorAll('.tab-pane');
    
    function switchTab(tabId) {
      if (!tabId) return;
      
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabPanes.forEach(pane => pane.classList.remove('active'));
      
      const targetBtn = wrapper.querySelector('.tab-button[data-tab="' + tabId + '"]');
      const targetPane = wrapper.querySelector('.tab-pane[data-tab="' + tabId + '"]');
      
      if (targetBtn) targetBtn.classList.add('active');
      if (targetPane) targetPane.classList.add('active');
    }
    
    wrapper.addEventListener('click', function(e) {
      const tabBtn = e.target.closest('.tab-button');
      if (!tabBtn) return;
      
      const tabId = tabBtn.getAttribute('data-tab');
      switchTab(tabId);
      
      e.preventDefault();
      e.stopPropagation();
    });
    
    // Активируем первую вкладку, если нет активных
    const hasActive = wrapper.querySelector('.tab-button.active');
    if (!hasActive && tabButtons.length > 0) {
      const firstTabId = tabButtons[0].getAttribute('data-tab');
      switchTab(firstTabId);
    }
  });
}

// Widget functionality
window.addEventListener("DOMContentLoaded", function() {
  // Initialize tabs first
  initTabsStandalone();

  const componentRenderers = {
    text: function(el, data) {
      if (data?.[0]?.[0] != null) el.textContent = data[0][0];
    },
    button: function(el, data) {
      const label = el.querySelector('.button-label') || el;
      if (data?.[0]?.[0] != null) label.textContent = data[0][0];
    },
    image: function(el, data) {
      if (data?.[0]?.[0] != null) {
        el.src = data[0][0];
        el.alt = el.dataset.componentId || 'image';
      }
    },
    default: function(el, data) {
      if (data?.[0]?.[0] != null) el.textContent = data[0][0];
    }
  };

  const components = document.querySelectorAll('[data-component-id]');
  const componentMap = new Map();

  components.forEach(el => {
    const componentId = el.dataset.componentId;
    if (!componentId) return;

    componentMap.set(componentId, {
      el,
      name: componentId,
      type: detectType(el)
    });
  });

  function detectType(el) {
    const tag = el.tagName.toLowerCase();
    const classes = el.className.toLowerCase();
    if (tag === 'img' || classes.includes('image') || classes.includes('avatar')) return 'image';
    if (tag === 'button' || classes.includes('button') || classes.includes('btn')) return 'button';
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return 'input';
    return 'text';
  }

  if (!window.WZ) {
    console.error("[widget] WZ.js not loaded!");
    return;
  }

  WZ.bindComponents(function(components) {

    WZ.getWidgetMappings(result => {
      const mappings = result.mappings || [];

      mappings.forEach(mapping => {
        const component = components.find(c => 
          c.name === mapping.componentId || 
          c.id === mapping.componentId ||
          c.selector === mapping.selector
        );

        if (!component) return;

        const target = componentMap.get(component.name) || 
                      componentMap.get(component.id) ||
                      document.querySelector(component.selector);

        if (!target) {
          console.warn(\`[widget] Element not found for \${component.name}\`);
          return;
        }

        const compData = componentMap.get(component.name) || {};
        compData.mapping = mapping;
        componentMap.set(component.name, { ...compData, el: target });

        WZ.getMappingData(component.name, response => {

          const content = response?.[0]?.content;
          if (!content) return;

          const values = content.map(row => row[0]).filter(Boolean);
          const renderer = componentRenderers[detectType(target.el)] || componentRenderers.default;
          renderer(target.el, content);

          window.widgetData = window.widgetData || {};
          window.widgetData[component.name] = values;
        });
      });
    });
  });

  WZ.addEventListener("*", function(event) {
    try {
      const data = JSON.parse(event.data);
      if (data.type === "FILTER_MAPPING_DATA") {
        const compName = data.componentName;
        WZ.getMappingDataByFilter(compName, { filters: data.filters }, response => {
          const content = response?.[0]?.content;
          if (!content) return;

          const el = document.querySelector(\`[data-component-id="\${compName}"]\`);
          if (!el) return;

          const renderer = componentRenderers[detectType(el)] || componentRenderers.default;
          renderer(el, content);
        });
      }
    } catch (e) {}
  });

});
`;

          const htmlFileContent = `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Exported Page</title>
      <style>
        ${css}
        body { 
          margin: 0; 
          padding: 20px; 
          background-color: #3D3AB81A;
          font-family: system-ui, -apple-system, sans-serif;
          height:100%;
        }
      </style>
    </head>
    <body >
      ${html}
      <script>
        ${js}
      </script>
    </body>
  </html>
`;

          const cssFileContent = css;
          const jsFileContent = js;
          const createDownloadFile = (
            content: string,
            filename: string,
            mimeType: string
          ) => {
            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          };
          createDownloadFile(htmlFileContent, 'index.html', 'text/html');
          createDownloadFile(cssFileContent, 'styles.css', 'text/css');
          createDownloadFile(
            jsFileContent,
            'script.js',
            'application/javascript'
          );

          editor.Modal.open({
            title: 'Экспорт завершён',
            content:
              'Файлы index.html, styles.css и script.js успешно экспортированы!'
          });
        }
      });

      editor.Commands.add('save-chart-attributes', {
        run: (editor, sender, options = {}) => {
          const chartComponents = editor
            .getWrapper()
            ?.find('[data-component-id="chart"]');
          let savedCount = 0;

          chartComponents?.forEach((chartComp) => {
            try {
              const traits = chartComp.getTraits();
              const chartType =
                traits.find((t) => t.getName() === 'chart-type')?.getValue() ||
                'line';
              const title =
                traits.find((t) => t.getName() === 'title')?.getValue() ||
                'My Chart';

              chartComp.addAttributes({
                'data-chart-type': chartType,
                'data-title': title
              });
              savedCount++;
            } catch (error) {
              console.error('❌ Error saving chart attributes:', error);
            }
          });
          return savedCount > 0;
        }
      });
    },
    [collectScriptsAndTraits, collectStyles]
  );

  const setupEditorEvents = useCallback(
    (editor: Editor) => {
      const onComponentSelected = (component: Component) => {
        if (!component) return;
        updateStyleManagerSectors(component);
        props.setSelectedTab(0);
      };

      const onComponentAdd = (component: Component) => {
        if (editor.getSelected() === component) {
          updateStyleManagerSectors(component);
          props.setSelectedTab(0);
        }
      };

      const onComponentDeselected = () => {
        updateStyleManagerSectors(null);
        props.setSelectedTab(1);
      };

      const onStylePropertyUpdate = (event: any) => {
        const selected = editor.getSelected();
        if (!selected) return;

        const property =
          typeof event?.property === 'string'
            ? event.property
            : event?.property?.getName?.() ||
              event?.property?.get?.('property') ||
              event?.property?.get?.('name');

        if (!property) return;

        const value =
          event?.value ??
          event?.property?.getValue?.() ??
          event?.property?.get?.('value') ??
          '';

        selected.addStyle({ [String(property)]: String(value) });
      };

      const onPageSelect = () => {
        const mainComponent = editor.Pages.getSelected()?.getMainComponent();
        if (!mainComponent) return;

        const allRules = editor.Css.getRules();
        const componentRules = allRules.filter((rule) => {
          try {
            const selectors = rule.getSelectors();
            return selectors.some((selector: any) => {
              try {
                return (
                  selector.get('active') &&
                  mainComponent.find(
                    `[data-gjs-type="${selector.get('name')}"]`
                  ).length > 0
                );
              } catch {
                return false;
              }
            });
          } catch {
            return false;
          }
        });

        componentRules.forEach((rule) => {
          try {
            editor.Css.remove(rule);
          } catch (error) {
            console.warn('Failed to remove CSS rule:', error);
          }
        });
      };

      const onCanvasFrameLoad = ({ window }: { window: Window }) => {
        const canvasBody = window.document.body;
        if (canvasBody) {
          canvasBody.style.backgroundColor = '#3D3AB81A';
          canvasBody.style.border = '1px solid #3D3AB899';
        }
      };

      const onLoad = () => {
        if (!editor.Panels.getPanel?.('basic-actions')) {
          editor.Panels.addPanel({
            id: 'basic-actions',
            el: '.gjs-pn-buttons',
            buttons: [
              {
                id: 'visibility',
                active: true,
                label: '👁',
                command: 'sw-visibility'
              },
              {
                id: 'undo',
                label: '↺',
                command: 'core:undo'
              },
              {
                id: 'redo',
                label: '↻',
                command: 'core:redo'
              },
              {
                id: 'export',
                label: '📤',
                command: 'export-code'
              },
              {
                id: 'preview',
                label: '👀',
                command: 'core:preview',
                context: 'core:preview'
              }
            ]
          });
        }

        const canvasBody = editor.Canvas.getBody();
        if (canvasBody) {
          canvasBody.style.backgroundColor = '#3D3AB81A';
          canvasBody.style.border = '1px solid #3D3AB899';
        }
        editor.refresh();
      };

      const cleanup = () => {
        editor.off('component:selected', onComponentSelected);
        editor.off('component:add', onComponentAdd);
        editor.off('component:deselected', onComponentDeselected);
        editor.off('style:property:update', onStylePropertyUpdate);
        editor.off('page:select', onPageSelect);
        editor.off('canvas:frame:load', onCanvasFrameLoad);
        editor.off('load', onLoad);
        editor.off('destroy', cleanup);
      };

      editor.on('component:selected', onComponentSelected);
      editor.on('component:add', onComponentAdd);
      editor.on('component:deselected', onComponentDeselected);
      editor.on('style:property:update', onStylePropertyUpdate);
      editor.on('page:select', onPageSelect);
      editor.on('canvas:frame:load', onCanvasFrameLoad);
      editor.on('load', onLoad);
      editor.on('destroy', cleanup);

      return cleanup;
    },
    [updateStyleManagerSectors, props.setSelectedTab]
  );

  const onEditor = useCallback(
    (editor: Editor) => {
      props.editorRef.current = editor;
      unregisterEditorRef.current?.();
      unregisterEditorRef.current = registerEditor(
        'widget-template:main',
        editor,
        { activate: true }
      );

      registerComponents(editor);

      if (onOpenCode) {
        editor.Commands.add('core:open-code', {
          run: (editor) => {
            onOpenCode();
            editor.stopCommand('core:open-code');
          }
        });
      }
      editor.on('component:selected', (model) => {});

      componentEventsCleanupRef.current?.();
      componentEventsCleanupRef.current =
        componentManagement.setupComponentEventHandlers(editor);

      setupEditorCommands(editor);

      editorEventsCleanupRef.current?.();
      editorEventsCleanupRef.current = setupEditorEvents(editor);
    },
    [
      componentManagement,
      setupEditorCommands,
      setupEditorEvents,
      onOpenCode,
      props.editorRef
    ]
  );

  return {
    onEditor,
    updateStyleManagerSectors,
    componentCreationInProgress
  };
};
