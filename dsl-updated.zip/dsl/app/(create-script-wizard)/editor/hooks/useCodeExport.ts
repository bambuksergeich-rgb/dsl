import { useCallback } from 'react';
import type { Editor, Component } from 'grapesjs';
import { defaultVariables } from '../editorConfig';
import { collectCanvasComponents } from '../utils/codeGenerators'; // ✅ Это правильно!

export const useCodeExport = () => {
  const collectCSSVariables = useCallback(
    (component: Component, variables: Set<string>) => {
      const styles = component.getStyle();

      Object.values(styles).forEach((styleValue) => {
        if (typeof styleValue === 'string') {
          const varMatches = styleValue.match(/var\(--([^)]+)\)/g);
          if (varMatches) {
            varMatches.forEach((match) => {
              const varName = match.replace(/var\(--([^)]+)\)/, '$1');
              variables.add(varName);
            });
          }

          const declMatches = styleValue.match(/--[^:]+:/g);
          if (declMatches) {
            declMatches.forEach((match) => {
              const varName = match.replace(':', '').trim();
              variables.add(varName);
            });
          }
        }
      });

      component.get('components')?.forEach((child: Component) => {
        collectCSSVariables(child, variables);
      });
    },
    []
  );

  const generateCSSVariablesBlock = useCallback(
    (variables: Set<string>, editor: Editor): string => {
      if (variables.size === 0) return '';

      let cssVariables = ':root {\n';

      variables.forEach((variable) => {
        const defaultValue =
          defaultVariables[variable as keyof typeof defaultVariables] ||
          `/* TODO: Define value for ${variable} */`;
        cssVariables += `  ${variable}: ${defaultValue};\n`;
      });

      cssVariables += '}\n\n';
      return cssVariables;
    },
    []
  );

  const formatCSS = useCallback((css: string): string => {
    if (!css || css.trim() === '') return css;

    try {
      let formatted = '';
      let indentLevel = 0;
      let inComment = false;

      const lines = css.split('}');

      lines.forEach((line, index) => {
        line = line.trim();
        if (!line) return;

        if (line.includes('/*')) {
          inComment = true;
        }
        if (line.includes('*/')) {
          inComment = false;
        }

        if (inComment) {
          formatted += '  '.repeat(indentLevel) + line + '\n';
          return;
        }

        if (line.includes('{')) {
          const parts = line.split('{');
          const selector = parts[0].trim();
          const properties = parts[1] ? parts[1].trim() : '';

          formatted += '  '.repeat(indentLevel) + selector + ' {\n';
          indentLevel++;

          if (properties) {
            const props = properties.split(';').filter((prop) => prop.trim());
            props.forEach((prop) => {
              if (prop.trim()) {
                formatted += '  '.repeat(indentLevel) + prop.trim() + ';\n';
              }
            });
          }
        } else {
          const properties = line.split(';').filter((prop) => prop.trim());
          properties.forEach((prop) => {
            if (prop.trim()) {
              formatted += '  '.repeat(indentLevel) + prop.trim() + ';\n';
            }
          });
        }

        if (index < lines.length - 1 || line.endsWith('}')) {
          indentLevel = Math.max(0, indentLevel - 1);
          formatted += '  '.repeat(indentLevel) + '}\n\n';
        }
      });

      return formatted.trim();
    } catch (error) {
      console.warn('Failed to format CSS, returning original:', error);
      return css;
    }
  }, []);

  const formatHTML = useCallback((html: string): string => {
    if (!html || html.trim() === '') return html;

    try {
      let formatted = '';
      let indentLevel = 0;
      const tags = html.match(/<[^>]+>|[^<]+/g) || [];

      tags.forEach((tag) => {
        tag = tag.trim();
        if (!tag) return;

        if (tag.startsWith('</')) {
          indentLevel = Math.max(0, indentLevel - 1);
          formatted += '  '.repeat(indentLevel) + tag + '\n';
        } else if (
          tag.startsWith('<') &&
          !tag.endsWith('/>') &&
          !tag.includes('</')
        ) {
          formatted += '  '.repeat(indentLevel) + tag + '\n';
          if (!tag.includes('/>') && !tag.startsWith('<!')) {
            indentLevel++;
          }
        } else if (tag.startsWith('<!')) {
          formatted += '  '.repeat(indentLevel) + tag + '\n';
        } else if (tag.includes('</')) {
          const parts = tag.split('</');
          const openTag = parts[0];
          const closeTag = '</' + parts[1];
          formatted += '  '.repeat(indentLevel) + openTag + '\n';
          formatted += '  '.repeat(indentLevel) + closeTag + '\n';
        } else {
          formatted += '  '.repeat(indentLevel) + tag + '\n';
        }
      });

      return formatted.trim();
    } catch (error) {
      console.warn('Failed to format HTML, returning original:', error);
      return html;
    }
  }, []);

  // const formatJS = useCallback((js: string): string => {
  //   if (!js || js.trim() === '') return js;

  //   try {
  //     // ✅ КРИТИЧНО: Защищаем JSON строки от форматирования
  //     const jsonPlaceholders: Map<string, string> = new Map();
  //     let placeholderIndex = 0;

  //     // Сохраняем все строки с JSON (внутри двойных кавычек)
  //     let protected = js.replace(/"([^"\\]|\\.)*"/g, (match) => {
  //       // Если строка содержит JSON (начинается с [ или {)
  //       const content = match.slice(1, -1); // Убираем кавычки
  //       if (content.startsWith('[') || content.startsWith('{')) {
  //         const placeholder = `__JSON_PLACEHOLDER_${placeholderIndex}__`;
  //         jsonPlaceholders.set(placeholder, match);
  //         placeholderIndex++;
  //         return placeholder;
  //       }
  //       return match;
  //     });

  //     // Форматируем код БЕЗ JSON строк
  //     const formatted = protected
  //       .replace(/{/g, ' {\n')
  //       .replace(/}/g, '\n}\n')
  //       .replace(/;/g, ';\n')
  //       .replace(/\n\s*\n/g, '\n')
  //       .split('\n')
  //       .map((line) => {
  //         const trimmed = line.trim();
  //         if (trimmed === '') return '';

  //         let indent = 0;
  //         if (trimmed.startsWith('}') || trimmed.startsWith(')')) {
  //           indent = -1;
  //         }

  //         const currentIndent = Math.max(
  //           0,
  //           (line.match(/^(\s*)/)?.[0].length || 0) / 2 + indent
  //         );
  //         return '  '.repeat(currentIndent) + trimmed;
  //       })
  //       .filter((line) => line !== '')
  //       .join('\n')
  //       .trim();

  //     // ✅ Восстанавливаем JSON строки
  //     let result = formatted;
  //     jsonPlaceholders.forEach((original, placeholder) => {
  //       result = result.replace(placeholder, original);
  //     });

  //     return result;
  //   } catch (error) {
  //     console.warn('Failed to format JS, returning original:', error);
  //     return js;
  //   }
  // }, []);

  const formatJS = useCallback((js: string): string => {
    if (!js || js.trim() === '') return js;

    try {
      const stringPlaceholders: Map<string, string> = new Map();
      let placeholderIndex = 0;

      // ✅ Сохраняем все строковые литералы
      const protectedJs = js.replace(
        /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/g,
        (match) => {
          const placeholder = `__STR_${placeholderIndex}__`;
          stringPlaceholders.set(placeholder, match);
          placeholderIndex++;
          return placeholder;
        }
      );

      // ✅ УЛУЧШЕНО: Более аккуратное форматирование
      const formatted = protectedJs
        .replace(/\s*{\s*/g, ' {\n') // { с пробелом
        .replace(/\s*}\s*/g, '\n}\n') // }
        .replace(/;(?!\s*$)/g, ';\n') // ; но не в конце строки
        .replace(/\n{2,}/g, '\n') // Убираем двойные переносы
        .split('\n')
        .map((line) => {
          const trimmed = line.trim();
          if (trimmed === '') return '';

          // Подсчёт отступов
          let depth = 0;
          for (let i = 0; i < line.length; i++) {
            if (line[i] === '{') depth++;
            if (line[i] === '}') depth--;
          }

          const indent = Math.max(0, depth);
          return '  '.repeat(indent) + trimmed;
        })
        .filter((line) => line !== '')
        .join('\n')
        .trim();

      // Восстанавливаем строки
      let result = formatted;
      stringPlaceholders.forEach((original, placeholder) => {
        result = result.replace(new RegExp(placeholder, 'g'), original);
      });

      return result;
    } catch (error) {
      console.warn('Failed to format JS, returning original:', error);
      return js;
    }
  }, []);

  const formatCode = useCallback(
    (code: string, type: 'html' | 'css' | 'js'): string => {
      if (!code || code.trim() === '') return code;

      try {
        switch (type) {
          case 'html':
            return formatHTML(code);
          case 'css':
            return formatCSS(code);
          case 'js':
            return formatJS(code);
          default:
            return code;
        }
      } catch (error) {
        console.warn(`Failed to format ${type} code:`, error);
        return code;
      }
    },
    [formatHTML, formatCSS, formatJS]
  );

  return {
    collectCSSVariables,
    generateCSSVariablesBlock,
    collectCanvasComponents, // ✅ Экспортируем импортированную функцию
    formatCode
  };
};
