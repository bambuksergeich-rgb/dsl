import { useCallback } from 'react';
import { store } from '@/src/store/store';
import { updateWidgetTemplateDraft } from '@/src/store/actions/updateWidgetTemplateDraft';
import { uploadWidgetTemplateFileRequest } from '@/src/requests/uploadWidgetTemplateFileRequest';
import { openSnackBarAction } from '@/src/store/actions/openSnackBar';
import { SnackType } from '@/src/store/counter/snackBarSlice';
import { sanitizePath } from '@/src/helpers/basePrefix';
import { normalizeHTMLWithCharts } from '../utils/codeGenerators';

interface UseWidgetSaveProps {
  departmentId: string;
  widgetTemplateDraftId: string;
  name: string;
  description: string;
  widgetTemplateDraft: any;
  widgetTemplateFiles: any[];
  groups: any;
  getEditorCode: () => {
    html: string;
    css: string;
    js: string;
    pages: Array<{ id: string; name: string; html: string; css?: string }>;
    currentPageId?: string;
  };
  formatCode: (code: string, type: 'html' | 'css' | 'js') => string;
  setIsSaving: (saving: boolean) => void;
  router: any;
}

const showToast = (message: string, type: 'success' | 'error' = 'success') => {
  let toastContainer = document.getElementById('gjs-custom-toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'gjs-custom-toast-container';
    Object.assign(toastContainer.style, {
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '12px',
      zIndex: '10000',
      pointerEvents: 'none'
    });
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement('div');
  Object.assign(toast.style, {
    backgroundColor: type === 'success' ? '#10161C' : '#d32f2f',
    color: '#fff',
    padding: '16px 24px',
    borderRadius: '8px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
    border: '1px solid rgba(255,255,255,0.1)',
    fontFamily: 'Montserrat, sans-serif',
    fontSize: '14px',
    fontWeight: '500',
    opacity: '0',
    transform: 'translateX(100%)',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    pointerEvents: 'auto',
    minWidth: '300px',
    display: 'flex',
    alignItems: 'center'
  });

  toast.innerHTML = `<span>${message}</span>`;
  toastContainer.appendChild(toast);

  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(0)';
  });

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(20px)';

    setTimeout(() => {
      if (toast.parentNode) toast.remove();
      if (toastContainer && toastContainer.childNodes.length === 0) {
        toastContainer.remove();
      }
    }, 300);
  }, 3000);
};

export const useWidgetSave = (props: UseWidgetSaveProps) => {
  const {
    departmentId,
    widgetTemplateDraftId,
    name,
    description,
    widgetTemplateDraft,
    widgetTemplateFiles,
    groups,
    getEditorCode,
    formatCode,
    setIsSaving,
    router
  } = props;

  const handleCreateWidgetTemplate = useCallback(
    async (redirectTo?: string) => {
      if (typeof window === 'undefined') return;

      if (!departmentId || !name?.trim() || !widgetTemplateDraftId) {
        store.dispatch(
          openSnackBarAction(SnackType.warning, 'Enter a widget name!', true)
        );
        return;
      }

      setIsSaving(true);

      try {
        const { html, css, js, pages, currentPageId } = getEditorCode();

        if ((!pages || pages.length === 0) && (!html || html.length < 10)) {
          throw new Error('No content to save');
        }

        const formattedGlobalJs = formatCode(js, 'js');
        const groupId =
          widgetTemplateDraft.groupId || groups.content?.[0]?.id || '';
        const effectiveSourceId =
          widgetTemplateDraft.sourceId || widgetTemplateDraftId;

        const uploadPromises: Promise<any>[] = [];

        const findExistingFile = (fileName: string) => {
          if (!widgetTemplateFiles) return null;
          return widgetTemplateFiles.find((f) => f.name === fileName);
        };

        const uploadOrUpdate = (
          content: string,
          fileName: string,
          contentType: string,
          defaultPath: string
        ) => {
          const existingFile = findExistingFile(fileName);
          const path = existingFile ? existingFile.path : defaultPath;

          uploadPromises.push(
            uploadWidgetTemplateFileRequest(
              content,
              widgetTemplateDraftId,
              contentType,
              fileName,
              path,
              effectiveSourceId
            )
          );
        };

        const cleanHtmlContent = (rawHtml: string) => {
          if (!rawHtml) return '';
          if (rawHtml.includes('<html') || rawHtml.includes('<body')) {
            try {
              const parser = new DOMParser();
              const doc = parser.parseFromString(rawHtml, 'text/html');
              return doc.body.innerHTML;
            } catch (e) {
              console.warn('Failed to parse HTML, returning raw', e);
              return rawHtml;
            }
          }
          return rawHtml;
        };

        const cleanHtmlFromAttributes = (htmlString: string): string => {
          let cleaned = htmlString.replace(
            /data-tabs="([^"]*)"/g,
            (match, jsonContent) => {
              const sanitized = jsonContent
                .replace(/\\r\\n|\\r|\\n/g, '')
                .replace(/\r\n|\r|\n/g, '')
                .replace(/\s{2,}/g, ' ')
                .trim();
              return `data-tabs="${sanitized}"`;
            }
          );

          cleaned = cleaned.replace(
            /data-([a-z-]+)="([^"]*)"/g,
            (match, attrName, attrValue) => {
              if (attrValue.length < 20) return match;

              const sanitized = attrValue
                .replace(/\\r\\n|\\r|\\n/g, '')
                .replace(/\r\n|\r|\n/g, '')
                .replace(/\s{2,}/g, ' ')
                .trim();
              return `data-${attrName}="${sanitized}"`;
            }
          );

          return cleaned;
        };

        if (pages && pages.length > 0) {
          const firstPageId = pages[0]?.id;

          pages.forEach((page, pageIndex) => {
            const isFirstPage = pageIndex === 0 || page.id === firstPageId;

            let baseName = '';
            if (isFirstPage) {
              baseName = 'index';
            } else {
              baseName = page.name
                ? page.name
                    .trim()
                    .toLowerCase()
                    .replace(/[^a-z0-9]/g, '-')
                : `page-${page.id}`;
            }

            const htmlFileName = `${baseName}.html`;
            const cssFileName = `${baseName}.css`;
            const jsFileName = `${baseName}.js`;

            const pageRawCss = page.css || css;
            const formattedPageCss = formatCode(pageRawCss, 'css');

            if (isFirstPage || formattedPageCss.length > 0) {
              uploadOrUpdate(formattedPageCss, cssFileName, 'text/css', '/css');
            }

            if (isFirstPage || formattedGlobalJs.length > 0) {
              uploadOrUpdate(
                formattedGlobalJs,
                jsFileName,
                'text/javascript',
                '/js'
              );
            }

            const cleanedHtml = cleanHtmlContent(page.html);
            const sanitizedHtml = cleanHtmlFromAttributes(cleanedHtml);
            const formattedHtml = formatCode(sanitizedHtml, 'html');

            const hasChartComponents =
              formattedHtml.includes('data-component-id="chart"') ||
              formattedHtml.includes('data-component-id="bar-chart"') ||
              formattedHtml.includes('data-component-id="pie-chart-json"');

            const fullPageContent = normalizeHTMLWithCharts(
              formattedHtml,
              page.name,
              hasChartComponents,
              widgetTemplateFiles,
              cssFileName,
              jsFileName
            );

            console.log(`📄 Generated HTML for ${htmlFileName}:`, {
              hasCharts: hasChartComponents,
              hasWzJs: widgetTemplateFiles?.some((f) => f.name === 'wz.js'),
              cssFile: cssFileName,
              jsFile: jsFileName,
              attributesCleaned: true,
              contentLength: fullPageContent.length
            });

            uploadOrUpdate(fullPageContent, htmlFileName, 'text/html', '/html');
          });
        }

        await Promise.all(uploadPromises);

        await store.dispatch(
          updateWidgetTemplateDraft(
            widgetTemplateDraftId,
            name.trim(),
            (description || '').trim(),
            groupId,
            true
          )
        );

        showToast(`Widget template successfully saved!`, 'success');

        const widgetData = {
          widgetTemplateDraftId,
          widgetTemplateId:
            widgetTemplateDraft.sourceId || widgetTemplateDraftId,
          name: name.trim(),
          description: (description || '').trim()
        };

        if (!redirectTo) {
          setTimeout(() => {
            const params = new URLSearchParams({
              departmentId,
              widgetTemplateDraftId,
              createConfiguration: '1'
            });
            const sourceId = String(widgetTemplateDraft.sourceId || '').trim();
            if (sourceId) params.set('widgetTemplateId', sourceId);
            router.push(
              sanitizePath(`/widget_configuration?${params.toString()}`)
            );
          }, 0);
        }

        return widgetData;
      } catch (error: any) {
        showToast(`Error saving widget: ${error.message}`, 'error');
        throw error;
      } finally {
        setIsSaving(false);
      }
    },
    [
      departmentId,
      widgetTemplateDraftId,
      name,
      description,
      widgetTemplateDraft,
      widgetTemplateFiles,
      groups,
      getEditorCode,
      formatCode,
      setIsSaving,
      router
    ]
  );

  return {
    handleCreateWidgetTemplate
  };
};
