import { useCallback } from 'react';
import type { Editor, Component } from 'grapesjs';

import {
  generateWidgetJS,
  normalizeHTMLWithCharts,
  collectCanvasComponents,
  hasChartComponents,
  type CanvasComponent
} from '../utils/codeGenerators';
import { defaultVariables } from '../editorConfig';
import { withAppScrollbarCss } from '@/src/helpers/appScrollbar';

export const useCodeGeneration = () => {
  const collectCSSVariables = useCallback(
    (component: Component, variables: Set<string>) => {
      const styles = component.getStyle();

      Object.values(styles).forEach((styleValue) => {
        if (typeof styleValue === 'string') {
          const varMatches = styleValue.match(/var\(--([^)]+)\)/g);
          if (varMatches) {
            varMatches.forEach((match) => {
              const varName = match.replace(/var\(--([^)]+)\)/, '$1');
              variables.add(varName);
            });
          }

          const declMatches = styleValue.match(/--[^:]+:/g);
          if (declMatches) {
            declMatches.forEach((match) => {
              const varName = match.replace(':', '').trim();
              variables.add(varName);
            });
          }
        }
      });

      component.get('components')?.forEach((child: Component) => {
        collectCSSVariables(child, variables);
      });
    },
    []
  );

  const generateCSSVariablesBlock = useCallback(
    (variables: Set<string>, editor: Editor): string => {
      if (variables.size === 0) return '';

      let cssVariables = ':root {\n';

      variables.forEach((variable) => {
        const defaultValue =
          defaultVariables[variable as keyof typeof defaultVariables] ||
          `/* TODO: Define value for ${variable} */`;
        cssVariables += `  ${variable}: ${defaultValue};\n`;
      });

      cssVariables += '}\n\n';
      return cssVariables;
    },
    []
  );

  /**
   * Processes a single page's content.
   * - Collects CSS variables used in this page.
   * - Collects canvas components for JS generation.
   * - Checks for charts.
   * - Normalizes HTML (adds chart attributes, etc.).
   */
  const processPageContent = useCallback(
    (
      editor: Editor,
      rootComponent: Component,
      rawHtml: string,
      name: string
    ) => {
      // 1. Collect CSS Variables specific to this page component tree
      const cssVariables = new Set<string>();
      collectCSSVariables(rootComponent, cssVariables);
      const variablesBlock = generateCSSVariablesBlock(cssVariables, editor);

      // 2. Collect Canvas Components (for JS mapping)
      const canvasComponents: CanvasComponent[] = [];
      collectCanvasComponents(rootComponent, canvasComponents);

      // 3. Check for Chart components
      const { hasAny } = hasChartComponents(canvasComponents);

      // 4. Normalize HTML (Inject chart attributes, etc.)
      const finalHtml = normalizeHTMLWithCharts(rawHtml, name, hasAny);

      return {
        html: finalHtml,
        cssVariables: variablesBlock,
        canvasComponents // Возвращаем компоненты для JS генерации
      };
    },
    [collectCSSVariables, generateCSSVariablesBlock]
  );

  const getEditorCode = useCallback(
    (editor: Editor, name: string) => {
      if (!editor) {
        console.warn('❌ Editor not found');
        return { html: '', css: '', js: '' };
      }

      try {
        // Run any preparation commands
        if (editor.runCommand) {
          editor.runCommand('save-chart-attributes');
        }

        const rawHtml = editor.getHtml();
        const rawCss =
          editor.getCss({
            avoidProtected: true,
            json: false,
            clearStyles: false
          }) || '';

        // Use the shared processing logic for the current editor view
        const wrapper = editor.getWrapper();

        if (!wrapper) {
          console.warn('⚠️ No wrapper found, returning raw code');
          return { html: rawHtml, css: rawCss, js: '' };
        }

        const {
          html: finalHtml,
          cssVariables,
          canvasComponents
        } = processPageContent(editor, wrapper, rawHtml, name);

        const fullCss = withAppScrollbarCss(cssVariables + rawCss);

        const allCanvasComponents: CanvasComponent[] = [];

        editor.Pages.getAll().forEach((page: any) => {
          const component = page.getMainComponent();
          collectCanvasComponents(component, allCanvasComponents);
        });

        // Передаём canvasComponents в generateWidgetJS
        const js = generateWidgetJS(canvasComponents);

        return { html: finalHtml, css: fullCss, js };
      } catch (error) {
        console.error('❌ Error generating editor code:', error);
        return { html: '', css: '', js: '' };
      }
    },
    [processPageContent]
  );

  const formatCSS = useCallback((css: string): string => {
    if (!css || css.trim() === '') return css;

    try {
      let formatted = '';
      let indentLevel = 0;
      let inComment = false;

      const lines = css.split('}');

      lines.forEach((line, index) => {
        line = line.trim();
        if (!line) return;

        if (line.includes('/*')) {
          inComment = true;
        }
        if (line.includes('*/')) {
          inComment = false;
        }

        if (inComment) {
          formatted += '  '.repeat(indentLevel) + line + '\n';
          return;
        }

        if (line.includes('{')) {
          const parts = line.split('{');
          const selector = parts[0].trim();
          const properties = parts[1] ? parts[1].trim() : '';

          formatted += '  '.repeat(indentLevel) + selector + ' {\n';
          indentLevel++;

          if (properties) {
            const props = properties.split(';').filter((prop) => prop.trim());
            props.forEach((prop) => {
              if (prop.trim()) {
                formatted += '  '.repeat(indentLevel) + prop.trim() + ';\n';
              }
            });
          }
        } else {
          const properties = line.split(';').filter((prop) => prop.trim());
          properties.forEach((prop) => {
            if (prop.trim()) {
              formatted += '  '.repeat(indentLevel) + prop.trim() + ';\n';
            }
          });
        }

        if (index < lines.length - 1 || line.endsWith('}')) {
          indentLevel = Math.max(0, indentLevel - 1);
          formatted += '  '.repeat(indentLevel) + '}\n\n';
        }
      });

      return formatted.trim();
    } catch (error) {
      console.warn('Failed to format CSS, returning original:', error);
      return css;
    }
  }, []);

  const formatHTML = useCallback((html: string): string => {
    if (!html || html.trim() === '') return html;

    try {
      let formatted = '';
      let indentLevel = 0;
      const tags = html.match(/<[^>]+>|[^<]+/g) || [];

      tags.forEach((tag) => {
        tag = tag.trim();
        if (!tag) return;

        if (tag.startsWith('</')) {
          indentLevel = Math.max(0, indentLevel - 1);
          formatted += '  '.repeat(indentLevel) + tag + '\n';
        } else if (
          tag.startsWith('<') &&
          !tag.endsWith('/>') &&
          !tag.includes('</')
        ) {
          formatted += '  '.repeat(indentLevel) + tag + '\n';
          if (!tag.includes('/>') && !tag.startsWith('<!')) {
            indentLevel++;
          }
        } else if (tag.startsWith('<!')) {
          formatted += '  '.repeat(indentLevel) + tag + '\n';
        } else if (tag.includes('</')) {
          const parts = tag.split('</');
          const openTag = parts[0];
          const closeTag = '</' + parts[1];
          formatted += '  '.repeat(indentLevel) + openTag + '\n';
          formatted += '  '.repeat(indentLevel) + closeTag + '\n';
        } else {
          formatted += '  '.repeat(indentLevel) + tag + '\n';
        }
      });

      return formatted.trim();
    } catch (error) {
      console.warn('Failed to format HTML, returning original:', error);
      return html;
    }
  }, []);

  // const formatJS = useCallback((js: string): string => {
  //   if (!js || js.trim() === '') return js;

  //   try {
  //     // ✅ КРИТИЧНО: Защищаем JSON строки от форматирования
  //     const jsonPlaceholders: Map<string, string> = new Map();
  //     let placeholderIndex = 0;

  //     // Сохраняем все строки с JSON (внутри двойных и одинарных кавычек)
  //     const protectedJs = js.replace(
  //       /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/g,
  //       (match) => {
  //         // Проверяем содержимое строки (убираем кавычки)
  //         const content = match.slice(1, -1);

  //         // Если строка содержит JSON (начинается с [ или { или содержит много {})
  //         if (
  //           content.startsWith('[') ||
  //           content.startsWith('{') ||
  //           (content.includes('{') && content.includes('}'))
  //         ) {
  //           const placeholder = `__JSON_PLACEHOLDER_${placeholderIndex}__`;
  //           jsonPlaceholders.set(placeholder, match);
  //           placeholderIndex++;
  //           return placeholder;
  //         }
  //         return match;
  //       }
  //     );

  //     // Форматируем код БЕЗ JSON строк
  //     const formatted = protectedJs
  //       .replace(/{/g, ' {\n')
  //       .replace(/}/g, '\n}\n')
  //       .replace(/;/g, ';\n')
  //       .replace(/\n\s*\n/g, '\n')
  //       .split('\n')
  //       .map((line) => {
  //         const trimmed = line.trim();
  //         if (trimmed === '') return '';

  //         let indent = 0;
  //         if (trimmed.startsWith('}') || trimmed.startsWith(')')) {
  //           indent = -1;
  //         }

  //         const currentIndent = Math.max(
  //           0,
  //           (line.match(/^(\s*)/)?.[0].length || 0) / 2 + indent
  //         );
  //         return '  '.repeat(currentIndent) + trimmed;
  //       })
  //       .filter((line) => line !== '')
  //       .join('\n')
  //       .trim();

  //     // ✅ КРИТИЧНО: Восстанавливаем JSON строки на их места
  //     let result = formatted;
  //     jsonPlaceholders.forEach((original, placeholder) => {
  //       result = result.replace(placeholder, original);
  //     });

  //     return result;
  //   } catch (error) {
  //     console.warn('Failed to format JS, returning original:', error);
  //     return js;
  //   }
  // }, []);

  const formatJS = useCallback((js: string): string => {
    if (!js || js.trim() === '') return js;

    try {
      const stringPlaceholders: Map<string, string> = new Map();
      let placeholderIndex = 0;

      // ✅ КРИТИЧНО: Сохраняем ВСЕ строковые литералы (не только JSON)
      const protectedJs = js.replace(
        /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/g,
        (match) => {
          const placeholder = `__STRING_PLACEHOLDER_${placeholderIndex}__`;
          stringPlaceholders.set(placeholder, match);
          placeholderIndex++;
          return placeholder;
        }
      );

      // Форматируем код БЕЗ строковых литералов
      const formatted = protectedJs
        .replace(/{/g, ' {\n')
        .replace(/}/g, '\n}\n')
        .replace(/;/g, ';\n') // ← Теперь безопасно!
        .replace(/\n\s*\n/g, '\n')
        .split('\n')
        .map((line) => {
          const trimmed = line.trim();
          if (trimmed === '') return '';

          let indent = 0;
          if (trimmed.startsWith('}') || trimmed.startsWith(')')) {
            indent = -1;
          }

          const currentIndent = Math.max(
            0,
            (line.match(/^(\s*)/)?.[0].length || 0) / 2 + indent
          );
          return '  '.repeat(currentIndent) + trimmed;
        })
        .filter((line) => line !== '')
        .join('\n')
        .trim();

      let result = formatted;
      stringPlaceholders.forEach((original, placeholder) => {
        result = result.replace(new RegExp(placeholder, 'g'), original);
      });

      return result;
    } catch (error) {
      console.warn('Failed to format JS, returning original:', error);
      return js;
    }
  }, []);

  const formatCode = useCallback(
    (code: string, type: 'html' | 'css' | 'js'): string => {
      if (!code || code.trim() === '') return code;

      try {
        switch (type) {
          case 'html':
            return formatHTML(code);
          case 'css':
            return formatCSS(code);
          case 'js':
            return formatJS(code);
          default:
            return code;
        }
      } catch (error) {
        console.warn(`Failed to format ${type} code:`, error);
        return code;
      }
    },
    [formatHTML, formatCSS, formatJS]
  );

  return {
    getEditorCode,
    processPageContent,
    collectCSSVariables,
    generateCSSVariablesBlock,
    formatCode,
    formatCSS,
    formatHTML,
    formatJS
  };
};
