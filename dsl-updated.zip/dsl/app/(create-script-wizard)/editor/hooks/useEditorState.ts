import { useState, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter, useSearchParams } from 'next/navigation';

import { State } from '@/src/store/initialState';
import { AppDispatch, store } from '@/src/store/store';
import { createWidgetTemplateDraft } from '@/src/store/actions/createWidgetTemplateDraft';
import { getWidgetTemplateFiles } from '@/src/store/actions/getWidgetTemplateFiles';

export const useEditorState = () => {
  const dispatch = useDispatch<AppDispatch>();
  const searchParams = useSearchParams();
  const router = useRouter();

  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState<number>(1);
  const [departmentId, setDepartmentId] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [name, setName] = useState<string>(`Test GrapesJSWidget ${Date.now()}`);
  const [description, setDescription] = useState<string>('');
  const [isTitleModalOpen, setIsTitleModalOpen] = useState(false);
  const [tempName, setTempName] = useState(name);
  const [tempDescription, setTempDescription] = useState(description);
  const [widgetTemplateDraftId, setWidgetTemplateDraftId] =
    useState<string>('');
  const [isDraftReady, setIsDraftReady] = useState(false);

  const widgetTemplateDraft = useSelector(
    (state: State) => state.widgetTemplateDraft
  );

  const widgetTemplateFiles = useSelector(
    (state: State) => state.widgetTemplateFiles
  );

  const groups = useSelector((state: State) => state.groups);
  const handleOpenCodeModal = useCallback(() => setIsCodeModalOpen(true), []);
  const handleCloseCodeModal = useCallback(() => setIsCodeModalOpen(false), []);

  const handleOpenTitleModal = useCallback(() => {
    setTempName(name);
    setTempDescription(description);
    setIsTitleModalOpen(true);
  }, [name, description]);

  const handleSaveTitleData = useCallback(() => {
    setName(tempName);
    setDescription(tempDescription);
    setIsTitleModalOpen(false);
  }, [tempName, tempDescription]);

  const handleCloseTitleModal = useCallback(() => {
    setIsTitleModalOpen(false);
  }, []);

  const handleComponentSelected = useCallback(() => {
    setSelectedTab(0);
  }, []);

  const handleComponentDeselected = useCallback(() => {
    setSelectedTab(1);
  }, []);

  useEffect(() => {
    if (
      widgetTemplateDraft.draftId &&
      widgetTemplateDraft.draftId !== widgetTemplateDraftId
    ) {
      setWidgetTemplateDraftId(widgetTemplateDraft.draftId);
      setIsDraftReady(true);

      store.dispatch(
        getWidgetTemplateFiles(
          widgetTemplateDraft.draftId,
          widgetTemplateDraft.sourceId
        )
      );
    }
  }, [widgetTemplateDraft, widgetTemplateDraftId]);

  useEffect(() => {
    const depId = searchParams.get('departmentId');
    const sourceId =
      searchParams.get('widgetTemplateId') || searchParams.get('sourceId');

    if (depId) setDepartmentId(depId);
    if (depId && sourceId) {
      store.dispatch(createWidgetTemplateDraft(depId, sourceId));
    }
  }, [searchParams]);

  useEffect(() => {
    if (widgetTemplateFiles) {
      const fileTypes = widgetTemplateFiles.map((f) => f.contentType);
      const missingTypes = ['text/html', 'text/css', 'text/javascript'].filter(
        (type) => !fileTypes.includes(type)
      );
    }
  }, [widgetTemplateFiles]);

  return {
    // State
    selectedTab,
    departmentId,
    isSaving,
    name,
    description,
    isTitleModalOpen,
    tempName,
    tempDescription,
    widgetTemplateDraftId,
    isDraftReady,

    // Redux state
    widgetTemplateDraft,
    widgetTemplateFiles,
    groups,

    // Setters
    setSelectedTab,
    setIsSaving,
    setName,
    setDescription,
    setTempName,
    setTempDescription,
    setWidgetTemplateDraftId,
    setIsDraftReady,
    setDepartmentId,

    // Handlers
    handleOpenTitleModal,
    handleSaveTitleData,
    handleCloseTitleModal,
    handleComponentSelected,
    handleComponentDeselected,

    // Other
    dispatch,
    router,

    //Code Editor Mode
    isCodeModalOpen,
    handleOpenCodeModal,
    handleCloseCodeModal
  };
};
