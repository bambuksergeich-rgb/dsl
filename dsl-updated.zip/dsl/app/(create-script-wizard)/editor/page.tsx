'use client';

import { Suspense } from 'react';
import { Loading } from '@/src/components/Loading/Loading';
import dynamic from 'next/dynamic';

const EditorContent = dynamic(() => import('./EditorContent'), {
  ssr: false,
  loading: () => <Loading />
});

export default function EditorPage() {
  return (
    <Suspense fallback={<Loading />}>
      <EditorContent />
    </Suspense>
  );
}
