import { getActiveEditor } from '@/src/editor/editorRegistry';
import { createTheme } from '@mui/material/styles';
import { EditorConfig, Component } from 'grapesjs';

const PROJECT_ID = 'my-website-project-';
// const hasSavedData = () => {
//   if (typeof window === 'undefined') return false; // Server-side check

//   // Check if GrapesJS has saved the components JSON
//   const savedData = localStorage.getItem(`${PROJECT_ID}components`);
//   return !!savedData && savedData !== '[]' && savedData !== '{}';
// };

export const MAIN_BORDER_COLOR = 'border-gray-700';

const LAYOUT_COMPONENT_TYPES = [
  'container',
  'section',
  'row',
  'column',
  'grid',
  'panel',
  'form',
  'table',
  'tabs',
  'grouper',
  'drawer',
  'news',
  'list',
  'tree',
  'carousel',
  'chart',
  'bar-chart',
  'pie-chart',
  'iframe',
  'drag-area'
];

const layoutTypeNotSelectors = LAYOUT_COMPONENT_TYPES.map(
  (type) => `:not([data-gjs-type="${type}"])`
).join('');

const layoutTypeSet = new Set(LAYOUT_COMPONENT_TYPES);

function shrinkWrapComponent(component: Component) {
  if (component.is?.('wrapper') || component.get('type') === 'wrapper') {
    component.components().forEach((child: Component) => shrinkWrapComponent(child));
    return;
  }
  const type = String(component.get('type') || '');
  if (layoutTypeSet.has(type)) {
    component.components().forEach((child: Component) => shrinkWrapComponent(child));
    return;
  }
  const style = { ...(component.getStyle() || {}) } as Record<string, any>;
  let changed = false;
  if (style.width === '100%' || style.width === 'auto') {
    delete style.width;
    changed = true;
  }
  if (style.height === '100%' || style.height === 'auto') {
    delete style.height;
    changed = true;
  }
  if (changed) {
    component.setStyle(style);
  }
  component.components().forEach((child: Component) => shrinkWrapComponent(child));
}

const CANVAS_SELECTION_CSS = `
.gjs-selected,
.gjs-hovered,
.gjs-hovered:not(.gjs-selected) {
  outline: none !important;
  outline-offset: 0 !important;
  box-shadow: none !important;
}
.gjs-selected-parent {
  outline: none !important;
  box-shadow: none !important;
  border: none !important;
}
body.gjs-selected,
body.gjs-hovered,
body.gjs-selected-parent,
[data-gjs-type="wrapper"].gjs-selected,
[data-gjs-type="wrapper"].gjs-hovered,
[data-gjs-type="wrapper"].gjs-selected-parent {
  outline: none !important;
  box-shadow: none !important;
  border: none !important;
}
[data-gjs-type="wrapper"] > [data-gjs-type]${layoutTypeNotSelectors} {
  width: fit-content;
  height: fit-content;
  max-width: 100%;
  display: inline-flex;
  vertical-align: top;
  box-sizing: border-box;
}
`;

export const theme = createTheme({
  palette: { mode: 'dark' }
});

export const customTemplates: any[] = [
  {
    name: 'Index',
    styles: `
      body {
        /* Используем Flow-root или Block, чтобы избежать проблем с dnd на пустой холст */
        display: block;
        width: 100%;
        min-height: 100vh;
        margin: 0;
        background-color: #3D3AB81A;
        border: 1px solid #3D3AB899;
      }
      `
  }
  // {
  //   name: 'About Page',
  //   component: `
  //     <div class="container mx-auto p-4">
  //     </div>
  //   `,
  //   styles: `
  //     body {
  //       /* Используем Flow-root или Block, чтобы избежать проблем с dnd на пустой холст */
  //       display: block;
  //       width: 100%;
  //       min-height: 100vh;
  //       margin: 0;
  //       background-color: #3D3AB81A;
  //       border: 1px solid #3D3AB899;
  //     }
  //     `
  // }
];

export const bodyStyleSectors = [
  // --- 1. Layout Mode (Настройки РОДИТЕЛЯ) ---
  // Эти настройки управляют тем, как body располагает СВОИХ детей.
  {
    id: 'layout-mode',
    name: 'Layout Mode',
    open: true,
    properties: [
      {
        id: 'display',
        name: 'Display',
        property: 'display',
        type: 'select',
        default: 'block',
        options: [
          { value: 'block', name: 'Block' },
          { value: 'flex', name: 'Flex' },
          { value: 'grid', name: 'Grid' }
        ]
      },
      {
        id: 'flex-direction',
        name: 'Direction',
        property: 'flex-direction',
        type: 'radio',
        default: 'row',
        options: [
          { value: 'row', title: 'Row' },
          { value: 'column', title: 'Column' }
        ],
        requires: { display: ['flex'] }
      },
      {
        id: 'flex-wrap',
        name: 'Wrap',
        property: 'flex-wrap',
        type: 'select',
        default: 'nowrap',
        options: [
          { value: 'nowrap', name: 'No Wrap' },
          { value: 'wrap', name: 'Wrap' },
          { value: 'wrap-reverse', name: 'Reverse' }
        ],
        requires: { display: ['flex'] }
      },
      {
        id: 'grid-template-columns',
        name: 'Grid Columns',
        property: 'grid-template-columns',
        type: 'text',
        default: '1fr 1fr',
        placeholder: '1fr 1fr 1fr',
        requires: { display: ['grid'] }
      },
      {
        id: 'grid-template-rows',
        name: 'Grid Rows',
        property: 'grid-template-rows',
        type: 'text',
        default: 'auto',
        requires: { display: ['grid'] }
      },
      {
        id: 'gap',
        name: 'Gap',
        property: 'gap',
        type: 'number',
        units: ['px', '%', 'rem'],
        default: '0',
        requires: { display: ['flex', 'grid'] }
      },
      {
        id: 'justify-content',
        name: 'Justify Content',
        property: 'justify-content',
        type: 'select',
        default: 'flex-start',
        options: [
          { value: 'flex-start', name: 'Start' },
          { value: 'center', name: 'Center' },
          { value: 'flex-end', name: 'End' },
          { value: 'space-between', name: 'Space Between' },
          { value: 'space-around', name: 'Space Around' }
        ],
        requires: { display: ['flex', 'grid'] }
      },
      {
        id: 'align-items',
        name: 'Align Items',
        property: 'align-items',
        type: 'select',
        default: 'stretch',
        options: [
          { value: 'stretch', name: 'Stretch' },
          { value: 'flex-start', name: 'Start' },
          { value: 'center', name: 'Center' },
          { value: 'flex-end', name: 'End' }
        ],
        requires: { display: ['flex', 'grid'] }
      }
    ]
  },

  {
    id: 'flex-children',
    name: 'Flex-Children',
    open: true,
    properties: [
      {
        id: 'flex-order-type',
        name: 'Flex Order Type',
        property: 'order-type',
        type: 'radio',
        default: '0',
        options: [
          {
            id: 'type1',
            label: 'Type 1',
            value: '',
            name: ''
          },
          {
            id: 'type2',
            label: 'Type 2',
            value: '',
            name: ''
          }
        ]
      },
      {
        id: 'order',
        name: 'Order',
        property: 'order',
        type: 'number',
        default: '0'
      },
      {
        id: 'flex-grow-shrink-group',
        name: 'Flex Shrink/Grow',
        type: 'composite',
        property: 'flex-group',
        properties: [
          {
            id: 'flex-basis',
            name: 'Basis',
            property: 'flex-basis',
            type: 'number',
            default: 'auto'
          },
          {
            id: 'flex-shrink',
            name: 'Shrink',
            property: 'flex-shrink',
            type: 'number',
            default: '1'
          },
          {
            id: 'flex-grow',
            name: 'Grow',
            property: 'flex-grow',
            type: 'number',
            default: '0'
          }
        ]
      },
      {
        id: 'align-self',
        name: 'Align Self',
        property: 'align-self',
        type: 'radio',
        default: 'auto',
        options: [
          {
            id: 'auto',
            label: 'Auto',
            value: 'auto',
            name: ''
          },
          {
            id: 'flex-start',
            label: 'Start',
            value: 'flex-start',
            name: ''
          },
          {
            id: 'center',
            label: 'Center',
            value: 'center',
            name: ''
          },
          {
            id: 'stretch',
            label: 'Stretch',
            value: 'stretch',
            name: ''
          }
        ]
      }
    ]
  },
  {
    id: 'layout-grid',
    name: 'Grid-Children',
    open: false,
    properties: [
      {
        id: 'grid-column-start',
        name: 'Start Column',
        property: 'grid-column-start',
        type: 'number',
        default: 'auto'
      }, // ПЕРЕМЕННАЯ
      {
        id: 'grid-column-end',
        name: 'End Column',
        property: 'grid-column-end',
        type: 'number',
        default: 'auto'
      }, // ПЕРЕМЕННАЯ
      {
        id: 'grid-row-start',
        name: 'Start Row',
        property: 'grid-row-start',
        type: 'number',
        default: 'auto'
      }, // ПЕРЕМЕННАЯ
      {
        id: 'grid-row-end',
        name: 'End Row',
        property: 'grid-row-end',
        type: 'number',
        default: 'auto'
      }, // ПЕРЕМЕННАЯ
      {
        id: 'justify-self',
        name: 'Justify-Self',
        property: 'justify-self', // ПЕРЕМЕННАЯ
        type: 'radio',
        default: 'start',
        options: [
          {
            id: 'start',
            label: 'Start',
            value: 'start',
            name: ''
          },
          {
            id: 'end',
            label: 'End',
            value: 'end',
            name: ''
          },
          {
            id: 'stretch',
            label: 'Stretch',
            value: 'stretch',
            name: ''
          },
          {
            id: 'auto',
            label: 'Auto',
            value: 'auto',
            name: ''
          },
          {
            id: 'center',
            label: 'Center',
            value: 'center',
            name: ''
          }
        ]
      },
      {
        id: 'align-self',
        name: 'Align-Self',
        property: 'align-self',
        type: 'radio',
        default: 'auto',
        options: [
          {
            id: 'auto',
            label: 'Auto',
            value: 'auto',
            name: ''
          },
          {
            id: 'flex-start',
            label: 'Start',
            value: 'flex-start',
            name: ''
          },
          {
            id: 'center',
            label: 'Center',
            value: 'center',
            name: ''
          },
          {
            id: 'stretch',
            label: 'Stretch',
            value: 'stretch',
            name: ''
          }
        ]
      }
    ]
  },
  {
    id: 'layout-position',
    name: 'Position Settings',
    open: true,
    properties: [
      {
        id: 'align-items',
        name: 'Align',
        property: 'text-align', // ПЕРЕМЕННАЯ
        type: 'radio',
        default: 'center',
        full: true,
        options: [
          {
            id: 'left',
            label: 'Left',
            value: 'left',
            name: ''
          },
          {
            id: 'center',
            label: 'Center',
            value: 'center',
            name: ''
          },
          {
            id: 'right',
            label: 'Right',
            value: 'right',
            name: ''
          }
        ]
      },
      {
        id: 'position',
        name: 'Position',
        property: 'position', // ПЕРЕМЕННАЯ
        type: 'select',
        default: 'relative',
        full: true,
        options: [
          {
            id: 'static',
            label: 'Static',
            value: 'static',
            name: ''
          },
          {
            id: 'relative',
            label: 'Relative',
            value: 'relative',
            name: ''
          },
          {
            id: 'absolute',
            label: 'Absolute',
            value: 'absolute',
            name: ''
          },
          {
            id: 'fixed',
            label: 'Fixed',
            value: 'fixed',
            name: ''
          },
          {
            id: 'sticky',
            label: 'Sticky',
            value: 'sticky',
            name: ''
          }
        ]
      },
      {
        id: 'top',
        name: 'Top',
        property: 'top',
        type: 'number',
        units: ['px', '%'],
        default: 'auto'
      }, // ПЕРЕМЕННАЯ
      {
        id: 'right',
        name: 'Right',
        property: 'right',
        type: 'number',
        units: ['px', '%'],
        default: 'auto'
      }, // ПЕРЕМЕННАЯ
      {
        id: 'left',
        name: 'Left',
        property: 'left',
        type: 'number',
        units: ['px', '%'],
        default: 'auto'
      }, // ПЕРЕМЕННАЯ
      {
        id: 'bottom',
        name: 'Bottom',
        property: 'bottom',
        type: 'number',
        units: ['px', '%'],
        default: 'auto'
      } // ПЕРЕМЕННАЯ
    ]
  }
];

export const gjsOptions: EditorConfig = {
  height: '100vh',
  showOffsets: false,
  showOffsetsSelected: false,
  undoManager: { trackSelection: true },
  selectorManager: { componentFirst: true },

  storageManager: false,

  styleManager: {
    sectors: bodyStyleSectors,
    clearProperties: true
  },

  plugins: [
    'grapesjs-tabs',
    // --- ПЛАГИН ДЛЯ НАСТРОЙКИ BODY И ЗАГРУЗКИ ШАБЛОНОВ ---
    (editor) => {
      console.log('🔄 Loading custom templates explicitly...');

      // БЕЗУСЛОВНАЯ ЗАГРУЗКА: Всегда грузим только customTemplates
      editor.loadProjectData({
        assets: [],
        pages: customTemplates.map((template) => ({
          name: template.name,
          component: template.component || '',
          styles: template.styles || ''
        }))
      });

      // Удалены слушатели 'storage:store', так как мы не сохраняем данные

      editor.on('load', () => {
        editor.addStyle(CANVAS_SELECTION_CSS);

        const wrapper = editor.getWrapper();
        if (wrapper) {
          wrapper.set({
            highlightable: false
          });
          wrapper.set('stylable', true);

          const currentStyle = wrapper.getStyle();
          if (!currentStyle.display) {
            wrapper.addStyle({
              display: 'block',
              'min-height': '100vh',
              'background-color': '#3D3AB81A'
            });
          }
          shrinkWrapComponent(wrapper);
        }
      });

      const disableResize = (component: any) => {
        component?.set?.('resizable', false);
      };

      editor.on('component:create', disableResize);
      editor.on('component:selected', disableResize);
      editor.on('component:add', (component) => {
        disableResize(component);
        shrinkWrapComponent(component);
      });
    }
  ],

  pluginsOpts: {
    'grapesjs-tabs': {
      tabsClasses: ['tabs'],
      tabClasses: ['tab'],
      panelClasses: ['panel'],
      multiSelect: true,
      direction: 'horizontal',
      blockId: 'tabs',
      label: 'Tabs',
      content: { type: 'tabs', components: [] }
    }
  },

  container: '#gjs',
  fromElement: true,
  dragMode: 'translate',

  canvas: {
    styles: [],
    scripts: ['https://cdn.jsdelivr.net/npm/chart.js'],
    frameStyle: `
    body {
      background-color: #3D3AB81A;
      border: 1px solid #3D3AB899;
      min-height: 100vh;
    }
    .gjs-dashed *:not(body):not(html):not([data-gjs-type="wrapper"]) {
      outline: 1px dashed #3D3AB840;
      outline-offset: -1px;
    }
    .gjs-dashed *:empty {
      min-height: 20px;
    }
    .gjs-dashed body,
    body.gjs-dashed,
    .gjs-dashed [data-gjs-type="wrapper"] {
      outline: none !important;
      box-shadow: none !important;
    }
    ${CANVAS_SELECTION_CSS}
    `
  },
  canvasCss: CANVAS_SELECTION_CSS
};

export const specialTypes = [
  'container',
  'button',
  'input',
  'form',
  'select',
  'textarea',
  'image',
  'video',
  'chart',
  'wz-table',
  'list',
  'card',
  'modal',
  'accordion',
  'tabs',
  'navbar',
  'custom-button',
  'image-icon',
  'label-text',
  'column',
  'row-column',
  'table row',
  'column-subcolumn',
  'grid',
  'grid-cell',
  'row',
  'pie-chart-json',
  'bar-chart',
  'mui-link',
  'checkbox-label',
  'chart-axis-x',
  'chart-axis-y',
  'points'
];

export const zoomOptions = [
  { value: '50', label: '50%' },
  { value: '75', label: '75%' },
  { value: '100', label: '100%' },
  { value: '125', label: '125%' },
  { value: '150', label: '150%' },
  { value: '200', label: '200%' }
];

export const defaultVariables = {
  '--primary-color': '#3D3AB8',
  '--secondary-color': '#6c63ff',
  '--background-color': '#3D3AB81A',
  '--text-color': '#ffffff',
  '--border-color': '#3D3AB899',
  '--border-radius': '4px',
  '--spacing-xs': '4px',
  '--spacing-sm': '8px',
  '--spacing-md': '16px',
  '--spacing-lg': '24px',
  '--spacing-xl': '32px',
  '--font-size-sm': '12px',
  '--font-size-md': '16px',
  '--font-size-lg': '20px',
  '--font-size-xl': '24px'
};
