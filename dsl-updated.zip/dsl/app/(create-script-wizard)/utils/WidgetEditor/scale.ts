export const getScaleOptions = () => {
  const result = [];
  for (let i = 1; i <= 20; i++) {
    result.push({
      label: `${i * 10}%`,
      value: `${i * 10}`,
    });
  }
  return result;
}
