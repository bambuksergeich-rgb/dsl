import React from "react";

export type IconType = (props: React.ComponentProps<'svg'>) => JSX.Element;
export type ImgType = (props: React.ComponentProps<'img'>) => JSX.Element;

export type WidgetType = 'PIE_CHART' | 'LINE_CHART' | 'BAR_CHART' | 'TABLE' | 'INFO_BLOCK';

export interface IWidgetTemplate {
  icon: IconType | ImgType;
  type: WidgetType;
  widgetTemplateId: string;
  preferredWidth: number;
  preferredHeight: number;
  widgetId?: string;
}
