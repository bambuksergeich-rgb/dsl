import { OptionType } from '../../components/types';

export interface IDeviceFormat {
  name: string;
  height: number;
  width: number;
}

export const deviceFormats = [
  {
    name: 'Phone',
    height: 700,
    width: 345
  },
  {
    name: 'Tablet',
    height: 1620,
    width: 2160
  },
  {
    name: 'Desktop',
    height: 1440,
    width: 2560
  }
];

export const getFormatOptions = () => {
  const formatOptions: OptionType[] = [];
  deviceFormats.forEach((format) => {
    formatOptions.push({
      value: format.name,
      label: format.name
    });
  });
  return formatOptions;
};

export const getDeviceFormatByName = (name: string) => {
  return deviceFormats.find((device) => device.name === name);
};

export const getOptionByName = (options: OptionType[], name: string) => {
  const option = options.find((opt) => opt.label === name);
  return option ? option : { value: 'Unknown', label: 'Unknown' };
};
