// utils/componentStyles.ts
interface Property {
	id: string;
	name: string;
	property: string;
	type: string;
	default: string;
	pseudoClass?: string;
	units?: string[];
	options?: { value: string }[];
}

interface Sector {
	id: string;
	name: string;
	open: boolean;
	properties: Property[];
}

interface ComponentStyles {
	[key: string]: {
		sectors: Sector[];
	};
}

export const componentStyles: ComponentStyles = {
	checkbox: {
		sectors: [
			{
				id: "appearance",
				name: "Appearance",
				open: true,
				properties: [
					{
						id: "checked-background-color",
						name: "Checked Background Color",
						property: "background-color",
						type: "color",
						default: "#3f51b5",
						pseudoClass: "checked",
					},
					{
						id: "border-color",
						name: "Border Color",
						property: "border-color",
						type: "color",
						default: "#ccc",
					},
				],
			},
			{
				id: "dimensions",
				name: "Dimensions",
				open: false,
				properties: [
					{
						id: "width",
						name: "Width",
						property: "width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "18px",
					},
					{
						id: "height",
						name: "Height",
						property: "height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "18px",
					},
					{
						id: "min-width",
						name: "Min Width",
						property: "min-width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "14px",
					},
					{
						id: "min-height",
						name: "Min Height",
						property: "min-height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "14px",
					},
					{
						id: "max-width",
						name: "Max Width",
						property: "max-width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "24px",
					},
					{
						id: "max-height",
						name: "Max Height",
						property: "max-height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "24px",
					},
				],
			},
			{
				id: "typography",
				name: "Typography",
				open: false,
				properties: [
					{
						id: "font-size",
						name: "Font Size",
						property: "font-size",
						type: "number",
						units: ["px", "rem", "em"],
						default: "14px",
					},
					{
						id: "color",
						name: "Text Color",
						property: "color",
						type: "color",
						default: "#000000",
					},
				],
			},
			{
				id: "spacing",
				name: "Spacing",
				open: false,
				properties: [
					{
						id: "row-gap",
						name: "Row Gap",
						property: "row-gap",
						type: "number",
						units: ["px", "rem"],
						default: "auto",
					},
					{
						id: "column-gap",
						name: "Column Gap",
						property: "column-gap",
						type: "number",
						units: ["px", "rem"],
						default: "auto",
					},
				],
			},
		],
	},
	input: {
		sectors: [
			{
				id: "appearance",
				name: "Appearance",
				open: true,
				properties: [
					{
						id: "background-color",
						name: "Background Color",
						property: "background-color",
						type: "color",
						default: "#fff",
					},
					{
						id: "color",
						name: "Text Color",
						property: "color",
						type: "color",
						default: "#495057",
					},
					{
						id: "disabled-background-color",
						name: "Disabled Background Color",
						property: "background-color",
						type: "color",
						default: "#e9ecef",
						pseudoClass: "disabled",
					},
				],
			},
			{
				id: "borders",
				name: "Borders",
				open: false,
				properties: [
					{
						id: "border-width",
						name: "Border Width",
						property: "border-width",
						type: "text",
						default: "1px",
					},
					{
						id: "border-color",
						name: "Border Color",
						property: "border-color",
						type: "color",
						default: "#ced4da",
					},
					{
						id: "border-radius",
						name: "Border Radius",
						property: "border-radius",
						type: "text",
						default: "4px",
					},
					{
						id: "focus-border-color",
						name: "Focus Border Color",
						property: "border-color",
						type: "color",
						default: "#80bdff",
						pseudoClass: "focus",
					},
				],
			},
			{
				id: "dimensions",
				name: "Dimensions",
				open: false,
				properties: [
					{
						id: "width",
						name: "Width",
						property: "width",
						type: "text",
						units: ["px", "%", "rem"],
						default: "100%",
					},
					{
						id: "height",
						name: "Height",
						property: "height",
						type: "text",
						units: ["px", "%", "rem"],
						default: "auto",
					},
				],
			},
			{
				id: "spacing",
				name: "Spacing",
				open: false,
				properties: [
					{
						id: "padding",
						name: "Padding",
						property: "padding",
						type: "text",
						default: "8px 12px",
					},
					{
						id: "margin",
						name: "Margin",
						property: "margin",
						type: "text",
						default: "0",
					},
				],
			},
			{
				id: "typography",
				name: "Typography",
				open: false,
				properties: [
					{
						id: "font-size",
						name: "Font Size",
						property: "font-size",
						type: "text",
						units: ["px", "rem", "em"],
						default: "14px",
					},
					{
						id: "font-family",
						name: "Font Family",
						property: "font-family",
						type: "text",
						default: "inherit",
					},
				],
			},
			{
				id: "focus",
				name: "Focus",
				open: false,
				properties: [
					{
						id: "focus-box-shadow",
						name: "Focus Box Shadow",
						property: "box-shadow",
						type: "text",
						default: "0 0 0 0.2rem rgba(0, 123, 255, 0.25)",
						pseudoClass: "focus",
					},
					{
						id: "focus-outline",
						name: "Focus Outline",
						property: "outline",
						type: "text",
						default: "0",
						pseudoClass: "focus",
					},
				],
			},
		],
	},
	label: {
		sectors: [
			{
				id: "appearance",
				name: "Appearance",
				open: true,
				properties: [
					{
						id: "color",
						name: "Text Color",
						property: "color",
						type: "color",
						default: "#3f51b5",
					},
					{
						id: "border-color",
						name: "Border Color",
						property: "border-color",
						type: "color",
						default: "#3f51b5",
					},
				],
			},
			{
				id: "dimensions",
				name: "Dimensions",
				open: false,
				properties: [
					{
						id: "width",
						name: "Width",
						property: "width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "200px",
					},
					{
						id: "height",
						name: "Height",
						property: "height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "40px",
					},
					{
						id: "min-width",
						name: "Min Width",
						property: "min-width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "100px",
					},
					{
						id: "max-width",
						name: "Max Width",
						property: "max-width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "400px",
					},
				],
			},
			{
				id: "typography",
				name: "Typography",
				open: false,
				properties: [
					{
						id: "font-size",
						name: "Font Size",
						property: "font-size",
						type: "number",
						units: ["px", "rem", "em"],
						default: "14px",
					},
				],
			},
			{
				id: "spacing",
				name: "Spacing",
				open: false,
				properties: [
					{
						id: "margin",
						name: "Margin",
						property: "margin",
						type: "text",
						units: ["px", "%", "rem"],
						default: "4px 0",
					},
				],
			},
		],
	},
	radio: {
		sectors: [
			{
				id: "appearance",
				name: "Appearance",
				open: true,
				properties: [
					{
						id: "checked-background-color",
						name: "Checked Background Color",
						property: "background-color",
						type: "color",
						default: "#3f51b5",
						pseudoClass: "checked",
					},
					{
						id: "border-color",
						name: "Border Color",
						property: "border-color",
						type: "color",
						default: "#ccc",
					},
				],
			},
			{
				id: "dimensions",
				name: "Dimensions",
				open: false,
				properties: [
					{
						id: "width",
						name: "Width",
						property: "width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "18px",
					},
					{
						id: "height",
						name: "Height",
						property: "height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "18px",
					},
					{
						id: "min-width",
						name: "Min Width",
						property: "min-width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "14px",
					},
					{
						id: "min-height",
						name: "Min Height",
						property: "min-height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "14px",
					},
					{
						id: "max-width",
						name: "Max Width",
						property: "max-width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "24px",
					},
					{
						id: "max-height",
						name: "Max Height",
						property: "max-height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "24px",
					},
				],
			},
			{
				id: "typography",
				name: "Typography",
				open: false,
				properties: [
					{
						id: "font-size",
						name: "Font Size",
						property: "font-size",
						type: "number",
						units: ["px", "rem", "em"],
						default: "14px",
					},
					{
						id: "color",
						name: "Text Color",
						property: "color",
						type: "color",
						default: "#ffffff",
					},
				],
			},
			{
				id: "spacing",
				name: "Spacing",
				open: false,
				properties: [
					{
						id: "row-gap",
						name: "Row Gap",
						property: "row-gap",
						type: "number",
						units: ["px", "%", "rem"],
						default: "auto",
					},
					{
						id: "column-gap",
						name: "Column Gap",
						property: "column-gap",
						type: "number",
						units: ["px", "%", "rem"],
						default: "auto",
					},
				],
			},
		],
	},
	select: {
		sectors: [
			{
				id: "appearance",
				name: "Appearance",
				open: true,
				properties: [
					{
						id: "background-color",
						name: "Background Color",
						property: "background-color",
						type: "color",
						default: "#fff",
					},
					{
						id: "border-color",
						name: "Border Color",
						property: "border-color",
						type: "color",
						default: "#ccc",
					},
					{
						id: "focus-border-color",
						name: "Focus Border Color",
						property: "border-color",
						type: "color",
						default: "#3f51b5",
						pseudoClass: "focus",
					},
				],
			},
			{
				id: "dimensions",
				name: "Dimensions",
				open: false,
				properties: [
					{
						id: "width",
						name: "Width",
						property: "width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "200px",
					},
					{
						id: "height",
						name: "Height",
						property: "height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "40px",
					},
					{
						id: "min-width",
						name: "Min Width",
						property: "min-width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "100px",
					},
					{
						id: "max-width",
						name: "Max Width",
						property: "max-width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "400px",
					},
					{
						id: "border-width",
						name: "Border Width",
						property: "border-width",
						type: "number",
						units: ["px"],
						default: "1px",
					},
				],
			},
			{
				id: "typography",
				name: "Typography",
				open: false,
				properties: [
					{
						id: "font-size",
						name: "Font Size",
						property: "font-size",
						type: "number",
						units: ["px", "rem", "em"],
						default: "14px",
					},
					{
						id: "color",
						name: "Text Color",
						property: "color",
						type: "color",
						default: "#3f51b5",
					},
				],
			},
			{
				id: "spacing",
				name: "Spacing",
				open: false,
				properties: [
					{
						id: "padding",
						name: "Padding",
						property: "padding",
						type: "text",
						default: "8px 12px",
					},
				],
			},
			{
				id: "focus",
				name: "Focus",
				open: false,
				properties: [
					{
						id: "focus-box-shadow",
						name: "Focus Box Shadow",
						property: "box-shadow",
						type: "text",
						default: "0 0 0 2px rgba(63, 81, 181, 0.2)",
						pseudoClass: "focus",
					},
					{
						id: "focus-outline",
						name: "Focus Outline",
						property: "outline",
						type: "text",
						default: "none",
						pseudoClass: "focus",
					},
				],
			},
		],
	},
	button: {
		sectors: [
			{
				id: "appearance",
				name: "Appearance",
				open: true,
				properties: [
					{
						id: "background-color",
						name: "Background Color",
						property: "background-color",
						type: "color",
						default: "#007bff",
					},
					{
						id: "color",
						name: "Text Color",
						property: "color",
						type: "color",
						default: "#fff",
					},
					{
						id: "border-color",
						name: "Border Color",
						property: " TZ: border-color",
						type: "color",
						default: "#007bff",
					},
				],
			},
			{
				id: "borders",
				name: "Borders",
				open: false,
				properties: [
					{
						id: "border-width",
						name: "Border Width",
						property: "border-width",
						type: "number",
						units: ["px"],
						default: "1px",
					},
					{
						id: "border-radius",
						name: "Border Radius",
						property: "border-radius",
						type: "number",
						units: ["px", "rem"],
						default: "4px",
					},
				],
			},
			{
				id: "dimensions",
				name: "Dimensions",
				open: false,
				properties: [
					{
						id: "width",
						name: "Width",
						property: "width",
						type: "number",
						units: ["px", "%", "rem"],
						default: "auto",
					},
					{
						id: "height",
						name: "Height",
						property: "height",
						type: "number",
						units: ["px", "%", "rem"],
						default: "auto",
					},
				],
			},
			{
				id: "typography",
				name: "Typography",
				open: false,
				properties: [
					{
						id: "font-size",
						name: "Font Size",
						property: "font-size",
						type: "number",
						units: ["px", "rem", "em"],
						default: "14px",
					},
					{
						id: "font-weight",
						name: "Font Weight",
						property: "font-weight",
						type: "select",
						options: [{ value: "400" }, { value: "500" }, { value: "700" }],
						default: "400",
					},
				],
			},
			{
				id: "spacing",
				name: "Spacing",
				open: false,
				properties: [
					{
						id: "padding",
						name: "Padding",
						property: "padding",
						type: "text",
						default: "8px 16px",
					},
					{
						id: "margin",
						name: "Margin",
						property: "margin",
						type: "text",
						default: "0",
					},
				],
			},
		],
	},
	default: {
		sectors: [
			{
				id: "general",
				name: "General",
				open: true,
				properties: [
					{
						id: "width",
						name: "Width",
						property: "width",
						units: ["px", "%", "rem"],
						default: "",
						type: "",
					},
					{
						id: "height",
						name: "Height",
						property: "height",
						units: ["px", "%", "rem"],
						default: "",
						type: "",
					},
					{
						id: "background-color",
						name: "Background Color",
						property: "background-color",
						type: "color",
						default: "",
					},
					{
						id: "margin",
						name: "Margin",
						property: "margin",
						units: ["px", "%", "rem"],
						default: "0",
						type: "",
					},
					{
						id: "padding",
						name: "Padding",
						property: "padding",
						units: ["px", "%", "rem"],
						default: "0",
						type: "",
					},
				],
			},
			{
				id: "typography",
				name: "Typography",
				open: false,
				properties: [
					{
						id: "font-size",
						name: "Font Size",
						property: "font-size",
						units: ["px", "rem", "em"],
						default: "16px",
						type: "",
					},
					{
						id: "color",
						name: "Text Color",
						property: "color",
						type: "color",
						default: "#333",
					},
					{
						id: "text-align",
						name: "Text Align",
						property: "text-align",
						default: "left",
						type: "",
					},
				],
			},
		],
	},
};
