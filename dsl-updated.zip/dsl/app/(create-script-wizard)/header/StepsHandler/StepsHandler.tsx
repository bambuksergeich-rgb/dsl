import React from 'react';
import classNames from 'classnames';
import BackStepIcon from '../../icons/BackStep.icon';
import ForwardStepIcon from '../../icons/ForwardStep.icon';
import SquareButton from '../../UI/SquareButton/SquareButton';

interface IStepsHandlerProps {
  isBackStepAvailable: boolean;
  onBackStepClick: () => void;
  isForwardStepAvailable: boolean;
  onForwardStepClick: () => void;
  size?: 'sm' | 'md';
}

const StepsHandler = ({
  isBackStepAvailable,
  onBackStepClick,
  isForwardStepAvailable,
  onForwardStepClick,
  size
}: IStepsHandlerProps) => {
  return (
    <div className='flex gap-widget-header'>
      <SquareButton
        size={'md'}
        onClick={onBackStepClick}
      >
        <div
          className={classNames({
            'opacity-30': !isBackStepAvailable,
            'opacity-100 cursor-pointer': isBackStepAvailable
          })}
        >
          <BackStepIcon />
        </div>
      </SquareButton>
      <SquareButton
        size={'md'}
        onClick={onForwardStepClick}
      >
        <div
          className={classNames({
            'opacity-30': !isForwardStepAvailable,
            'opacity-100 cursor-pointer': isForwardStepAvailable
          })}
        >
          <ForwardStepIcon />
        </div>
      </SquareButton>
    </div>
  );
};

export default StepsHandler;
