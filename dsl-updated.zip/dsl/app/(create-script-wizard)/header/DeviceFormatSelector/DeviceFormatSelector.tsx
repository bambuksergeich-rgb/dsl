// 'use client';

// import React, { useEffect, useState } from 'react';
// import { OptionType, Select } from '../../UI/Select/Select';
// import {
//   getDeviceFormatByName,
//   getOptionByName,
//   IDeviceFormat
// } from '../../utils/WidgetEditor/devceFormat';
// import { Input } from '../../UI/Input/Input';
// // import { COMMON_SELECT_WIDTH } from '../Header';

// interface IDeviceFormatSelectorProps {
//   formatOptions: OptionType[];
//   selectedDeviceFormat: IDeviceFormat;
//   changeDeviceFormat: (deviceFormat: IDeviceFormat) => void;
// }

// const DeviceFormatSelector = ({
//   formatOptions,
//   selectedDeviceFormat,
//   changeDeviceFormat
// }: IDeviceFormatSelectorProps) => {
//   // function for use selector action
//   const manualChangeSelectedOption = (option: OptionType) => {
//     const newDeviceFormat = getDeviceFormatByName(option.label)!;
//     changeDeviceFormat(newDeviceFormat);
//   };

//   // inputs states left-height right-width
//   const [leftInputValue, setLeftInputValue] = useState<string>('');
//   const [rightInputValue, setRightInputValue] = useState<string>('');

//   // changes input states after device format updating
//   useEffect(() => {
//     setLeftInputValue(selectedDeviceFormat.height + 'px');
//     setRightInputValue(selectedDeviceFormat.width + 'px');
//   }, [selectedDeviceFormat]);

//   // changes device format when user ended text to inputs.
//   const inputBlur = () => {
//     changeDeviceFormat({
//       name: '',
//       height: Number(leftInputValue.replace(/\D/g, '')),
//       width: Number(rightInputValue.replace(/\D/g, ''))
//     });
//   };

//   return (
//     <div className='flex gap-widget-header'>
//       <Select
//         options={formatOptions}
//         activeOption={getOptionByName(formatOptions, selectedDeviceFormat.name)}
//         onChange={(event) => manualChangeSelectedOption(event)}
//         mainStyles={{ width: COMMON_SELECT_WIDTH }}
//       />
//       <Input
//         style={{ height: '44px', maxWidth: '80px' }}
//         onBlur={inputBlur}
//         onChange={(event) => setLeftInputValue(event.target.value)}
//         value={leftInputValue}
//       />
//       <Input
//         style={{ height: '44px', maxWidth: '80px' }}
//         onBlur={inputBlur}
//         onChange={(event) => setRightInputValue(event.target.value)}
//         value={rightInputValue}
//       />
//     </div>
//   );
// };

// export default DeviceFormatSelector;
