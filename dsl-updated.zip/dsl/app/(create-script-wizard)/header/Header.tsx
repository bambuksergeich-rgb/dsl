// import React, { useMemo, useState } from 'react';
// import { OptionType, Select } from '../UI/Select/Select';
// import ListSelector from '../UI/ListSelector/ListSelector';
// import VerticalSeparatorIcon from '../icons/VerticalSeparator.icon';
// import DeviceFormatSelector from './DeviceFormatSelector/DeviceFormatSelector';
// import {
//   getFormatOptions,
//   IDeviceFormat
// } from '../utils/WidgetEditor/devceFormat';
// import StepsHandler from './StepsHandler/StepsHandler';
// import SquareButton from '../UI/SquareButton/SquareButton';
// import ActiveInfoIcon from '../icons/ActiveInfo.icon';
// import EmptyDocumentIcon from '../icons/EmptyDocument.icon';
// import TilesIcon from '../icons/Tiles.icon';
// import FullScreenMaximizeIcon from '../icons/FullScreenMaximize.icon';
// import { Button } from '../UI/Button/Button';
// import { ThreeDotsMini } from '../icons/ThreeDotsMini.icon';
// import { useAppDispatch, useAppSelector } from '../hooks/reduxHooks';
// import {
//   changeFormatDevice,
//   changeWidgetProjectPage
// } from '../store/slices/widgetEditor.slice';
// import { getScaleOptions } from '../utils/WidgetEditor/scale';

// export const COMMON_SELECT_WIDTH = '130px';
// export const SCALE_SELECT_WIDTH = '100px';

// const Header = () => {
//   // general
//   const widgetProject = useAppSelector((state) => state.widgetEditor);
//   const dispatch = useAppDispatch();

//   // pages handler
//   const pageOptions = useMemo(() => {
//     const options: OptionType[] = [];
//     widgetProject.pages.forEach((page) => {
//       options.push({
//         value: String(page.number),
//         label:
//           page.number === 2
//             ? `Pagesdvdsvdevbvdsdx ${page.number}`
//             : `Page ${page.number}`
//       });
//     });
//     return options;
//   }, [widgetProject.pages.length]);

//   const changePage = (pageNumber: number) => {
//     if (pageNumber >= 1 && pageNumber <= widgetProject.pages.length) {
//       dispatch(changeWidgetProjectPage(pageNumber));
//     }
//   };

//   // device format handler
//   const selectedDeviceFormat = widgetProject.pages.find(
//     (page) => page.number === widgetProject.selectedPage
//   )!.deviceFormat;
//   const changeDeviceFormat = (deviceFormat: IDeviceFormat) => {
//     dispatch(changeFormatDevice(deviceFormat));
//   };

//   // back and forward steps handler
//   const [isBackStepAvailable, setBackForwardAvailable] =
//     useState<boolean>(false);
//   const [isForwardStepAvailable, setForwardAvailable] = useState<boolean>(true);

//   const onBackStepClick = () => {};

//   const onForwardStepClick = () => {};

//   // info
//   const onInfoClick = () => {};

//   const onFileClick = () => {};

//   // scale handler
//   const scaleOptions = getScaleOptions();
//   const [scaleSelectedOption, setScaleSelectedOption] = useState<OptionType>(
//     scaleOptions[9]
//   );

//   const onFullScreenMaximizeClick = () => {};

//   // right buttons area
//   const onBackClick = () => {};

//   const onSaveClick = () => {};

//   const onMenuClick = () => {};

//   return (
//     <div className='w-full flex h-full pl-2 pr-2'>
//       <div className='w-[15%] flex flex-col justify-center items-start'>
//         <span className='text-[20px] font-medium leading-[24px]'>
//           {widgetProject.title}
//         </span>
//         <span className='text-[14px] font-medium leading-[17px]'>
//           {widgetProject.description}
//         </span>
//       </div>
//       <div className='w-[70%] flex gap-widget-header justify-center items-center'>
//         <div className='flex gap-widget-header'>
//           <Select
//             options={pageOptions}
//             activeOption={pageOptions.find(
//               (opt) => Number(opt.value) === widgetProject.selectedPage
//             )}
//             onChange={(event) => changePage(Number(event.value))}
//             mainStyles={{ width: COMMON_SELECT_WIDTH }}
//           />
//           <ListSelector
//             selectedItem={widgetProject.selectedPage}
//             allItemsCount={widgetProject.pages.length}
//             onLeftClick={() => changePage(widgetProject.selectedPage - 1)}
//             onRightClick={() => changePage(widgetProject.selectedPage + 1)}
//             size={'md'}
//           />
//         </div>

//         <div>
//           <VerticalSeparatorIcon />
//         </div>

//         <div className='flex gap-widget-header'>
//           <DeviceFormatSelector
//             formatOptions={getFormatOptions()}
//             selectedDeviceFormat={selectedDeviceFormat}
//             changeDeviceFormat={changeDeviceFormat}
//           />
//         </div>

//         <div>
//           <VerticalSeparatorIcon />
//         </div>

//         <StepsHandler
//           isBackStepAvailable={isBackStepAvailable}
//           onBackStepClick={onBackStepClick}
//           isForwardStepAvailable={isForwardStepAvailable}
//           onForwardStepClick={onForwardStepClick}
//           size={'md'}
//         />

//         <div>
//           <VerticalSeparatorIcon />
//         </div>

//         <SquareButton
//           size={'md'}
//           onClick={onInfoClick}
//           isCursorCounter={true}
//         >
//           <ActiveInfoIcon />
//         </SquareButton>

//         <SquareButton
//           size={'md'}
//           onClick={onFileClick}
//           isCursorCounter={true}
//         >
//           <EmptyDocumentIcon />
//         </SquareButton>

//         <div>
//           <VerticalSeparatorIcon />
//         </div>

//         <SquareButton
//           size={'md'}
//           onClick={onFileClick}
//           isCursorCounter={true}
//           isActive={true}
//         >
//           <TilesIcon />
//         </SquareButton>

//         <div>
//           <VerticalSeparatorIcon />
//         </div>

//         <Select
//           options={scaleOptions}
//           activeOption={scaleSelectedOption}
//           onChange={(option) => setScaleSelectedOption(option)}
//           mainStyles={{ width: SCALE_SELECT_WIDTH }}
//         />
//         <SquareButton
//           size={'md'}
//           onClick={onFullScreenMaximizeClick}
//           isCursorCounter={true}
//         >
//           <FullScreenMaximizeIcon />
//         </SquareButton>
//       </div>
//       <div className='w-[15%] flex gap-widget-header justify-end items-center'>
//         <Button
//           color={'secondary'}
//           onClick={onBackClick}
//         >
//           Back
//         </Button>
//         <Button onClick={onSaveClick}>Save</Button>
//         <SquareButton
//           size={'md'}
//           onClick={onMenuClick}
//           isCursorCounter={true}
//           isBlue={true}
//         >
//           <ThreeDotsMini />
//         </SquareButton>
//       </div>
//     </div>
//   );
// };

// export default Header;
