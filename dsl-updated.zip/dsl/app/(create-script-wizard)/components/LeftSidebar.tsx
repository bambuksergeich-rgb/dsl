import * as React from 'react';
import { LayersProvider } from '@grapesjs/react';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import { useState } from 'react';
import { Button } from '@mui/material';

import CustomLayerManager from './CustomLayerManager';
import TreeIcon from '../icons/Tree.icon';
import { DatabaseIcon } from '@/public/icons/Databases.icon';
import MapIcon from '../icons/Map.icon';
import { JavascriptIcon } from '@/public/icons/Javascript.icon';
import { SettingIcon } from '@/public/icons/Setting.icon';
import AttributesManager from './AttributesManager';
import DashboardsListModal from './DashboardsListModal';

import { MAIN_TXT_COLOR, cx } from './common';

const defaultTabProps = {
  className: '!min-w-0'
};

interface LeftSidebarProps {
  departmentId: string;
  onSaveAndNavigateToDashboard: (dashboardId: string) => Promise<void>;
}

export default function LeftSidebar({
  departmentId,
  onSaveAndNavigateToDashboard
}: LeftSidebarProps) {
  const [selectedTab, setSelectedTab] = useState(0);
  const [isDashboardModalOpen, setIsDashboardModalOpen] = useState(false);

  return (
    <div
      className={cx('flex flex-col w-[310px]', MAIN_TXT_COLOR)}
      style={{
        background: 'rgba(22, 27, 36, 1)',
        height: 'calc(100vh - 70px)',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <div
        className='flex flex-col gap-[6px] p-[8px]'
        style={{
          height: 'calc(100% - 80px)',
          overflow: 'hidden'
        }}
      >
        <Tabs
          value={selectedTab}
          onChange={(_, v) => setSelectedTab(v)}
          variant='fullWidth'
          className={cx(MAIN_TXT_COLOR, 'gap-[6px]')}
          sx={{
            flexShrink: 0,
            '& .MuiTabs-indicator': {
              display: 'none'
            },
            '& .MuiTab-root': {
              background: 'rgba(255, 255, 255, 0.1)',
              borderRadius: '6px',
              width: '56px',
              height: '56px',
              margin: '0 4px'
            },
            '& .MuiTab-root.Mui-selected': {
              background: 'rgba(42, 43, 107, 1)',
              border: '1px solid rgba(65, 112, 255, 1)'
            }
          }}
        >
          <Tab
            {...defaultTabProps}
            label={<TreeIcon />}
          />
          <Tab
            {...defaultTabProps}
            label={<MapIcon />}
          />
          <Tab
            {...defaultTabProps}
            label={<DatabaseIcon />}
          />
          <Tab
            {...defaultTabProps}
            label={<JavascriptIcon />}
          />
          <Tab
            {...defaultTabProps}
            label={<SettingIcon />}
          />
        </Tabs>

        <div
          className={cx('overflow-y-auto flex-grow')}
          style={{
            scrollbarWidth: 'none',
            msOverflowStyle: 'none'
          }}
        >
          {selectedTab === 0 && (
            <LayersProvider>
              {(props) => <CustomLayerManager {...props} />}
            </LayersProvider>
          )}
          {selectedTab === 2 && <AttributesManager />}
        </div>
      </div>

      <div
        style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          height: '90px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          background: 'rgba(22, 27, 36, 1)',
          zIndex: 100
        }}
      >
        <Button
          onClick={() => setIsDashboardModalOpen(true)}
          sx={{
            width: '170px',
            padding: '12px 16px',
            backgroundColor: '#3D3AB8',
            color: '#fff',
            textTransform: 'none',
            fontSize: '14px',
            fontWeight: 500,
            borderRadius: '6px',
            '&:hover': {
              backgroundColor: '#4441CC'
            },
            '&:active': {
              backgroundColor: '#504DE3'
            }
          }}
        >
          Go to Dashboard
        </Button>
      </div>

      <DashboardsListModal
        open={isDashboardModalOpen}
        onClose={() => setIsDashboardModalOpen(false)}
        departmentId={departmentId}
        onSaveAndNavigate={onSaveAndNavigateToDashboard}
      />
    </div>
  );
}
