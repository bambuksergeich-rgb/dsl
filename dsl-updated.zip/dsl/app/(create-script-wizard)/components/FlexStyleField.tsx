import React from 'react';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import { Property, PropertyRadio, PropertyComposite } from 'grapesjs';

import { FlexOrderTypeIcons, FlexGrowShrinkIcons } from './icons/FlexIcons';

import {
  AlignItemsIcons,
  JustifyContentIcons,
  JustifyItemsIcons
} from './icons/GridIcons';

import StylePropertyField from './StylePropertyField';

interface FlexStyleFieldProps {
  prop: Property;
  onChange: (value: any) => void;
  value: string;
}

const toggleBtnSx = {
  flex: 1,
  border: 'none',
  borderRadius: '6px !important',
  backgroundColor: 'rgba(255, 255, 255, 0.1)',
  padding: '6px',
  height: '34px',
  '&.Mui-selected': {
    backgroundColor: 'rgba(65, 112, 255, 1) !important',
    color: 'white'
  },
  '&:hover': {
    backgroundColor: 'rgba(255, 255, 255, 0.2)'
  }
};

const groupSx = {
  display: 'flex',
  gap: '8px',
  width: '100%',
  backgroundColor: 'transparent'
};

export const FlexStyleField: React.FC<FlexStyleFieldProps> = ({
  prop,
  onChange,
  value
}) => {
  const propId = prop.getId();

  // 1. Обработка радио-свойств (Иконки выбора)
  if (
    propId === 'flex-order-type' ||
    propId === 'align-self' ||
    propId === 'align-items' ||
    propId === 'justify-items' ||
    propId === 'justify-self' ||
    propId === 'justify-content'
  ) {
    const radioProp = prop as PropertyRadio;

    return (
      <ToggleButtonGroup
        value={value}
        exclusive
        onChange={(e, newVal) => newVal !== null && onChange(newVal)}
        sx={groupSx}
      >
        {radioProp.getOptions().map((option) => {
          const optId = radioProp.getOptionId(option);
          let icon = null;

          if (propId === 'flex-order-type') {
            if (optId === '0' || optId === 'type1')
              icon = FlexOrderTypeIcons.type1;
            if (optId === '1' || optId === 'type2')
              icon = FlexOrderTypeIcons.type2;
          } else if (propId === 'align-self' || propId === 'align-items') {
            if (optId === 'flex-start' || optId === 'start')
              icon = AlignItemsIcons.start;
            if (optId === 'flex-end' || optId === 'end')
              icon = AlignItemsIcons.end;
            if (optId === 'center') icon = AlignItemsIcons.center;
            if (optId === 'stretch') icon = AlignItemsIcons.stretch;
            if (optId === 'baseline') icon = AlignItemsIcons.baseline;
          } else if (propId === 'justify-items' || propId === 'justify-self') {
            if (optId === 'start') icon = JustifyItemsIcons.start;
            if (optId === 'end') icon = JustifyItemsIcons.end;
            if (optId === 'center') icon = JustifyItemsIcons.center;
            if (optId === 'stretch') icon = JustifyItemsIcons.stretch;
            if (optId === 'normal' || optId === 'auto')
              icon = JustifyItemsIcons.normal;
          } else if (propId === 'justify-content') {
            if (optId === 'flex-start' || optId === 'start')
              icon = JustifyContentIcons.start;
            if (optId === 'flex-end' || optId === 'end')
              icon = JustifyContentIcons.end;
            if (optId === 'center') icon = JustifyContentIcons.center;
            if (optId === 'space-between')
              icon = JustifyContentIcons['space-between'];
            if (optId === 'space-around')
              icon = JustifyContentIcons['space-around'];
            if (optId === 'space-evenly')
              icon = JustifyContentIcons['space-evenly'];
          }

          return (
            <ToggleButton
              key={optId}
              value={optId}
              sx={toggleBtnSx}
            >
              {icon || radioProp.getOptionLabel(option)}
            </ToggleButton>
          );
        })}
      </ToggleButtonGroup>
    );
  }

  // 2. Обработка композитных свойств (Flex Grow/Shrink/Basis)
  if (propId === 'flex-grow-shrink-group') {
    const compositeProp = prop as PropertyComposite;
    const subProps = compositeProp.getProperties();

    return (
      <div className='flex flex-col gap-[24px] w-full'>
        <div className='flex gap-2 w-full'>
          {subProps.map((subProp) => {
            const subId = subProp.getId();
            const subVal = subProp.getValue();
            let icon = null;
            let isSelected = false;

            if (subId === 'flex-shrink') {
              icon = FlexGrowShrinkIcons.shrink;
              isSelected = subVal !== '0' && subVal !== 0 && subVal !== '';
            }
            if (subId === 'flex-grow') {
              icon = FlexGrowShrinkIcons.grow;
              isSelected = subVal !== '0' && subVal !== 0 && subVal !== '';
            }
            if (subId === 'flex-basis') {
              icon = FlexGrowShrinkIcons.basis;
              isSelected = subVal !== 'auto' && subVal !== '';
            }

            const handleIconClick = () => {
              if (subId === 'flex-grow' || subId === 'flex-shrink') {
                subProp.upValue(isSelected ? '0' : '1');
              } else if (subId === 'flex-basis') {
                if (!isSelected) subProp.upValue('100%');
                else subProp.upValue('auto');
              }
            };

            return (
              <ToggleButton
                key={`btn-${subId}`}
                value='check'
                selected={isSelected}
                onClick={handleIconClick}
                sx={toggleBtnSx}
              >
                {icon}
              </ToggleButton>
            );
          })}
        </div>
        <div className='flex gap-2 w-full'>
          {subProps.map((subProp) => (
            <div
              key={`input-${subProp.getId()}`}
              className='flex-1 flex flex-col gap-2'
            >
              <span
                className='font-medium text-[14px] text-white text-left'
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                {subProp.getLabel()}
              </span>
              <StylePropertyField
                prop={subProp}
                style={{
                  marginBottom: 0,
                  padding: 0,
                  width: '100%',
                  border: 'none'
                }}
              />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className='w-full'>
      <StylePropertyField
        prop={prop}
        style={{
          marginBottom: 0,
          padding: 0,
          width: '100%',
          border: 'none'
        }}
      />
    </div>
  );
};
