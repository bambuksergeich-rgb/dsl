import * as React from 'react';
import { createPortal } from 'react-dom';
import { Editor, Trait } from 'grapesjs';
import { useEditorMaybe } from '@grapesjs/react';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import IconButton from '@mui/material/IconButton';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import { cx, MAIN_TXT_COLOR } from './common';
import ColorElement from './ColorElement';
import { CustomSelect } from './Select';
import { IconPickerModal } from '@/src/components/CreateFlowchartBlock/IconPickerModal/IconPickerModal';
import { useEffect, useState } from 'react';
import { iconsStore } from '@/src/helpers/getIconsHelper';
import * as AllIcons from '../../../public/icons/flowchartBlock';
import { renderToStaticMarkup } from 'react-dom/server';
import {
  Box,
  InputAdornment,
  Select,
  MenuItem,
  Typography,
  Switch,
  FormControl,
  Button
} from '@mui/material';

import { ChartLayer, CustomTraitManagerProps, RoadMapMilestone } from './types';
import { AccordionIcon } from './icons/AccordionIcon';
import { RepeaterTrait } from '../data/_components/traits/RepeaterTrait';
import {
  CANVAS_INLINE_ICON_PICKER_EVENT,
  flushAllGrapesLayouts
} from '@/src/utils/grapesLayout';
import { EDITOR_SIDEBAR_BG } from '@/src/styles/editorSidebarTokens';
import {
  getPaletteTraitName,
  paletteSettingsSchema
} from '@/src/components/CreateFlowchartBlock/PaletteTypeSettings/paletteSettingsSchema';

export default function CustomTraitManager({
  traits
}: CustomTraitManagerProps) {
  const [chartData, setChartData] = useState<ChartLayer[]>([]);
  const [selectedLayerIndex, setSelectedLayerIndex] = useState(0);
  const [newLayerName, setNewLayerName] = useState('');
  const [newLayerColor, setNewLayerColor] = useState('#ffffff');

  const [isIconPickerOpen, setIsIconPickerOpen] = useState(false);
  const [activeIconTrait, setActiveIconTrait] = useState<Trait | null>(null);
  const [activeIconTraitName, setActiveIconTraitName] = useState<string | null>(null);
  const [tableData, setTableData] = useState<string[][]>([]);
  const [cardsData, setCardsData] = useState<
    { title: string; description: string; image: string }[]
  >([]);
  const [newPointLabel, setNewPointLabel] = useState('');
  const [newPointValue, setNewPointValue] = useState('');
  const [newPointColor, setNewPointColor] = useState('#ffffff');
  const [roadMapData, setRoadMapData] = useState<RoadMapMilestone[]>([]);
  const editor = useEditorMaybe();
  const [manualSaveState, setManualSaveState] = useState<
    'idle' | 'saving' | 'saved' | 'error'
  >('idle');

  const handleManualSave = async () => {
    if (manualSaveState === 'saving') return;
    setManualSaveState('saving');
    try {
      await flushAllGrapesLayouts();
      setManualSaveState('saved');
      window.setTimeout(() => setManualSaveState('idle'), 1400);
    } catch (error) {
      console.error('Failed to flush editor settings', error);
      setManualSaveState('error');
    }
  };

  useEffect(() => {
    if (!editor) return;

    const handleCanvasInlineIconPicker = (event: Event) => {
      const detail = (event as CustomEvent<{ traitName?: string }>).detail;
      const traitName = String(detail?.traitName || 'selectImage');
      const selected = editor.getSelected?.();
      const trait = selected?.getTrait?.(traitName) as Trait | undefined;
      if (!trait || trait.getType?.() !== 'select-icon') return;

      setActiveIconTrait(trait);
      setActiveIconTraitName(traitName);
      setIsIconPickerOpen(true);
    };

    window.addEventListener(
      CANVAS_INLINE_ICON_PICKER_EVENT,
      handleCanvasInlineIconPicker as EventListener
    );
    return () => {
      window.removeEventListener(
        CANVAS_INLINE_ICON_PICKER_EVENT,
        handleCanvasInlineIconPicker as EventListener
      );
    };
  }, [editor]);

  const chartDataTrait = traits.find((t) => t.getName() === 'chart-data');
  const addLayerTrait = traits.find((t) => t.getName() === 'add-layer');
  const removeLayerTrait = traits.find((t) => t.getName() === 'remove-layer');

  const selectOptions = chartData.map((l, idx) => ({
    value: String(idx),
    label: l.name || `Layer ${idx + 1}`,
    originalIndex: idx
  }));

  const activeOption = selectOptions[selectedLayerIndex] || null;
  const parseUnitValue = (value: string) => {
    if (!value || typeof value !== 'string')
      return { numericValue: '', unitValue: 'px' };
    if (value === 'auto') return { numericValue: '', unitValue: 'auto' };
    const match = value.match(/^(\d*\.?\d+)([a-zA-Z%]*)$/);
    if (!match) return { numericValue: value, unitValue: 'px' };
    const [, numericValue, unitValue] = match;
    return { numericValue, unitValue: unitValue || 'px' };
  };

  const handleNumberCycle = (trait: Trait, direction: 'up' | 'down') => {
    const configuredStep = Number(trait.attributes.step ?? 1);
    const step =
      Number.isFinite(configuredStep) && configuredStep > 0 ? configuredStep : 1;
    const currentValue = parseFloat(trait.getValue()) || 0;
    const min = trait.attributes.min ?? -Infinity;
    const max = trait.attributes.max ?? Infinity;
    let newValue =
      direction === 'up' ? currentValue + step : currentValue - step;
    newValue = Math.max(min, Math.min(max, newValue));
    handleTraitChange(trait, newValue.toString());
  };

  const [traitStates, setTraitStates] = useState<{
    [key: string]: { value: string; unit: string };
  }>({});

  const handleNumberChange = (
    trait: Trait,
    ev: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const traitName = trait.getName();
    const newValue = ev.target.value;
    setTraitStates((prev) => ({
      ...prev,
      [traitName]: {
        ...prev[traitName],
        value: newValue,
        unit: newValue === '' ? 'auto' : prev[traitName]?.unit || 'px'
      }
    }));
    if (newValue === '') {
      handleTraitChange(trait, 'auto');
    } else if (traitStates[traitName]?.unit === 'auto') {
      handleTraitChange(trait, 'auto');
    } else {
      handleTraitChange(
        trait,
        newValue + (traitStates[traitName]?.unit || 'px')
      );
    }
  };

  const handleUnitChange = (
    trait: Trait,
    ev: { target: { value: unknown } }
  ) => {
    const traitName = trait.getName();
    const newUnit = ev.target.value as string;
    setTraitStates((prev) => ({
      ...prev,
      [traitName]: {
        ...prev[traitName],
        unit: newUnit,
        value: newUnit === 'auto' ? '' : prev[traitName]?.value || '0'
      }
    }));
    if (newUnit === 'auto') {
      handleTraitChange(trait, 'auto');
    } else if (traitStates[traitName]?.value) {
      handleTraitChange(trait, traitStates[traitName].value + newUnit);
    } else {
      handleTraitChange(trait, '0' + newUnit);
    }
  };

  const handleUnitCycle = (trait: Trait, direction: 'up' | 'down') => {
    const traitName = trait.getName();
    const step = 1;
    const currentValue = parseFloat(traitStates[traitName]?.value) || 0;
    let newValue =
      direction === 'up' ? currentValue + step : currentValue - step;
    setTraitStates((prev) => ({
      ...prev,
      [traitName]: {
        ...prev[traitName],
        value: newValue.toString()
      }
    }));
    if (traitStates[traitName]?.unit === 'auto') {
      handleTraitChange(trait, 'auto');
    } else {
      handleTraitChange(
        trait,
        newValue + (traitStates[traitName]?.unit || 'px')
      );
    }
  };

  const handleTraitChange = (trait: Trait, value: string | boolean) => {
    trait.setValue(value);
  };

  const handleFileChange = (
    trait: Trait,
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const fileUrl = URL.createObjectURL(file);
      handleTraitChange(trait, fileUrl);
    }
  };

  const getIconDataUrl = (iconName: string) => {
    const IconComponent = AllIcons[iconName as keyof typeof AllIcons];
    if (!IconComponent) return null;
    const svgString = renderToStaticMarkup(<IconComponent />);
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svgString)}`;
  };

  const handleIconSelect = (iconId: string, trait: Trait) => {
    const iconMeta = iconsStore.find((icon) => icon.id === iconId);
    if (!iconMeta) {
      return;
    }
    const iconSrc = getIconDataUrl(iconMeta.name);
    if (!iconSrc) {
      return;
    }
    handleTraitChange(trait, iconSrc);
    setIsIconPickerOpen(false);
    setActiveIconTrait(null);
    setActiveIconTraitName(null);
  };

  const resolveIconPreview = (rawValue: unknown) => {
    const raw = String(rawValue ?? '').trim();
    if (!raw) return '';
    if (
      raw.startsWith('data:image/') ||
      raw.startsWith('blob:') ||
      raw.startsWith('http://') ||
      raw.startsWith('https://') ||
      raw.startsWith('/')
    ) {
      return raw;
    }

    const iconMeta = iconsStore.find((icon) => icon.id === raw);
    return iconMeta ? getIconDataUrl(iconMeta.name) || '' : '';
  };

  const handleButtonClick = (trait: Trait, options = {}) => {
    if (!editor || typeof editor.getSelected !== 'function') {
      console.error(
        'Editor is not initialized or invalid in CustomTraitManager'
      );
      return;
    }

    const component = editor.getSelected() || trait.attributes.target;
    const command = trait.attributes.command;

    if (typeof command !== 'string') {
      console.warn(
        `Command is not a string for trait: ${trait.getName()}`,
        command
      );
      return;
    }

    if (!component) {
      console.warn(`No component selected or provided for command: ${command}`);
      return;
    }

    if (editor.Commands.get(command)) {
      try {
        editor.runCommand(command, { component, ...options });
      } catch (error) {
        console.error(`Error running command ${command}:`, error);
      }
    } else {
      console.warn(`Command ${command} not found, retrying after 100ms`);
      setTimeout(() => {
        if (editor.Commands.get(command)) {
          try {
            editor.runCommand(command, { component, ...options });
          } catch (error) {
            console.error(
              `Error running command ${command} after retry:`,
              error
            );
          }
        } else {
          console.error(`Command ${command} still not registered after retry`);
        }
      }, 100);
    }
  };

  const handleLayerColorChange = (
    trait: Trait,
    layerIndex: number,
    color: string
  ) => {
    const newData = [...chartData];
    newData[layerIndex] = { ...newData[layerIndex], color };
    setChartData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleLayerNameChange = (
    trait: Trait,
    layerIndex: number,
    name: string
  ) => {
    const newData = [...chartData];
    newData[layerIndex] = { ...newData[layerIndex], name };
    setChartData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleChartPointChange = (
    trait: Trait,
    layerIndex: number,
    pointIndex: number,
    field: 'label' | 'value' | 'color',
    value: string | number
  ) => {
    const newData = [...chartData];
    newData[layerIndex].points[pointIndex] = {
      ...newData[layerIndex].points[pointIndex],
      [field]: value
    };
    setChartData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleTableCellChange = (
    trait: Trait,
    rowIndex: number,
    colIndex: number,
    value: string
  ) => {
    const newData = [...tableData];
    newData[rowIndex][colIndex] = value;
    setTableData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleClearCell = (
    trait: Trait,
    rowIndex: number,
    colIndex: number
  ) => {
    const newData = [...tableData];
    newData[rowIndex][colIndex] = '';
    setTableData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleRoadMapFieldChange = (
    trait: Trait,
    milestoneIndex: number,
    field: 'title' | 'date' | 'description' | 'status',
    value: string
  ) => {
    const newData = [...roadMapData];
    newData[milestoneIndex] = { ...newData[milestoneIndex], [field]: value };
    setRoadMapData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleAddRow = (trait: Trait, editor: Editor) => {
    const newData = [...tableData];

    if (newData.length >= 20) {
      editor?.Modal.open({
        title: 'Limit Reached',
        content: '<div style="padding: 10px">Maximum 20 rows allowed.</div>'
      });
      return;
    }

    const colsCount = newData.length > 0 ? newData[0].length : 5;

    const newRow = Array.from({ length: colsCount }).map((_, index) => {
      if (index === 0) return 'English';
      if (index === 1) return 'Ireland';
      return '$362.392';
    });

    newData.push(newRow);

    setTableData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleAddColumn = (trait: Trait, editor: Editor) => {
    const newData = tableData.map((row) => [...row]);

    if (newData[0]?.length >= 10) {
      editor?.Modal.open({
        title: 'Limit Reached',
        content: '<div style="padding: 10px">Maximum 10 columns allowed.</div>'
      });
      return;
    }

    newData.forEach((row, rowIndex) => {
      if (rowIndex === 0) {
        row.push('New Month');
      } else {
        row.push('$362.392');
      }
    });

    setTableData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleCardFieldChange = (
    trait: Trait,
    cardIndex: number,
    field: 'title' | 'description' | 'image',
    value: string
  ) => {
    const newData = [...cardsData];
    newData[cardIndex] = { ...newData[cardIndex], [field]: value };
    setCardsData(newData);
    handleTraitChange(trait, JSON.stringify(newData));
  };

  const handleCardImageChange = (
    trait: Trait,
    cardIndex: number,
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const fileUrl = URL.createObjectURL(file);
      handleCardFieldChange(trait, cardIndex, 'image', fileUrl);
    }
  };
  const getDefaultChartData = () => {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    const values = [5, 7, 9, 12, 20, 26, 25.5, 23, 15, 8, 5, 3];
    const lineColor = '#4170FF';

    return [
      {
        id: crypto.randomUUID(),
        name: 'Layer 1',
        color: lineColor,
        points: months.map((month, index) => ({
          label: month,
          value: values[index],
          color: lineColor
        }))
      }
    ];
  };

  useEffect(() => {
    traits.forEach((trait) => {
      if (trait.getType() === 'json' && trait.getName() === 'table-data') {
        const defaultTableData = [
          ['Language', 'Country', 'Jan', 'Feb', 'Mar'],
          ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
          ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
          ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
          ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
          ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
          ['English', 'Ireland', '$362.392', '$362.392', '$362.392'],
          ['English', 'Ireland', '$362.392', '$362.392', '$362.392']
        ];

        try {
          const rawValue = trait.getValue();
          const valueToParse = rawValue || trait.getDefault() || '[]';
          const parsedData = JSON.parse(valueToParse);

          setTableData(parsedData.length > 0 ? parsedData : defaultTableData);
        } catch (e) {
          console.error('Invalid JSON in table-data trait:', e);
          setTableData(defaultTableData);
        }
      } else if (
        trait.getType() === 'json' &&
        trait.getName() === 'chart-data'
      ) {
        try {
          const rawValue = trait.getValue();
          const parsedData = JSON.parse(rawValue || '[]');
          setChartData(parsedData.length ? parsedData : getDefaultChartData());
        } catch (e) {
          console.error('Invalid JSON in chart-data trait:', e);
          setChartData(getDefaultChartData());
        }
      } else if (trait.getType() === 'json' && trait.getName() === 'cards') {
        const defaultCards = [
          ...Array.from({ length: 6 }, (_, i) => ({
              title: `Info ${i + 1}`,
              description: 'Description',
              image: 'https://via.placeholder.com/150'
            }))
        ];

        try {
          const rawValue = trait.getValue();
          const parsedData = JSON.parse(rawValue || '[]');
          setCardsData(parsedData.length ? parsedData : defaultCards);
        } catch (e) {
          console.error('Invalid JSON in cards trait:', e);
          setCardsData(defaultCards);
        }
      } else if (trait.getType() === 'json' && trait.getName() === 'road-map') {
        const defaultRoadMap = [
          {
            id: crypto.randomUUID(),
            title: 'Milestone 1',
            date: '2025-07-10',
            description: 'Description',
            status: 'planned'
          }
        ];

        try {
          const rawValue = trait.getValue();
          const parsedData = JSON.parse(rawValue || '[]');
          setRoadMapData(parsedData.length ? parsedData : defaultRoadMap);
        } catch (e) {
          console.error('Invalid JSON in road-map trait:', e);
          setRoadMapData(defaultRoadMap);
        }
      } else if (trait.getType() === 'list') {
        const rawValue = trait.getValue();
        if (!rawValue && trait.getDefault()) {
          const defaultVal = trait.getDefault();
          trait.setValue(defaultVal);
        }
      }
    });
  }, [traits]);

  useEffect(() => {
    if (!editor) return;
    const handleTraitChangeEvent = (changedTrait: Trait) => {
      if (changedTrait.getName() === 'chart-data') {
        try {
          const newValue = changedTrait.getValue();
          const parsedData = JSON.parse(newValue || '[]');
          setChartData(parsedData.length ? parsedData : getDefaultChartData());
        } catch (e) {
          console.error('Invalid JSON in chart-data trait:', e);
          setChartData(getDefaultChartData());
        }
      } else if (changedTrait.getName() === 'cards') {
        try {
          const newValue = changedTrait.getValue();
          const parsedData = JSON.parse(newValue || '[]');
          setCardsData(
            parsedData.length
              ? parsedData
              : [
                  ...Array.from({ length: 6 }, (_, i) => ({
                      title: `Product ${i + 1}`,
                      description: 'Description',
                      image: 'https://via.placeholder.com/150'
                    }))
                ]
          );
        } catch (e) {
          console.error('Invalid JSON in cards trait:', e);
          setCardsData([
            ...Array.from({ length: 6 }, (_, i) => ({
                title: `Product ${i + 1}`,
                description: 'Description',
                image: 'https://via.placeholder.com/150'
              }))
          ]);
        }
      }
    };
    editor.on('trait:change', handleTraitChangeEvent);
    return () => {
      editor.off('trait:change', handleTraitChangeEvent);
    };
  }, [editor]);

  const isEditorReady = !!editor && typeof editor.getSelected === 'function';

  const selectedComponentType = editor?.getSelected?.()?.get?.('type');
  const visuallyHiddenTraits: Record<string, Set<string>> = {
    'custom-select': new Set(['value', 'placeholder', 'disabled', 'multiple']),
    Number: new Set(['value']),
    counter: new Set(['value']),
    'mui-link': new Set(['name', 'page-link']),
    switch: new Set(['checked']),
    'single-radio': new Set(['label', 'gapX', 'gapY']),
    'single-checkbox': new Set(['checked', 'text', 'gapX', 'gapY']),
    'checkbox-group': new Set(['group-gap'])
  };
  const selectedTypeKey = String(selectedComponentType || '');
  const hiddenForSelected = selectedComponentType
    ? visuallyHiddenTraits[selectedTypeKey]
    : undefined;
  const designFields = selectedTypeKey
    ? paletteSettingsSchema[selectedTypeKey]
    : undefined;
  const designTraitOrder = designFields
    ? designFields.map((field) => getPaletteTraitName(selectedTypeKey, field.name))
    : null;
  const designTraitNames = designTraitOrder
    ? new Set(designTraitOrder)
    : null;
  // The PDF/Figma target sidebars are compact cards; the legacy Settings/Main
  // frame is exactly the visual discrepancy called out in the remarks.
  const usesFramedSettings = false;
  const traitsPanelBackground = EDITOR_SIDEBAR_BG;

  const generalTraits = traits
    .filter(
      (trait) =>
        !trait.getName().startsWith('row') &&
        !trait.getName().startsWith('remove-row-') &&
        trait.getName() !== 'add-row' &&
        trait.getName() !== 'addCard' &&
        trait.getName() !== 'removeLastCard' &&
        trait.getName() !== 'addItem' &&
        trait.getName() !== 'removeLastItem' &&
        trait.getName() !== 'add-milestone' &&
        trait.getName() !== 'remove-milestone' &&
        trait.getName() !== 'chart-data' &&
        trait.getName() !== 'points-manager' &&
        !hiddenForSelected?.has(trait.getName()) &&
        (!designTraitNames || designTraitNames.has(trait.getName()))
    )
    .sort((left, right) => {
      if (!designTraitOrder) return 0;
      const leftIndex = designTraitOrder.indexOf(left.getName());
      const rightIndex = designTraitOrder.indexOf(right.getName());
      return (leftIndex < 0 ? Number.MAX_SAFE_INTEGER : leftIndex) -
        (rightIndex < 0 ? Number.MAX_SAFE_INTEGER : rightIndex);
    });
  const pointTraits = traits.filter((trait) =>
    trait.getName().startsWith('point')
  );
  const rowTraits = traits.filter((trait) => trait.getName().startsWith('row'));
  const addRowTrait = traits.find((trait) => trait.getName() === 'add-row');
  const removeRowTraits = traits.filter((trait) =>
    trait.getName().startsWith('remove-row-')
  );
  const addPointTrait = traits.find((trait) => trait.getName() === 'add-point');
  const removePointTrait = traits.find(
    (trait) => trait.getName() === 'remove-point'
  );
  const addCardTrait = traits.find((trait) => trait.getName() === 'addCard');
  const removeLastCardTrait = traits.find(
    (trait) => trait.getName() === 'removeLastCard'
  );
  const cardsTrait = traits.find((trait) => trait.getName() === 'cards');
  const cardsDataParsed = cardsTrait
    ? JSON.parse(cardsTrait.getValue() || '[]')
    : [];

  const pointGroups: { [key: string]: Trait[] } = {};
  pointTraits.forEach((trait) => {
    const match = trait.getName().match(/point(\d+)-/);
    if (match) {
      const pointNum = match[1];
      if (!pointGroups[pointNum]) {
        pointGroups[pointNum] = [];
      }
      pointGroups[pointNum].push(trait);
    }
  });

  return (
    <div
      className={cx(
        'gjs-custom-trait-manager text-left w-full max-w-full h-full box-border overflow-x-hidden',
        '[&_.MuiAccordion-root]:w-full [&_.MuiAccordion-root]:max-w-full',
        '[&_.MuiAccordionDetails-root]:max-w-full [&_.MuiAccordionDetails-root]:box-border',
        MAIN_TXT_COLOR
      )}
      style={{
        backgroundColor: traitsPanelBackground,
        color: 'rgba(65, 112, 255, 1)',
        height: '100%',
        fontFamily: 'Montserrat'
      }}
    >
      {traits.length > 0 && (
        <>
          {generalTraits.length > 0 && (
            <Accordion
              disableGutters
              defaultExpanded
              sx={{
                color: 'rgba(65, 112, 255, 1)',
                backgroundColor: traitsPanelBackground,
                '&.MuiAccordion-root': {
                  backgroundColor: traitsPanelBackground,
                  color: 'rgba(65, 112, 255, 1)',
                  '&:before': {
                    display: 'none'
                  },
                  '&.Mui-expanded': {
                    backgroundColor: traitsPanelBackground
                  }
                }
              }}
            >
              <AccordionSummary
                aria-hidden={usesFramedSettings ? undefined : 'true'}
                expandIcon={usesFramedSettings ? AccordionIcon : undefined}
                sx={{
                  display: usesFramedSettings ? 'flex' : 'none',
                  minHeight: usesFramedSettings ? '42px' : 0,
                  px: usesFramedSettings ? '16px' : 0,
                  color: '#4170FF',
                  backgroundColor: traitsPanelBackground,
                  '& .MuiAccordionSummary-content': {
                    my: 0
                  },
                  '&.Mui-expanded': {
                    minHeight: usesFramedSettings ? '42px' : 0
                  }
                }}
              >
                {usesFramedSettings && (
                  <Typography
                    sx={{
                      fontFamily: 'Montserrat',
                      fontSize: '14px',
                      fontWeight: 500,
                      color: '#4170FF'
                    }}
                  >
                    Main
                  </Typography>
                )}
              </AccordionSummary>
              <AccordionDetails
                sx={{
                  color: 'rgba(65, 112, 255, 1)',
                  backgroundColor: traitsPanelBackground,
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '18px',
                  padding: '14px 16px 20px',
                  alignContent: 'flex-start'
                }}
              >
                {generalTraits.map((trait) => {
                  const type = trait.getType();
                  const name = trait.getName();
                  const label = trait.getLabel();
                  const value = trait.getValue();
                  const hasUnits = !!trait.attributes.unit;
                  const units: string[] = Array.isArray(trait.attributes.unit)
                    ? trait.attributes.unit
                    : trait.attributes.unit
                      ? [String(trait.attributes.unit)]
                      : ['px', '%', 'vw', 'vh', 'rem', 'em'];
                  const isRemoveTrait =
                    name.startsWith('remove-row-') || name === 'remove-point';

                  const { numericValue, unitValue } = hasUnits
                    ? parseUnitValue(value)
                    : { numericValue: value ?? '', unitValue: '' };

                  switch (type) {
                    case 'mask':
                      return (
                        <Box
                          key={name}
                          sx={{
                            width: '100%',
                            '& .MuiFormControl-root': {
                              width: '100%'
                            }
                          }}
                        >
                          <Typography
                            className={cx(
                              'text-sm font-semibold',
                              MAIN_TXT_COLOR
                            )}
                            style={{
                              fontSize: '14px',
                              marginBottom: '8px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            {label || name}
                          </Typography>
                          <TextField
                            value={value || '+X (XXX) XXX-XXXX'}
                            onChange={(e) => {
                              const newValue = e.target.value;
                              if (/^[0-9+\-\(\) X]*$/.test(newValue)) {
                                handleTraitChange(trait, newValue);
                              }
                            }}
                            placeholder='+X (XXX) XXX-XXXX'
                            sx={{
                              '& .MuiInputBase-root': {
                                height: '34px',
                                color: '#fff',
                                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                                borderRadius: '6px',
                                border: 'none'
                              },
                              '& .MuiInputBase-input': {
                                height: '34px',
                                padding: '0 14px',
                                boxSizing: 'border-box',
                                border: 'none'
                              },
                              '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                { border: 'none' }
                            }}
                          />
                        </Box>
                      );
                    case 'json':
                      if (name === 'table-data') {
                        return (
                          <Box
                            sx={{
                              color: 'rgba(255, 255, 255, 1)',
                              borderRadius: '6px',
                              height: '100%',
                              overflowY: 'auto'
                            }}
                          >
                            <div
                              style={{
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '16px'
                              }}
                            >
                              {tableData[0]?.map((_, colIndex) => (
                                <Box
                                  key={`column-${colIndex}`}
                                  sx={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '8px',
                                    borderRadius: '6px',
                                    padding: '8px',
                                    backgroundColor: '#2E3134',
                                    transition: 'all 0.3s ease',
                                    width: '310px',
                                    maxWidth: '400px'
                                  }}
                                >
                                  <div
                                    style={{
                                      display: 'flex',
                                      alignItems: 'left',
                                      flexDirection: 'row',
                                      justifyContent: 'space-between'
                                    }}
                                  >
                                    <div
                                      style={{
                                        display: 'flex',
                                        alignItems: 'left',
                                        flexDirection: 'column',
                                        gap: '14px'
                                      }}
                                    >
                                      <span
                                        className={cx(
                                          'text-sm font-semibold',
                                          MAIN_TXT_COLOR
                                        )}
                                        style={{
                                          fontSize: '14px',
                                          fontFamily: 'Montserrat'
                                        }}
                                      >
                                        Name
                                      </span>
                                      <TextField
                                        value={tableData[0][colIndex] ?? ''}
                                        placeholder={`Header ${colIndex + 1}`}
                                        onChange={(e) =>
                                          handleTableCellChange(
                                            trait,
                                            0,
                                            colIndex,
                                            e.target.value
                                          )
                                        }
                                        sx={{
                                          flex: 1,
                                          '& .MuiInputBase-root': {
                                            height: '34px',
                                            color: '#fff',
                                            backgroundColor:
                                              'rgba(255, 255, 255, 0.1)',
                                            borderRadius: '6px',
                                            border: 'none'
                                          },
                                          '& .MuiInputBase-input': {
                                            height: '34px',
                                            padding: '0 14px',
                                            boxSizing: 'border-box',
                                            border: 'none'
                                          },
                                          '& .MuiOutlinedInput-notchedOutline':
                                            { border: 'none' },
                                          '&:hover .MuiOutlinedInput-notchedOutline':
                                            { border: 'none' },
                                          '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                            { border: 'none' }
                                        }}
                                      />
                                    </div>
                                    <IconButton
                                      onClick={() => {
                                        if (editor) handleAddColumn(trait, editor);
                                      }}
                                      title='Add Column'
                                      disabled={!isEditorReady}
                                      sx={{
                                        backgroundColor: '#4170ff',
                                        width: '36px',
                                        height: '36px',
                                        borderRadius: '6px',
                                        '&:hover': {
                                          backgroundColor: '#365fd9'
                                        },
                                        '&:disabled': {
                                          backgroundColor:
                                            'rgba(65, 112, 255, 0.5)'
                                        }
                                      }}
                                    >
                                      <svg
                                        width='14'
                                        height='14'
                                        viewBox='0 0 14 14'
                                        fill='none'
                                        xmlns='http://www.w3.org/2000/svg'
                                      >
                                        <path
                                          d='M7 0.75V13.25M13.25 7H0.75'
                                          stroke='white'
                                          strokeWidth='1.5'
                                          strokeLinecap='round'
                                          strokeLinejoin='round'
                                        />
                                      </svg>
                                    </IconButton>
                                  </div>
                                  <span
                                    className={cx(
                                      'text-sm font-semibold',
                                      MAIN_TXT_COLOR
                                    )}
                                    style={{
                                      fontSize: '14px',
                                      marginTop: '8px',
                                      fontFamily: 'Montserrat'
                                    }}
                                  >
                                    Cells
                                  </span>
                                  {tableData.slice(1).map((row, rowIndex) => (
                                    <div
                                      key={`cell-${rowIndex + 1}-${colIndex}`}
                                      style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '8px'
                                      }}
                                    >
                                      <TextField
                                        value={row[colIndex] ?? ''}
                                        placeholder={`Cell ${rowIndex + 1}`}
                                        onChange={(e) =>
                                          handleTableCellChange(
                                            trait,
                                            rowIndex + 1,
                                            colIndex,
                                            e.target.value
                                          )
                                        }
                                        sx={{
                                          flex: 1,
                                          '& .MuiInputBase-root': {
                                            height: '34px',
                                            color: '#fff',
                                            backgroundColor:
                                              'rgba(255, 255, 255, 0.1)',
                                            borderRadius: '6px',
                                            border: 'none'
                                          },
                                          '& .MuiInputBase-input': {
                                            height: '34px',
                                            padding: '0 14px',
                                            boxSizing: 'border-box',
                                            border: 'none'
                                          },
                                          '& .MuiOutlinedInput-notchedOutline':
                                            { border: 'none' },
                                          '&:hover .MuiOutlinedInput-notchedOutline':
                                            { border: 'none' },
                                          '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                            { border: 'none' }
                                        }}
                                      />
                                      <IconButton
                                        onClick={() =>
                                          handleClearCell(
                                            trait,
                                            rowIndex + 1,
                                            colIndex
                                          )
                                        }
                                        title='Clear Cell'
                                        disabled={!isEditorReady}
                                        sx={{
                                          backgroundColor: '#3D3AB8',
                                          width: '36px',
                                          height: '36px',
                                          borderRadius: '6px',
                                          '&:hover': {
                                            backgroundColor: '#365fd9'
                                          },
                                          '&:disabled': {
                                            backgroundColor: 'transparent'
                                          }
                                        }}
                                      >
                                        <svg
                                          width='12'
                                          height='12'
                                          viewBox='0 0 12 12'
                                          fill='none'
                                          xmlns='http://www.w3.org/2000/svg'
                                        >
                                          <path
                                            fill-rule='evenodd'
                                            clip-rule='evenodd'
                                            d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                                            fill='white'
                                          />
                                        </svg>
                                      </IconButton>
                                      {rowIndex === tableData.length - 2 && (
                                        <IconButton
                                          onClick={() => {
                                            if (editor) handleAddRow(trait, editor);
                                          }}
                                          title='Add Row'
                                          disabled={!isEditorReady}
                                          sx={{
                                            backgroundColor: '#4170ff',
                                            width: '36px',
                                            height: '36px',
                                            borderRadius: '6px',
                                            '&:hover': {
                                              backgroundColor: '#365fd9'
                                            },
                                            '&:disabled': {
                                              backgroundColor:
                                                'rgba(65, 112, 255, 0.5)'
                                            }
                                          }}
                                        >
                                          <svg
                                            width='14'
                                            height='14'
                                            viewBox='0 0 14 14'
                                            fill='none'
                                            xmlns='http://www.w3.org/2000/svg'
                                          >
                                            <path
                                              d='M7 0.75V13.25M13.25 7H0.75'
                                              stroke='white'
                                              strokeWidth='1.5'
                                              strokeLinecap='round'
                                              strokeLinejoin='round'
                                            />
                                          </svg>
                                        </IconButton>
                                      )}
                                    </div>
                                  ))}
                                </Box>
                              ))}
                            </div>
                          </Box>
                        );
                      } else if (name === 'cards') {
                        return (
                          <Box
                            key={name}
                            sx={{
                              color: 'rgba(255, 255, 255, 1)',
                              borderRadius: '6px',
                              height: '100%',
                              overflowY: 'auto',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '8px'
                            }}
                          >
                            {cardsData.map((card, cardIndex) => (
                              <Box
                                key={`card-${cardIndex}`}
                                sx={{
                                  position: 'relative',
                                  display: 'flex',
                                  flexDirection: 'column',
                                  gap: '8px',
                                  borderRadius: '6px',
                                  padding: '16px',
                                  backgroundColor: '#2E3134',
                                  transition: 'all 0.3s ease',
                                  width: '310px',
                                  maxWidth: '400px'
                                }}
                              >
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    gap: '8px'
                                  }}
                                >
                                  <span
                                    className={cx(
                                      'text-sm font-semibold',
                                      MAIN_TXT_COLOR
                                    )}
                                    style={{
                                      fontSize: '14px',
                                      fontFamily: 'Montserrat'
                                    }}
                                  >
                                    Card {cardIndex + 1}
                                  </span>
                                  <IconButton
                                    onClick={() => {
                                      const newData = [...cardsData];
                                      if (newData.length <= 1) {
                                        editor?.Modal.open({
                                          title: 'Ошибка',
                                          content:
                                            'Должна остаться хотя бы одна карточка.'
                                        });
                                        return;
                                      }
                                      newData.splice(cardIndex, 1);
                                      handleTraitChange(
                                        trait,
                                        JSON.stringify(newData)
                                      );
                                    }}
                                    title='Remove Card'
                                    disabled={cardsData.length <= 1}
                                    sx={{
                                      backgroundColor: '#3D3AB8',
                                      width: '36px',
                                      height: '36px',
                                      borderRadius: '6px',
                                      '&:hover': { backgroundColor: '#d32f2f' },
                                      '&:disabled': {
                                        backgroundColor:
                                          'rgba(244, 67, 54, 0.5)'
                                      }
                                    }}
                                  >
                                    <svg
                                      width='12'
                                      height='12'
                                      viewBox='0 0 12 12'
                                      fill='none'
                                      xmlns='http://www.w3.org/2000/svg'
                                    >
                                      <path
                                        fillRule='evenodd'
                                        clipRule='evenodd'
                                        d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                                        fill='white'
                                      />
                                    </svg>
                                  </IconButton>
                                </Box>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '8px'
                                  }}
                                >
                                  <Box
                                    sx={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '4px'
                                    }}
                                  >
                                    <span
                                      className={cx('text-xs', MAIN_TXT_COLOR)}
                                      style={{
                                        fontSize: '14px',
                                        fontFamily: 'Montserrat'
                                      }}
                                    >
                                      Title
                                    </span>
                                    <TextField
                                      value={card.title || ''}
                                      placeholder={`Product ${cardIndex + 1}`}
                                      onChange={(e) =>
                                        handleCardFieldChange(
                                          trait,
                                          cardIndex,
                                          'title',
                                          e.target.value
                                        )
                                      }
                                      sx={{
                                        width: '100%',
                                        '& .MuiInputBase-root': {
                                          height: '34px',
                                          color: '#fff',
                                          backgroundColor:
                                            'rgba(255, 255, 255, 0.1)',
                                          borderRadius: '6px',
                                          border: 'none'
                                        },
                                        '& .MuiInputBase-input': {
                                          height: '34px',
                                          padding: '0 14px',
                                          boxSizing: 'border-box',
                                          border: 'none'
                                        },
                                        '& .MuiOutlinedInput-notchedOutline': {
                                          border: 'none'
                                        },
                                        '&:hover .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          },
                                        '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          }
                                      }}
                                    />
                                  </Box>
                                  <Box
                                    sx={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '4px'
                                    }}
                                  >
                                    <span
                                      className={cx('text-xs', MAIN_TXT_COLOR)}
                                      style={{
                                        fontSize: '14px',
                                        fontFamily: 'Montserrat'
                                      }}
                                    >
                                      Description
                                    </span>
                                    <TextField
                                      value={card.description || ''}
                                      placeholder='Description'
                                      onChange={(e) =>
                                        handleCardFieldChange(
                                          trait,
                                          cardIndex,
                                          'description',
                                          e.target.value
                                        )
                                      }
                                      sx={{
                                        width: '100%',
                                        '& .MuiInputBase-root': {
                                          height: '34px',
                                          color: '#fff',
                                          backgroundColor:
                                            'rgba(255, 255, 255, 0.1)',
                                          borderRadius: '6px',
                                          border: 'none'
                                        },
                                        '& .MuiInputBase-input': {
                                          height: '34px',
                                          padding: '0 14px',
                                          boxSizing: 'border-box',
                                          border: 'none'
                                        },
                                        '& .MuiOutlinedInput-notchedOutline': {
                                          border: 'none'
                                        },
                                        '&:hover .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          },
                                        '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          }
                                      }}
                                    />
                                  </Box>
                                  <Box
                                    sx={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '4px',
                                      position: 'relative'
                                    }}
                                  >
                                    <span
                                      className={cx('text-xs', MAIN_TXT_COLOR)}
                                      style={{
                                        fontSize: '14px',
                                        fontFamily: 'Montserrat'
                                      }}
                                    >
                                      Image
                                    </span>
                                    <label
                                      className={cx(
                                        'inline-flex items-center justify-center gap-2',
                                        'px-4 py-2 rounded border cursor-pointer',
                                        'hover:bg-opacity-30 transition-colors'
                                      )}
                                      style={{
                                        backgroundColor:
                                          'rgba(65, 112, 255, 0.2)',
                                        borderColor: 'rgba(65, 112, 255, 1)',
                                        color: '#fff'
                                      }}
                                    >
                                      <span className='flex items-center justify-center'>
                                        <svg
                                          width='18'
                                          height='22'
                                          viewBox='0 0 18 22'
                                          fill='none'
                                          xmlns='http://www.w3.org/2000/svg'
                                          style={{ display: 'inline-block' }}
                                        >
                                          <path
                                            d='M2.48585 0.714233C1.94027 0.714233 1.41702 0.930968 1.03123 1.31676C0.645445 1.70255 0.428711 2.22579 0.428711 2.77138V19.2285C0.428711 19.7741 0.645445 20.2973 1.03123 20.6831C1.41702 21.0689 1.94027 21.2857 2.48585 21.2857H15.5144C16.06 21.2857 16.5833 21.0689 16.969 20.6831C17.3548 20.2973 17.5716 19.7741 17.5716 19.2285V8.92395C17.5716 8.29909 17.323 7.69995 16.8816 7.25766L10.9407 1.3168C10.5549 0.93101 10.0317 0.714259 9.48614 0.714233H2.48585ZM1.71443 2.77138C1.71443 2.56678 1.7957 2.37056 1.94037 2.22589C2.08504 2.08122 2.28126 1.99995 2.48585 1.99995H9.00014V7.57138C9.00014 8.02603 9.18075 8.46207 9.50224 8.78356C9.82373 9.10505 10.2598 9.28566 10.7144 9.28566H16.2859V19.2285C16.2859 19.4331 16.2046 19.6293 16.0599 19.774C15.9152 19.9187 15.719 19.9999 15.5144 19.9999H2.48585C2.28126 19.9999 2.08504 19.9187 1.94037 19.774C1.7957 19.6293 1.71443 19.4331 1.71443 19.2285V2.77138ZM15.8059 7.99995H10.7144C10.6008 7.99995 10.4918 7.9548 10.4114 7.87442C10.331 7.79405 10.2859 7.68504 10.2859 7.57138V2.47995L15.8059 7.99995Z'
                                            fill='currentColor'
                                          />
                                        </svg>
                                      </span>
                                      <span>Choose Image</span>
                                      <input
                                        type='file'
                                        accept='image/*'
                                        onChange={(e) =>
                                          handleCardImageChange(
                                            trait,
                                            cardIndex,
                                            e
                                          )
                                        }
                                        className='hidden'
                                      />
                                    </label>
                                    {cardIndex === cardsData.length - 1 && (
                                      <IconButton
                                        onClick={() => {
                                          const newData = [...cardsData];
                                          if (newData.length >= 20) {
                                            editor?.Modal.open({
                                              title: 'Ошибка',
                                              content: 'Максимум 20 карточек.'
                                            });
                                            return;
                                          }
                                          newData.push({
                                            title: `Product ${newData.length + 1}`,
                                            description: 'Description',
                                            image:
                                              'https://via.placeholder.com/150'
                                          });
                                          handleTraitChange(
                                            trait,
                                            JSON.stringify(newData)
                                          );
                                        }}
                                        title='Add Card'
                                        disabled={cardsData.length >= 20}
                                        sx={{
                                          alignSelf: 'end',
                                          backgroundColor: '#4170ff',
                                          width: '36px',
                                          height: '36px',
                                          borderRadius: '6px',
                                          '&:hover': {
                                            backgroundColor: '#365fd9'
                                          },
                                          '&:disabled': {
                                            backgroundColor:
                                              'rgba(65, 112, 255, 0.5)'
                                          }
                                        }}
                                      >
                                        <svg
                                          width='18'
                                          height='18'
                                          viewBox='0 0 14 14'
                                          fill='none'
                                          xmlns='http://www.w3.org/2000/svg'
                                        >
                                          <path
                                            d='M7 0.75V13.25M13.25 7H0.75'
                                            stroke='white'
                                            strokeWidth='1.5'
                                            strokeLinecap='round'
                                            strokeLinejoin='round'
                                          />
                                        </svg>
                                      </IconButton>
                                    )}
                                  </Box>
                                </Box>
                              </Box>
                            ))}
                          </Box>
                        );
                      } else if (name === 'road-map') {
                        return (
                          <Box
                            key={name}
                            sx={{
                              color: 'rgba(255, 255, 255, 1)',
                              borderRadius: '6px',
                              height: '100%',
                              overflowY: 'auto',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '8px'
                            }}
                          >
                            {roadMapData.map((milestone, milestoneIndex) => (
                              <Box
                                key={`milestone-${milestone.id}`}
                                sx={{
                                  position: 'relative',
                                  display: 'flex',
                                  flexDirection: 'column',
                                  gap: '8px',
                                  borderRadius: '6px',
                                  padding: '16px',
                                  backgroundColor: '#2E3134',
                                  transition: 'all 0.3s ease',
                                  width: '310px',
                                  maxWidth: '400px'
                                }}
                              >
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    gap: '8px'
                                  }}
                                >
                                  <span
                                    className={cx(
                                      'text-sm font-semibold',
                                      MAIN_TXT_COLOR
                                    )}
                                    style={{
                                      fontSize: '14px',
                                      fontFamily: 'Montserrat'
                                    }}
                                  >
                                    Milestone {milestoneIndex + 1}
                                  </span>
                                  <IconButton
                                    onClick={() => {
                                      const newData = [...roadMapData];
                                      if (newData.length <= 1) {
                                        editor?.Modal.open({
                                          title: 'Ошибка',
                                          content:
                                            'Должна остаться хотя бы одна веха.'
                                        });
                                        return;
                                      }
                                      newData.splice(milestoneIndex, 1);
                                      setRoadMapData(newData);
                                      handleTraitChange(
                                        trait,
                                        JSON.stringify(newData)
                                      );
                                    }}
                                    title='Remove Milestone'
                                    disabled={roadMapData.length <= 1}
                                    sx={{
                                      backgroundColor: '#3D3AB8',
                                      width: '36px',
                                      height: '36px',
                                      borderRadius: '6px',
                                      '&:hover': { backgroundColor: '#d32f2f' },
                                      '&:disabled': {
                                        backgroundColor:
                                          'rgba(244, 67, 54, 0.5)'
                                      }
                                    }}
                                  >
                                    <svg
                                      width='12'
                                      height='12'
                                      viewBox='0 0 12 12'
                                      fill='none'
                                      xmlns='http://www.w3.org/2000/svg'
                                    >
                                      <path
                                        fillRule='evenodd'
                                        clipRule='evenodd'
                                        d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                                        fill='white'
                                      />
                                    </svg>
                                  </IconButton>
                                </Box>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '8px'
                                  }}
                                >
                                  <Box
                                    sx={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '4px'
                                    }}
                                  >
                                    <span
                                      className={cx('text-xs', MAIN_TXT_COLOR)}
                                      style={{
                                        fontSize: '14px',
                                        fontFamily: 'Montserrat'
                                      }}
                                    >
                                      Title
                                    </span>
                                    <TextField
                                      value={milestone.title || ''}
                                      placeholder={`Веха ${milestoneIndex + 1}`}
                                      onChange={(e) =>
                                        handleRoadMapFieldChange(
                                          trait,
                                          milestoneIndex,
                                          'title',
                                          e.target.value
                                        )
                                      }
                                      sx={{
                                        width: '100%',
                                        '& .MuiInputBase-root': {
                                          height: '34px',
                                          color: '#fff',
                                          backgroundColor:
                                            'rgba(255, 255, 255, 0.1)',
                                          borderRadius: '6px',
                                          border: 'none'
                                        },
                                        '& .MuiInputBase-input': {
                                          height: '34px',
                                          padding: '0 14px',
                                          boxSizing: 'border-box',
                                          border: 'none'
                                        },
                                        '& .MuiOutlinedInput-notchedOutline': {
                                          border: 'none'
                                        },
                                        '&:hover .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          },
                                        '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          }
                                      }}
                                    />
                                  </Box>
                                  <Box
                                    sx={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '4px'
                                    }}
                                  >
                                    <span
                                      className={cx('text-xs', MAIN_TXT_COLOR)}
                                      style={{
                                        fontSize: '14px',
                                        fontFamily: 'Montserrat'
                                      }}
                                    >
                                      Date
                                    </span>
                                    <TextField
                                      type='date'
                                      value={milestone.date || ''}
                                      onChange={(e) =>
                                        handleRoadMapFieldChange(
                                          trait,
                                          milestoneIndex,
                                          'date',
                                          e.target.value
                                        )
                                      }
                                      sx={{
                                        width: '100%',
                                        '& .MuiInputBase-root': {
                                          height: '34px',
                                          color: '#fff',
                                          backgroundColor:
                                            'rgba(255, 255, 255, 0.1)',
                                          borderRadius: '6px',
                                          border: 'none'
                                        },
                                        '& .MuiInputBase-input': {
                                          height: '34px',
                                          padding: '0 14px',
                                          boxSizing: 'border-box',
                                          border: 'none'
                                        },
                                        '& .MuiOutlinedInput-notchedOutline': {
                                          border: 'none'
                                        },
                                        '&:hover .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          },
                                        '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          }
                                      }}
                                    />
                                  </Box>
                                  <Box
                                    sx={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '4px'
                                    }}
                                  >
                                    <span
                                      className={cx('text-xs', MAIN_TXT_COLOR)}
                                      style={{
                                        fontSize: '14px',
                                        fontFamily: 'Montserrat'
                                      }}
                                    >
                                      Description
                                    </span>
                                    <TextField
                                      value={milestone.description || ''}
                                      placeholder='Описание'
                                      onChange={(e) =>
                                        handleRoadMapFieldChange(
                                          trait,
                                          milestoneIndex,
                                          'description',
                                          e.target.value
                                        )
                                      }
                                      sx={{
                                        width: '100%',
                                        '& .MuiInputBase-root': {
                                          height: '34px',
                                          color: '#fff',
                                          backgroundColor:
                                            'rgba(255, 255, 255, 0.1)',
                                          borderRadius: '6px',
                                          border: 'none'
                                        },
                                        '& .MuiInputBase-input': {
                                          height: '34px',
                                          padding: '0 14px',
                                          boxSizing: 'border-box',
                                          border: 'none'
                                        },
                                        '& .MuiOutlinedInput-notchedOutline': {
                                          border: 'none'
                                        },
                                        '&:hover .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          },
                                        '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          }
                                      }}
                                    />
                                  </Box>
                                  <Box
                                    sx={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: '4px'
                                    }}
                                  >
                                    <span
                                      className={cx('text-xs', MAIN_TXT_COLOR)}
                                      style={{
                                        fontSize: '14px',
                                        fontFamily: 'Montserrat'
                                      }}
                                    >
                                      Status
                                    </span>
                                    <Select
                                      value={milestone.status || 'planned'}
                                      onChange={(e) =>
                                        handleRoadMapFieldChange(
                                          trait,
                                          milestoneIndex,
                                          'status',
                                          e.target.value
                                        )
                                      }
                                      sx={{
                                        height: '34px',
                                        color: '#fff',
                                        backgroundColor:
                                          'rgba(255, 255, 255, 0.1)',
                                        borderRadius: '6px',
                                        border: 'none',
                                        '& .MuiSelect-select': {
                                          padding: '0 14px',
                                          height: '34px',
                                          boxSizing: 'border-box'
                                        },
                                        '& .MuiOutlinedInput-notchedOutline': {
                                          border: 'none'
                                        },
                                        '&:hover .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          },
                                        '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                          {
                                            border: 'none'
                                          }
                                      }}
                                    >
                                      <MenuItem value='planned'>
                                        Planned
                                      </MenuItem>
                                      <MenuItem value='in-progress'>
                                        In process{' '}
                                      </MenuItem>
                                      <MenuItem value='completed'>
                                        Completed
                                      </MenuItem>
                                    </Select>
                                  </Box>
                                  {milestoneIndex ===
                                    roadMapData.length - 1 && (
                                    <IconButton
                                      onClick={() => {
                                        const newData = [...roadMapData];
                                        if (newData.length >= 20) {
                                          editor?.Modal.open({
                                            title: 'Error',
                                            content: 'Max 20 Milestones.'
                                          });
                                          return;
                                        }
                                        newData.push({
                                          id: crypto.randomUUID(),
                                          title: `Milestone ${newData.length + 1}`,
                                          date: '2025-07-10',
                                          description: 'Description',
                                          status: 'planned'
                                        });
                                        setRoadMapData(newData);
                                        handleTraitChange(
                                          trait,
                                          JSON.stringify(newData)
                                        );
                                      }}
                                      title='Add Milestone'
                                      disabled={roadMapData.length >= 20}
                                      sx={{
                                        alignSelf: 'end',
                                        backgroundColor: '#4170ff',
                                        width: '36px',
                                        height: '36px',
                                        borderRadius: '6px',
                                        '&:hover': {
                                          backgroundColor: '#365fd9'
                                        },
                                        '&:disabled': {
                                          backgroundColor:
                                            'rgba(65, 112, 255, 0.5)'
                                        }
                                      }}
                                    >
                                      <svg
                                        width='14'
                                        height='14'
                                        viewBox='0 0 14 14'
                                        fill='none'
                                        xmlns='http://www.w3.org/2000/svg'
                                      >
                                        <path
                                          d='M7 0.75V13.25M13.25 7H0.75'
                                          stroke='white'
                                          strokeWidth='1.5'
                                          strokeLinecap='round'
                                          strokeLinejoin='round'
                                        />
                                      </svg>
                                    </IconButton>
                                  )}
                                </Box>
                              </Box>
                            ))}
                          </Box>
                        );
                      }
                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <label
                            className={cx(
                              'text-sm capitalize mb-[11px]',
                              MAIN_TXT_COLOR
                            )}
                            style={{
                              fontSize: '14px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            {label}
                          </label>
                          <TextField
                            size='small'
                            fullWidth
                            multiline
                            rows={4}
                            value={value ?? ''}
                            onChange={(e) =>
                              handleTraitChange(trait, e.target.value)
                            }
                            sx={{
                              '& .MuiInputBase-root': {
                                color: '#fff',
                                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                                borderRadius: '6px',
                                border: 'none'
                              },
                              '& .MuiInputBase-input': {
                                padding: '8px 14px',
                                boxSizing: 'border-box',
                                border: 'none'
                              },
                              '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                { border: 'none' }
                            }}
                          />
                        </div>
                      );

                    case 'number':
                      if (hasUnits) {
                        const traitName = trait.getName();
                        const currentValue =
                          traitStates[traitName]?.value || numericValue;
                        const currentUnit =
                          traitStates[traitName]?.unit || unitValue || 'px';

                        if (!traitStates[traitName]) {
                          setTraitStates((prev) => ({
                            ...prev,
                            [traitName]: {
                              value: numericValue || 0,
                              unit: unitValue || 'px'
                            }
                          }));
                        }

                        return (
                          <div
                            key={name}
                            className='w-full mb-2'
                          >
                            <label
                              className={cx(
                                'block capitalize mb-[11px] text-sm',
                                MAIN_TXT_COLOR
                              )}
                              style={{
                                fontSize: '14px',
                                fontFamily: 'Montserrat'
                              }}
                            >
                              {label}
                            </label>
                            <TextField
                              type='number'
                              value={currentValue || 0}
                              placeholder='Enter Value'
                              onChange={(e) => handleNumberChange(trait, e)}
                              style={{
                                background: 'rgba(255, 255, 255, 0.1)',
                                borderRadius: '6px',
                                border: 'none'
                              }}
                              size='small'
                              fullWidth
                              sx={{
                                background: 'rgba(255, 255, 255, 0.1)',
                                '& .MuiOutlinedInput-root': {
                                  border: 'none',
                                  borderRadius: '6px',
                                  height: '34px',
                                  '& input': {
                                    border: 'none',
                                    padding: '0 14px',
                                    height: '34px'
                                  },
                                  '& fieldset': {
                                    border: 'none'
                                  },
                                  '&:hover fieldset': {
                                    border: 'none'
                                  },
                                  '&.Mui-focused fieldset': {
                                    border: 'none'
                                  }
                                }
                              }}
                              InputProps={{
                                endAdornment: (
                                  <InputAdornment
                                    position='end'
                                    sx={{
                                      display: 'flex',
                                      alignItems: 'center',
                                      textAlign: 'center'
                                    }}
                                  >
                                    <Select
                                      value={currentUnit}
                                      onChange={(e) =>
                                        handleUnitChange(trait, e)
                                      }
                                      variant='standard'
                                      disableUnderline
                                      sx={{
                                        '& .MuiSelect-select': {
                                          fontSize: '8px',
                                          border:
                                            '1px solid rgba(255, 255, 255, 0.15)',
                                          borderRadius: '6px',
                                          width: '24px',
                                          height: '24px',
                                          display: 'flex',
                                          alignItems: 'center',
                                          justifyContent: 'center !important',
                                          padding: '0 !important',
                                          margin: '0 !important',
                                          boxSizing: 'border-box',
                                          textAlign: 'center !important',
                                          lineHeight: '24px',
                                          overflow: 'hidden'
                                        },
                                        '& .MuiSelect-icon': {
                                          display: 'none'
                                        },
                                        '& .MuiSelect-select.Mui-focused': {
                                          width: '24px',
                                          height: '24px',
                                          border:
                                            '1px solid rgba(255, 255, 255, 0.15)',
                                          borderRadius: '6px',
                                          padding: '0 !important',
                                          margin: '0 !important',
                                          lineHeight: '24px'
                                        },
                                        width: '24px',
                                        height: '24px',
                                        minWidth: '24px'
                                      }}
                                    >
                                      {units.map((unit: string) => (
                                        <MenuItem
                                          key={unit}
                                          value={unit}
                                          sx={{
                                            fontSize: '10px',
                                            width: 'auto',
                                            minHeight: '24px',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            textAlign: 'center'
                                          }}
                                        >
                                          {unit}
                                        </MenuItem>
                                      ))}
                                    </Select>
                                    <Box
                                      sx={{
                                        display: 'flex',
                                        flexDirection: 'column',
                                        ml: '4px'
                                      }}
                                    >
                                      <svg
                                        width='12'
                                        height='12'
                                        viewBox='0 0 12 12'
                                        fill='none'
                                        xmlns='http://www.w3.org/2000/svg'
                                        style={{ cursor: 'pointer' }}
                                        onClick={() =>
                                          handleUnitCycle(trait, 'up')
                                        }
                                      >
                                        <path
                                          d='M8.5 7L6 4.5L3.5 7'
                                          stroke='rgba(255, 255, 255, 0.5)'
                                          strokeWidth='2'
                                          strokeLinecap='round'
                                          strokeLinejoin='round'
                                        />
                                      </svg>
                                      <svg
                                        width='12'
                                        height='12'
                                        viewBox='0 0 12 12'
                                        fill='none'
                                        xmlns='http://www.w3.org/2000/svg'
                                        style={{ cursor: 'pointer' }}
                                        onClick={() =>
                                          handleUnitCycle(trait, 'down')
                                        }
                                      >
                                        <path
                                          d='M3.5 5L6 7.5L8.5 5'
                                          stroke='rgba(255, 255, 255, 0.5)'
                                          strokeWidth='2'
                                          strokeLinecap='round'
                                          strokeLinejoin='round'
                                        />
                                      </svg>
                                    </Box>
                                  </InputAdornment>
                                )
                              }}
                            />
                          </div>
                        );
                      }
                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <label
                            className={cx(
                              'block capitalize mb-[11px] text-sm',
                              MAIN_TXT_COLOR
                            )}
                            style={{
                              fontSize: '14px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            {label}
                          </label>
                          <TextField
                            fullWidth
                            type='number'
                            value={value ?? ''}
                            onChange={(e) =>
                              handleTraitChange(trait, e.target.value)
                            }
                            sx={{
                              borderRadius: '6px !important',
                              background: 'rgba(255, 255, 255, 0.1)',
                              '& .MuiInputBase-root': {
                                borderRadius: '6px !important',
                                height: '34px',
                                color: '#fff',
                                background: 'transparent',
                                border: 'none'
                              },
                              '& .MuiInputBase-input': {
                                padding: '0 14px',
                                height: '34px',
                                boxSizing: 'border-box',
                                border: 'none'
                              },
                              '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                {
                                  border: 'none'
                                }
                            }}
                            InputProps={{
                              endAdornment: (
                                <InputAdornment
                                  position='end'
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    textAlign: 'center'
                                  }}
                                >
                                  <Box
                                    sx={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      ml: '4px'
                                    }}
                                  >
                                    <svg
                                      width='12'
                                      height='12'
                                      viewBox='0 0 12 12'
                                      fill='none'
                                      xmlns='http://www.w3.org/2000/svg'
                                      style={{ cursor: 'pointer' }}
                                      onClick={() =>
                                        handleNumberCycle(trait, 'up')
                                      }
                                    >
                                      <path
                                        d='M8.5 7L6 4.5L3.5 7'
                                        stroke='rgba(255, 255, 255, 0.5)'
                                        strokeWidth='2'
                                        strokeLinecap='round'
                                        strokeLinejoin='round'
                                      />
                                    </svg>
                                    <svg
                                      width='12'
                                      height='12'
                                      viewBox='0 0 12 12'
                                      fill='none'
                                      xmlns='http://www.w3.org/2000/svg'
                                      style={{ cursor: 'pointer' }}
                                      onClick={() =>
                                        handleNumberCycle(trait, 'down')
                                      }
                                    >
                                      <path
                                        d='M3.5 5L6 7.5L8.5 5'
                                        stroke='rgba(255, 255, 255, 0.5)'
                                        strokeWidth='2'
                                        strokeLinecap='round'
                                        strokeLinejoin='round'
                                      />
                                    </svg>
                                  </Box>
                                </InputAdornment>
                              )
                            }}
                          />
                        </div>
                      );
                    case 'text':
                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <label
                            className={cx(
                              'block capitalize mb-[11px] text-sm',
                              MAIN_TXT_COLOR
                            )}
                            style={{
                              fontSize: '14px',
                              borderRadius: '6px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            {label}
                          </label>
                          <TextField
                            fullWidth
                            value={value ?? ''}
                            onChange={(e) =>
                              handleTraitChange(trait, e.target.value)
                            }
                            placeholder={
                              trait.get('placeholder') || 'Enter Value'
                            }
                            sx={{
                              height: '34px',
                              '& .MuiInputBase-root': {
                                height: '34px',
                                color: '#fff',
                                background: 'rgba(255, 255, 255, 0.1)',
                                borderRadius: '6px',
                                border: 'none',
                                fontFamily: 'Montserrat',
                                fontSize: '14px'
                              },
                              '& .MuiInputBase-input': {
                                height: '34px',
                                padding: '0 14px',
                                boxSizing: 'border-box',
                                border: 'none',
                                fontFamily: 'Montserrat',
                                '&::placeholder': {
                                  fontSize: '14px',
                                  color: '#D3D6E7',
                                  opacity: 1
                                }
                              },
                              '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none',
                                fontFamily: 'Montserrat'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                border: 'none',
                                fontFamily: 'Montserrat'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                {
                                  border: 'none',
                                  fontFamily: 'Montserrat'
                                }
                            }}
                          />
                        </div>
                      );

                    case 'select':
                      if (name === 'minMax') {
                        return (
                          <div
                            key={name}
                            className='w-full mb-2'
                          >
                            <label
                              className={cx(
                                'block capitalize mb-[11px] text-sm',
                                MAIN_TXT_COLOR
                              )}
                              style={{
                                fontSize: '14px',
                                fontFamily: 'Montserrat'
                              }}
                            >
                              {label}
                            </label>
                            <div className='flex gap-2'>
                              {trait.getOptions().map((option) => (
                                <button
                                  key={String(option.id ?? option.value ?? '')}
                                  onClick={() =>
                                    handleTraitChange(trait, String(option.value ?? option.id ?? ''))
                                  }
                                  style={{
                                    flex: '1',
                                    width: '153px',
                                    height: '34px',
                                    borderRadius: '6px',
                                    backgroundColor:
                                      value === option.value
                                        ? '#4170FF'
                                        : 'rgba(255, 255, 255, 0.1)',
                                    color: '#fff',
                                    border: 'none',
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    fontSize: '14px'
                                  }}
                                >
                                  {String(option.name ?? option.label ?? '')}
                                </button>
                              ))}
                            </div>
                          </div>
                        );
                      }
                      if (
                        name === 'main-axis-alignment' ||
                        name === 'cross-axis-alignment'
                      ) {
                        const buttonWidth =
                          name === 'main-axis-alignment' ? '55px' : '73.5px';
                        return (
                          <div
                            key={name}
                            className='w-full mb-2'
                          >
                            <label
                              className={cx(
                                'block capitalize mb-[11px] text-sm',
                                MAIN_TXT_COLOR
                              )}
                              style={{
                                fontSize: '14px',
                                fontFamily: 'Montserrat'
                              }}
                            >
                              {label}
                            </label>
                            <div className='flex gap-2 flex-wrap'>
                              {trait.getOptions().map((option) => (
                                <button
                                  key={String(option.id ?? option.value ?? '')}
                                  onClick={() =>
                                    handleTraitChange(trait, String(option.value ?? option.id ?? ''))
                                  }
                                  style={{
                                    flex: '1',
                                    minWidth: buttonWidth,
                                    height: '34px',
                                    borderRadius: '6px',
                                    backgroundColor:
                                      value === option.value
                                        ? '#4170FF'
                                        : 'rgba(255, 255, 255, 0.1)',
                                    color: '#fff',
                                    border: 'none',
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    padding: '5px'
                                  }}
                                  dangerouslySetInnerHTML={{
                                    __html: String(option.icon ?? '')
                                  }}
                                  title={String(option.label ?? '')}
                                />
                              ))}
                            </div>
                          </div>
                        );
                      }
                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <label
                            className={cx(
                              'block capitalize mb-[11px] text-sm',
                              MAIN_TXT_COLOR
                            )}
                            style={{
                              fontSize: '14px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            {label}
                          </label>
                          <CustomSelect
                            maxWidth='100%'
                            options={trait.getOptions().map((option) => ({
                              value: String(option.value ?? option.id ?? ''),
                              label: String(option.name ?? option.label ?? option.value ?? option.id ?? '')
                            }))}
                            activeOption={
                              value
                                ? trait
                                    .getOptions()
                                    .find(
                                      (option) =>
                                        (option.value || option.id) === value
                                    )
                                  ? {
                                      value: String(value),
                                      label: String(
                                        trait
                                          .getOptions()
                                          .find(
                                            (option) =>
                                              (option.value || option.id) ===
                                              value
                                          )?.name ??
                                        trait
                                          .getOptions()
                                          .find(
                                            (option) =>
                                              (option.value || option.id) ===
                                              value
                                          )?.label ??
                                        value ??
                                        ''
                                      )
                                    }
                                  : undefined
                                : undefined
                            }
                            onChange={(option) =>
                              handleTraitChange(trait, option.value)
                            }
                            placeholder={value ? undefined : 'Select option...'}
                            size='sm'
                            color='secondary'
                            truncateLength={20}
                          />
                        </div>
                      );
                    case 'repeater':
                      return (
                        <RepeaterTrait
                          key={trait.getId()}
                          trait={trait}
                        />
                      );
                    case 'switch':
                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <div className='flex flex-col items-start'>
                            <span
                              className={cx(MAIN_TXT_COLOR, 'block')}
                              style={{
                                fontSize: '14px',
                                fontFamily: 'Montserrat',
                                marginBottom: '20px',
                                lineHeight: '1.2'
                              }}
                            >
                              {label}
                            </span>
                            <Switch
                              checked={!!value}
                              onChange={(e) =>
                                handleTraitChange(trait, e.target.checked)
                              }
                              sx={{
                                '& .MuiSwitch-switchBase.Mui-checked': {
                                  color: '#4170ff',
                                  '&:hover': {
                                    backgroundColor: 'rgba(65, 112, 255, 0.08)'
                                  }
                                },
                                '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track':
                                  {
                                    backgroundColor: '#4170ff'
                                  }
                              }}
                            />
                          </div>
                        </div>
                      );
                    case 'checkbox': {
                      const checked =
                        value === true ||
                        value === 'true' ||
                        value === 1 ||
                        value === '1';

                      const compactIconToggle =
                        name === 'showIcon' &&
                        ['password', 'email', 'telephone', 'login'].includes(
                          String(selectedComponentType || '')
                        );

                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <FormControlLabel
                            sx={{
                              m: 0,
                              minHeight: compactIconToggle ? '24px' : undefined,
                              alignItems: 'center',
                              '& .MuiFormControlLabel-label': {
                                display: 'flex',
                                alignItems: 'center'
                              }
                            }}
                            control={
                              <Checkbox
                                checked={checked}
                                onChange={(e) =>
                                  handleTraitChange(trait, e.target.checked)
                                }
                                disableRipple={compactIconToggle}
                                sx={{
                                  color: '#64748b',
                                  p: compactIconToggle ? 0 : undefined,
                                  mr: compactIconToggle ? '10px' : undefined,
                                  width: compactIconToggle ? '20px' : undefined,
                                  height: compactIconToggle ? '20px' : undefined,
                                  '& .MuiSvgIcon-root': {
                                    fontSize: compactIconToggle ? '20px' : undefined
                                  },
                                  '&.Mui-checked': {
                                    color: '#4170ff'
                                  }
                                }}
                              />
                            }
                            label={
                              <span
                                className={cx(MAIN_TXT_COLOR)}
                                style={{
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  gap: '8px',
                                  fontSize: '14px',
                                  fontFamily: 'Montserrat'
                                }}
                              >
                                {label}
                                {compactIconToggle && ['password', 'email'].includes(String(selectedComponentType)) && (
                                  <span
                                    aria-hidden='true'
                                    title='Show or hide the input icon'
                                    style={{
                                      width: '18px',
                                      height: '18px',
                                      border: '1px solid rgba(255,255,255,.22)',
                                      borderRadius: '50%',
                                      color: 'rgba(255,255,255,.48)',
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                      fontSize: '11px',
                                      lineHeight: 1
                                    }}
                                  >
                                    i
                                  </span>
                                )}
                              </span>
                            }
                          />
                        </div>
                      );
                    }
                    case 'color': {
                      const isLabelTextColor =
                        selectedComponentType === 'label-text' &&
                        (name === 'color' || name === 'borderColor');
                      return (
                        <div
                          key={name}
                          className={isLabelTextColor ? 'mb-2' : 'w-full mb-2'}
                          style={
                            isLabelTextColor
                              ? {
                                  width: '150px',
                                  flex: '1 1 150px',
                                  minWidth: '150px',
                                  maxWidth: '150px'
                                }
                              : undefined
                          }
                        >
                          <label
                            className={cx(
                              'block capitalize mb-[11px] text-sm',
                              MAIN_TXT_COLOR
                            )}
                            style={{
                              fontSize: '14px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            {label}
                          </label>
                          <ColorElement
                            value={value || '#000000'}
                            onChange={(color) =>
                              handleTraitChange(trait, color)
                            }
                          />
                        </div>
                      );
                    }
                    case 'file':
                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <label
                            className={cx(
                              'block capitalize mb-[11px] text-sm',
                              MAIN_TXT_COLOR
                            )}
                            style={{
                              fontSize: '14px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            {label}
                          </label>
                          <label
                            className={cx(
                              'inline-flex items-center justify-center gap-2',
                              'px-4 py-2 rounded border cursor-pointer',
                              'hover:bg-opacity-30 transition-colors'
                            )}
                            style={{
                              backgroundColor: 'rgba(65, 112, 255, 0.2)',
                              borderColor: 'rgba(65, 112, 255, 1)',
                              color: '#fff'
                            }}
                          >
                            <span className='flex items-center justify-center'>
                              <svg
                                width='18'
                                height='22'
                                viewBox='0 0 18 22'
                                fill='none'
                                xmlns='http://www.w3.org/2000/svg'
                                style={{ display: 'inline-block' }}
                              >
                                <path
                                  d='M2.48585 0.714233C1.94027 0.714233 1.41702 0.930968 1.03123 1.31676C0.645445 1.70255 0.428711 2.22579 0.428711 2.77138V19.2285C0.428711 19.7741 0.645445 20.2973 1.03123 20.6831C1.41702 21.0689 1.94027 21.2857 2.48585 21.2857H15.5144C16.06 21.2857 16.5833 21.0689 16.969 20.6831C17.3548 20.2973 17.5716 19.7741 17.5716 19.2285V8.92395C17.5716 8.29909 17.323 7.69995 16.8816 7.25766L10.9407 1.3168C10.5549 0.93101 10.0317 0.714259 9.48614 0.714233H2.48585ZM1.71443 2.77138C1.71443 2.56678 1.7957 2.37056 1.94037 2.22589C2.08504 2.08122 2.28126 1.99995 2.48585 1.99995H9.00014V7.57138C9.00014 8.02603 9.18075 8.46207 9.50224 8.78356C9.82373 9.10505 10.2598 9.28566 10.7144 9.28566H16.2859V19.2285C16.2859 19.4331 16.2046 19.6293 16.0599 19.774C15.9152 19.9187 15.719 19.9999 15.5144 19.9999H2.48585C2.28126 19.9999 2.08504 19.9187 1.94037 19.774C1.7957 19.6293 1.71443 19.4331 1.71443 19.2285V2.77138ZM15.8059 7.99995H10.7144C10.6008 7.99995 10.4918 7.9548 10.4114 7.87442C10.331 7.79405 10.2859 7.68504 10.2859 7.57138V2.47995L15.8059 7.99995Z'
                                  fill='currentColor'
                                />
                              </svg>
                            </span>
                            <span>Choose file</span>
                            <input
                              type='file'
                              accept='image/*'
                              onChange={(e) => handleFileChange(trait, e)}
                              className='hidden'
                            />
                          </label>
                        </div>
                      );
                    case 'select-icon':
                      return (
                        <>
                          <div
                            key={name}
                            className='w-full mb-2'
                          >
                            <label
                              className={cx(
                                'block capitalize mb-[11px] text-sm',
                                MAIN_TXT_COLOR
                              )}
                              style={{
                                fontSize: '14px',
                                fontFamily: 'Montserrat'
                              }}
                            >
                              {label}
                            </label>
                            <div className='flex items-center gap-2'>
                              <button
                                type='button'
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  width:
                                    selectedComponentType === 'button-icon' && name === 'selectImage'
                                      ? '86px'
                                      : selectedComponentType === 'login' && name === 'selectImage'
                                        ? '190px'
                                      : (selectedComponentType === 'password' || selectedComponentType === 'email' || selectedComponentType === 'telephone') && name === 'selectImage'
                                        ? '82px'
                                        : '153px',
                                  height:
                                    selectedComponentType === 'button-icon' && name === 'selectImage'
                                      ? '86px'
                                      : selectedComponentType === 'login' && name === 'selectImage'
                                        ? '46px'
                                      : (selectedComponentType === 'password' || selectedComponentType === 'email' || selectedComponentType === 'telephone') && name === 'selectImage'
                                        ? '72px'
                                        : selectedComponentType === 'circle-image' && name === 'selectImage'
                                          ? '46px'
                                          : '34px',
                                  backgroundColor: '#4170FF33',
                                  border: '1px solid #4170FF',
                                  borderRadius: '4px',
                                  cursor: 'pointer',
                                  padding: '0'
                                }}
                                onClick={(event) => {
                                  event.preventDefault();
                                  event.stopPropagation();
                                  setActiveIconTrait(trait);
                                  setActiveIconTraitName(name);
                                  setIsIconPickerOpen(true);
                                }}
                                aria-label={selectedComponentType === 'circle-image' || selectedComponentType === 'button-icon' || selectedComponentType === 'login' || selectedComponentType === 'telephone' ? 'Select Image' : 'Select Icon'}
                                title={selectedComponentType === 'circle-image' || selectedComponentType === 'button-icon' || selectedComponentType === 'login' || selectedComponentType === 'telephone' ? 'Select Image' : 'Select Icon'}
                              >
                                {resolveIconPreview(value) ? (
                                  <img
                                    src={resolveIconPreview(value)}
                                    alt='Selected Icon'
                                    style={{
                                      width: selectedComponentType === 'button-icon' ? '32px' : '24px',
                                      height: selectedComponentType === 'button-icon' ? '32px' : '24px',
                                      objectFit: 'contain'
                                    }}
                                  />
                                ) : (
                                  <svg
                                    width='24'
                                    height='24'
                                    viewBox='0 0 24 24'
                                    fill='none'
                                    xmlns='http://www.w3.org/2000/svg'
                                    aria-hidden='true'
                                  >
                                    <rect x='4.5' y='4.5' width='5.5' height='5.5' rx='1' stroke='white' strokeWidth='1.5' />
                                    <rect x='14' y='4.5' width='5.5' height='5.5' rx='1' stroke='white' strokeWidth='1.5' />
                                    <rect x='4.5' y='14' width='5.5' height='5.5' rx='1' stroke='white' strokeWidth='1.5' />
                                    <rect x='14' y='14' width='5.5' height='5.5' rx='1' stroke='white' strokeWidth='1.5' />
                                  </svg>
                                )}
                              </button>
                            </div>
                          </div>
                          {isIconPickerOpen && activeIconTraitName === name &&
                            createPortal(
                              <IconPickerModal
                                open={isIconPickerOpen}
                                onClose={() => {
                                  setIsIconPickerOpen(false);
                                  setActiveIconTrait(null);
                                  setActiveIconTraitName(null);
                                }}
                                onSelect={(iconId) => {
                                  const currentTrait =
                                    traits.find((item) => item.getName() === activeIconTraitName) ||
                                    activeIconTrait;
                                  if (currentTrait) {
                                    handleIconSelect(iconId, currentTrait);
                                  }
                                }}
                                selectedId={
                                  iconsStore.some((icon) => icon.id === String(value ?? ''))
                                    ? String(value)
                                    : undefined
                                }
                              />,
                              document.body
                            )}
                        </>
                      );

                    case 'list':
                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          {!(['single-radio', 'single-checkbox'].includes(String(selectedComponentType)) && name === 'options') && (
                            <label
                              className={cx(
                                'block capitalize mb-[11px] text-sm',
                                MAIN_TXT_COLOR
                              )}
                              style={{
                                fontSize: '14px',
                                fontFamily: 'Montserrat'
                              }}
                            >
                              {label}
                            </label>
                          )}
                          <div
                            style={{
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '8px'
                            }}
                          >
                            {(() => {
                              let items: any[] = [];
                              try {
                                let rawValue = value || trait.getValue();

                                if (!rawValue) {
                                  const component = trait.target;
                                  rawValue =
                                    component.get(name) ||
                                    component.getAttributes()[name];
                                }

                                if (typeof rawValue === 'string') {
                                  items = JSON.parse(rawValue || '[]');
                                } else if (Array.isArray(rawValue)) {
                                  items = rawValue;
                                }
                              } catch (e) {
                                console.error('Invalid JSON', e);
                              }

                              return items.map((item: any, index: number) => {
                                const isTabStruct =
                                  'name' in (item || {}) ||
                                  'id' in (item || {});

                                const displayValue =
                                  typeof item === 'object'
                                    ? isTabStruct
                                      ? item.name || item.label
                                      : item.label
                                    : item;
                                const isSelectOptionsList =
                                  selectedComponentType === 'custom-select' &&
                                  name === 'options';
                                const isRadioOptionsList =
                                  selectedComponentType === 'single-radio' &&
                                  name === 'options';
                                const isCheckboxOptionsList =
                                  selectedComponentType === 'single-checkbox' &&
                                  name === 'options';
                                const usesInlineAddButton =
                                  isSelectOptionsList || isRadioOptionsList || isCheckboxOptionsList;
                                const isLastItem = index === items.length - 1;

                                return (
                                  <div
                                    key={`${name}-${index}`}
                                    className='flex items-center gap-2 w-full min-w-0'
                                  >
                                    <TextField
                                      fullWidth
                                      value={displayValue ?? ''}
                                      onChange={(e) => {
                                        const newItems = [...items];
                                        const newVal = e.target.value;

                                        if (typeof item === 'object') {
                                          if (isTabStruct) {
                                            newItems[index] = {
                                              ...item,
                                              name: newVal,
                                              label: newVal,
                                              id: item.id || `tab${index + 1}`
                                            };
                                          } else {
                                            newItems[index] = {
                                              ...item,
                                              label: newVal,
                                              value:
                                                isSelectOptionsList ||
                                                isRadioOptionsList ||
                                                isCheckboxOptionsList
                                                  ? newVal
                                                  : item.value ||
                                                    `option${index + 1}`
                                            };
                                          }
                                        } else {
                                          newItems[index] = newVal;
                                        }

                                        handleTraitChange(
                                          trait,
                                          JSON.stringify(newItems)
                                        );
                                      }}
                                      sx={{
                                        flex: 1,
                                        minWidth: 0,
                                        height: '34px',
                                        '& .MuiInputBase-root': {
                                          height: '34px',
                                          color: '#fff',
                                          background:
                                            'rgba(255, 255, 255, 0.1)',
                                          borderRadius: '4px',
                                          border: 'none'
                                        },
                                        '& .MuiInputBase-input': {
                                          height: '34px',
                                          padding: '0 14px',
                                          boxSizing: 'border-box',
                                          border: 'none'
                                        },
                                        '& .MuiOutlinedInput-notchedOutline': {
                                          border: 'none'
                                        },
                                        '&:hover .MuiOutlinedInput-notchedOutline':
                                          { border: 'none' },
                                        '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                          { border: 'none' }
                                      }}
                                    />
                                    <button
                                      style={{
                                        width: '36px',
                                        height: '36px',
                                        flexShrink: 0,
                                        background:
                                          usesInlineAddButton && isLastItem
                                            ? '#4170FF'
                                            : '#3D3AB8',
                                        borderRadius: '4px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        cursor: 'pointer',
                                        border: '0',
                                        padding: '0'
                                      }}
                                      onClick={() => {
                                        if (usesInlineAddButton && isLastItem) {
                                          const nextIndex = items.length + 1;
                                          const nextLabel = isRadioOptionsList
                                            ? `Radio ${nextIndex}`
                                            : isCheckboxOptionsList
                                              ? `Checkbox ${nextIndex}`
                                              : `Option ${nextIndex}`;
                                          handleTraitChange(
                                            trait,
                                            JSON.stringify([
                                              ...items,
                                              {
                                                value: nextLabel,
                                                label: nextLabel
                                              }
                                            ])
                                          );
                                          return;
                                        }

                                        const newItems = items.filter(
                                          (_: any, i: number) => i !== index
                                        );
                                        handleTraitChange(
                                          trait,
                                          JSON.stringify(newItems)
                                        );
                                      }}
                                      title={
                                        usesInlineAddButton && isLastItem
                                          ? 'Add Item'
                                          : 'Remove Item'
                                      }
                                    >
                                      <span
                                        aria-hidden='true'
                                        style={{
                                          color: '#fff',
                                          fontSize: '24px',
                                          lineHeight: 1,
                                          fontWeight: 300,
                                          transform: usesInlineAddButton && isLastItem
                                            ? 'translateY(-1px)'
                                            : 'translateY(-2px)'
                                        }}
                                      >
                                        {usesInlineAddButton && isLastItem
                                          ? '+'
                                          : '×'}
                                      </span>
                                    </button>
                                  </div>
                                );
                              });
                            })()}

                            {!([
                              'custom-select',
                              'single-radio',
                              'single-checkbox'
                            ].includes(String(selectedComponentType)) && name === 'options') && (
                            <button
                              style={{
                                width: '36px',
                                height: '36px',
                                background: '#4170FF',
                                borderRadius: '4px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                cursor: 'pointer',
                                border: '0',
                                padding: '0'
                              }}
                              onClick={() => {
                                let items: any[] = [];
                                try {
                                  let rawValue = value || trait.getValue();

                                  if (!rawValue) {
                                    const component = trait.target;
                                    rawValue =
                                      component.get(name) ||
                                      component.getAttributes()[name];
                                  }

                                  if (typeof rawValue === 'string') {
                                    items = JSON.parse(rawValue || '[]');
                                  } else if (Array.isArray(rawValue)) {
                                    items = rawValue;
                                  }
                                } catch (e) {
                                  console.error('Invalid JSON', e);
                                }

                                const isTabStruct =
                                  items.length > 0 &&
                                  ('name' in items[0] || 'id' in items[0]);

                                const isTabTrait =
                                  name === 'tabs-list' || name === 'tabs';

                                let newItem;

                                if (isTabStruct || isTabTrait) {
                                  const nextId =
                                    items.length > 0 ? items.length + 1 : 1;
                                  newItem = {
                                    id: `tab${nextId}`,
                                    name: `Tab ${nextId}`
                                  };
                                } else {
                                  newItem = {
                                    value: `option${items.length + 1}`,
                                    label: `Option ${items.length + 1}`
                                  };
                                }

                                items.push(newItem);
                                handleTraitChange(trait, JSON.stringify(items));
                              }}
                              title='Add Item'
                            >
                              <svg
                                width='20'
                                height='20'
                                viewBox='0 0 20 20'
                                fill='none'
                                xmlns='http://www.w3.org/2000/svg'
                              >
                                <path
                                  fillRule='evenodd'
                                  clipRule='evenodd'
                                  d='M10 3C10.5523 3 11 3.44772 11 4V9H16C16.5523 9 17 9.44772 17 10C17 10.5523 16.5523 11 16 11H11V16C11 16.5523 10.5523 17 10 17C9.44772 17 9 16.5523 9 16V11H4C3.44772 11 3 10.5523 3 10C3 9.44772 3.44772 9 4 9H9V4C9 3.44772 9.44772 3 10 3Z'
                                  fill='white'
                                />
                              </svg>
                            </button>
                            )}
                          </div>
                        </div>
                      );

                    case 'button':
                      const addLayerTrait = generalTraits.find(
                        (t) => t.getName() === 'add-layer'
                      );
                      const removeLayerTrait = generalTraits.find(
                        (t) => t.getName() === 'remove-layer'
                      );
                      const addPointTrait = generalTraits.find(
                        (t) => t.getName() === 'add-point'
                      );
                      const removePointTrait = generalTraits.find(
                        (t) => t.getName() === 'remove-point'
                      );
                      return addLayerTrait ||
                        addPointTrait ||
                        removeLayerTrait ||
                        removePointTrait ? null : (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <IconButton
                            color={isRemoveTrait ? 'error' : 'primary'}
                            onClick={() => handleButtonClick(trait)}
                            title={label}
                            disabled={!isEditorReady}
                            sx={{
                              fontSize: '14px',
                              color: isRemoveTrait ? '#f44336' : '#4170ff',
                              '&:hover': {
                                backgroundColor: isRemoveTrait
                                  ? 'rgba(244, 67, 54, 0.1)'
                                  : 'rgba(65, 112, 255, 0.1)'
                              }
                            }}
                          >
                            {isRemoveTrait ? <RemoveIcon /> : <AddIcon />}
                          </IconButton>
                        </div>
                      );

                    default:
                      return (
                        <div
                          key={name}
                          className='w-full mb-2'
                        >
                          <label
                            className={cx(
                              'block capitalize mb-[11px] text-sm',
                              MAIN_TXT_COLOR
                            )}
                            style={{
                              fontSize: '14px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            {label}
                          </label>
                          <TextField
                            size='small'
                            fullWidth
                            value={value ?? ''}
                            onChange={(e) =>
                              handleTraitChange(trait, e.target.value)
                            }
                            sx={{
                              height: '34px',
                              '& .MuiInputBase-root': {
                                height: '34px',
                                color: '#fff',
                                backgroundColor: 'rgba(65, 112, 255, 0.2)',
                                borderRadius: '6px',
                                border: 'none'
                              },
                              '& .MuiInputBase-input': {
                                height: '34px',
                                padding: '0 14px',
                                boxSizing: 'border-box',
                                border: 'none'
                              },
                              '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline':
                                {
                                  border: 'none'
                                }
                            }}
                          />
                        </div>
                      );
                  }
                })}
              </AccordionDetails>
            </Accordion>
          )}
          {chartDataTrait && (
            <Accordion
              disableGutters
              defaultExpanded
              sx={{
                color: 'rgba(65, 112, 255, 1)',
                backgroundColor: EDITOR_SIDEBAR_BG,
                '&.MuiAccordion-root': {
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  color: 'rgba(65, 112, 255, 1)',
                  '&:before': {
                    display: 'none'
                  },
                  '&.Mui-expanded': {
                    backgroundColor: 'rgba(16, 22, 28, 0.5)'
                  }
                }
              }}
            >
              <AccordionSummary
                expandIcon={AccordionIcon}
                sx={{
                  color: 'rgba(65, 112, 255, 1)',
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  '&.MuiAccordionSummary-root': {
                    color: 'rgba(65, 112, 255, 1)',
                    backgroundColor: EDITOR_SIDEBAR_BG,
                    '&.Mui-expanded': {
                      backgroundColor: 'rgba(16, 22, 28, 0.5)'
                    }
                  },
                  '& .MuiAccordionSummary-expandIconWrapper': {
                    transition: 'transform 0.3s ease',
                    '&.Mui-expanded': {
                      transform: 'rotate(180deg)'
                    }
                  }
                }}
              >
                <span
                  style={{
                    color: 'rgba(65, 112, 255, 1)',
                    fontSize: '16px',
                    fontWeight: 500
                  }}
                >
                  Layers
                </span>
              </AccordionSummary>
              <AccordionDetails
                sx={{
                  color: 'rgba(65, 112, 255, 1)',
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '18px',
                  padding: '14px 16px 20px',
                  alignContent: 'flex-start'
                }}
              >
                <Box
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '16px',
                    flex: 1,
                    minWidth: 0
                  }}
                >
                  <Box
                    sx={{
                      position: 'relative',
                      display: 'flex',
                      flexDirection: 'row',
                      alignItems: 'center',
                      width: '100%',
                      gap: '8px',
                      borderRadius: '6px',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '4px',
                        flex: 1,
                        minWidth: 0
                      }}
                    >
                      <TextField
                        value={newLayerName || ''}
                        placeholder='New Layer'
                        onChange={(e) => setNewLayerName(e.target.value)}
                        sx={{
                          width: '100%',
                          '& .MuiInputBase-root': {
                            height: '34px',
                            color: '#fff',
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            borderRadius: '6px',
                            border: 'none'
                          },
                          '& .MuiInputBase-input': {
                            height: '34px',
                            padding: '0 14px',
                            boxSizing: 'border-box',
                            border: 'none'
                          },
                          '& .MuiOutlinedInput-notchedOutline': {
                            border: 'none'
                          },
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            border: 'none'
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            border: 'none'
                          }
                        }}
                      />
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '4px'
                      }}
                    >
                      <ColorElement
                        value={newLayerColor || '#ffffff'}
                        onChange={(color) => setNewLayerColor(color)}
                        mini
                      />
                    </div>
                    {addLayerTrait && (
                      <IconButton
                        onClick={() =>
                          handleButtonClick(addLayerTrait, {
                            name: newLayerName,
                            color: newLayerColor
                          })
                        }
                        title='Add Layer'
                        disabled={!isEditorReady}
                        sx={{
                          backgroundColor: '#4170ff',
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          '&:hover': {
                            backgroundColor: '#365fd9'
                          },
                          '&:disabled': {
                            backgroundColor: 'rgba(65, 112, 255, 0.5)'
                          }
                        }}
                      >
                        <svg
                          width='14'
                          height='14'
                          viewBox='0 0 14 14'
                          fill='none'
                          xmlns='http://www.w3.org/2000/svg'
                        >
                          <path
                            d='M7 0.75V13.25M13.25 7H0.75'
                            stroke='white'
                            strokeWidth='1.5'
                            strokeLinecap='round'
                            strokeLinejoin='round'
                          />
                        </svg>
                      </IconButton>
                    )}
                  </Box>
                  {chartData.map((layer, layerIndex) => (
                    <Box
                      key={`layer-${layer.id}`}
                      sx={{
                        position: 'relative',
                        display: 'flex',
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: '8px',
                        borderRadius: '6px',
                        transition: 'all 0.3s ease',
                        width: 'auto',
                        flex: 1,
                        minWidth: 0
                      }}
                    >
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '4px',
                          flex: 1,
                          minWidth: 0
                        }}
                      >
                        <TextField
                          value={layer.name || `Layer ${layerIndex + 1}`}
                          placeholder={`Layer ${layerIndex + 1}`}
                          onChange={(e) =>
                            handleLayerNameChange(
                              chartDataTrait,
                              layerIndex,
                              e.target.value
                            )
                          }
                          sx={{
                            width: 'auto',
                            '& .MuiInputBase-root': {
                              height: '34px',
                              color: '#fff',
                              backgroundColor: 'rgba(255, 255, 255, 0.1)',
                              borderRadius: '6px',
                              border: 'none'
                            },
                            '& .MuiInputBase-input': {
                              height: '34px',
                              padding: '0 14px',
                              boxSizing: 'border-box',
                              border: 'none'
                            },
                            '& .MuiOutlinedInput-notchedOutline': {
                              border: 'none'
                            },
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                              border: 'none'
                            },
                            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                              border: 'none'
                            }
                          }}
                        />
                      </div>
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '4px'
                        }}
                      >
                        <ColorElement
                          value={layer.color || '#ffffff'}
                          onChange={(color) =>
                            handleLayerColorChange(
                              chartDataTrait,
                              layerIndex,
                              color
                            )
                          }
                          mini
                        />
                      </div>
                      {removeLayerTrait && (
                        <IconButton
                          onClick={() =>
                            handleButtonClick(removeLayerTrait, { layerIndex })
                          }
                          title='Remove Layer'
                          disabled={!isEditorReady || chartData.length <= 1}
                          sx={{
                            backgroundColor: '#3D3AB8',
                            width: '36px',
                            height: '36px',
                            borderRadius: '6px',
                            '&:hover': {
                              backgroundColor: '#3D3AB8'
                            },
                            '&:disabled': {
                              backgroundColor: '#3D3AB8'
                            }
                          }}
                        >
                          <svg
                            width='12'
                            height='12'
                            viewBox='0 0 12 12'
                            fill='none'
                            xmlns='http://www.w3.org/2000/svg'
                          >
                            <path
                              fillRule='evenodd'
                              clipRule='evenodd'
                              d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                              fill='white'
                            />
                          </svg>
                        </IconButton>
                      )}
                    </Box>
                  ))}
                </Box>
              </AccordionDetails>
            </Accordion>
          )}

          {chartDataTrait && (
            <Accordion
              disableGutters
              defaultExpanded
              sx={{
                color: 'rgba(65, 112, 255, 1)',
                backgroundColor: EDITOR_SIDEBAR_BG,
                '&.MuiAccordion-root': {
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  color: 'rgba(65, 112, 255, 1)',
                  '&:before': {
                    display: 'none'
                  },
                  '&.Mui-expanded': {
                    backgroundColor: 'rgba(16, 22, 28, 0.5)'
                  }
                }
              }}
            >
              <AccordionSummary
                expandIcon={AccordionIcon}
                sx={{
                  color: 'rgba(65, 112, 255, 1)',
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  '&.MuiAccordionSummary-root': {
                    color: 'rgba(65, 112, 255, 1)',
                    backgroundColor: EDITOR_SIDEBAR_BG,
                    '&.Mui-expanded': {
                      backgroundColor: 'rgba(16, 22, 28, 0.5)'
                    }
                  },
                  '& .MuiAccordionSummary-expandIconWrapper': {
                    transition: 'transform 0.3s ease',
                    '&.Mui-expanded': {
                      transform: 'rotate(180deg)'
                    }
                  }
                }}
              >
                <span
                  style={{
                    color: 'rgba(65, 112, 255, 1)',
                    fontSize: '16px',
                    fontWeight: 500
                  }}
                >
                  Data
                </span>
              </AccordionSummary>
              <AccordionDetails
                sx={{
                  color: 'rgba(65, 112, 255, 1)',
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '18px',
                  padding: '14px 16px 20px',
                  alignContent: 'flex-start'
                }}
              >
                <Box
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '16px',
                    position: 'relative',
                    backgroundColor: '#2E3033',
                    borderRadius: '6px',
                    padding: '12px',
                    maxWidth: '322px',
                    boxSizing: 'border-box'
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      justifyContent: 'flex-end',
                      gap: '8px',
                      width: '100%'
                    }}
                  >
                    {addLayerTrait && (
                      <IconButton
                        onClick={() => handleButtonClick(addLayerTrait)}
                        title='Add Layer'
                        disabled={!isEditorReady}
                        sx={{
                          backgroundColor: '#4170ff',
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          '&:hover': { backgroundColor: '#365fd9' },
                          '&:disabled': {
                            backgroundColor: 'rgba(65, 112, 255, 0.5)'
                          }
                        }}
                      >
                        <svg
                          width='14'
                          height='14'
                          viewBox='0 0 14 14'
                          fill='none'
                          xmlns='http://www.w3.org/2000/svg'
                        >
                          <path
                            d='M7 0.75V13.25M13.25 7H0.75'
                            stroke='white'
                            strokeWidth='1.5'
                            strokeLinecap='round'
                            strokeLinejoin='round'
                          />
                        </svg>
                      </IconButton>
                    )}
                    {removeLayerTrait && (
                      <IconButton
                        onClick={() =>
                          handleButtonClick(removeLayerTrait, {
                            layerIndex: selectedLayerIndex
                          })
                        }
                        title='Remove Layer'
                        disabled={!isEditorReady || chartData.length <= 1}
                        sx={{
                          backgroundColor: '#3D3AB8',
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          '&:hover': { backgroundColor: '#3D3AB8' },
                          '&:disabled': { backgroundColor: '#3D3AB8' }
                        }}
                      >
                        <svg
                          width='12'
                          height='12'
                          viewBox='0 0 12 12'
                          fill='none'
                          xmlns='http://www.w3.org/2000/svg'
                        >
                          <path
                            fillRule='evenodd'
                            clipRule='evenodd'
                            d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                            fill='white'
                          />
                        </svg>
                      </IconButton>
                    )}
                  </Box>

                  <FormControl sx={{ width: '100%' }}>
                    <Typography
                      sx={{
                        mb: '11px',
                        color: '#fff',
                        fontFamily: 'Montserrat',
                        fontSize: '14px'
                      }}
                    >
                      Choice Layer
                    </Typography>
                    <CustomSelect
                      options={selectOptions}
                      activeOption={activeOption}
                      onChange={(option) => {
                        setSelectedLayerIndex(Number(option.value));
                      }}
                      placeholder='Choice Layer'
                      size='sm'
                      color='secondary'
                      className='w-full'
                      disabled={chartData.length === 0}
                      maxWidth={''}
                    />
                  </FormControl>

                  <Box
                    sx={{
                      backgroundColor: '#2E3033',
                      borderRadius: '6px',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '12px',
                      width: '100%'
                    }}
                  >
                    {chartData[selectedLayerIndex]?.points.length > 0 && (
                      <Box
                        sx={{
                          display: 'flex',
                          gap: '8px',
                          width: '100%',
                          paddingRight: '44px',
                          mb: '1px',
                          ml: '3px'
                        }}
                      >
                        <Box sx={{ flex: 1 }}>
                          <span
                            className={cx('text-xs', MAIN_TXT_COLOR)}
                            style={{
                              fontSize: '14px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            X
                          </span>
                        </Box>
                        <Box sx={{ flex: 1 }}>
                          <span
                            className={cx('text-xs', MAIN_TXT_COLOR)}
                            style={{
                              fontSize: '14px',
                              fontFamily: 'Montserrat'
                            }}
                          >
                            Y
                          </span>
                        </Box>
                      </Box>
                    )}

                    {chartData[selectedLayerIndex]?.points.map(
                      (point, index) => (
                        <Box
                          key={`point-${index}`}
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            width: '100%'
                          }}
                        >
                          <TextField
                            value={point.label || ''}
                            placeholder='Label'
                            onChange={(e) =>
                              handleChartPointChange(
                                chartDataTrait,
                                selectedLayerIndex,
                                index,
                                'label',
                                e.target.value
                              )
                            }
                            sx={{
                              flex: 1,
                              '& .MuiInputBase-root': {
                                height: '34px',
                                color: '#fff',
                                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                                borderRadius: '6px',
                                border: 'none'
                              },
                              '& .MuiInputBase-input': {
                                height: '34px',
                                padding: '0 14px'
                              },
                              '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              }
                            }}
                          />
                          <TextField
                            type='number'
                            value={point.value || 0}
                            placeholder='Value'
                            onChange={(e) =>
                              handleChartPointChange(
                                chartDataTrait,
                                selectedLayerIndex,
                                index,
                                'value',
                                parseFloat(e.target.value) || 0
                              )
                            }
                            sx={{
                              flex: 1,
                              '& .MuiInputBase-root': {
                                height: '34px',
                                color: '#fff',
                                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                                borderRadius: '6px',
                                border: 'none'
                              },
                              '& .MuiInputBase-input': {
                                height: '34px',
                                padding: '0 14px'
                              },
                              '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none'
                              }
                            }}
                          />
                          {removePointTrait && (
                            <IconButton
                              onClick={() =>
                                handleButtonClick(removePointTrait, {
                                  layerIndex: selectedLayerIndex,
                                  index
                                })
                              }
                              disabled={
                                !isEditorReady ||
                                chartData[selectedLayerIndex].points.length <= 1
                              }
                              sx={{
                                backgroundColor: '#3D3AB8',
                                width: '36px',
                                height: '36px',
                                borderRadius: '6px',
                                flexShrink: 0,
                                '&:hover': { backgroundColor: '#3D3AB8' },
                                '&:disabled': { backgroundColor: '#3D3AB8' }
                              }}
                            >
                              <svg
                                width='12'
                                height='12'
                                viewBox='0 0 12 12'
                                fill='none'
                                xmlns='http://www.w3.org/2000/svg'
                              >
                                <path
                                  fillRule='evenodd'
                                  clipRule='evenodd'
                                  d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                                  fill='white'
                                />
                              </svg>
                            </IconButton>
                          )}
                        </Box>
                      )
                    )}

                    <Box
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        paddingTop: '8px',
                        width: '100%'
                      }}
                    >
                      <TextField
                        placeholder='X'
                        sx={{
                          flex: 1,
                          '& .MuiInputBase-root': {
                            height: '34px',
                            color: '#fff',
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            borderRadius: '6px',
                            border: 'none'
                          },
                          '& .MuiInputBase-input': {
                            height: '34px',
                            padding: '0 14px'
                          },
                          '& .MuiOutlinedInput-notchedOutline': {
                            border: 'none'
                          }
                        }}
                      />
                      <TextField
                        type='number'
                        placeholder='Y'
                        sx={{
                          flex: 1,
                          '& .MuiInputBase-root': {
                            height: '34px',
                            color: '#fff',
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            borderRadius: '6px',
                            border: 'none'
                          },
                          '& .MuiInputBase-input': {
                            height: '34px',
                            padding: '0 14px'
                          },
                          '& .MuiOutlinedInput-notchedOutline': {
                            border: 'none'
                          }
                        }}
                      />
                      {addPointTrait && (
                        <IconButton
                          onClick={() => {
                            if (chartData.length === 0) return;
                            const newData = [...chartData];
                            const targetLayer = newData[selectedLayerIndex];
                            if (targetLayer) {
                              targetLayer.points.push({
                                label: newPointLabel,
                                value: parseFloat(newPointValue),
                                color: newPointColor || targetLayer.color
                              });
                              setChartData(newData);
                              handleTraitChange(
                                chartDataTrait,
                                JSON.stringify(newData)
                              );
                              setNewPointLabel('');
                              setNewPointValue('');
                            }
                          }}
                          disabled={
                            !isEditorReady ||
                            !newPointLabel?.trim() ||
                            newPointValue === ''
                          }
                          sx={{
                            backgroundColor: '#4170ff',
                            width: '36px',
                            height: '36px',
                            borderRadius: '6px',
                            flexShrink: 0,
                            '&:hover': { backgroundColor: '#365fd9' },
                            '&:disabled': {
                              backgroundColor: 'rgba(65, 112, 255, 0.5)'
                            }
                          }}
                        >
                          <svg
                            width='14'
                            height='14'
                            viewBox='0 0 14 14'
                            fill='none'
                            xmlns='http://www.w3.org/2000/svg'
                          >
                            <path
                              d='M7 0.75V13.25M13.25 7H0.75'
                              stroke='white'
                              strokeWidth='1.5'
                              strokeLinecap='round'
                              strokeLinejoin='round'
                            />
                          </svg>
                        </IconButton>
                      )}
                    </Box>
                  </Box>
                </Box>
              </AccordionDetails>
            </Accordion>
          )}

          {chartDataTrait && (
            <Accordion
              disableGutters
              defaultExpanded
              sx={{
                color: 'rgba(65, 112, 255, 1)',
                backgroundColor: EDITOR_SIDEBAR_BG,
                '&.MuiAccordion-root': {
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  color: 'rgba(65, 112, 255, 1)',
                  '&:before': { display: 'none' },
                  '&.Mui-expanded': { backgroundColor: 'rgba(16, 22, 28, 0.5)' }
                }
              }}
            >
              <AccordionSummary
                expandIcon={AccordionIcon}
                sx={{
                  color: 'rgba(65, 112, 255, 1)',
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  '&.MuiAccordionSummary-root': {
                    color: 'rgba(65, 112, 255, 1)',
                    backgroundColor: EDITOR_SIDEBAR_BG,
                    '&.Mui-expanded': {
                      backgroundColor: 'rgba(16, 22, 28, 0.5)'
                    }
                  },
                  '& .MuiAccordionSummary-expandIconWrapper': {
                    transition: 'transform 0.3s ease',
                    '&.Mui-expanded': { transform: 'rotate(180deg)' }
                  }
                }}
              >
                <span
                  style={{
                    color: 'rgba(65, 112, 255, 1)',
                    fontSize: '16px',
                    fontWeight: 500
                  }}
                >
                  Points
                </span>
              </AccordionSummary>
              <AccordionDetails
                sx={{
                  color: 'rgba(65, 112, 255, 1)',
                  backgroundColor: EDITOR_SIDEBAR_BG,
                  padding: '16px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px'
                }}
              >
                <Box
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    position: 'relative',
                    backgroundColor: '#2E3033',
                    borderRadius: '6px',
                    padding: '12px',
                    maxWidth: '322px',
                    maxHeight: '214px',
                    boxSizing: 'border-box'
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      justifyContent: 'flex-end',
                      width: '100%',
                      mb: '12px'
                    }}
                  >
                    {addPointTrait && (
                      <IconButton
                        onClick={() => {
                          if (chartData.length === 0) return;
                          const newData = [...chartData];
                          const targetLayer = newData[selectedLayerIndex];
                          if (targetLayer) {
                            targetLayer.points.push({
                              label: newPointLabel,
                              value: parseFloat(newPointValue),
                              color: newPointColor || targetLayer.color
                            });
                            setChartData(newData);
                            handleTraitChange(
                              chartDataTrait,
                              JSON.stringify(newData)
                            );
                            setNewPointLabel('');
                            setNewPointValue('');
                          }
                        }}
                        disabled={
                          !isEditorReady ||
                          !newPointLabel?.trim() ||
                          newPointValue === ''
                        }
                        sx={{
                          backgroundColor: '#4170ff',
                          width: '36px',
                          height: '36px',
                          borderRadius: '6px',
                          flexShrink: 0,
                          '&:hover': { backgroundColor: '#365fd9' },
                          '&:disabled': {
                            backgroundColor: 'rgba(65, 112, 255, 0.5)'
                          }
                        }}
                      >
                        <svg
                          width='14'
                          height='14'
                          viewBox='0 0 14 14'
                          fill='none'
                          xmlns='http://www.w3.org/2000/svg'
                        >
                          <path
                            d='M7 0.75V13.25M13.25 7H0.75'
                            stroke='white'
                            strokeWidth='1.5'
                            strokeLinecap='round'
                            strokeLinejoin='round'
                          />
                        </svg>
                      </IconButton>
                    )}
                  </Box>
                  <Box sx={{ display: 'flex', gap: '8px', width: '100%' }}>
                    <Box
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '11px',
                        flex: 1
                      }}
                    >
                      <span
                        className={cx('text-xs', MAIN_TXT_COLOR)}
                        style={{
                          fontSize: '14px',
                          fontFamily: 'Montserrat'
                        }}
                      >
                        X
                      </span>
                      <TextField
                        value={newPointLabel || ''}
                        onChange={(e) => setNewPointLabel(e.target.value)}
                        placeholder='X'
                        sx={{
                          width: '100%',
                          '& .MuiInputBase-root': {
                            height: '34px',
                            color: '#fff',
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            borderRadius: '6px',
                            border: 'none'
                          },
                          '& .MuiInputBase-input': {
                            height: '34px',
                            padding: '0 14px'
                          },
                          '& .MuiOutlinedInput-notchedOutline': {
                            border: 'none'
                          }
                        }}
                      />
                    </Box>
                    <Box
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '7px',
                        flex: 1
                      }}
                    >
                      <span
                        className={cx('text-xs', MAIN_TXT_COLOR)}
                        style={{
                          fontSize: '14px',
                          fontFamily: 'Montserrat',
                          marginLeft: '3px'
                        }}
                      >
                        Y
                      </span>
                      <TextField
                        type='number'
                        value={newPointValue ?? ''}
                        onChange={(e) => setNewPointValue(e.target.value)}
                        placeholder='Y'
                        sx={{
                          width: '100%',
                          '& .MuiInputBase-root': {
                            height: '34px',
                            color: '#fff',
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            borderRadius: '6px',
                            border: 'none'
                          },
                          '& .MuiInputBase-input': {
                            height: '34px',
                            padding: '0 14px'
                          },
                          '& .MuiOutlinedInput-notchedOutline': {
                            border: 'none'
                          }
                        }}
                      />
                    </Box>
                  </Box>

                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'flex-end',
                      gap: '30px',
                      width: '100%',
                      mt: '11px'
                    }}
                  >
                    <Box
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '14px',
                        flexShrink: 0
                      }}
                    >
                      <span
                        className={cx('text-xs', MAIN_TXT_COLOR)}
                        style={{
                          fontSize: '14px',
                          fontFamily: 'Montserrat'
                        }}
                      >
                        Color
                      </span>
                      <ColorElement
                        value={newPointColor || '#ffffff'}
                        onChange={(c) => setNewPointColor(c)}
                        mini
                      />
                    </Box>
                    <Box
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '11px',
                        flex: 1
                      }}
                    >
                      <span
                        className={cx('text-xs', MAIN_TXT_COLOR)}
                        style={{
                          fontSize: '14px',
                          fontFamily: 'Montserrat'
                        }}
                      >
                        Choice Layer
                      </span>
                      <CustomSelect
                        options={selectOptions}
                        activeOption={activeOption}
                        // Обработчик изменений
                        onChange={(option) => {
                          // Преобразуем строковое value обратно в число для вашего стейта
                          setSelectedLayerIndex(Number(option.value));
                        }}
                        // Настройки внешнего вида под ваш дизайн
                        placeholder='Choice Layer'
                        size='sm' // Или "md", если нужна высота 44px (в MUI было 34px, значит "sm" ближе)
                        color='secondary' // Полупрозрачный фон (как было rgba(255, 255, 255, 0.1))
                        className='w-full' // width: 100%
                        // Если нужно отключить
                        disabled={chartData.length === 0}
                        maxWidth={''}
                      />
                    </Box>
                  </Box>
                </Box>
              </AccordionDetails>
            </Accordion>
          )}

          {}
        </>
      )}

      {traits.length > 0 && (
        <Box
          sx={{
            position: 'sticky',
            bottom: 0,
            zIndex: 4,
            display: 'flex',
            justifyContent: 'flex-end',
            px: '12px',
            py: '10px',
            mt: '10px',
            backgroundColor: traitsPanelBackground,
            borderTop: '1px solid rgba(255,255,255,0.12)'
          }}
        >
          <Button
            variant='contained'
            disabled={manualSaveState === 'saving'}
            onClick={handleManualSave}
            sx={{
              minWidth: '104px',
              height: '36px',
              textTransform: 'none',
              fontFamily: 'Montserrat',
              fontSize: '14px',
              fontWeight: 500,
              backgroundColor:
                manualSaveState === 'error' ? '#B42318' : '#4170FF',
              '&:hover': {
                backgroundColor:
                  manualSaveState === 'error' ? '#912018' : '#3562E8'
              }
            }}
          >
            {manualSaveState === 'saving'
              ? 'Saving...'
              : manualSaveState === 'saved'
                ? 'Saved'
                : manualSaveState === 'error'
                  ? 'Retry save'
                  : 'Save'}
          </Button>
        </Box>
      )}
    </div>
  );
}
