import React, { useState, useEffect } from 'react';
import {
  BlocksProvider,
  SelectorsProvider,
  StylesProvider,
  TraitsProvider,
  useEditorMaybe
} from '@grapesjs/react';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import { Box, useMediaQuery, useTheme } from '@mui/material';

import CustomBlockManager from './CustomBlockManager';
import { MAIN_TXT_COLOR, cx } from './common';
import CustomStyleManager from './CustomStyleManager';
import CustomTraitManager from './CustomTraitManager';
import CustomComponentHeader from './CustomComponentHeader';
import CustomSelectorManager from './CustomSelectorManager';

const defaultTabProps = {
  className: '!min-w-0',
  sx: {
    width: '148px',
    height: '34px',
    minHeight: '34px',
    padding: 0,
    background: 'rgba(255, 255, 255, 0.1)',
    borderRadius: '6px',
    transform: 'matrix(-1, 0, 0, 1, 0, 0)',
    '&.Mui-selected': {
      background: 'rgba(65, 112, 255, 1)'
    }
  }
};

interface RightSidebarProps {
  className?: string;
  activeTab: number;
  onTabChange: (tabIndex: number) => void;
}

export default function RightSidebar({
  activeTab,
  onTabChange
}: RightSidebarProps) {
  const theme = useTheme();
  const editor = useEditorMaybe();
  const isSmallScreen = useMediaQuery(theme.breakpoints.down(1700));

  const [viewMode, setViewMode] = useState<string>('Basic');

  useEffect(() => {
    if (!editor) return;

    const handleComponentChange = () => {
      setViewMode('Basic');
      if (activeTab !== 0) {
        onTabChange(0);
      }
    };

    editor.on('component:selected', handleComponentChange);
    return () => {
      editor.off('component:selected', handleComponentChange);
    };
  }, [editor, activeTab, onTabChange]);

  useEffect(() => {
    if (activeTab === 0) {
      setViewMode('Basic');
    }
  }, [activeTab]);

  return (
    <Box
      className={cx('w-[auto]', 'bg-[#151B22]', MAIN_TXT_COLOR)}
      sx={{
        overflowY: 'hidden',
        background: '#151B22',
        borderLeft: '1px solid rgba(255,255,255,0.06)',
        height: '100vh',
        paddingBottom: '90px',
        width: isSmallScreen && activeTab === 1 ? '80px' : '350px',
        maxWidth: isSmallScreen && activeTab === 1 ? '80px' : '350px',
        transition: 'all 0.3s ease'
      }}
    >
      <Tabs
        value={activeTab}
        onChange={(_, v) => onTabChange(v)}
        sx={{
          position: 'sticky',
          padding: '16px',
          background: !activeTab ? '#151B22' : 'transparent',
          '& .MuiTabs-flexContainer': {
            display: 'flex',
            gap: '8px',
            justifyContent:
              isSmallScreen && activeTab === 1 ? 'center' : 'flex-start'
          },
          '.MuiTabs-indicator': { display: 'none' }
        }}
      >
        <Tab
          {...defaultTabProps}
          sx={{
            ...defaultTabProps.sx,
            width: isSmallScreen && activeTab === 1 ? '0px' : '148px',
            minWidth: isSmallScreen && activeTab === 1 ? '0px' : '148px'
          }}
          label={
            <Box
              sx={{
                transform: 'matrix(-1, 0, 0, 1, 0, 0)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <svg
                width={isSmallScreen && activeTab === 1 ? '20' : '25'}
                height={isSmallScreen && activeTab === 1 ? '20' : '24'}
                viewBox='0 0 25 24'
                fill='none'
                xmlns='http://www.w3.org/2000/svg'
              >
                <path
                  d='M16.2679 12.7307C16.6775 12.6693 16.9598 12.2874 16.8983 11.8777C16.8369 11.4681 16.455 11.1859 16.0454 11.2473L16.2679 12.7307ZM20.122 10.6358C19.7124 10.6973 19.4301 11.0791 19.4916 11.4888C19.553 11.8984 19.9349 12.1807 20.3445 12.1192L20.122 10.6358ZM12.7547 15V15.75H13.4923L13.5046 15.0125L12.7547 15ZM6.25 4.75C5.83579 4.75 5.5 5.08579 5.5 5.5C5.5 5.91421 5.83579 6.25 6.25 6.25V4.75ZM10.75 3.75C11.1642 3.75 11.5 3.41421 11.5 3C11.5 2.58579 11.1642 2.25 10.75 2.25V3.75ZM14.75 2.25C14.3358 2.25 14 2.58579 14 3C14 3.41421 14.3358 3.75 14.75 3.75V2.25ZM16.25 7.25H9.25V8.75H16.25V7.25ZM9.25 7.25C8.76889 7.25 8.4582 7.24928 8.22275 7.22794C7.9976 7.20754 7.91586 7.17311 7.875 7.14952L7.125 8.44856C7.43221 8.62593 7.75817 8.69198 8.08735 8.72182C8.40622 8.75072 8.79649 8.75 9.25 8.75V7.25ZM6 5.5C6 5.95351 5.99928 6.34378 6.02818 6.66265C6.05802 6.99183 6.12407 7.31779 6.30144 7.625L7.60048 6.875C7.57689 6.83414 7.54246 6.7524 7.52206 6.52725C7.50072 6.2918 7.5 5.98111 7.5 5.5H6ZM7.875 7.14952C7.76099 7.08369 7.66631 6.98901 7.60048 6.875L6.30144 7.625C6.49892 7.96704 6.78296 8.25108 7.125 8.44856L7.875 7.14952ZM18 5.5C18 5.98111 17.9993 6.2918 17.9779 6.52725C17.9575 6.7524 17.9231 6.83414 17.8995 6.875L19.1986 7.625C19.3759 7.31779 19.442 6.99183 19.4718 6.66265C19.5007 6.34378 19.5 5.95351 19.5 5.5H18ZM16.25 8.75C16.7035 8.75 17.0938 8.75072 17.4127 8.72182C17.7418 8.69198 18.0678 8.62593 18.375 8.44856L17.625 7.14952C17.5841 7.17311 17.5024 7.20754 17.2773 7.22794C17.0418 7.24928 16.7311 7.25 16.25 7.25V8.75ZM17.8995 6.875C17.8337 6.98901 17.739 7.08369 17.625 7.14952L18.375 8.44856C18.717 8.25108 19.0011 7.96704 19.1986 7.625L17.8995 6.875ZM16.25 3.75C16.7311 3.75 17.0418 3.75072 17.2773 3.77206C17.5024 3.79246 17.5841 3.82689 17.625 3.85048L18.375 2.55144C18.0678 2.37407 17.7418 2.30802 17.4127 2.27818C17.0938 2.24928 16.7035 2.25 16.25 2.25V3.75ZM19.5 5.5C19.5 5.04649 19.5007 4.65622 19.4718 4.33735C19.442 4.00817 19.3759 3.68221 19.1986 3.375L17.8995 4.125C17.9231 4.16586 17.9575 4.2476 17.9779 4.47275C17.9993 4.7082 18 5.01889 18 5.5H19.5ZM17.625 3.85048C17.739 3.91631 17.8337 4.01099 17.8995 4.125L19.1986 3.375C19.0011 3.03296 18.717 2.74892 18.375 2.55144L17.625 3.85048ZM9.25 2.25C8.79649 2.25 8.40622 2.24928 8.08735 2.27818C7.75817 2.30802 7.43221 2.37407 7.125 2.55144L7.875 3.85048C7.91586 3.82689 7.9976 3.79246 8.22275 3.77206C8.4582 3.75072 8.76889 3.75 9.25 3.75V2.25ZM7.5 5.5C7.5 5.01889 7.50072 4.7082 7.52206 4.47275C7.54246 4.2476 7.57689 4.16586 7.60048 4.125L6.30144 3.375C6.12407 3.68221 6.05802 4.00817 6.02818 4.33735C5.99928 4.65622 6 5.04649 6 5.5H7.5ZM7.125 2.55144C6.78296 2.74892 6.49892 3.03296 6.30144 3.375L7.60048 4.125C7.66631 4.01099 7.76099 3.91631 7.875 3.85048L7.125 2.55144ZM11.5 21V17H10V21H11.5ZM14 17V21H15.5V17H14ZM14 21C14 21.4926 13.9984 21.7866 13.9701 21.9973C13.9571 22.0939 13.9418 22.1423 13.9328 22.164C13.9308 22.1691 13.9291 22.1724 13.9281 22.1743C13.9271 22.1762 13.9269 22.1767 13.9268 22.1768C13.9271 22.1765 13.9272 22.1763 13.9268 22.1768L14.9874 23.2374C15.2965 22.9284 15.4089 22.5527 15.4567 22.1972C15.5016 21.8633 15.5 21.4502 15.5 21H14ZM12.75 23.75C13.2002 23.75 13.6133 23.7516 13.9472 23.7067C14.3027 23.6589 14.6784 23.5465 14.9874 23.2374L13.9268 22.1768C13.9263 22.1772 13.9264 22.1771 13.9268 22.1768C13.9267 22.1769 13.9262 22.1771 13.9243 22.1781C13.9224 22.1791 13.9191 22.1808 13.914 22.1828C13.8923 22.1918 13.8439 22.2071 13.7473 22.2201C13.5366 22.2484 13.2426 22.25 12.75 22.25V23.75ZM12.75 15.75C13.2426 15.75 13.5366 15.7516 13.7473 15.7799C13.8439 15.7929 13.8923 15.8082 13.914 15.8172C13.9191 15.8192 13.9224 15.8209 13.9243 15.8219C13.9262 15.8229 13.9267 15.8231 13.9268 15.8232C13.9263 15.8228 13.9264 15.8229 13.9268 15.8232L14.9874 14.7626C14.6784 14.4535 14.3027 14.3411 13.9472 14.2933C13.6133 14.2484 13.2002 14.25 12.75 14.25V15.75ZM15.5 17C15.5 16.5498 15.5016 16.1367 15.4567 15.8028C15.4089 15.4473 15.2965 15.0716 14.9874 14.7626L13.9268 15.8232C13.9271 15.8235 13.9272 15.8237 13.9268 15.8232C13.9269 15.8233 13.9271 15.8238 13.9281 15.8257C13.9291 15.8276 13.9308 15.8309 13.9328 15.836C13.9418 15.8577 13.9571 15.9061 13.9701 16.0027C13.9984 16.2134 14 16.5074 14 17H15.5ZM11.5 17C11.5 16.5074 11.5016 16.2134 11.5299 16.0027C11.5429 15.9061 11.5582 15.8577 11.5672 15.836C11.5692 15.8309 11.5709 15.8276 11.5719 15.8257C11.5729 15.8238 11.5734 15.8229 11.5735 15.8228C11.5731 15.8233 11.5732 15.8231 11.5735 15.8228L10.5126 14.7626C10.2035 15.0716 10.0911 15.4473 10.0433 15.8028C9.99841 16.1367 10 16.5498 10 17H11.5ZM12.75 14.25C12.2998 14.25 11.8867 14.2484 11.5528 14.2933C11.1973 14.3411 10.8216 14.4535 10.5126 14.7626L11.5735 15.8228C11.5738 15.8225 11.574 15.8224 11.5735 15.8228C11.5736 15.8227 11.5738 15.8229 11.5757 15.8219C11.5776 15.8209 11.5809 15.8192 11.586 15.8172C11.6077 15.8082 11.6561 15.7929 11.7527 15.7799C11.9634 15.7516 12.2574 15.75 12.75 15.75V14.25ZM10 21C10 21.4502 9.99841 21.8633 10.0433 22.1972C10.0911 22.5527 10.2035 22.9284 10.5126 23.2374L11.5732 22.1768C11.5728 22.1763 11.5729 22.1765 11.5732 22.1768C11.5731 22.1767 11.5729 22.1762 11.5719 22.1743C11.5709 22.1724 11.5692 22.1691 11.5672 22.164C11.5582 22.1423 11.5429 22.0939 11.5299 21.9973C11.5016 21.7866 11.5 21.4926 11.5 21H10ZM12.75 22.25C12.2574 22.25 11.9634 22.2484 11.7527 22.2201C11.6561 22.2071 11.6077 22.1918 11.586 22.1828C11.5809 22.1808 11.5776 22.1791 11.5757 22.1781C11.5738 22.1771 11.5733 22.1769 11.5732 22.1768C11.5735 22.1771 11.5737 22.1772 11.5732 22.1768L10.5126 23.2374C10.8216 23.5465 11.1973 23.6589 11.5528 23.7067C11.8867 23.7516 12.2998 23.75 12.75 23.75V22.25ZM19.7949 4.75H18.75V6.25H19.7949V4.75ZM23.5 8.4551C23.5 8.02002 23.5004 7.65783 23.481 7.3612C23.4613 7.05823 23.4187 6.77171 23.3088 6.49258L21.9131 7.04208C21.9422 7.11609 21.9692 7.22858 21.9842 7.45878C21.9996 7.6953 22 8.00043 22 8.4551H23.5ZM19.7949 6.25C20.2496 6.25 20.5547 6.25037 20.7912 6.26579C21.0214 6.2808 21.1339 6.30776 21.2079 6.3369L21.7574 4.94117C21.4783 4.83128 21.1918 4.78872 20.8888 4.76897C20.5922 4.74963 20.23 4.75 19.7949 4.75V6.25ZM23.3088 6.49258C23.0293 5.78261 22.4674 5.22069 21.7574 4.94117L21.2079 6.3369C21.5306 6.46395 21.7861 6.71937 21.9131 7.04208L23.3088 6.49258ZM20.3445 12.1192C21.0531 12.0129 21.596 11.9422 22.0404 11.7061L21.3365 10.3815C21.1754 10.4671 20.9501 10.5116 20.122 10.6358L20.3445 12.1192ZM22 8.4551C22 9.29243 21.9894 9.52185 21.9286 9.69391L23.343 10.1935C23.5106 9.71904 23.5 9.17157 23.5 8.4551H22ZM22.0404 11.7061C22.6487 11.3829 23.1136 10.843 23.343 10.1935L21.9286 9.69391C21.8244 9.98918 21.6131 10.2346 21.3365 10.3815L22.0404 11.7061ZM16.0454 11.2473C15.2521 11.3663 14.5876 11.4646 14.0649 11.6116C13.5218 11.7643 13.0413 11.9923 12.6662 12.4278L13.8028 13.4067C13.9123 13.2796 14.0803 13.1654 14.4709 13.0556C14.8818 12.94 15.4361 12.8555 16.2679 12.7307L16.0454 11.2473ZM13.5046 15.0125C13.5224 13.9469 13.6213 13.6175 13.8028 13.4067L12.6662 12.4278C12.0854 13.1023 12.0217 13.9787 12.0048 14.9875L13.5046 15.0125ZM12.75 15.75H12.7547V14.25H12.75V15.75ZM6.75 4.75H6.25V6.25H6.75V4.75ZM9.25 3.75H10.75V2.25H9.25V3.75ZM14.75 3.75H16.25V2.25H14.75V3.75Z'
                  fill='white'
                />
              </svg>
            </Box>
          }
        />
        <Tab
          {...defaultTabProps}
          sx={{
            ...defaultTabProps.sx,
            width: isSmallScreen && activeTab === 1 ? '40px' : '148px',
            minWidth: isSmallScreen && activeTab === 1 ? '40px' : '148px'
          }}
          label={
            <Box
              sx={{
                transform: 'matrix(-1, 0, 0, 1, 0, 0)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <svg
                width={isSmallScreen && activeTab === 1 ? '16' : '19'}
                height={isSmallScreen && activeTab === 1 ? '16' : '18'}
                viewBox='0 0 19 18'
                fill='none'
                xmlns='http://www.w3.org/2000/svg'
              >
                <path
                  d='M0.75 0H8.75V10H0.75V0ZM2.75 2V8H6.75V2H2.75ZM10.75 0H18.75V6H10.75V0ZM12.75 2V4H16.75V2H12.75ZM10.75 8H18.75V18H10.75V8ZM12.75 10V16H16.75V10H12.75ZM0.75 12H8.75V18H0.75V12ZM2.75 14V16H6.75V14H2.75Z'
                  fill='white'
                />
              </svg>
            </Box>
          }
        />
      </Tabs>

      <div
        className={cx('flex-grow rounded')}
        style={{
          height: '100vh',
          fontFamily: 'Montserrat !important'
        }}
      >
        {activeTab === 0 ? (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              height: 'calc(100vh - 150px)',
              overflow: 'hidden',
              scrollbarWidth: 'none',
              '&::-webkit-scrollbar': { display: 'none' },
              '-ms-overflow-style': 'none'
            }}
          >
            <Box
              sx={{
                minHeight: 48,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderBottom: '1px solid rgba(255,255,255,0.05)',
                background: '#1A2028',
                color: '#FFFFFF',
                fontFamily: 'Montserrat, sans-serif',
                fontSize: '15px',
                fontWeight: 600,
                letterSpacing: '0.01em'
              }}
            >
              Settings
            </Box>
            <CustomComponentHeader />
            <Box
              sx={{
                flex: 1,
                overflowY: 'auto',
                scrollbarWidth: 'thin',
                scrollbarColor: 'rgba(126, 139, 164, 0.72) transparent',
                '&::-webkit-scrollbar': { width: '5px' },
                '&::-webkit-scrollbar-track': { background: 'transparent' },
                '&::-webkit-scrollbar-thumb': {
                  background: 'rgba(126, 139, 164, 0.72)',
                  borderRadius: '999px'
                }
              }}
            >
              <Box
                sx={{
                  '& > div:first-of-type': {
                    marginBottom: 0,
                    paddingBottom: 0
                  },
                  '& > div:last-of-type': { marginTop: 0, paddingTop: 0 }
                }}
              >
                <SelectorsProvider>
                  {(props) => (
                    <CustomSelectorManager
                      {...props}
                      viewMode={viewMode}
                      onViewModeChange={setViewMode}
                    />
                  )}
                </SelectorsProvider>
                <TraitsProvider>
                  {(props) => <CustomTraitManager {...props} />}
                </TraitsProvider>
                <StylesProvider>
                  {(props) => (
                    <CustomStyleManager
                      {...props}
                      activeViewMode={viewMode}
                    />
                  )}
                </StylesProvider>
              </Box>
            </Box>
          </Box>
        ) : (
          <BlocksProvider>
            {(props) => (
              <Box
                sx={{
                  height: 'calc(100vh - 150px)',
                  overflowY: 'auto',
                  scrollbarWidth: 'thin',
                  scrollbarColor: 'rgba(126, 139, 164, 0.72) transparent',
                  '&::-webkit-scrollbar': { width: '5px' },
                  '&::-webkit-scrollbar-track': { background: 'transparent' },
                  '&::-webkit-scrollbar-thumb': {
                    background: 'rgba(126, 139, 164, 0.72)',
                    borderRadius: '999px'
                  },
                  padding: isSmallScreen ? '8px' : '16px'
                }}
              >
                <CustomBlockManager {...props} />
              </Box>
            )}
          </BlocksProvider>
        )}
      </div>
    </Box>
  );
}
