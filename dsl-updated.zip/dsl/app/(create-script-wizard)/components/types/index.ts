import { ReactNode } from 'react';
import { AssetsResultProps, BlocksResultProps } from '@grapesjs/react';

import { IconType, ImgType } from '../../utils/WidgetEditor/IWidgetTemplate';
import { ModalProps } from '@mui/material';
import { Component, Property, Trait } from 'grapesjs';

export interface OptionType {
  value: string;
  label: string;
  name?: string;
  onDoubleClick?: () => void;
}

export interface ExtendableType {
  label: string;
  onClick: () => void;
}

export interface SelectProps {
  maxWidth: string | { xs: string; sm: string; md: string };
  options: OptionType[];
  onChange?: (option: OptionType) => void;
  activeOption?: OptionType;
  disabled?: boolean;
  size?: 'sm' | 'md';
  label?: string;
  placeholder?: string;
  extendable?: ExtendableType;
  className?: string;
  color?: 'primary' | 'secondary' | string;
  onOpen?: () => void;
  onClose?: () => void;
  canRemove?: (option: OptionType) => boolean;
  mainStyles?: React.CSSProperties;
  truncateLength?: number;
  icon?: React.ReactNode;
  onRename?: (newValue: string) => void;
  onRemove?: (option: any) => void;
  onAddInstance?: () => void;
}

export interface CommandButtonConfig {
  id: string;
  iconPath?: string;
  iconComponent?: React.ReactNode;
  options?: Record<string, any>;
  disabled?: (undoManager: any) => boolean;
  customHandler?: boolean;
}

export interface TopbarButtonsProps {
  className?: string;
}

export type ButtonProps = {
  icon?: IconType | ImgType;
  children?: string | ReactNode;
  url?: string;
  color?: 'primary' | 'secondary' | 'dark';
  disabled?: boolean;
  active?: boolean;
  size?: 'sm' | 'md';
  align?: 'left' | 'center' | 'right';
  fitContent?: boolean;
  fontWeight?: 'normal' | 'semibold' | 'bold';
} & React.ButtonHTMLAttributes<HTMLButtonElement>;

export interface ColorElementProps {
  mini?: boolean;
  value: string;
  onChange: (value: string) => void;
}

export type CustomAssetManagerProps = Pick<
  AssetsResultProps,
  'assets' | 'close' | 'select'
>;

export type CustomBlockManagerProps = Pick<
  BlocksResultProps,
  'mapCategoryBlocks' | 'dragStart' | 'dragStop'
>;

export type DragRect = {
  y: number;
  h: number;
  pointerInside: boolean;
};

export interface CustomModalProps extends Omit<
  ModalProps,
  'title' | 'children'
> {
  open: boolean;
  title: React.ReactNode;
  children?: React.ReactNode;
  close: () => void;
}

export interface ListSelectorProps {
  selectedItem: number;
  allItemsCount: number;
  onLeftClick: () => void;
  onRightClick: () => void;
  size?: 'sm' | 'md';
}

export interface CustomTraitManagerProps {
  traits: Trait[];
}

export type ChartLayer = {
  id: string;
  name: string;
  color: string;
  points: { label: string; value: number; color: string }[];
};

export type RoadMapMilestone = {
  id: string;
  title: string;
  date: string;
  description: string;
  status: string;
};

export declare interface LayerItemProps extends React.HTMLProps<HTMLDivElement> {
  component: Component;
  level: number;
  draggingCmp?: Component;
  dragParent?: Component;
}

export interface TopbarProps extends React.HTMLAttributes<HTMLDivElement> {
  onCreateWidgetTemplate?: () => void;
  onOpenTitleModal?: () => void;
  departmentId?: string;
  isSaving?: boolean;
  widgetName?: string;
  widgetDescription?: string;
}

export interface StylePropertyFieldProps extends React.HTMLProps<HTMLDivElement> {
  trait: Trait;
}

export interface GridStyleFieldProps {
  prop: Property;
  onChange: (value: any) => void;
  value: string;
}

export interface GridTrackGroup {
  value: string;
  unit: string;
  count: string;
  min?: string;
  minUnit?: string;
  max?: string;
  maxUnit?: string;
  id: string;
}

export interface NewGroupState {
  value: string;
  unit: string;
  count: string;
  min: string;
  minUnit: string;
  max: string;
  maxUnit: string;
}
