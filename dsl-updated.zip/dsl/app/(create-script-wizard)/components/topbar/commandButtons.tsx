import { DocumentIcon } from '../icons/Document';
import { FrameIcon } from '../icons/Frame';
import { FullscreenIcon } from '../icons/Fullscreen';
import { PreviewIcon } from '../icons/Preview';
import { RedoIcon } from '../icons/Redo';
import { UndoIcon } from '../icons/Undo';
import TilesIcon from '../../icons/Tiles.icon';
import { CommandButtonConfig } from '../types';

export const COMMAND_BUTTONS: CommandButtonConfig[] = [
  {
    id: 'core:undo',
    iconComponent: <UndoIcon />,
    disabled: (undoManager) => !undoManager?.hasUndo?.()
  },
  {
    id: 'core:redo',
    iconComponent: <RedoIcon />,
    disabled: (undoManager) => !undoManager?.hasRedo?.()
  },
  {
    id: 'core:open-code',
    iconComponent: <DocumentIcon />
  },
  {
    id: 'core:component-outline',
    iconComponent: <FrameIcon />,
    options: {}
  },
  {
    id: 'core:toggle-offsets',
    iconComponent: <TilesIcon />,
    customHandler: true
  },
  {
    id: 'core:fullscreen',
    iconComponent: <FullscreenIcon />,
    customHandler: true
  },
  {
    id: 'core:preview',
    iconComponent: <PreviewIcon />,
    customHandler: true
  }
];

export const ZOOM_SPLIT_INDEX =
  COMMAND_BUTTONS.findIndex((btn) => btn.id === 'core:toggle-offsets') + 1;

export const CUSTOM_COMMAND_HANDLERS = {
  'core:fullscreen': 'toggleFullscreen',
  'core:preview': 'togglePreview',
  'core:toggle-offsets': 'toggleOffsets'
} as const;
