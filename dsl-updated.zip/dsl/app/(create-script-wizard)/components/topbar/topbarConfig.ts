import { zoomOptions } from '../../editor/editorConfig';

export const TOPBAR_BUTTONS_CONFIG = {
  canvas: {
    defaultWidth: '800',
    defaultHeight: '500',
    minDimension: 100
  },
  styles: {
    button: {
      base: 'topbar-button',
      frame: 'frame',
      frameActive: 'frame-active',
      offsets: 'offsets',
      offsetsActive: 'offsets-active',
      fullscreenActive: 'fullscreen-active',
      previewActive: 'preview-active',
      active: 'active'
    },
    input:
      'bg-[rgba(255,255,255,0.1)] text-white border-none rounded h-[44px] px-2 outline-none w-[100px] focus:ring-2 focus:ring-sky-300'
  },
  zoom: {
    options: zoomOptions,
    select: {
      maxWidth: '120px',
      minWidth: '120px',
      height: '44px'
    }
  },
  fullscreen: {
    selectors: {
      container: '#gjs'
    }
  },
  update: {
    debounceTime: 100
  }
} as const;
