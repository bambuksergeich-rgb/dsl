import { useState, useRef, useCallback, useEffect } from 'react';
import { useEditor } from '@grapesjs/react';
import { COMMAND_BUTTONS, ZOOM_SPLIT_INDEX } from '../commandButtons';
import { TOPBAR_BUTTONS_CONFIG } from '../topbarConfig';
import { clearSpacingOverlay } from '../../../editor/utils/spacingOverlay';

export const useTopbarButtons = () => {
  const editor = useEditor();
  const { UndoManager, Commands, Canvas } = editor;

  const [isOffsetsVisible, setIsOffsetsVisible] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPreview, setIsPreview] = useState(false);
  const [isFrameActive, setIsFrameActive] = useState(false);
  const [currentZoom, setCurrentZoom] = useState('1');

  const applyCanvasGrid = useCallback(
    (enabled: boolean) => {
      try {
        const doc = editor.Canvas.getDocument();
        const body = editor.Canvas.getBody();
        if (!doc || !body) return;

        const styleId = 'gjs-canvas-grid-style';
        let styleEl = doc.getElementById(styleId) as HTMLStyleElement | null;
        if (!styleEl) {
          styleEl = doc.createElement('style');
          styleEl.id = styleId;
          styleEl.textContent = `
            body.gjs-show-canvas-grid,
            body.gjs-show-canvas-grid [data-gjs-type="wrapper"] {
              background-image:
                linear-gradient(to right, rgba(65, 112, 255, 0.35) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(65, 112, 255, 0.35) 1px, transparent 1px) !important;
              background-size: 20px 20px !important;
              background-position: 0 0 !important;
            }
          `;
          doc.head.appendChild(styleEl);
        }

        body.classList.toggle('gjs-show-canvas-grid', enabled);
      } catch (error) {
        console.warn('Failed to toggle canvas grid class:', error);
      }
    },
    [editor]
  );

  const toggleOffsets = useCallback(() => {
    const next = !isOffsetsVisible;
    setIsOffsetsVisible(next);

    try {
      const config = editor.getConfig() as {
        showOffsets?: boolean;
        showOffsetsSelected?: boolean;
      };
      config.showOffsets = false;
      config.showOffsetsSelected = false;
    } catch (error) {
      console.warn('Failed to update offsets config:', error);
    }

    const canvasEl = document.querySelector('#gjs') as HTMLElement | null;
    if (canvasEl) {
      canvasEl.classList.toggle('gjs-hide-offsets', !next);
    }

    applyCanvasGrid(next);
    clearSpacingOverlay(editor);
  }, [editor, isOffsetsVisible, applyCanvasGrid]);
  const [canvasWidth, setCanvasWidth] = useState<string | number>(
    TOPBAR_BUTTONS_CONFIG.canvas.defaultWidth
  );
  const [canvasHeight, setCanvasHeight] = useState<string | number>(
    TOPBAR_BUTTONS_CONFIG.canvas.defaultHeight
  );

  const isUpdatingRef = useRef(false);

  const updateCanvas = useCallback(() => {
    if (isUpdatingRef.current) return;
    isUpdatingRef.current = true;

    try {
      const zoom = Canvas.getZoom();
      if (zoom !== undefined && zoom !== null) {
        const matchedOption = TOPBAR_BUTTONS_CONFIG.zoom.options.find(
          (opt) => Math.abs(parseFloat(opt.value) - zoom) < 0.01
        );
        const newZoom = matchedOption?.value || '1';
        setCurrentZoom((prev) => (prev !== newZoom ? newZoom : prev));
      }

      const canvasElement = document.querySelector(
        '#gjs .gjs-frame'
      ) as HTMLElement;
      if (canvasElement) {
        const width = canvasElement.offsetWidth;
        const height = canvasElement.offsetHeight;
        setCanvasWidth((prev) =>
          prev !== width.toString() ? width.toString() : prev
        );
        setCanvasHeight((prev) =>
          prev !== height.toString() ? height.toString() : prev
        );
      }
    } catch (error) {
      console.warn('Failed to get canvas data:', error);
    }

    setTimeout(() => {
      isUpdatingRef.current = false;
    }, TOPBAR_BUTTONS_CONFIG.update.debounceTime);
  }, [Canvas]);

  const handleZoomChange = useCallback(
    (option: { value: string; label: string }) => {
      const zoomValue = parseFloat(option.value);
      setCurrentZoom(option.value);

      try {
        Canvas.setZoom(zoomValue);
      } catch (error) {
        console.warn('Failed to set zoom level:', error);
        try {
          Commands.run('core:canvas-zoom', { zoom: zoomValue });
        } catch (cmdError) {
          console.warn('Failed to run zoom command:', cmdError);
        }
      }
    },
    [Canvas, Commands]
  );

  const handleWidthChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const widthValue = parseInt(event.target.value, 10);
      if (
        isNaN(widthValue) ||
        widthValue < TOPBAR_BUTTONS_CONFIG.canvas.minDimension
      )
        return;

      setCanvasWidth(event.target.value);
      try {
        const canvasElement = document.querySelector(
          '#gjs .gjs-frame'
        ) as HTMLElement;
        if (canvasElement) {
          canvasElement.style.width = `${widthValue}px`;
          // Обновляем редактор
          setTimeout(() => {
            editor.refresh();
          }, 100);
        }
      } catch (error) {
        console.warn('Failed to set canvas width:', error);
      }
    },
    [editor]
  );

  const handleHeightChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const heightValue = parseInt(event.target.value, 10);
      if (
        isNaN(heightValue) ||
        heightValue < TOPBAR_BUTTONS_CONFIG.canvas.minDimension
      )
        return;

      setCanvasHeight(event.target.value);
      try {
        const canvasElement = document.querySelector(
          '#gjs .gjs-frame'
        ) as HTMLElement;
        if (canvasElement) {
          canvasElement.style.height = `${heightValue}px`;
          // Обновляем редактор
          setTimeout(() => {
            editor.refresh();
          }, 100);
        }
      } catch (error) {
        console.warn('Failed to set canvas height:', error);
      }
    },
    [editor]
  );

  const toggleFullscreen = useCallback(() => {
    const grapesJsContainer = document.querySelector(
      TOPBAR_BUTTONS_CONFIG.fullscreen.selectors.container
    ) as HTMLElement;

    if (!grapesJsContainer) {
      console.warn('GrapesJS container not found');
      return;
    }

    if (!document.fullscreenElement) {
      // Вход в полноэкранный режим
      if (grapesJsContainer.requestFullscreen) {
        grapesJsContainer.requestFullscreen();
      } else if ((grapesJsContainer as any).webkitRequestFullscreen) {
        (grapesJsContainer as any).webkitRequestFullscreen();
      } else if ((grapesJsContainer as any).msRequestFullscreen) {
        (grapesJsContainer as any).msRequestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      // Выход из полноэкранного режима
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if ((document as any).webkitExitFullscreen) {
        (document as any).webkitExitFullscreen();
      } else if ((document as any).msExitFullscreen) {
        (document as any).msExitFullscreen();
      }
      setIsFullscreen(false);
    }
  }, []);

  const togglePreview = useCallback(() => {
    if (!isPreview) {
      Commands.run('core:preview');
      setIsPreview(true);

      const checkPreviewClose = () => {
        const modal = editor.Modal;
        if (!modal.isOpen()) {
          setIsPreview(false);
          editor.off('modal:close', checkPreviewClose);
        }
      };

      editor.on('modal:close', checkPreviewClose);
    } else {
      Commands.stop('core:preview');
      setIsPreview(false);
    }
  }, [isPreview, Commands, editor]);

  const handleCommandClick = useCallback(
    (id: string, options: any = {}) => {
      if (id === 'core:fullscreen') {
        toggleFullscreen();
      } else if (id === 'core:preview') {
        togglePreview();
      } else if (id === 'core:toggle-offsets') {
        toggleOffsets();
      } else {
        if (Commands.isActive(id)) {
          Commands.stop(id);
        } else {
          Commands.run(id, options);
        }

        if (id === 'core:component-outline') {
          setTimeout(() => {
            setIsFrameActive(Commands.isActive(id));
          }, 100);
        }
      }
    },
    [Commands, toggleFullscreen, togglePreview, toggleOffsets]
  );

  useEffect(() => {
    const canvasEl = document.querySelector('#gjs') as HTMLElement | null;
    if (!canvasEl) return;

    try {
      const config = editor.getConfig() as {
        showOffsets?: boolean;
        showOffsetsSelected?: boolean;
      };
      config.showOffsets = false;
      config.showOffsetsSelected = false;
    } catch {
      return;
    }

    canvasEl.classList.add('gjs-hide-offsets');
    setIsOffsetsVisible(false);
    clearSpacingOverlay(editor);
    applyCanvasGrid(false);
  }, [editor, applyCanvasGrid]);

  useEffect(() => {
    const syncGrid = () => {
      applyCanvasGrid(isOffsetsVisible);
      if (!isOffsetsVisible) {
        clearSpacingOverlay(editor);
      }
    };
    syncGrid();
    editor.on('canvas:frame:load', syncGrid);
    editor.on('page:select', syncGrid);

    return () => {
      editor.off('canvas:frame:load', syncGrid);
      editor.off('page:select', syncGrid);
    };
  }, [editor, applyCanvasGrid, isOffsetsVisible]);

  useEffect(() => {
    const handleUpdate = () => updateCanvas();
    const handleZoom = () => updateCanvas();
    const handleFrameToggle = () => {
      setIsFrameActive(Commands.isActive('core:component-outline'));
    };

    editor.on('update', handleUpdate);
    editor.on('canvas:zoom', handleZoom);
    editor.on('canvasScroll', handleZoom);
    editor.on('component:outline:toggle', handleFrameToggle);
    editor.on('run:core:component-outline', handleFrameToggle);
    editor.on('stop:core:component-outline', handleFrameToggle);

    setIsFrameActive(Commands.isActive('core:component-outline'));
    updateCanvas();

    return () => {
      editor.off('update', handleUpdate);
      editor.off('canvas:zoom', handleZoom);
      editor.off('canvasScroll', handleZoom);
      editor.off('component:outline:toggle', handleFrameToggle);
      editor.off('run:core:component-outline', handleFrameToggle);
      editor.off('stop:core:component-outline', handleFrameToggle);
    };
  }, [editor, updateCanvas, Commands]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      const fullscreenElement =
        document.fullscreenElement ||
        (document as any).webkitFullscreenElement ||
        (document as any).msFullscreenElement;
      setIsFullscreen(!!fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('msfullscreenchange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener(
        'webkitfullscreenchange',
        handleFullscreenChange
      );
      document.removeEventListener(
        'msfullscreenchange',
        handleFullscreenChange
      );
    };
  }, []);

  return {
    isFullscreen,
    isPreview,
    isFrameActive,
    isOffsetsVisible,
    currentZoom,
    canvasWidth,
    canvasHeight,

    handleZoomChange,
    handleWidthChange,
    handleHeightChange,
    handleCommandClick,
    toggleOffsets,

    commandButtons: COMMAND_BUTTONS,
    zoomSplitIndex: ZOOM_SPLIT_INDEX,
    stylesConfig: TOPBAR_BUTTONS_CONFIG.styles,
    zoomConfig: TOPBAR_BUTTONS_CONFIG.zoom,

    UndoManager,
    Commands
  };
};
