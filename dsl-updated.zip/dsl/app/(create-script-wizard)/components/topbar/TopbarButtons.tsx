import { Button } from '@mui/material';
import { Box } from '@mui/system';

import { TopbarButtonsProps } from '../types';
import { useTopbarButtons } from './hooks/useTopbarButtons';
import { CustomSelect } from './../Select';
import { topBarButtonsStyles } from '../componentsConfig';

export default function TopbarButtons({ className }: TopbarButtonsProps) {
  const {
    isFullscreen,
    isPreview,
    isFrameActive,
    isOffsetsVisible,
    currentZoom,
    canvasWidth,
    canvasHeight,
    handleZoomChange,
    handleWidthChange,
    handleHeightChange,
    handleCommandClick,
    commandButtons,
    zoomSplitIndex,
    stylesConfig,
    zoomConfig,
    UndoManager,
    Commands
  } = useTopbarButtons();

  return (
    <Box className={`flex gap-[4px] items-center ${className || ''}`}>
      <style>{topBarButtonsStyles}</style>

      <input
        type='number'
        value={canvasWidth}
        onChange={handleWidthChange}
        className={stylesConfig.input}
        placeholder='Ширина'
        min='100'
      />
      <input
        type='number'
        value={canvasHeight}
        onChange={handleHeightChange}
        className={stylesConfig.input}
        placeholder='Высота'
        min='100'
      />

      {commandButtons
        .slice(0, zoomSplitIndex)
        .map(({ id, iconComponent, disabled, options = {} }) => (
          <Button
            key={id}
            className={`
              ${stylesConfig.button.base}
              ${
                id === 'core:component-outline'
                  ? isFrameActive
                    ? stylesConfig.button.frameActive
                    : stylesConfig.button.frame
                  : ''
              }
              ${
                id === 'core:toggle-offsets'
                  ? isOffsetsVisible
                    ? stylesConfig.button.offsetsActive
                    : stylesConfig.button.offsets
                  : ''
              }
              ${Commands.isActive(id) ? stylesConfig.button.active : ''}
            `}
            onClick={(e) => handleCommandClick(id, options)}
            disabled={disabled?.(UndoManager)}
            title={id}
          >
            {iconComponent}
          </Button>
        ))}

      <CustomSelect
        maxWidth={zoomConfig.select.maxWidth}
        options={zoomConfig.options}
        activeOption={zoomConfig.options.find(
          (opt) => opt.value === currentZoom
        )}
        onChange={(e) => handleZoomChange(e)}
        size='md'
        color='secondary'
        mainStyles={{
          minWidth: zoomConfig.select.minWidth,
          height: zoomConfig.select.height
        }}
        className='h-full'
        placeholder='Zoom'
      />

      {commandButtons
        .slice(zoomSplitIndex)
        .map(({ id, iconComponent, disabled, options = {} }) => (
          <Button
            key={id}
            type='button'
            className={`
              ${stylesConfig.button.base}
              ${id === 'core:fullscreen' && isFullscreen ? stylesConfig.button.fullscreenActive : ''}
              ${id === 'core:preview' && isPreview ? stylesConfig.button.previewActive : ''}
              ${
                id === 'core:toggle-offsets'
                  ? isOffsetsVisible
                    ? stylesConfig.button.offsetsActive
                    : stylesConfig.button.offsets
                  : ''
              }
              ${Commands.isActive(id) ? stylesConfig.button.active : ''}
            `}
            onClick={() => handleCommandClick(id, options)}
            disabled={disabled?.(UndoManager)}
            title={id}
          >
            {iconComponent}
          </Button>
        ))}
    </Box>
  );
}
