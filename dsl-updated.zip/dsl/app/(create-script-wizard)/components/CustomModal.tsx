import * as React from 'react';
import { mdiClose } from '@mdi/js';
import Icon from '@mdi/react';
import Box from '@mui/material/Box';
import Fade from '@mui/material/Fade';
import Modal, { ModalProps } from '@mui/material/Modal';

import { MAIN_BG_COLOR, MAIN_TXT_COLOR, cx } from './common';
import { CustomModalProps } from './types';
import { modalDefaultStyles } from './componentsConfig';

export default function CustomModal({
  children,
  title,
  close,
  ...props
}: CustomModalProps) {
  return (
    <Modal
      onClose={close}
      {...props}
    >
      <Fade in={props.open}>
        <Box
          sx={modalDefaultStyles}
          className={cx(MAIN_BG_COLOR, MAIN_TXT_COLOR, 'rounded')}
        >
          <div className='flex pb-3'>
            <div className='flex-grow text-lg'>{title}</div>
            <div
              onClick={close}
              className='cursor-pointer'
            >
              <Icon
                size={1}
                path={mdiClose}
              />
            </div>
          </div>
          <div className='flex-grow overflow-y-auto'>{children}</div>
        </Box>
      </Fade>
    </Modal>
  );
}
