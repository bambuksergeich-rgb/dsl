import React, { useState, useEffect } from 'react';
import { useEditorMaybe } from '@grapesjs/react';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';
import { Grid } from '@mui/material';
import { Stack, Box } from '@mui/system';

import CssIcon from '@/public/icons/widgetEditor/Css.icon';
import HtmlIcon from '@/public/icons/widgetEditor/Html.icon';
import JavascriptIcon from '@/public/icons/widgetEditor/Javascript.icon';
import CodeMirrorComponentTiled from '@/src/components/CodeMirror/CodeMirrorComponentTiled';
import { TabMUIButton } from '@/src/styles/muiButtonStyles';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import {
  html as htmlBeautify,
  css as cssBeautify,
  js as jsBeautify
} from 'js-beautify';

interface CodeEditorModalProps {
  open: boolean;
  onClose: () => void;
}

type TabType = 'html' | 'css' | 'js';

export default function CodeEditorModal({
  open,
  onClose
}: CodeEditorModalProps) {
  const editor = useEditorMaybe();
  const [activeTab, setActiveTab] = useState<TabType>('html');

  const [htmlContent, setHtmlContent] = useState('');
  const [cssContent, setCssContent] = useState('');
  const [jsContent, setJsContent] = useState('');

  const htmlBeautifyOptions: NonNullable<Parameters<typeof htmlBeautify>[1]> = {
    indent_size: 2,
    indent_char: ' ',
    max_preserve_newlines: 1,
    preserve_newlines: true,
    indent_scripts: 'keep',
    end_with_newline: true,
    wrap_line_length: 80,
    indent_inner_html: true,
    indent_empty_lines: true,
    wrap_attributes: 'force-aligned',
    wrap_attributes_indent_size: 2,
    unformatted: [],
    extra_liners: [
      'head',
      'body',
      '/html',
      'div',
      'p',
      'form',
      'section',
      'header',
      'footer',
      'nav'
    ]
  };

  const cssBeautifyOptions: NonNullable<Parameters<typeof cssBeautify>[1]> = {
    indent_size: 2,
    indent_char: ' ',
    end_with_newline: true,
    selector_separator_newline: true,
    newline_between_rules: true
  };

  const jsBeautifyOptions: NonNullable<Parameters<typeof jsBeautify>[1]> = {
    indent_size: 2,
    indent_char: ' ',
    max_preserve_newlines: 1,
    preserve_newlines: true,
    end_with_newline: true,
    wrap_line_length: 80
  };

  useEffect(() => {
    if (open && editor) {
      const rawHtml = editor.getHtml();
      setHtmlContent(htmlBeautify(rawHtml, htmlBeautifyOptions));

      const rawCss = editor.getCss() || '';
      setCssContent(cssBeautify(rawCss, cssBeautifyOptions));

      const rawJs = editor.getJs() || '';
      setJsContent(jsBeautify(rawJs, jsBeautifyOptions));
    }
  }, [open, editor]);

  const handleSave = () => {
    if (!editor) return;
    editor.setComponents(htmlContent);
    editor.setStyle(cssContent);
    // editor.setJs(jsContent);
    onClose();
  };

  const getCurrentEditorProps = () => {
    switch (activeTab) {
      case 'html':
        return {
          language: 'HTML' as const,
          editorType: 'text/html',
          content: htmlContent,
          setter: setHtmlContent
        };
      case 'css':
        return {
          language: 'CSS' as const,
          editorType: 'text/css',
          content: cssContent,
          setter: setCssContent
        };
      case 'js':
        return {
          language: 'JavaScript' as const,
          editorType: 'text/javascript',
          content: jsContent,
          setter: setJsContent
        };
      default:
        return {
          language: 'HTML' as const,
          editorType: 'text/html',
          content: htmlContent,
          setter: setHtmlContent
        };
    }
  };

  const currentProps = getCurrentEditorProps();

  if (!editor) return null;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth={false}
      fullWidth
      PaperProps={{
        sx: {
          backgroundColor: '#10161C',
          color: 'white',
          height: '90vh', // Высота модалки
          width: '95vw',
          maxWidth: '1600px',
          display: 'flex',
          flexDirection: 'column',
          borderRadius: '8px',
          border: '1px solid rgba(255,255,255,0.1)'
        }
      }}
    >
      <DialogContent
        sx={{
          p: 2,
          flex: 1, // Растягиваем контент на всю высоту Dialog
          display: 'flex', // Важно для вложенных элементов с height: 100%
          flexDirection: 'column',
          overflow: 'hidden',
          backgroundColor: '#0d1117'
        }}
      >
        <Grid
          sx={{
            display: 'grid',
            gridTemplateRows: '34px 1fr', // 34px на табы, остальное редактору
            width: '100%',
            height: '100%', // Занимаем всю высоту DialogContent
            gap: '4px'
          }}
        >
          {/* Панель вкладок */}
          <Stack
            flexDirection={'row'}
            gap={'2px'}
          >
            <TabMUIButton
              selected={activeTab === 'html'}
              onClick={() => setActiveTab('html')}
            >
              <HtmlIcon />
              <TypographyMontserrat500 sx={{ fontSize: '14px' }}>
                HTML Code
              </TypographyMontserrat500>
            </TabMUIButton>

            <TabMUIButton
              selected={activeTab === 'css'}
              onClick={() => setActiveTab('css')}
            >
              <CssIcon />
              <TypographyMontserrat500 sx={{ fontSize: '14px' }}>
                CSS Code
              </TypographyMontserrat500>
            </TabMUIButton>

            <TabMUIButton
              selected={activeTab === 'js'}
              onClick={() => setActiveTab('js')}
            >
              <JavascriptIcon />
              <TypographyMontserrat500 sx={{ fontSize: '14px' }}>
                JavaScript Code
              </TypographyMontserrat500>
            </TabMUIButton>
          </Stack>

          <Box
            sx={{
              height: '100%',
              width: '100%',
              overflow: 'hidden',
              position: 'relative',
              '& .cm-theme, & .cm-editor': {
                height: '100% !important',
                maxHeight: '100% !important'
              },
              '& .cm-scroller': {
                overflow: 'auto !important',
                height: '100% !important',
                paddingBottom: '20px'
              },
              '& > div': {
                height: '100%'
              }
            }}
          >
            <CodeMirrorComponentTiled
              key={activeTab}
              fileId={`code-editor-${activeTab}`}
              language={currentProps.language}
              editorType={currentProps.editorType}
              codeInFile={currentProps.content}
              setHtmlContent={activeTab === 'html' ? setHtmlContent : () => {}}
              setCssContent={activeTab === 'css' ? setCssContent : () => {}}
              setJsContent={activeTab === 'js' ? setJsContent : () => {}}
              visualistation={''}
            />
          </Box>
        </Grid>
      </DialogContent>

      <DialogActions
        sx={{
          // borderTop: '1px solid rgba(255,255,255,0.1)',
          p: 2,
          backgroundColor: 'rgba(16, 22, 28, 0.5)'
        }}
      >
        <Button
          onClick={onClose}
          sx={{
            color: 'rgba(255,255,255,0.6)',
            textTransform: 'none',
            '&:hover': { color: '#fff' }
          }}
        >
          Cancel
        </Button>
        <Button
          onClick={handleSave}
          variant='contained'
          sx={{
            backgroundColor: '#4170FF',
            textTransform: 'none',
            color: '#fff',
            '&:hover': { backgroundColor: '#3560db' }
          }}
        >
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
}
