import * as React from 'react';
import { useEditor } from '@grapesjs/react';
import { useState, useEffect, useMemo } from 'react';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';
import Box from '@mui/material/Box';
import { cx } from './common'; // Убедитесь, что путь правильный

// --- ИКОНКИ ---
const TagIcon = () => (
  <svg
    width='18'
    height='18'
    viewBox='0 0 24 24'
    fill='none'
    stroke='currentColor'
    strokeWidth='2'
    strokeLinecap='round'
    strokeLinejoin='round'
    className='opacity-70'
  >
    <path d='M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z'></path>
    <line
      x1='7'
      y1='7'
      x2='7.01'
      y2='7'
    ></line>
  </svg>
);

const TrashIcon = () => (
  <svg
    width='16'
    height='16'
    viewBox='0 0 24 24'
    fill='none'
    stroke='currentColor'
    strokeWidth='2'
    strokeLinecap='round'
    strokeLinejoin='round'
  >
    <polyline points='3 6 5 6 21 6'></polyline>
    <path d='M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2'></path>
  </svg>
);

const PlusIcon = () => (
  <svg
    width='16'
    height='16'
    viewBox='0 0 24 24'
    fill='none'
    stroke='currentColor'
    strokeWidth='2'
    strokeLinecap='round'
    strokeLinejoin='round'
    className='text-[#4170FF]'
  >
    <line
      x1='12'
      y1='5'
      x2='12'
      y2='19'
    ></line>
    <line
      x1='5'
      y1='12'
      x2='19'
      y2='12'
    ></line>
  </svg>
);

// --- КОМПОНЕНТ ОДНОГО АТРИБУТА (AttributeItem) ---
// Стилизован точно как LayerItem
interface AttributeItemProps {
  attrKey: string;
  attrValue: string;
  index: number;
  onChange: (idx: number, key: "key" | "value", val: string) => void;
  onDelete: (idx: number) => void;
  searchTerm: string;
}

function AttributeItem({
  attrKey,
  attrValue,
  index,
  onChange,
  onDelete,
  searchTerm
}: AttributeItemProps) {
  const [isOpen, setIsOpen] = useState(false);

  const selected = isOpen;
  const isHovered = false;

  // Поиск
  const match = (attrKey + attrValue)
    .toLowerCase()
    .includes(searchTerm.toLowerCase());
  if (searchTerm && !match) return null;

  const wrapperCls = cx(
    selected &&
      'bg-[rgba(42,43,107,1)] border border-[rgba(65,112,255,1)] box-sizing-border-box',
    !selected && 'bg-transparent border-0',
    'cursor-pointer border-b border-transparent'
  );

  const toggleOpen = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsOpen(!isOpen);
  };

  return (
    <div className='layer-item flex flex-col'>
      <div
        className='group max-w-full'
        onClick={toggleOpen}
      >
        <div
          className={cx(
            wrapperCls,
            'flex items-center px-[16px] gap-1 h-[48px]',
            !selected && 'hover:bg-[rgba(42,43,107,0.5)]'
          )}
        >
          <div
            className='cursor-pointer flex-shrink-0 mr-1'
            onClick={toggleOpen}
          >
            {isOpen ? (
              <svg
                width='18'
                height='18'
                viewBox='0 0 18 18'
                fill='none'
                className='text-white'
              >
                <path
                  d='M5.25 7.5L9 11.25L12.75 7.5'
                  stroke='currentColor'
                  strokeWidth='2'
                  strokeLinecap='round'
                  strokeLinejoin='round'
                />
              </svg>
            ) : (
              <svg
                width='18'
                height='18'
                viewBox='0 0 18 18'
                fill='none'
                className='text-white'
              >
                <path
                  d='M7.5 12.75L11.25 9L7.5 5.25'
                  stroke='currentColor'
                  strokeWidth='2'
                  strokeLinecap='round'
                  strokeLinejoin='round'
                />
              </svg>
            )}
          </div>

          {/* ИКОНКА */}
          <div
            className='flex-shrink-0 flex items-center justify-center mr-2'
            style={{ width: '20px', height: '20px' }}
          >
            <TagIcon />
          </div>

          {/* ТЕКСТ (Ключ : Значение) */}
          <div className='truncate flex-grow text-white text-sm'>
            <span className={cx(selected ? 'text-white' : 'text-gray-200')}>
              {attrKey}
            </span>
            <span className='text-gray-500 mx-1'>:</span>
            <span className='text-gray-400'>{attrValue}</span>
          </div>

          {/* КНОПКА УДАЛЕНИЯ (вместо глаза, появляется при ховере) */}
          <div
            className={cx(
              'group-hover:opacity-100 flex-shrink-0 text-gray-400 hover:text-red-400',
              selected ? 'opacity-100' : 'opacity-0'
            )}
            onClick={(e) => {
              e.stopPropagation();
              onDelete(index);
            }}
          >
            <TrashIcon />
          </div>
        </div>
      </div>

      {/* "ДЕТИ" - Панель редактирования (открывается при клике на стрелку) */}
      {isOpen && (
        <div className='flex flex-col gap-2 p-3 bg-[rgba(0,0,0,0.2)] border-l border-[rgba(65,112,255,0.3)] ml-[16px]'>
          <TextField
            label='Name (Key)'
            value={attrKey}
            onChange={(e) => onChange(index, 'key', e.target.value)}
            size='small'
            fullWidth
            variant='outlined'
            sx={{
              '& .MuiInputBase-input': { color: 'white', fontSize: '13px' },
              '& .MuiInputLabel-root': { color: 'rgba(255,255,255,0.5)' },
              '& .MuiOutlinedInput-root': {
                '& fieldset': { borderColor: 'rgba(255,255,255,0.1)' },
                '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.3)' },
                '&.Mui-focused fieldset': { borderColor: '#4170FF' }
              }
            }}
          />
          <TextField
            label='Value'
            value={attrValue}
            onChange={(e) => onChange(index, 'value', e.target.value)}
            size='small'
            fullWidth
            multiline // Значение может быть длинным
            maxRows={4}
            variant='outlined'
            sx={{
              '& .MuiInputBase-input': { color: 'white', fontSize: '13px' },
              '& .MuiInputLabel-root': { color: 'rgba(255,255,255,0.5)' },
              '& .MuiOutlinedInput-root': {
                '& fieldset': { borderColor: 'rgba(255,255,255,0.1)' },
                '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.3)' },
                '&.Mui-focused fieldset': { borderColor: '#4170FF' }
              }
            }}
          />
        </div>
      )}
    </div>
  );
}

export default function AttributesManager() {
  const editor = useEditor();
  const [selectedComponent, setSelectedComponent] = useState<any>(null);
  const [attributesList, setAttributesList] = useState<
    { key: string; value: string }[]
  >([]);
  const [searchQuery, setSearchQuery] = useState('');

  const updateFromComponent = (component: any) => {
    if (!component) {
      setAttributesList([]);
      return;
    }
    const attrs = component.getAttributes();
    const list = Object.entries(attrs)
      .filter(([key]) => key !== 'class')
      .map(([key, value]) => ({ key, value: String(value) }));
    setAttributesList(list);
  };

  useEffect(() => {
    const onSelect = () => {
      const selected = editor.getSelected();
      setSelectedComponent(selected);
      updateFromComponent(selected);
    };
    const onUpdate = () => {
      const selected = editor.getSelected();
      if (selected) updateFromComponent(selected);
    };
    editor.on('component:selected', onSelect);
    editor.on('component:deselected', onSelect);
    editor.on('component:update:attributes', onUpdate);
    onSelect();
    return () => {
      editor.off('component:selected', onSelect);
      editor.off('component:deselected', onSelect);
      editor.off('component:update:attributes', onUpdate);
    };
  }, [editor]);

  const syncAttributes = (newList: { key: string; value: string }[]) => {
    if (!selectedComponent) return;
    const newAttrs: Record<string, string> = {};
    newList.forEach((item) => {
      if (item.key.trim()) newAttrs[item.key] = item.value;
    });

    const currentAttrs = selectedComponent.getAttributes();
    Object.keys(currentAttrs).forEach((key) => {
      if (key !== 'class' && !newAttrs[key])
        selectedComponent.removeAttributes(key);
    });
    selectedComponent.addAttributes(newAttrs);
    setAttributesList(newList);
  };

  const handleChange = (index: number, field: 'key' | 'value', val: string) => {
    const newList = [...attributesList];
    newList[index][field] = val;
    if (field === 'value') syncAttributes(newList);
    else setAttributesList(newList);
  };

  const handleBlur = () => syncAttributes(attributesList);

  const handleDelete = (index: number) => {
    const newList = attributesList.filter((_, i) => i !== index);
    syncAttributes(newList);
  };

  const handleAdd = () => {
    const newList = [...attributesList, { key: 'new-attr', value: '' }];
    syncAttributes(newList);
  };

  if (!selectedComponent) {
    return (
      <Box
        sx={{
          p: 2,
          textAlign: 'center',
          color: 'rgba(255,255,255,0.5)',
          fontSize: '14px'
        }}
      >
        Select a component
      </Box>
    );
  }

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        overflow: 'hidden',
        position: 'relative'
      }}
    >
      <TextField
        placeholder='Search attributes'
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        sx={{
          mb: 1,
          height: '44px',
          '& .MuiOutlinedInput-root': {
            borderRadius: '5px',
            backgroundColor: 'rgba(255, 255, 255, 0.1)',
            height: '44px',
            color: 'white',
            '& .MuiOutlinedInput-notchedOutline': { border: 'none' },
            '&:hover .MuiOutlinedInput-notchedOutline': { border: 'none' },
            '&.Mui-focused .MuiOutlinedInput-notchedOutline': { border: 'none' }
          }
        }}
        InputProps={{
          endAdornment: (
            <InputAdornment position='start'>
              <SearchIcon
                fontSize='small'
                sx={{ color: 'rgba(255,255,255,0.5)' }}
              />
            </InputAdornment>
          )
        }}
      />

      <div className='gjs-custom-layer-manager flex-1 overflow-y-auto overflow-x-hidden text-sm text-left select-none relative'>
        {attributesList.map((attr, index) => (
          <div
            key={index}
            onBlur={handleBlur}
          >
            {' '}
            <AttributeItem
              attrKey={attr.key}
              attrValue={attr.value}
              index={index}
              onChange={handleChange}
              onDelete={handleDelete}
              searchTerm={searchQuery}
            />
          </div>
        ))}

        {!searchQuery && (
          <button
            type='button'
            onClick={handleAdd}
            className={cx('rounded px-2 py-1')}
            style={{
              width: '36px',
              height: '36px',
              background: 'rgba(65, 112, 255, 1)',
              border: 'none',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center'
            }}
          >
            <svg
              width='15'
              height='14'
              viewBox='0 0 15 14'
              fill='none'
              xmlns='http://www.w3.org/2000/svg'
              style={{
                display: 'block'
              }}
            >
              <path
                d='M7.25 0.75V13.25M13.5 7H1'
                stroke='white'
                strokeWidth='1.5'
                strokeLinecap='round'
                strokeLinejoin='round'
              />
            </svg>
          </button>
        )}
      </div>
    </Box>
  );
}
