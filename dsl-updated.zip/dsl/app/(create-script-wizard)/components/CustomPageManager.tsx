import * as React from 'react';
import { PagesResultProps } from '@grapesjs/react';
import type { Page } from 'grapesjs';

import { cx } from './common';
import { CustomSelect } from './Select';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';
import { ArrowRightIcon } from './icons/ArrowRightIcon';
import { ListSelectorProps, OptionType } from './types';

const SquareButton: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  size?: 'sm' | 'md';
}> = ({ children, onClick, size = 'md' }) => {
  return (
    <button
      type='button'
      className={cx(
        'flex items-center justify-center',
        size === 'sm' ? 'w-8 h-8' : 'w-10 h-10'
      )}
      style={{
        background: 'rgba(255, 255, 255, 0.1)',
        borderRadius: '4px',
        minWidth: '44px',
        width: 'auto',
        height: '44px',
        border: 'none'
      }}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

const ListSelector: React.FC<ListSelectorProps> = ({
  selectedItem,
  allItemsCount,
  onLeftClick,
  onRightClick
}) => {
  const isLeftNotActive = React.useMemo(
    () => selectedItem === 1,
    [selectedItem]
  );
  const isRightNotActive = React.useMemo(
    () => selectedItem === allItemsCount,
    [selectedItem, allItemsCount]
  );

  return (
    <div className='flex gap-[4px]'>
      <SquareButton
        size={'md'}
        onClick={isLeftNotActive ? undefined : onLeftClick}
      >
        <ArrowLeftIcon isActive={!isLeftNotActive} />
      </SquareButton>
      <SquareButton size={'md'}>
        {`${selectedItem} / ${allItemsCount}`}
      </SquareButton>
      <SquareButton
        size={'md'}
        onClick={isRightNotActive ? undefined : onRightClick}
      >
        <ArrowRightIcon isActive={!isRightNotActive} />
      </SquareButton>
    </div>
  );
};

export default function CustomPageManager({
  pages,
  selected,
  add,
  select,
  remove
}: PagesResultProps) {
  const addNewPage = () => {
    const nextIndex = pages.length + 1;
    add({
      name: `New page ${nextIndex}`,
      component: ``
    });
  };

  const duplicatePage = (page: Page) => {
    if (!page) return;
    const mainComponent = page.getMainComponent();
    const content = mainComponent.toHTML();
    add({
      name: `${page.getName() || 'Untitled'} copy`,
      component: content
    });
  };

  const selectedIndex =
    selected && pages.includes(selected) ? pages.indexOf(selected) + 1 : 0;

  const handlePrevious = () => {
    if (selectedIndex > 1) {
      select(pages[selectedIndex - 2]);
    }
  };

  const handleNext = () => {
    if (selectedIndex < pages.length) {
      select(pages[selectedIndex]);
    }
  };

  // КРИТИЧНО: Определяем первую страницу (Index)
  const firstPage = pages.length > 0 ? pages[0] : null;

  // Функция для проверки, является ли страница первой
  const isFirstPage = (page: Page): boolean => {
    return firstPage ? page.getId() === firstPage.getId() : false;
  };

  const options: OptionType[] = pages.map((page, index) => ({
    value: page.getId(),
    label: page.getName() || `Untitled page ${index + 1}`,
    onDoubleClick: () => duplicatePage(page)
  }));

  const activeOption = selected
    ? options.find((option) => option.value === selected.getId())
    : undefined;

  return (
    <div className='gjs-custom-page-manager'>
      <div className='flex items-center justify-between gap-[6px]'>
        <CustomSelect
          maxWidth='200px'
          options={options}
          activeOption={activeOption}
          onChange={(option) => {
            const page = pages.find((p) => p.getId() === option.value);
            if (page) select(page);
          }}
          placeholder='Select a page...'
          disabled={pages.length === 0}
          color='secondary'
          className='w-[200px]'
          truncateLength={5}
          onRemove={(option) => {
            const page = pages.find((p) => p.getId() === option.value);
            // КРИТИЧНО: Блокируем удаление первой страницы
            if (page && !isFirstPage(page)) {
              remove(page);
            }
          }}
          extendable={{
            label: 'Add New Page',
            onClick: () => {
              addNewPage();
            }
          }}
          // КРИТИЧНО: Передаём функцию для определения, можно ли удалить опцию
          canRemove={(option) => {
            const page = pages.find((p) => p.getId() === option.value);
            return page ? !isFirstPage(page) : false;
          }}
        />
        <div className='flex items-center gap-[4px]'>
          <ListSelector
            selectedItem={selectedIndex}
            allItemsCount={pages.length}
            onLeftClick={handlePrevious}
            onRightClick={handleNext}
            size='sm'
          />
        </div>
      </div>
    </div>
  );
}

// import * as React from 'react';
// import { PagesResultProps } from '@grapesjs/react';
// import type { Page } from 'grapesjs';

// import { cx } from './common';
// import { CustomSelect } from './Select';
// import { ArrowLeftIcon } from './icons/ArrowLeftIcon';
// import { ArrowRightIcon } from './icons/ArrowRightIcon';
// import { ListSelectorProps, OptionType } from './types';

// const SquareButton: React.FC<{
//   children: React.ReactNode;
//   onClick?: () => void;
//   size?: 'sm' | 'md';
// }> = ({ children, onClick, size = 'md' }) => {
//   return (
//     <button
//       type='button'
//       className={cx(
//         'flex items-center justify-center',
//         size === 'sm' ? 'w-8 h-8' : 'w-10 h-10'
//       )}
//       style={{
//         background: 'rgba(255, 255, 255, 0.1)',
//         borderRadius: '4px',
//         minWidth: '44px',
//         width: 'auto',
//         height: '44px',
//         border: 'none'
//       }}
//       onClick={onClick}
//     >
//       {children}
//     </button>
//   );
// };

// const ListSelector: React.FC<ListSelectorProps> = ({
//   selectedItem,
//   allItemsCount,
//   onLeftClick,
//   onRightClick
// }) => {
//   const isLeftNotActive = React.useMemo(
//     () => selectedItem === 1,
//     [selectedItem]
//   );
//   const isRightNotActive = React.useMemo(
//     () => selectedItem === allItemsCount,
//     [selectedItem, allItemsCount]
//   );

//   return (
//     <div className='flex gap-[4px]'>
//       <SquareButton
//         size={'md'}
//         onClick={isLeftNotActive ? undefined : onLeftClick}
//       >
//         <ArrowLeftIcon isActive={!isLeftNotActive} />
//       </SquareButton>
//       <SquareButton size={'md'}>
//         {`${selectedItem} / ${allItemsCount}`}
//       </SquareButton>
//       <SquareButton
//         size={'md'}
//         onClick={isRightNotActive ? undefined : onRightClick}
//       >
//         <ArrowRightIcon isActive={!isRightNotActive} />
//       </SquareButton>
//     </div>
//   );
// };

// export default function CustomPageManager({
//   pages,
//   selected,
//   add,
//   select,
//   remove
// }: PagesResultProps) {
//   const addNewPage = () => {
//     const nextIndex = pages.length + 1;
//     add({
//       name: `New page ${nextIndex}`,
//       component: ``
//     });
//   };

//   const duplicatePage = (page: Page) => {
//     if (!page) return;
//     const mainComponent = page.getMainComponent();
//     const content = mainComponent.toHTML();
//     add({
//       name: `${page.getName() || 'Untitled'} copy`,
//       component: content
//     });
//   };

//   const selectedIndex =
//     selected && pages.includes(selected) ? pages.indexOf(selected) + 1 : 0;

//   const handlePrevious = () => {
//     if (selectedIndex > 1) {
//       select(pages[selectedIndex - 2]);
//     }
//   };

//   const handleNext = () => {
//     if (selectedIndex < pages.length) {
//       select(pages[selectedIndex]);
//     }
//   };

//   const options: OptionType[] = pages.map((page, index) => ({
//     value: page.getId(),
//     label: page.getName() || `Untitled page ${index + 1}`,
//     onDoubleClick: () => duplicatePage(page)
//   }));

//   const activeOption = selected
//     ? options.find((option) => option.value === selected.getId())
//     : undefined;

//   return (
//     <div className='gjs-custom-page-manager'>
//       <div className='flex items-center justify-between gap-[6px]'>
//         <CustomSelect
//           maxWidth='200px'
//           options={options}
//           activeOption={activeOption}
//           onChange={(option) => {
//             const page = pages.find((p) => p.getId() === option.value);
//             if (page) select(page);
//           }}
//           placeholder='Select a page...'
//           disabled={pages.length === 0}
//           color='secondary'
//           className='w-[200px]'
//           truncateLength={5}
//           onRemove={(option) => {
//             const page = pages.find((p) => p.getId() === option.value);
//             if (page) remove(page);
//           }}
//           extendable={{
//             label: 'Add New Page',
//             onClick: () => {
//               addNewPage();
//             }
//           }}
//         />
//         <div className='flex items-center gap-[4px]'>
//           <ListSelector
//             selectedItem={selectedIndex}
//             allItemsCount={pages.length}
//             onLeftClick={handlePrevious}
//             onRightClick={handleNext}
//             size='sm'
//           />
//         </div>
//       </div>
//     </div>
//   );
// }
