import * as React from 'react';
import { DevicesProvider, PagesProvider, WithEditor } from '@grapesjs/react';
import Button from '@mui/material/Button';
import { Typography, Tooltip } from '@mui/material';
import { Stack } from '@mui/system';

import { TopbarProps } from './types';
import { truncateText } from './helpers';
import { cx } from './common';
import TopbarButtons from './topbar/TopbarButtons';
import CustomPageManager from './CustomPageManager';
import { CustomSelect } from './Select';

export default function Topbar({
  children,
  onCreateWidgetTemplate,
  onOpenTitleModal,
  departmentId,
  isSaving = false,
  widgetName,
  widgetDescription,
  ...props
}: TopbarProps) {
  const handleSave = async () => {
    if (onCreateWidgetTemplate) {
      await onCreateWidgetTemplate();
    } else {
      console.warn('Save function not implemented');
    }
  };

  const handleBack = () => {
    window.history.back();
  };

  const truncatedName = truncateText(widgetName || 'Title', 13);
  const truncatedDescription = truncateText(
    widgetDescription || 'Description',
    12
  );

  return (
    <div
      className={cx(
        'gjs-top-sidebar flex flex-col sm:flex-row items-start sm:items-center justify-between px-2 sm:px-[8px] py-2 sm:py-[6px] bg-gradient-to-r from-[#0A0F18] to-[#373B44] gap-2 sm:gap-0'
      )}
    >
      <Tooltip
        title={widgetName || 'Title'}
        placement='bottom-start'
        enterDelay={500}
      >
        <Stack
          onClick={onOpenTitleModal}
          sx={{
            width: 'auto',
            maxWidth: { xs: '200px', sm: '250px', md: '298px' },
            gap: '4px',
            cursor: 'pointer'
          }}
          className='min-w-0'
        >
          <Typography
            fontSize={{ xs: 16, sm: 18, md: 20 }}
            noWrap
            className='text-ellipsis overflow-hidden'
          >
            {truncatedName}
          </Typography>
          <Typography
            fontSize={{ xs: 12, sm: 14 }}
            noWrap
            className='text-ellipsis overflow-hidden'
          >
            {truncatedDescription}
          </Typography>
        </Stack>
      </Tooltip>

      <div className='flex items-center justify-center gap-1 sm:gap-[6px] flex-wrap sm:flex-nowrap order-3 sm:order-2'>
        <PagesProvider>
          {(props) => (
            <div className='flex items-center h-[40px] sm:h-[44px]'>
              <CustomPageManager {...props} />
            </div>
          )}
        </PagesProvider>

        <div className='flex items-center gap-1 sm:gap-[6px] h-[40px] sm:h-[44px]'>
          <DevicesProvider>
            {({ selected, select, devices }) => {
              const options = devices.map((device) => ({
                value: String(device.id),
                label: device.getName() || String(device.id)
              }));

              const activeOption =
                options.find((option) => option.value === String(selected)) ??
                undefined;

              return (
                <CustomSelect
                  maxWidth={{ xs: '140px', sm: '160px', md: '200px' }}
                  options={options}
                  activeOption={activeOption}
                  onChange={(option) => select(option.value)}
                  size='md'
                  color='secondary'
                  mainStyles={{
                    width: '200px',
                    height: '44px'
                  }}
                  className='h-full'
                />
              );
            }}
          </DevicesProvider>
        </div>

        <WithEditor>
          <div className='flex items-center h-[40px] sm:h-[44px] gap-1 sm:gap-[4px]'>
            <TopbarButtons className='gap-1 sm:gap-[6px]' />
          </div>
        </WithEditor>
      </div>

      <div className='flex-shrink-0 order-2 sm:order-3 ml-auto sm:ml-0'>
        <div className='flex items-center gap-1 sm:gap-[4px] flex-wrap sm:flex-nowrap'>
          <Button
            variant='contained'
            onClick={handleBack}
            sx={{
              width: { xs: '80px', sm: '100px', md: '120px' },
              height: { xs: '36px', sm: '40px', md: '44px' },
              backgroundColor: 'rgba(114, 113, 112, 1)',
              color: '#fff',
              borderRadius: '0.375rem',
              textTransform: 'none',
              fontSize: { xs: 14, sm: 16 },
              border: 'none',
              '&:hover': {
                backgroundColor: 'rgba(114, 113, 112, 0.8)',
                border: 'none'
              },
              minWidth: 'auto'
            }}
          >
            Back
          </Button>
          <Button
            variant='contained'
            onClick={handleSave}
            disabled={!departmentId || isSaving}
            sx={{
              width: { xs: '80px', sm: '100px', md: '120px' },
              height: { xs: '36px', sm: '40px', md: '44px' },
              backgroundColor: departmentId
                ? 'rgba(65, 112, 255, 1)'
                : 'rgba(65, 112, 255, 0.5)',
              color: '#fff',
              borderRadius: '0.375rem',
              textTransform: 'none',
              fontSize: { xs: 14, sm: 16 },
              border: 'none',
              '&:hover':
                departmentId && !isSaving
                  ? {
                      backgroundColor: 'rgba(65, 112, 255, 0.8)',
                      border: 'none'
                    }
                  : {},
              minWidth: 'auto'
            }}
          >
            {isSaving ? 'Saving...' : 'Save'}
          </Button>
        </div>
      </div>

      {children}
    </div>
  );
}
