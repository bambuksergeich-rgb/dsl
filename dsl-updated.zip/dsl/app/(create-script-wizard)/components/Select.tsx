'use client';

import React, { useEffect } from 'react';
import classNames from 'classnames';
import clsx from 'clsx';
import CloseIcon from '@mui/icons-material/Close';
import { AddCircleOutlineIcon } from '@/assets/icons';
import { selectStyles } from './componentsConfig';
import { OptionType, SelectProps, ExtendableType } from './types';
import { SelectIcon } from './icons/Select';
import { Button } from '@/src/components/UI/Button/Button';

export const CustomSelect: React.FC<SelectProps> = ({
  maxWidth,
  options,
  activeOption,
  onChange = () => {},
  onRemove = () => {},
  onAddInstance = () => {},
  canRemove = () => true,
  disabled,
  size = 'md',
  className,
  label,
  placeholder,
  color = 'secondary',
  onOpen,
  onClose,
  icon,
  mainStyles,
  truncateLength = 5,
  extendable
}: SelectProps) => {
  const isSmall = size === 'sm';
  const isMedium = size === 'md';

  const [open, setOpen] = React.useState<boolean>(false);
  const selectInstanceId = React.useId();

  React.useEffect(() => {
    const closeOtherSelect = (event: Event) => {
      const detail = (event as CustomEvent<{ id?: string }>).detail;
      if (detail?.id !== selectInstanceId) setOpen(false);
    };
    window.addEventListener('dsl:custom-select-open', closeOtherSelect as EventListener);
    return () =>
      window.removeEventListener('dsl:custom-select-open', closeOtherSelect as EventListener);
  }, [selectInstanceId]);

  React.useEffect(() => {
    if (!open) return;
    window.dispatchEvent(
      new CustomEvent('dsl:custom-select-open', { detail: { id: selectInstanceId } })
    );
  }, [open, selectInstanceId]);

  const primaryStyles = 'bg-dsl-purple-700';
  const secondaryStyles = 'bg-white bg-opacity-10';

  const onCloseSelect = () => setOpen(false);
  const onChangeSelectOption = (option: OptionType) => {
    onChange(option);
    setOpen(false);
  };
  const onBodyOpenToggle = () => {
    setOpen((prev) => !prev);
  };

  useEffect(() => {
    if (open && onOpen) {
      onOpen();
    } else if (!open && onClose) {
      onClose();
    }
  }, [open, onOpen, onClose]);

  const getMaxWidth = (): string | undefined => {
    if (typeof maxWidth === 'string') return maxWidth;
    return maxWidth?.md;
  };

  const truncatedLabel =
    activeOption?.label || activeOption?.name
      ? activeOption.label.length > truncateLength
        ? `${activeOption.label.slice(0, truncateLength)}...`
        : activeOption.label
      : placeholder || 'Select option...';

  return (
    <div
      className={clsx('flex flex-col gap-1.5', className)}
      style={{
        ...mainStyles,
        maxWidth: getMaxWidth()
      }}
    >
      <style>{selectStyles}</style>
      {label && <div className='text-sm font-medium text-white'>{label}</div>}
      <div
        className={classNames(
          { 'opacity-50 pointer-events-none': disabled },
          'relative z-30 px-[0]',
          'w-full'
        )}
        style={{ maxWidth: getMaxWidth() }}
      >
        <button
          className={classNames(
            {
              'rounded-b-md': !open,
              'h-[36px] sm:h-[44px] py-2 sm:py-3 text-sm': isMedium,
              'h-[30px] sm:h-[34px] py-1.5 text-xs': isSmall,
              [primaryStyles]: color === 'primary',
              [secondaryStyles]: color === 'secondary',
              'text-white': true
            },
            'flex items-center justify-between gap-2 sm:gap-4 px-[0px] w-full rounded-t-md leading-none'
          )}
          type='button'
          onClick={onBodyOpenToggle}
        >
          <div
            className={classNames(
              {
                'h-[30px] sm:h-[34px]': isSmall,
                'h-[36px] sm:h-[44px]': isMedium
              },
              'text-left pl-3 sm:pl-4 pr-8 sm:pr-12'
            )}
            style={{ width: 'calc(100% - 40px)' }}
          >
            <span
              className={classNames(
                {
                  'leading-[30px] sm:leading-[34px]': isSmall,
                  'leading-[36px] sm:leading-[44px]': isMedium,
                  'text-white': true
                },
                'text-xs sm:text-[14px]'
              )}
            >
              {truncatedLabel}
            </span>
          </div>
          <div
            className={classNames(
              {
                'h-[30px] w-[30px] sm:h-[34px] sm:w-[34px]': isSmall,
                'h-[36px] w-[36px] sm:h-[44px] sm:w-[44px]': isMedium
              },
              'absolute top-0 right-[4px] sm:right-[8px] flex justify-center items-center'
            )}
          >
            <span className={classNames('select-icon', { open })}>
              {icon || <SelectIcon />}
            </span>
          </div>
        </button>
        {open && (
          <div className='border border-dsl-gray-800 absolute left-0 top-full flex flex-col pt-1 pb-2 bg-black selector-scroll-drop-down-list rounded-b-md overflow-hidden w-full max-h-48 z-50'>
            <div className='overflow-y-auto max-h-40 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]'>
              {options.length === 0 ? (
                <div className='px-4 sm:px-5 py-2 sm:py-3 text-xs sm:text-sm text-gray-400'>
                  No options available
                </div>
              ) : (
                options.map((option) => {
                  // КРИТИЧНО: Проверяем, можно ли удалить этот option
                  const isRemovable = canRemove(option);

                  return (
                    <div
                      key={option.value}
                      className={classNames(
                        {
                          'px-5 py-2': extendable
                        },
                        'flex items-center text-sm'
                      )}
                    >
                      <button
                        className={classNames(
                          {
                            'py-2': isSmall,
                            'py-2 sm:py-3': isMedium
                          },
                          'flex px-4 sm:px-5 text-xs sm:text-sm text-white',
                          !extendable && 'hover:bg-gray-800 active-option',
                          'w-full text-left'
                        )}
                        type='button'
                        key={option.value + option.label}
                        onClick={() => onChangeSelectOption(option)}
                        onDoubleClick={option.onDoubleClick}
                      >
                        {option.label}
                      </button>
                      {/* КРИТИЧНО: Показываем кнопку удаления только если можно удалить */}
                      {extendable && isRemovable && (
                        <button
                          type='button'
                          onClick={() => onRemove(option)}
                          className='ml-auto bg-[#3D3AB8] text-white p-1 rounded'
                        >
                          <CloseIcon fontSize='small' />
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
            {extendable && (
              <div className='px-4 mt-2 border-t border-gray-700 sticky bottom-0 bg-black'>
                <Button
                  type='button'
                  icon={AddCircleOutlineIcon}
                  size='sm'
                  className='flex items-center justify-center w-full'
                  onClick={extendable.onClick}
                >
                  {extendable.label}
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
      {open && (
        <div
          className='fixed left-0 top-0 w-screen h-screen z-20'
          onClick={onCloseSelect}
        />
      )}
    </div>
  );
};
