export const SELECT_OPTIONS = [
  { value: '', label: 'Basic' },
  { value: 'Flex', label: 'Flex' },
  { value: 'Grid', label: 'Grid' },
  { value: 'Position', label: 'Position' }
];

export const toggleBtnSx = {
  flex: 1,
  border: 'none',
  borderRadius: '6px !important',
  backgroundColor: 'rgba(255, 255, 255, 0.1)',
  padding: '6px',
  height: '34px',
  '&.Mui-selected': {
    backgroundColor: 'rgba(65, 112, 255, 1) !important',
    color: 'white'
  },
  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.2)' }
};
export const groupSx = {
  display: 'flex',
  gap: '8px',
  width: '100%',
  backgroundColor: 'transparent'
};
export const textFieldSx = {
  backgroundColor: 'rgba(255, 255, 255, 0.1)',
  borderRadius: '6px',
  '& .MuiOutlinedInput-root': {
    '& fieldset': { border: 'none' },
    '&:hover fieldset': { border: 'none' },
    '&.Mui-focused fieldset': { border: 'none' },
    height: '34px',
    fontFamily: 'Montserrat',
    '& input': {
      border: 'none',
      padding: '0 10px',
      height: '34px',
      fontFamily: 'Montserrat',
      color: 'white',
      fontSize: '13px'
    }
  }
};
export const selectSx = {
  '& .MuiSelect-select': {
    fontSize: '10px',
    border: '1px solid rgba(255, 255, 255, 0.15)',
    borderRadius: '6px',
    height: '24px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center !important',
    padding: '0 !important',
    margin: '0 !important',
    textAlign: 'center !important',
    fontFamily: 'Montserrat'
  },
  '& .MuiSelect-icon': { display: 'none' },
  height: '24px'
};

export const availableUnits = [
  'px',
  '%',
  'fr',
  'rem',
  'calc',
  'minmax',
  'auto-fit',
  'auto-fill'
];
export const innerUnits = ['px', '%', 'fr', 'rem'];
