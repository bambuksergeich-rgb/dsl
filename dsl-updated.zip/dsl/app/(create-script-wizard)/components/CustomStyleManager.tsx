import * as React from 'react';
import { StylesResultProps } from '@grapesjs/react';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import { Box } from '@mui/material';

import StylePropertyField from './StylePropertyField';
import { AccordionIcon } from './icons/AccordionIcon';
import { EDITOR_SIDEBAR_BG } from '@/src/styles/editorSidebarTokens';

interface CustomStyleManagerProps extends Omit<StylesResultProps, 'Container'> {
  activeViewMode: string;
}

export default function CustomStyleManager({
  sectors,
  activeViewMode = 'Basic'
}: CustomStyleManagerProps) {
  const SPECIAL_SECTOR_IDS = [
    'flex-children',
    'layout-grid',
    'layout-position',
    'grid-parent'
  ];

  return (
    <Box
      className='gjs-custom-style-manager text-left'
      sx={{
        height: 'auto',
        overflowY: 'auto',
        display: 'flex',
        flexDirection: 'column',
        background: EDITOR_SIDEBAR_BG,
        fontFamily: 'Montserrat, sans-serif',
        scrollbarWidth: 'none',
        '&::-webkit-scrollbar': {
          display: 'none'
        },
        '-ms-overflow-style': 'none'
      }}
    >
      {sectors.map((sector) => {
        const sectorId = sector.getId();

        if (activeViewMode === 'Flex') {
          if (sectorId !== 'flex-children') return null;
        } else if (activeViewMode === 'Grid') {
          if (sectorId !== 'layout-grid' && sectorId !== 'grid-parent')
            return null;
        } else if (activeViewMode === 'Position') {
          if (sectorId !== 'layout-position') return null;
        } else {
          if (SPECIAL_SECTOR_IDS.includes(sectorId)) return null;
        }

        if (sectorId === 'layout-position') {
          return (
            <Box
              key={sectorId}
              className='flex flex-wrap'
              sx={{
                color: 'rgba(255, 255, 255, 1)',
                background: 'rgba(16, 22, 28, 0)',
                padding: '8px'
              }}
            >
              {sector.getProperties().map((prop) => (
                <StylePropertyField
                  key={prop.getId()}
                  prop={prop}
                />
              ))}
            </Box>
          );
        }
        return (
          <Accordion
            key={sectorId}
            disableGutters
            defaultExpanded={activeViewMode !== 'Basic'}
            sx={{
              fontSize: '16px',
              fontWeight: '500',
              color: 'rgba(65, 112, 255, 1)',
              background: 'rgba(16, 22, 28, 0)',
              '&.MuiAccordion-root': {
                backgroundColor: 'rgba(16, 22, 28, 0)',
                '&:before': {
                  display: 'none'
                }
              }
            }}
          >
            <AccordionSummary
              expandIcon={AccordionIcon}
              sx={{
                backgroundColor: 'rgba(16, 22, 28, 0)',
                '&.MuiAccordionSummary-root': {
                  backgroundColor: 'rgba(16, 22, 28, 0)'
                },
                '& .MuiAccordionSummary-expandIconWrapper': {
                  transition: 'transform 0.3s ease',
                  '&.Mui-expanded': {
                    transform: 'rotate(180deg)'
                  }
                }
              }}
            >
              {sector.getName()}
            </AccordionSummary>
            <AccordionDetails
              className='flex flex-wrap'
              sx={{
                color: 'rgba(255, 255, 255, 1)',
                background: 'rgba(16, 22, 28, 0)',
                padding: '8px'
              }}
            >
              {sector.getProperties().map((prop) => (
                <StylePropertyField
                  key={prop.getId()}
                  prop={prop}
                />
              ))}
            </AccordionDetails>
          </Accordion>
        );
      })}
    </Box>
  );
}
