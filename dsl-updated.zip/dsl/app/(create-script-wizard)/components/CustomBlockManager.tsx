import * as React from 'react';
import { Box, Stack, useMediaQuery, useTheme } from '@mui/system';

import { MAIN_BG_COLOR, MAIN_TXT_COLOR, cx } from './common';
import { CustomBlockManagerProps } from './types';

export default function CustomBlockManager({
  mapCategoryBlocks,
  dragStart,
  dragStop
}: CustomBlockManagerProps) {
  const theme = useTheme();
  const isSmallScreen = useMediaQuery(theme.breakpoints.down(1700));

  const categories = Array.from(mapCategoryBlocks).sort(([a], [b]) => {
    if (a === 'Main') return -1;
    if (b === 'Main') return 1;
    return a.localeCompare(b);
  });

  if (!categories.length) {
    return null;
  }

  return (
    <Box
      className={cx('gjs-custom-block-manager p-0 w-[auto]', MAIN_TXT_COLOR)}
      sx={{
        height: '100%',
        overflowY: 'auto',
        padding: isSmallScreen ? '4px' : '0',
        background: 'transparent',
        scrollbarWidth: 'none',
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none'
      }}
    >
      {categories.map(([category, blocks]) => (
        <React.Fragment key={category}>
          {!isSmallScreen && (
            <Stack className={cx('py-2 px-4', MAIN_BG_COLOR, MAIN_TXT_COLOR)}>
              {category}
            </Stack>
          )}

          <Stack className={cx('flex-col gap-1 p-1')}>
            {blocks.map((block) => (
              <Stack
                flexDirection={'row'}
                key={block.getId()}
                draggable
                className={cx(
                  'flex items-center rounded cursor-pointer transition-colors bg-[#10161C80] box-border',
                  isSmallScreen
                    ? 'justify-center p-2 w-12 h-12 min-h-12'
                    : 'px-5 h-10 w-full'
                )}
                onDragStart={(ev) => dragStart(block, ev.nativeEvent)}
                onDragEnd={() => dragStop(false)}
                title={isSmallScreen ? block.getLabel() : ''}
              >
                <Stack
                  className={cx(
                    'flex items-center justify-center flex-shrink-0 overflow-hidden rounded',
                    isSmallScreen ? 'h-8 w-8' : 'h-8 w-8'
                  )}
                  dangerouslySetInnerHTML={
                    block.getMedia()
                      ? { __html: block.getMedia()! }
                      : {
                          __html:
                            '<svg viewBox="0 0 24 24"><rect width="24" height="24" fill="gray"/></svg>'
                        }
                  }
                />
                {!isSmallScreen && (
                  <Stack
                    className={cx('text-sm ml-2 w-full truncate', MAIN_TXT_COLOR)}
                    title={block.getLabel()}
                  >
                    {block.getLabel()}
                  </Stack>
                )}
              </Stack>
            ))}
          </Stack>
        </React.Fragment>
      ))}

      <style jsx>{`
        .gjs-custom-block-manager {
          max-height: calc(100vh - 180px);
          overflow-y: auto;
          margin-bottom: 100px;
          position: relative;
          contain: layout;
        }
        .gjs-custom-block-manager::-webkit-scrollbar {
          display: none;
        }
        .gjs-custom-block-manager {
          scrollbar-width: none;
        }
      `}</style>
    </Box>
  );
}
