import React from 'react';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import { Property, PropertyRadio } from 'grapesjs';

import { TextAlignIcons } from './icons/PositionIcons';

interface PositionStyleFieldProps {
  prop: Property;
  onChange: (value: any) => void;
  value: string;
}

export const PositionStyleField: React.FC<PositionStyleFieldProps> = ({
  prop,
  onChange,
  value
}) => {
  const propId = prop.getId();
  const radioProp = prop as PropertyRadio;

  if (propId === 'text-align' || propId === 'align') {
    return (
      <ToggleButtonGroup
        value={value}
        exclusive
        onChange={(e, newVal) => newVal && onChange(newVal)}
        sx={{
          display: 'flex',
          gap: '8px',
          width: '100%',
          backgroundColor: 'transparent'
        }}
      >
        {radioProp.getOptions().map((option) => {
          const optId = radioProp.getOptionId(option);
          let icon = null;

          if (optId === 'left') icon = TextAlignIcons.left;
          if (optId === 'center') icon = TextAlignIcons.center;
          if (optId === 'right') icon = TextAlignIcons.right;

          return (
            <ToggleButton
              key={optId}
              value={optId}
              sx={{
                flex: 1,
                border: 'none',
                borderRadius: '6px !important',
                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                padding: '6px',
                height: '34px',
                '&.Mui-selected': {
                  backgroundColor: 'rgba(65, 112, 255, 1) !important',
                  color: 'white'
                },
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.2)'
                }
              }}
            >
              {icon || radioProp.getOptionLabel(option)}
            </ToggleButton>
          );
        })}
      </ToggleButtonGroup>
    );
  }

  return null;
};
