import React, { useState, useEffect, useLayoutEffect, useRef } from 'react';
import { Property, PropertyRadio } from 'grapesjs';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@mui/material/IconButton';
import Box from '@mui/material/Box';
import InputAdornment from '@mui/material/InputAdornment';
import Typography from '@mui/material/Typography';

import {
  AlignItemsIcons,
  JustifyContentIcons,
  JustifyItemsIcons
} from './icons/GridIcons';
import {
  availableUnits,
  groupSx,
  innerUnits,
  selectSx,
  textFieldSx,
  toggleBtnSx
} from './utils';
import { GridStyleFieldProps, GridTrackGroup, NewGroupState } from './types';

import {
  parseValueToGroups,
  groupsToCss,
  cycleValue,
  cycleCount
} from './helpers';

export const GridStyleField: React.FC<GridStyleFieldProps> = ({
  prop,
  onChange,
  value
}) => {
  const propId = prop.getId();
  const radioProp = prop as PropertyRadio;
  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (propId === 'grid-template-columns' || propId === 'grid-template-rows') {
      if (rootRef.current) {
        const parentProp = rootRef.current.closest(
          '.gjs-sm-property'
        ) as HTMLElement;
        if (parentProp) {
          parentProp.style.width = '100%';
          parentProp.style.flexBasis = '100%';
          parentProp.style.maxWidth = '100%';
        }
      }
    }
  }, [propId]);

  const [groups, setGroups] = useState<GridTrackGroup[]>(() =>
    parseValueToGroups(value)
  );

  const [newGroupState, setNewGroupState] = useState<NewGroupState>({
    value: '1',
    unit: 'fr',
    count: '1',
    min: '100',
    minUnit: 'px',
    max: '1',
    maxUnit: 'fr'
  });

  useEffect(() => {
    if (value && document.activeElement?.tagName !== 'INPUT') {
      const serializedCurrent = groupsToCss(groups);
      if (serializedCurrent !== value) {
        setGroups(parseValueToGroups(value));
      }
    }
  }, [value]);

  const handleGroupChange = (
    index: number,
    field: keyof GridTrackGroup,
    val: string
  ) => {
    const updatedGroups = [...groups];
    updatedGroups[index] = { ...updatedGroups[index], [field]: val };

    if (
      field === 'unit' &&
      (val === 'minmax' || val === 'auto-fit' || val === 'auto-fill')
    ) {
      if (!updatedGroups[index].min) {
        updatedGroups[index].min = '100';
        updatedGroups[index].minUnit = 'px';
        updatedGroups[index].max = '1';
        updatedGroups[index].maxUnit = 'fr';
      }
    }
    setGroups(updatedGroups);
    onChange(groupsToCss(updatedGroups));
  };

  const handleRemoveGroup = (index: number) => {
    const updatedGroups = groups.filter((_, i) => i !== index);
    setGroups(updatedGroups);
    onChange(groupsToCss(updatedGroups));
  };

  const handleAddGroup = () => {
    const newGroup: GridTrackGroup = {
      value: newGroupState.value,
      unit: newGroupState.unit,
      count: newGroupState.count,
      min: newGroupState.min,
      minUnit: newGroupState.minUnit,
      max: newGroupState.max,
      maxUnit: newGroupState.maxUnit,
      id: Date.now().toString()
    };
    const updatedGroups = [...groups, newGroup];
    setGroups(updatedGroups);
    onChange(groupsToCss(updatedGroups));
    setNewGroupState((prev) => ({ ...prev, value: '1', count: '1' }));
  };

  const updateNewGroup = (field: keyof NewGroupState, val: string) => {
    setNewGroupState((prev) => ({ ...prev, [field]: val }));
  };

  const handleNewCycle = (
    field: keyof NewGroupState,
    direction: 'up' | 'down'
  ) => {
    if (field === 'count') {
      updateNewGroup('count', cycleCount(newGroupState.count, direction));
    } else {
      updateNewGroup(field, cycleValue(newGroupState[field], direction));
    }
  };

  const handleGroupCycle = (
    index: number,
    field: keyof GridTrackGroup,
    direction: 'up' | 'down'
  ) => {
    const group = groups[index];
    if (field === 'count') {
      handleGroupChange(index, 'count', cycleCount(group.count, direction));
    } else {
      const currentVal = group[field as keyof GridTrackGroup] as string;
      handleGroupChange(index, field, cycleValue(currentVal, direction));
    }
  };

  const renderArrows = (onCycle: (dir: 'up' | 'down') => void) => (
    <Box sx={{ display: 'flex', flexDirection: 'column', ml: '4px' }}>
      <svg
        width='12'
        height='12'
        viewBox='0 0 12 12'
        fill='none'
        style={{ cursor: 'pointer' }}
        onClick={() => onCycle('up')}
      >
        <path
          d='M8.5 7L6 4.5L3.5 7'
          stroke='rgba(255, 255, 255, 0.5)'
          strokeWidth='2'
          strokeLinecap='round'
          strokeLinejoin='round'
        />
      </svg>
      <svg
        width='12'
        height='12'
        viewBox='0 0 12 12'
        fill='none'
        style={{ cursor: 'pointer' }}
        onClick={() => onCycle('down')}
      >
        <path
          d='M3.5 5L6 7.5L8.5 5'
          stroke='rgba(255, 255, 255, 0.5)'
          strokeWidth='2'
          strokeLinecap='round'
          strokeLinejoin='round'
        />
      </svg>
    </Box>
  );

  const renderUnitSelect = (
    currentUnit: string,
    onChangeUnit: (u: string) => void,
    isInner = false
  ) => (
    <Select
      value={currentUnit}
      onChange={(e) => onChangeUnit(e.target.value)}
      variant='outlined'
      disableUnderline
      sx={{
        ...selectSx,
        width:
          !isInner &&
          (currentUnit === 'calc' ||
            currentUnit === 'minmax' ||
            currentUnit === 'auto-fit' ||
            currentUnit === 'auto-fill')
            ? '55px'
            : '24px',
        minWidth:
          !isInner &&
          (currentUnit === 'calc' ||
            currentUnit === 'minmax' ||
            currentUnit === 'auto-fit' ||
            currentUnit === 'auto-fill')
            ? '55px'
            : '24px'
      }}
      MenuProps={{
        PaperProps: {
          sx: {
            backgroundColor: 'black',
            border: '1px solid #2D3748',
            borderRadius: '6px',
            '& .MuiMenuItem-root': {
              fontSize: '14px',
              color: 'white',
              fontFamily: 'Montserrat',
              '&:hover': { backgroundColor: 'rgba(42, 43, 107)' }
            }
          }
        }
      }}
    >
      {(isInner ? innerUnits : availableUnits).map((u) => (
        <MenuItem
          key={u}
          value={u}
        >
          {u}
        </MenuItem>
      ))}
    </Select>
  );

  const renderNewRow = () => {
    const isSpecial =
      newGroupState.unit === 'calc' ||
      newGroupState.unit === 'minmax' ||
      newGroupState.unit === 'auto-fit' ||
      newGroupState.unit === 'auto-fill';

    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
        {/* Верхняя строка */}
        <Box
          sx={{
            display: 'flex',
            gap: '8px',
            alignItems: 'center',
            position: 'relative',
            zIndex: 2
          }}
        >
          <TextField
            value={isSpecial ? '' : newGroupState.value}
            onChange={(e) => updateNewGroup('value', e.target.value)}
            placeholder={isSpecial ? '' : 'Val'}
            disabled={isSpecial}
            size='small'
            sx={{
              ...textFieldSx,
              flex: 'none',
              width: '133px',
              ...(isSpecial && {
                '& .MuiInputBase-root': {
                  justifyContent: 'center',
                  paddingRight: '0 !important'
                },
                '& input': { display: 'none' },
                '& .MuiInputAdornment-positionEnd': {
                  marginLeft: 0,
                  marginRight: 0
                }
              })
            }}
            InputProps={{
              endAdornment: (
                <InputAdornment
                  position='end'
                  sx={{ display: 'flex', alignItems: 'center' }}
                >
                  {renderUnitSelect(newGroupState.unit, (u) =>
                    updateNewGroup('unit', u)
                  )}
                  {!isSpecial &&
                    renderArrows((d) => handleNewCycle('value', d))}
                </InputAdornment>
              )
            }}
          />

          <TextField
            value={newGroupState.count}
            onChange={(e) => updateNewGroup('count', e.target.value)}
            placeholder='x'
            size='small'
            type='number'
            sx={{
              ...textFieldSx,
              flex: 'none',
              width: '133px',
              '& input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button':
                { '-webkit-appearance': 'none', margin: 0 },
              '& input[type=number]': { '-moz-appearance': 'textfield' }
            }}
            InputProps={{
              endAdornment: (
                <InputAdornment position='end'>
                  {renderArrows((d) => handleNewCycle('count', d))}
                </InputAdornment>
              )
            }}
          />

          <IconButton
            onClick={handleAddGroup}
            sx={{
              backgroundColor: '#4170ff',
              width: '36px',
              height: '34px',
              borderRadius: '6px',
              flexShrink: 0,
              '&:hover': { backgroundColor: '#365fd9' }
            }}
          >
            <svg
              width='14'
              height='14'
              viewBox='0 0 14 14'
              fill='none'
            >
              <path
                d='M7 0.75V13.25M13.25 7H0.75'
                stroke='white'
                strokeWidth='1.5'
                strokeLinecap='round'
                strokeLinejoin='round'
              />
            </svg>
          </IconButton>
        </Box>

        {newGroupState.unit === 'calc' && (
          <TextField
            value={newGroupState.value}
            onChange={(e) => updateNewGroup('value', e.target.value)}
            placeholder='e.g. 100% - 20px'
            size='small'
            fullWidth
            sx={{ ...textFieldSx, marginTop: '4px' }}
          />
        )}

        {(newGroupState.unit === 'auto-fit' ||
          newGroupState.unit === 'auto-fill') && (
          <TextField
            value={newGroupState.unit}
            disabled={true}
            size='small'
            fullWidth
            sx={{
              ...textFieldSx,
              marginTop: '4px',
              '& input': {
                textAlign: 'center',
                color: '#aaa',
                fontStyle: 'italic',
                cursor: 'default'
              }
            }}
          />
        )}

        {newGroupState.unit === 'minmax' && (
          <Box
            sx={{
              display: 'flex',
              gap: '8px',
              marginTop: '24px'
            }}
          >
            <Box sx={{ position: 'relative' }}>
              <Typography
                sx={{
                  fontSize: '12px',
                  color: '#aaa',
                  position: 'absolute',
                  top: '-20px',
                  left: '2px',
                  fontFamily: 'Montserrat, sans-serif'
                }}
              >
                Min
              </Typography>
              <TextField
                value={newGroupState.min}
                onChange={(e) => updateNewGroup('min', e.target.value)}
                size='small'
                sx={{ ...textFieldSx, width: '133px' }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position='end'>
                      {renderUnitSelect(
                        newGroupState.minUnit,
                        (u) => updateNewGroup('minUnit', u),
                        true
                      )}
                      {renderArrows((d) => handleNewCycle('min', d))}
                    </InputAdornment>
                  )
                }}
              />
            </Box>

            <Box sx={{ position: 'relative' }}>
              <Typography
                sx={{
                  fontSize: '12px',
                  color: '#aaa',
                  position: 'absolute',
                  top: '-20px',
                  left: '2px',
                  fontFamily: 'Montserrat, sans-serif'
                }}
              >
                Max
              </Typography>
              <TextField
                value={newGroupState.max}
                onChange={(e) => updateNewGroup('max', e.target.value)}
                size='small'
                sx={{ ...textFieldSx, width: '133px' }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position='end'>
                      {renderUnitSelect(
                        newGroupState.maxUnit,
                        (u) => updateNewGroup('maxUnit', u),
                        true
                      )}
                      {renderArrows((d) => handleNewCycle('max', d))}
                    </InputAdornment>
                  )
                }}
              />
            </Box>
          </Box>
        )}
      </Box>
    );
  };

  const renderExistingRow = (group: GridTrackGroup, index: number) => {
    const isSpecial =
      group.unit === 'calc' ||
      group.unit === 'minmax' ||
      group.unit === 'auto-fit' ||
      group.unit === 'auto-fill';

    return (
      <Box
        key={group.id}
        sx={{ display: 'flex', flexDirection: 'column', gap: '4px' }}
      >
        <Box sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <TextField
            value={isSpecial ? '' : group.value}
            onChange={(e) => handleGroupChange(index, 'value', e.target.value)}
            placeholder={isSpecial ? '' : 'Val'}
            disabled={isSpecial}
            size='small'
            sx={{
              ...textFieldSx,
              flex: 'none',
              width: '133px',
              ...(isSpecial && {
                '& .MuiInputBase-root': {
                  justifyContent: 'center',
                  paddingRight: '0 !important'
                },
                '& input': { display: 'none' },
                '& .MuiInputAdornment-positionEnd': {
                  marginLeft: 0,
                  marginRight: 0
                }
              })
            }}
            InputProps={{
              endAdornment: (
                <InputAdornment
                  position='end'
                  sx={{ display: 'flex', alignItems: 'center' }}
                >
                  {renderUnitSelect(group.unit, (u) =>
                    handleGroupChange(index, 'unit', u)
                  )}
                  {!isSpecial &&
                    renderArrows((d) => handleGroupCycle(index, 'value', d))}
                </InputAdornment>
              )
            }}
          />

          <TextField
            value={group.count}
            onChange={(e) => handleGroupChange(index, 'count', e.target.value)}
            placeholder='x'
            size='small'
            type='number'
            sx={{
              ...textFieldSx,
              flex: 'none',
              width: '133px',
              '& input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button':
                { '-webkit-appearance': 'none', margin: 0 },
              '& input[type=number]': { '-moz-appearance': 'textfield' }
            }}
            InputProps={{
              endAdornment: (
                <InputAdornment position='end'>
                  {renderArrows((d) => handleGroupCycle(index, 'count', d))}
                </InputAdornment>
              )
            }}
          />

          <IconButton
            onClick={() => handleRemoveGroup(index)}
            sx={{
              backgroundColor: '#3D3AB8',
              width: '36px',
              height: '34px',
              borderRadius: '6px',
              flexShrink: 0,
              '&:hover': { backgroundColor: '#302d91' }
            }}
          >
            <svg
              width='12'
              height='12'
              viewBox='0 0 12 12'
              fill='none'
            >
              <path
                fillRule='evenodd'
                clipRule='evenodd'
                d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                fill='white'
              />
            </svg>
          </IconButton>
        </Box>

        {group.unit === 'calc' && (
          <TextField
            value={group.value}
            onChange={(e) => handleGroupChange(index, 'value', e.target.value)}
            placeholder='e.g. 100% - 20px'
            size='small'
            fullWidth
            sx={{ ...textFieldSx, marginTop: '4px' }}
          />
        )}

        {(group.unit === 'auto-fit' || group.unit === 'auto-fill') && (
          <TextField
            value={group.unit}
            disabled={true}
            size='small'
            fullWidth
            sx={{
              ...textFieldSx,
              marginTop: '4px',
              '& input': {
                textAlign: 'center',
                color: '#aaa',
                fontStyle: 'italic',
                cursor: 'default'
              }
            }}
          />
        )}

        {(group.unit === 'minmax' ||
          group.unit === 'auto-fit' ||
          group.unit === 'auto-fill') && (
          <Box sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <Box sx={{ position: 'relative' }}>
              <TextField
                value={group.min}
                onChange={(e) =>
                  handleGroupChange(index, 'min', e.target.value)
                }
                size='small'
                sx={{ ...textFieldSx, width: '105px' }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position='end'>
                      {renderUnitSelect(
                        group.minUnit!,
                        (u) => handleGroupChange(index, 'minUnit', u),
                        true
                      )}
                      {renderArrows((d) => handleGroupCycle(index, 'min', d))}
                    </InputAdornment>
                  )
                }}
              />
            </Box>

            <Box sx={{ position: 'relative' }}>
              <TextField
                value={group.max}
                onChange={(e) =>
                  handleGroupChange(index, 'max', e.target.value)
                }
                size='small'
                sx={{ ...textFieldSx, width: '105px' }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position='end'>
                      {renderUnitSelect(
                        group.maxUnit!,
                        (u) => handleGroupChange(index, 'maxUnit', u),
                        true
                      )}
                      {renderArrows((d) => handleGroupCycle(index, 'max', d))}
                    </InputAdornment>
                  )
                }}
              />
            </Box>

            <Box sx={{ position: 'relative' }}>
              <TextField
                value={group.count}
                onChange={(e) =>
                  handleGroupChange(index, 'count', e.target.value)
                }
                size='small'
                sx={{
                  ...textFieldSx,
                  width: '50px',
                  '& .MuiOutlinedInput-input': {
                    padding: '0 0 0 8px !important',
                    textAlign: 'center'
                  },
                  '& input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button':
                    {
                      '-webkit-appearance': 'none',
                      margin: 0
                    }
                }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment
                      position='end'
                      sx={{ marginRight: '-4px', marginLeft: 0 }}
                    >
                      {renderArrows((d) => handleGroupCycle(index, 'count', d))}
                    </InputAdornment>
                  )
                }}
              />
            </Box>

            <IconButton
              onClick={() => handleRemoveGroup(index)}
              sx={{
                backgroundColor: '#3D3AB8',
                width: '36px',
                height: '34px',
                borderRadius: '6px',
                flexShrink: 0,
                '&:hover': { backgroundColor: '#302d91' }
              }}
            >
              <svg
                width='12'
                height='12'
                viewBox='0 0 12 12'
                fill='none'
              >
                <path
                  fillRule='evenodd'
                  clipRule='evenodd'
                  d='M11.7099 1.37603C11.7811 1.30485 11.8377 1.22034 11.8763 1.12731C11.9149 1.03428 11.9348 0.934556 11.9348 0.833836C11.9349 0.733115 11.9151 0.633369 11.8766 0.540291C11.8381 0.447214 11.7817 0.362628 11.7105 0.291364C11.6393 0.2201 11.5548 0.163554 11.4618 0.124952C11.3688 0.086351 11.269 0.0664513 11.1683 0.0663894C11.0676 0.0663275 10.9679 0.0861046 10.8748 0.124591C10.7817 0.163078 10.6971 0.219521 10.6259 0.290698L6.00052 4.91603L1.37652 0.290698C1.2326 0.146774 1.03739 0.065918 0.833853 0.065918C0.630313 0.065918 0.43511 0.146774 0.291186 0.290698C0.147262 0.434622 0.0664063 0.629825 0.0664062 0.833364C0.0664062 1.0369 0.147262 1.23211 0.291186 1.37603L4.91652 6.00003L0.291186 10.624C0.219922 10.6953 0.163392 10.7799 0.124825 10.873C0.0862567 10.9661 0.0664062 11.0659 0.0664062 11.1667C0.0664062 11.2675 0.0862567 11.3673 0.124825 11.4604C0.163392 11.5535 0.219922 11.6381 0.291186 11.7094C0.43511 11.8533 0.630313 11.9341 0.833853 11.9341C0.934635 11.9341 1.03443 11.9143 1.12754 11.8757C1.22065 11.8372 1.30526 11.7806 1.37652 11.7094L6.00052 7.08403L10.6259 11.7094C10.7698 11.8531 10.9649 11.9338 11.1683 11.9337C11.3717 11.9335 11.5668 11.8526 11.7105 11.7087C11.8543 11.5648 11.935 11.3696 11.9348 11.1662C11.9347 10.9628 11.8538 10.7678 11.7099 10.624L7.08452 6.00003L11.7099 1.37603Z'
                  fill='white'
                />
              </svg>
            </IconButton>
          </Box>
        )}
      </Box>
    );
  };

  if (propId === 'grid-template-columns' || propId === 'grid-template-rows') {
    return (
      <Box
        ref={rootRef}
        sx={{
          width: '100%',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px'
        }}
      >
        {renderNewRow()}
        {groups.map((group, index) => renderExistingRow(group, index))}
      </Box>
    );
  }

  if (propId === 'justify-items' || propId === 'justify-self') {
    return (
      <ToggleButtonGroup
        value={value}
        exclusive
        onChange={(e, newVal) => newVal && onChange(newVal)}
        sx={groupSx}
      >
        {radioProp.getOptions().map((option) => {
          const optId = radioProp.getOptionId(option);
          let icon = null;
          if (optId === 'start') icon = JustifyItemsIcons.start;
          if (optId === 'end') icon = JustifyItemsIcons.end;
          if (optId === 'stretch') icon = JustifyItemsIcons.stretch;
          if (optId === 'normal' || optId === 'auto')
            icon = JustifyItemsIcons.normal;
          if (optId === 'center') icon = JustifyItemsIcons.center;
          return (
            <ToggleButton
              key={optId}
              value={optId}
              sx={toggleBtnSx}
            >
              {icon || radioProp.getOptionLabel(option)}
            </ToggleButton>
          );
        })}
      </ToggleButtonGroup>
    );
  }

  if (propId === 'justify-content') {
    return (
      <ToggleButtonGroup
        value={value}
        exclusive
        onChange={(e, newVal) => newVal && onChange(newVal)}
        sx={groupSx}
      >
        {radioProp.getOptions().map((option) => {
          const optId = radioProp.getOptionId(option);
          let icon = null;
          if (optId === 'start') icon = JustifyContentIcons.start;
          if (optId === 'end') icon = JustifyContentIcons.end;
          if (optId === 'stretch') icon = JustifyContentIcons.stretch;
          if (optId === 'space-between')
            icon = JustifyContentIcons['space-between'];
          if (optId === 'space-around')
            icon = JustifyContentIcons['space-around'];
          if (optId === 'space-evenly')
            icon = JustifyContentIcons['space-evenly'];
          if (optId === 'center') icon = JustifyContentIcons.center;
          return (
            <ToggleButton
              key={optId}
              value={optId}
              sx={toggleBtnSx}
            >
              {icon || radioProp.getOptionLabel(option)}
            </ToggleButton>
          );
        })}
      </ToggleButtonGroup>
    );
  }

  if (propId === 'align-items' || propId === 'align-self') {
    return (
      <ToggleButtonGroup
        value={value}
        exclusive
        onChange={(e, newVal) => newVal && onChange(newVal)}
        sx={groupSx}
      >
        {radioProp.getOptions().map((option) => {
          const optId = radioProp.getOptionId(option);
          let icon = null;
          if (optId === 'start') icon = AlignItemsIcons.start;
          if (optId === 'end') icon = AlignItemsIcons.end;
          if (optId === 'stretch') icon = AlignItemsIcons.stretch;
          if (optId === 'baseline' || optId === 'auto')
            icon = AlignItemsIcons.baseline;
          if (optId === 'center') icon = AlignItemsIcons.center;
          return (
            <ToggleButton
              key={optId}
              value={optId}
              sx={toggleBtnSx}
            >
              {icon || radioProp.getOptionLabel(option)}
            </ToggleButton>
          );
        })}
      </ToggleButtonGroup>
    );
  }

  if (
    propId === 'grid-column-start' ||
    propId === 'grid-column-end' ||
    propId === 'grid-row-start' ||
    propId === 'grid-row-end'
  ) {
    return (
      <Box sx={{ width: '100%' }}>
        <TextField
          value={value || ''}
          onChange={(e) => onChange(e.target.value)}
          placeholder='auto'
          size='small'
          type='number'
          sx={{
            ...textFieldSx,
            width: '100%',
            '& input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button':
              { '-webkit-appearance': 'none', margin: 0 },
            '& input[type=number]': { '-moz-appearance': 'textfield' }
          }}
          InputProps={{
            endAdornment: (
              <InputAdornment position='end'>
                {renderArrows((d) => {
                  const current = parseInt(value) || 0;
                  const next = d === 'up' ? current + 1 : current - 1;
                  onChange(next.toString());
                })}
              </InputAdornment>
            )
          }}
        />
      </Box>
    );
  }
  return null;
};
