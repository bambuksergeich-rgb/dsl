import * as React from 'react';
import { useEditor } from '@grapesjs/react';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import FormControl from '@mui/material/FormControl';
import InputAdornment from '@mui/material/InputAdornment';
import TextField from '@mui/material/TextField';
import { Box } from '@mui/material';

import { ROUND_BORDER_COLOR, cx } from './common';
import { CustomSelect } from './Select';
import { StylePropertyFieldProps } from './types';

export default function TraitPropertyField({
  trait,
  ...rest
}: StylePropertyFieldProps) {
  const editor = useEditor();
  const handleChange = (value: string) => {
    trait.setValue(value);
  };

  const onChange = (ev: any) => {
    handleChange(ev.target.value);
  };

  const handleNumberCycle = (direction: 'up' | 'down') => {
    const step = 1;
    const currentValue = parseFloat(trait.getValue()) || 0;
    const min = trait.attributes.min ?? -Infinity;
    const max = trait.attributes.max ?? Infinity;
    let newValue =
      direction === 'up' ? currentValue + step : currentValue - step;
    newValue = Math.max(min, Math.min(max, newValue));
    handleChange(newValue.toString());
  };

  const handleButtonClick = () => {
    const command = trait.get('command');
    if (command) {
      typeof command === 'string'
        ? editor.runCommand(command)
        : command(editor, trait);
    }
  };

  const type = trait.getType();
  1;
  const defValue = trait.getDefault() || trait.attributes.placeholder;
  const value = trait.getValue();
  const valueWithDef = typeof value !== 'undefined' ? value : defValue;

  let inputToRender = (
    <TextField
      placeholder={defValue}
      value={value}
      onChange={onChange}
      size='small'
      fullWidth
    />
  );

  switch (type) {
    case 'number':
      {
        inputToRender = (
          <TextField
            type='number'
            value={value}
            onChange={onChange}
            size='small'
            fullWidth
            sx={{
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              '& .MuiOutlinedInput-root': {
                border: 'none',
                borderRadius: '6px',
                height: '34px',
                '& input': {
                  border: 'none',
                  padding: '0 14px',
                  height: '34px'
                },
                '& fieldset': {
                  border: 'none'
                },
                '&:hover fieldset': {
                  border: 'none'
                },
                '&.Mui-focused fieldset': {
                  border: 'none'
                }
              }
            }}
            InputProps={{
              endAdornment: (
                <InputAdornment
                  position='end'
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    textAlign: 'center'
                  }}
                >
                  <Box
                    sx={{ display: 'flex', flexDirection: 'column', ml: '4px' }}
                  >
                    <svg
                      width='12'
                      height='12'
                      viewBox='0 0 12 12'
                      fill='none'
                      xmlns='http://www.w3.org/2000/svg'
                      style={{ cursor: 'pointer' }}
                      onClick={() => handleNumberCycle('up')}
                    >
                      <path
                        d='M8.5 7L6 4.5L3.5 7'
                        stroke='rgba(255, 255, 255, 0.5)'
                        strokeWidth='2'
                        strokeLinecap='round'
                        strokeLinejoin='round'
                      />
                    </svg>
                    <svg
                      width='12'
                      height='12'
                      viewBox='0 0 12 12'
                      fill='none'
                      xmlns='http://www.w3.org/2000/svg'
                      style={{ cursor: 'pointer' }}
                      onClick={() => handleNumberCycle('down')}
                    >
                      <path
                        d='M3.5 5L6 7.5L8.5 5'
                        stroke='rgba(255, 255, 255, 0.5)'
                        strokeWidth='2'
                        strokeLinecap='round'
                        strokeLinejoin='round'
                      />
                    </svg>
                  </Box>
                </InputAdornment>
              )
            }}
          />
        );
      }
      break;
    case 'select':
      {
        inputToRender = (
          <FormControl
            fullWidth
            size='small'
          >
            <CustomSelect
              onChange={onChange}
              options={trait.getOptions().map((option: any) => ({
                value: option.value || option.id,
                label: option.name || option.name
              }))}
              activeOption={value ? { value, label: value } : undefined}
              maxWidth={'202px'}
            />
          </FormControl>
        );
      }
      break;
    case 'color':
      {
        inputToRender = (
          <TextField
            fullWidth
            placeholder={defValue}
            value={value}
            onChange={onChange}
            size='small'
            InputProps={{
              startAdornment: (
                <InputAdornment position='start'>
                  <div
                    className={`w-[15px] h-[15px] ${ROUND_BORDER_COLOR}`}
                    style={{ backgroundColor: valueWithDef }}
                  >
                    <input
                      type='color'
                      className='w-[15px] h-[15px] cursor-pointer opacity-0'
                      value={valueWithDef}
                      onChange={(ev) => handleChange(ev.target.value)}
                    />
                  </div>
                </InputAdornment>
              )
            }}
          />
        );
      }
      break;
    case 'checkbox':
      {
        inputToRender = (
          <Checkbox
            checked={value}
            onChange={(ev) => trait.setValue(ev.target.checked)}
            size='small'
          />
        );
      }
      break;
    case 'button':
      {
        inputToRender = (
          <Button
            fullWidth
            onClick={handleButtonClick}
          >
            {trait.getLabel()}
          </Button>
        );
      }
      break;
  }

  return (
    <div
      {...rest}
      className={cx('mb-3 px-1 w-full')}
    >
      <div className={cx('flex mb-2 items-center')}>
        <div className='flex-grow capitalize'>{trait.getLabel()}</div>
      </div>
      {inputToRender}
    </div>
  );
}
