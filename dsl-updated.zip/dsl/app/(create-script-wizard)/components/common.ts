export const MAIN_BG_COLOR = 'bg-[#22272E]';

export const MAIN_TXT_COLOR = 'text-white';

export const BTN_CLS = 'border rounded px-2.5 py-1.5 w-full';

export const MAIN_BORDER_COLOR = 'border-slate-500';

export const ROUND_BORDER_COLOR = `rounded border ${MAIN_BORDER_COLOR}`;

export function cx(...inputs: any[]): string {
  const inp = Array.isArray(inputs[0]) ? inputs[0] : [...inputs];
  return inp.filter(Boolean).join(' ');
}
