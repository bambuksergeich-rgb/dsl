import React, { useState, useEffect } from 'react';
import { SelectorsResultProps } from '@grapesjs/react';
import type { Selector } from 'grapesjs';
import { mdiClose } from '@mdi/js';
import Icon from '@mdi/react';

import { Typography, TextField, TypographyProps } from '@mui/material';
import { CustomSelect } from './Select';
import { OptionsOpenIcon } from './icons/OptionsOpenIcon';
import { SELECT_OPTIONS } from './utils';

import { cx } from './common';

const TypographyMontserrat500 = ({ children, ...props }: TypographyProps) => (
  <Typography
    {...props}
    sx={{
      fontFamily: 'Montserrat, sans-serif',
      fontWeight: 500,
      ...props.sx
    }}
  >
    {children}
  </Typography>
);

interface CustomSelectorManagerProps extends Omit<
  SelectorsResultProps,
  'Container'
> {
  viewMode?: string; // 1. Добавляем проп
  onViewModeChange?: (mode: string) => void;
}

export default function CustomSelectorManager({
  selectors,
  selectedState,
  states,
  targets,
  setState,
  addSelector,
  removeSelector,
  viewMode, // 2. Принимаем проп
  onViewModeChange
}: CustomSelectorManagerProps) {
  const [editingSelector, setEditingSelector] = useState<Selector | null>(null);
  const [editValue, setEditValue] = useState('');

  // Инициализируем локальный стейт значением из пропса (если есть) или пустой строкой
  const [localViewMode, setLocalViewMode] = useState(viewMode || '');

  // 3. Синхронизируем локальный стейт с внешним пропом viewMode при его изменении
  useEffect(() => {
    if (viewMode !== undefined) {
      setLocalViewMode(viewMode);
    }
  }, [viewMode]);

  const addNewSelector = () => {
    const next = selectors.length + 1;
    addSelector({ name: `Class_name${next}`, label: `Class_name` });
  };

  const startEditing = (selector: Selector) => {
    setEditingSelector(selector);
    setEditValue(selector.getLabel());
  };

  const saveEdit = (selector: Selector) => {
    if (editValue.trim() && editValue !== selector.getLabel()) {
      selector.set('name', editValue.trim());
      selector.set('label', editValue.trim());
    }
    setEditingSelector(null);
    setEditValue('');
  };

  const cancelEdit = () => {
    setEditingSelector(null);
    setEditValue('');
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLElement>, selector: Selector) => {
    if (e.key === 'Enter') {
      saveEdit(selector);
    } else if (e.key === 'Escape') {
      cancelEdit();
    }
  };

  const targetStr = targets.join(', ');

  // 4. Логика определения currentLabel для селектора
  let currentLabel = 'Basic';

  // Приоритет:
  // 1. localViewMode (если это UI режим типа Basic, Flex, Grid)
  // 2. selectedState (если это GrapesJS State типа Hover, Click)

  // Проверяем, является ли текущий режим одним из UI-режимов
  const uiModeOption = SELECT_OPTIONS.find(
    (opt) => opt.value === localViewMode
  );

  if (uiModeOption) {
    currentLabel = uiModeOption.label;
  } else if (selectedState) {
    // Если UI режим не выбран (или сброшен), показываем состояние GrapesJS
    const gjsState = states.find((s) => s.id === selectedState);
    if (gjsState) {
      currentLabel = gjsState.getName();
    } else {
      currentLabel = selectedState;
    }
  } else if (localViewMode) {
    // Фолбек для кастомных строк, если они есть
    currentLabel = localViewMode;
  }

  return (
    <div
      className='gjs-custom-selector-manager flex flex-col gap-2 text-left bg-[rgba(16,22,28,0.5)]'
      style={{ padding: '0 16px' }}
    >
      <div className='flex items-center'>
        <div className='flex gap-[28px] items-center'>
          <TypographyMontserrat500
            sx={{ fontSize: '16px', fontFamily: 'Montserrat, sans-serif' }}
          >
            Selectors
          </TypographyMontserrat500>
          <CustomSelect
            maxWidth='202px'
            options={SELECT_OPTIONS}
            // 5. Передаем вычисленный label и актуальное значение value
            activeOption={{
              value: localViewMode || selectedState || '',
              label: currentLabel
            }}
            onChange={(option) => {
              const val = option.value;
              const isUiMode = ['Basic', 'Flex', 'Grid', 'Position'].includes(
                val
              );

              if (isUiMode) {
                setLocalViewMode(val);
                if (onViewModeChange) onViewModeChange(val);
                // Если переключаемся на UI режим, сбрасываем состояние GrapesJS (например Hover)
                if (selectedState) setState('');
              } else {
                // Если выбрали State (Hover, Click), сбрасываем UI режим в Basic (визуально) или пустую строку
                // Но сохраняем Basic для отображения контента
                setLocalViewMode('');
                setState(val);
                // Обычно при переключении на Hover мы хотим видеть базовые стили + изменения
                if (onViewModeChange) onViewModeChange('Basic');
              }
            }}
            placeholder='Basic'
            size='sm'
            color='secondary'
            truncateLength={20}
            className='hover:bg-[rgba(255,255,255,0.1)] active:bg-[rgba(255,255,255,0.1)]'
            mainStyles={{
              height: '34px',
              width: '205px !important',
              borderRadius: '6px',
              border: 'none',
              color: '#fff',
              fontWeight: 500,
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center'
            }}
            icon={<OptionsOpenIcon />}
          />
        </div>
      </div>
      <div
        className={cx(
          'flex items-center gap-[16px] flex-wrap p-2 bg-black/30 rounded min-h-[45px]'
        )}
      >
        {targetStr && (
          <button
            type='button'
            onClick={addNewSelector}
            className={cx('rounded px-2 py-1')}
            style={{
              width: '36px',
              height: '36px',
              background: 'rgba(65, 112, 255, 1)',
              border: 'none',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center'
            }}
          >
            <svg
              width='15'
              height='14'
              viewBox='0 0 15 14'
              fill='none'
              xmlns='http://www.w3.org/2000/svg'
              style={{
                display: 'block'
              }}
            >
              <path
                d='M7.25 0.75V13.25M13.5 7H1'
                stroke='white'
                strokeWidth='1.5'
                strokeLinecap='round'
                strokeLinejoin='round'
              />
            </svg>
          </button>
        )}
        {selectors.map((selector) => (
          <div
            key={selector.toString()}
            className='max-w-[300px] h-[34px] px-[12px] py-[7px] flex items-center gap-[2px] whitespace-nowrap bg-[rgba(16,22,28,0.5)] rounded border border-[rgba(255,255,255,0.15)]'
          >
            {editingSelector === selector ? (
              <TextField
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                onKeyDown={(e) => handleKeyPress(e, selector)}
                onBlur={() => saveEdit(selector)}
                autoFocus
                size='small'
                variant='outlined'
                sx={{
                  maxWidth: '300px',
                  '& .MuiInputBase-input': {
                    padding: '4px 8px',
                    color: '#fff',
                    fontSize: '14px',
                    fontFamily: 'Montserrat, sans-serif'
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'rgba(255,255,255,0.15)'
                  }
                }}
              />
            ) : (
              <>
                <div
                  onDoubleClick={() => startEditing(selector)}
                  style={{
                    cursor: 'pointer',
                    textOverflow: 'ellipsis',
                    overflow: 'hidden',
                    whiteSpace: 'nowrap',
                    maxWidth: '260px'
                  }}
                >
                  {selector.getLabel()}
                </div>
                <button
                  type='button'
                  onClick={() => removeSelector(selector)}
                  style={{ border: 'none' }}
                >
                  <Icon
                    size={0.7}
                    path={mdiClose}
                  />
                </button>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
