import React from 'react';

export const JustifySelfIcons = {
  start: (
    <svg
      width='14'
      height='20'
      viewBox='0 0 14 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M0 20V0H2V20H0ZM11 15V5H14V15H11ZM5 15V5H8V15H5Z'
        fill='white'
      />
    </svg>
  ),
  end: (
    <svg
      width='14'
      height='20'
      viewBox='0 0 14 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M12 20V0H14V20H12ZM6 15V5H9V15H6ZM0 15V5H3V15H0Z'
        fill='white'
      />
    </svg>
  ),
  stretch: (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M18 20V15H15V5H18V0H20V20H18ZM0 20V0H2V5H5V15H2V20H0Z'
        fill='white'
      />
    </svg>
  ),
  // Название опциональное, зависит от значения в конфиге (например, auto или baseline)
  icon4: (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M18 20V0H20V20H18ZM0 20V0H2V20H0ZM13 15V5H16V15H13ZM4 15V5H7V15H4Z'
        fill='white'
      />
    </svg>
  ),
  center: (
    <svg
      width='24'
      height='24'
      viewBox='0 0 24 24'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M20 22V2H22V22H20ZM2 22V2H4V22H2ZM13 17V12V7H16V17H13ZM8 17V12V7H11V12V17H8Z'
        fill='white'
      />
    </svg>
  )
};

export const JustifyItemsIcons = {
  start: (
    <svg
      width='14'
      height='20'
      viewBox='0 0 14 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M0 20V0H2V20H0ZM11 15V5H14V15H11ZM5 15V5H8V15H5Z'
        fill='white'
      />
    </svg>
  ),
  end: (
    <svg
      width='14'
      height='20'
      viewBox='0 0 14 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M12 20V0H14V20H12ZM6 15V5H9V15H6ZM0 15V5H3V15H0Z'
        fill='white'
      />
    </svg>
  ),
  stretch: (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M18 20V15H15V5H18V0H20V20H18ZM0 20V0H2V5H18V15H2V20H0Z'
        fill='white'
      />
    </svg>
  ),
  normal: (
    <svg
      width='14'
      height='14'
      viewBox='0 0 14 14'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M1 4.2002V9.8002C1 10.9203 1 11.4801 1.21799 11.9079C1.40973 12.2842 1.71547 12.5905 2.0918 12.7822C2.5192 13 3.07899 13 4.19691 13H9.80309C10.921 13 11.48 13 11.9074 12.7822C12.2837 12.5905 12.5905 12.2842 12.7822 11.9079C13 11.4805 13 10.9215 13 9.80358V4.19691C13 3.07899 13 2.5192 12.7822 2.0918C12.5905 1.71547 12.2837 1.40973 11.9074 1.21799C11.4796 1 10.9203 1 9.8002 1H4.2002C3.08009 1 2.51962 1 2.0918 1.21799C1.71547 1.40973 1.40973 1.71547 1.21799 2.0918C1 2.51962 1 3.08009 1 4.2002Z'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
    </svg>
  ),
  center: (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M18 20V0H20V20H18ZM0 20V0H2V20H0ZM13 15V5H16V15H13ZM4 15V5H16V15H4Z'
        fill='white'
      />
    </svg>
  )
};

export const JustifyContentIcons = {
  start: (
    <svg
      width='14'
      height='20'
      viewBox='0 0 14 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M0 20V0H2V20H0ZM11 15V5H14V15H11ZM5 15V5H8V15H5Z'
        fill='white'
      />
    </svg>
  ),
  end: (
    <svg
      width='14'
      height='20'
      viewBox='0 0 14 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M12 20V0H14V20H12ZM6 15V5H9V15H6ZM0 15V5H3V15H0Z'
        fill='white'
      />
    </svg>
  ),
  stretch: (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M18 20V15H15V5H18V0H20V20H18ZM0 20V0H2V5H18V15H2V20H0Z'
        fill='white'
      />
    </svg>
  ),
  'space-between': (
    <svg
      width='43'
      height='24'
      viewBox='0 0 43 24'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M12 19V5'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M31 19V5'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M26.6668 12H17.3335'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M12 19V5'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M31 19V5'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M26.6668 12H17.3335'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
    </svg>
  ),
  'space-around': (
    <svg
      width='46'
      height='24'
      viewBox='0 0 46 24'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M12 19V5'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M34 19V5'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M23 8C20.7909 8 19 9.79086 19 12C19 14.2091 20.7909 16 23 16C25.2091 16 27 14.2091 27 12C27 9.79086 25.2091 8 23 8Z'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M23 8C20.7909 8 19 9.79086 19 12C19 14.2091 20.7909 16 23 16C25.2091 16 27 14.2091 27 12C27 9.79086 25.2091 8 23 8Z'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
    </svg>
  ),
  'space-evenly': (
    <svg
      width='24'
      height='16'
      viewBox='0 0 24 16'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M13.726 13.0199L17.0199 9.72596C17.4489 9.29694 17.6634 9.08226 17.7437 8.8349C17.8144 8.61732 17.8144 8.38339 17.7437 8.16581C17.6634 7.91846 17.4489 7.70349 17.0199 7.27447L13.7252 3.9798C13.2967 3.55127 13.0824 3.33696 12.8352 3.25664C12.6176 3.18594 12.3831 3.18594 12.1656 3.25664C11.9183 3.33697 11.7034 3.55187 11.2747 3.98053L7.9808 7.27447L7.98054 7.27496C7.55169 7.70381 7.33699 7.91851 7.25664 8.16581C7.18594 8.38339 7.18594 8.61732 7.25664 8.8349C7.33696 9.08212 7.55154 9.2967 7.98007 9.72523L11.2768 13.0219C11.7044 13.4496 11.9186 13.6637 12.1656 13.744C12.3831 13.8147 12.6176 13.8147 12.8352 13.744C13.0824 13.6636 13.2968 13.4493 13.7255 13.0206L13.726 13.0199Z'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M1 15V1'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        d='M23 15V1'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
    </svg>
  ),
  center: (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M18 20V0H20V20H18ZM0 20V0H2V20H0ZM13 15V5H16V15H13ZM4 15V5H16V15H4Z'
        fill='white'
      />
    </svg>
  )
};

export const AlignItemsIcons = {
  start: (
    <svg
      width='20'
      height='19'
      viewBox='0 0 20 19'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M0 0L20 0V2L0 2V0Z'
        fill='white'
      />
      <path
        d='M0 17L20 17V19L0 19V17Z'
        fill='white'
      />
      <path
        d='M9 2L9 7V12H6L6 7V2H9ZM13 2L13 7V12H10V7L10 2H13Z'
        fill='white'
      />
    </svg>
  ),
  end: (
    <svg
      width='20'
      height='19'
      viewBox='0 0 20 19'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M20 19H0L0 17H20V19Z'
        fill='white'
      />
      <path
        d='M20 2L0 2L0 0L20 0V2Z'
        fill='white'
      />
      <path
        d='M11 17V12V7H14V12V17H11ZM7 17V12V7H10V12V17H7Z'
        fill='white'
      />
    </svg>
  ),
  stretch: (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M20 2H15V5L5 5V2H0L0 0H20V2ZM20 20H0L0 18H5L5 2H15L15 18H20V20Z'
        fill='white'
      />
    </svg>
  ),
  baseline: (
    <svg
      width='20'
      height='16'
      viewBox='0 0 20 16'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M1 7V11.8002C1 12.9203 1 13.4801 1.21799 13.9079C1.40973 14.2842 1.71547 14.5905 2.0918 14.7822C2.5192 15 3.07899 15 4.19691 15H15.8031C16.921 15 17.48 15 17.9074 14.7822C18.2837 14.5905 18.5905 14.2842 18.7822 13.9079C19 13.4805 19 12.9215 19 11.8036V7M1 7V5M1 7H19M1 5V4.2002C1 3.08009 1 2.51962 1.21799 2.0918C1.40973 1.71547 1.71547 1.40973 2.0918 1.21799C2.51962 1 3.08009 1 4.2002 1H15.8002C16.9203 1 17.4796 1 17.9074 1.21799C18.2837 1.40973 18.5905 1.71547 18.7822 2.0918C19 2.5192 19 3.07899 19 4.19691V5M1 5H19M5 11H9M19 7V5'
        stroke='white'
        stroke-width='2'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
    </svg>
  ),
  center: (
    <svg
      width='24'
      height='24'
      viewBox='0 0 24 24'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M2 3L22 3V5L2 5V3Z'
        fill='white'
      />
      <path
        d='M2 20L22 20V22L2 22V20Z'
        fill='white'
      />
      <path
        d='M12 7L12 12.5V18H9V12.5L9 7H12ZM16 7V12.5V18H13V12.5L13 7H16Z'
        fill='white'
      />
    </svg>
  )
};
