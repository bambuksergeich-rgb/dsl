export const AccordionIcon = (
  <svg
    width='12'
    height='7'
    viewBox='0 0 12 7'
    fill='none'
    xmlns='http://www.w3.org/2000/svg'
    style={{ transition: 'transform 0.3s ease' }}
  >
    <path
      d='M1 1L6 6L11 1'
      stroke='#4170FF'
      strokeWidth='2'
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);
