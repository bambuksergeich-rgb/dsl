import React from 'react';

export const FlexOrderTypeIcons = {
  type1: (
    <svg
      width='22'
      height='15'
      viewBox='0 0 22 15'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M13.0052 13.5002L7.34656 10.4632L2.58443 7.90733C2.0272 7.60826 2.0272 6.72546 2.58443 6.4264L7.34656 3.87056L13.0052 0.833496'
        stroke='white'
        strokeWidth='1.66667'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M20.8333 13.5002L15.1483 10.4631L10.364 7.9073C9.80413 7.60823 9.80413 6.72543 10.364 6.42636L15.1483 3.87053L20.8333 0.833496'
        stroke='white'
        strokeWidth='1.66667'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M0.833252 13.5002V0.833496'
        stroke='white'
        strokeWidth='1.66667'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  ),
  type2: (
    <svg
      width='12'
      height='18'
      viewBox='0 0 12 18'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M3.52002 9L10.27 2.5'
        stroke='white'
        strokeWidth='2'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M3.52002 9L10.27 15.5'
        stroke='white'
        strokeWidth='2'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M1 1V17'
        stroke='white'
        strokeWidth='2'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  )
};

export const FlexGrowShrinkIcons = {
  shrink: (
    <svg
      width='22'
      height='22'
      viewBox='0 0 22 22'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M13.5 8.5L21 1M21 1H15.375M21 1V6.625M1 1L8.5 8.5M1 1V6.625M1 1H6.625M13.5 13.5L21 21M21 21V15.375M21 21H15.375M8.5 13.5L1 21M1 21H6.625M1 21V15.375'
        stroke='white'
        strokeWidth='2'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  ),
  grow: (
    <svg
      width='22'
      height='22'
      viewBox='0 0 22 22'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M6 2.33782C7.47087 1.48697 9.1786 1 11 1C16.5228 1 21 5.47715 21 11C21 16.5228 16.5228 21 11 21C5.47715 21 1 16.5228 1 11C1 9.1786 1.48697 7.47087 2.33782 6'
        stroke='white'
        strokeWidth='2'
        strokeLinecap='round'
      />
    </svg>
  ),
  basis: (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M13.6531 12.7635H16.0106C16.3631 12.7635 16.6384 12.4778 16.6384 12.1253C16.6384 11.7832 16.3573 11.4872 16.0106 11.4872H12.1466C11.9724 11.4872 11.8171 11.557 11.7045 11.6701C11.5914 11.7875 11.5189 11.9424 11.5189 12.1132V15.9666C11.5189 16.3181 11.8054 16.5926 12.1588 16.5926C12.5019 16.5926 12.7988 16.3123 12.7988 15.9666V13.7165L18.9162 19.8171C19.1664 20.0667 19.5629 20.0579 19.8128 19.8087C20.0554 19.5668 20.0664 19.1592 19.8212 18.9146L13.6531 12.7635ZM6.34688 12.7635H3.98937C3.63686 12.7635 3.36162 12.4778 3.36162 12.1253C3.36162 11.7832 3.64267 11.4872 3.98937 11.4872H7.85337C8.0276 11.4872 8.18294 11.557 8.29552 11.6701C8.40864 11.7875 8.48112 11.9424 8.48112 12.1132V15.9666C8.48112 16.3181 8.19461 16.5926 7.84118 16.5926C7.49809 16.5926 7.20125 16.3123 7.20125 15.9666V13.7165L1.08379 19.8171C0.833567 20.0667 0.437145 20.0579 0.187234 19.8087C-0.0553679 19.5668 -0.0664475 19.1592 0.178797 18.9146L6.34688 12.7635ZM13.6531 7.23647H16.0106C16.3631 7.23647 16.6384 7.52219 16.6384 7.87464C16.6384 8.21679 16.3573 8.51282 16.0106 8.51282H12.1466C11.9724 8.51282 11.8171 8.44302 11.7045 8.32987C11.5914 8.21248 11.5189 8.05763 11.5189 7.8868V4.03343C11.5189 3.6819 11.8054 3.40741 12.1588 3.40741C12.5019 3.40741 12.7988 3.68769 12.7988 4.03343V6.28349L18.9162 0.182872C19.1664 -0.0666599 19.5629 -0.0579181 19.8128 0.191305C20.0554 0.43324 20.0664 0.840823 19.8212 1.08539L13.6531 7.23647ZM6.34688 7.23647H3.98937C3.63686 7.23647 3.36162 7.52219 3.36162 7.87464C3.36162 8.21679 3.64267 8.51282 3.98937 8.51282H7.85337C8.0276 8.51282 8.18294 8.44302 8.29552 8.32987C8.40864 8.21248 8.48112 8.05763 8.48112 7.8868V4.03343C8.48112 3.6819 8.19461 3.40741 7.84118 3.40741C7.49809 3.40741 7.20125 3.68769 7.20125 4.03343V6.28349L1.08379 0.182872C0.833567 -0.0666599 0.437145 -0.0579181 0.187234 0.191305C-0.0553679 0.43324 -0.0664475 0.840823 0.178797 1.08539L6.34688 7.23647Z'
        fill='white'
      />
    </svg>
  )
};

export const AlignSelfIcons = {
  end: (
    <svg
      width='20'
      height='19'
      viewBox='0 0 20 19'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M20 19H0L0 17H20V19Z'
        fill='white'
      />
      <path
        d='M20 2L0 2L0 0L20 0V2Z'
        fill='white'
      />
      <path
        d='M11 17V12V7H14V12V17H11ZM7 17V12V7H10V12V17H7Z'
        fill='white'
      />
    </svg>
  ),
  start: (
    <svg
      width='20'
      height='19'
      viewBox='0 0 20 19'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M0 0L20 0V2L0 2V0Z'
        fill='white'
      />
      <path
        d='M0 17L20 17V19L0 19V17Z'
        fill='white'
      />
      <path
        d='M9 2L9 7V12H6L6 7V2H9ZM13 2L13 7V12H10V7L10 2H13Z'
        fill='white'
      />
    </svg>
  ),
  center: (
    <svg
      width='20'
      height='19'
      viewBox='0 0 20 19'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M0 0L20 0V2L0 2V0Z'
        fill='white'
      />
      <path
        d='M0 17L20 17V19L0 19V17Z'
        fill='white'
      />
      <path
        d='M10 4L10 9.5V15H7L7 9.5L7 4H10ZM14 4L14 9.5V15H11V9.5L11 4H14Z'
        fill='white'
      />
    </svg>
  ),
  stretch: (
    <svg
      width='24'
      height='24'
      viewBox='0 0 24 24'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M2 3L22 3V5L2 5V3Z'
        fill='white'
      />
      <path
        d='M2 20L22 20V22L2 22V20Z'
        fill='white'
      />
      <path
        d='M12 5L12 12.5V20H9V12.5L9 5H12ZM16 5L16 12.5V20H13V12.5L13 5H16Z'
        fill='white'
      />
    </svg>
  )
};
