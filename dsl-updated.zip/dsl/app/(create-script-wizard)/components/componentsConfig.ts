export const selectStyles = `
  .active-option {
    padding: 8px 16px !important;
    margin: 0 !important;
    text-indent: 0 !important;
    text-align: left !important;
    transform: none !important;
    transition: background-color 0.2s, color 0.2s;
    box-sizing: border-box;
    width: 100%;
  }
  .active-option:hover {
    background-color: rgba(42,43,107) !important;
    color: white !important;
    padding: 8px 16px !important;
    margin: 0 !important;
    text-indent: 0 !important;
    text-align: left !important;
    transform: none !important;
  }
  .select-icon {
    transition: transform 0.2s ease;
  }
  .select-icon.open {
    transform: rotate(180deg);
  }
`;

export const topBarButtonsStyles = `
          .topbar-button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 44px;
            height: 44px;
            border-radius: 4px;
            background-color: rgba(255, 255, 255, 0.1);
            border: none;
            transition: background-color 0.2s;
            cursor: pointer;
            color: white;
          }
          .topbar-button:hover {
            background-color: rgba(255, 255, 255, 0.2);
          }
          .topbar-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
          }
          .topbar-button.active {
            color: rgb(125, 211, 252);
          }
          .topbar-button.frame {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
          }
          .topbar-button.frame-active {
            background-color: rgba(42, 43, 107, 1);
            border: 1px solid #4170FF !important;
          }
          .topbar-button.offsets {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
          }
          .topbar-button.offsets-active {
            background-color: rgba(42, 43, 107, 1);
            border: 1px solid #4170FF !important;
          }
          .topbar-button.fullscreen-active {
            background-color: rgba(42, 43, 107, 1);
          }
          .topbar-button.preview-active {
            background-color: rgba(125, 211, 252, 0.2);
          }
        `;

export const modalDefaultStyles = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 900,
  border: '2px solid #000',
  boxShadow: 24,
  overflow: 'hidden',
  display: 'flex',
  flexDirection: 'column',
  maxHeight: '90vh',
  p: 2
};
