'use client';

import { Input } from '@mui/material';
import { Box } from '@mui/system';
import React from 'react';

import { ColorElementProps } from './types';

const ColorElement: React.FC<ColorElementProps> = ({
  value,
  onChange,
  mini = false
}) => {
  return (
    <Box
      className='color-picker'
      style={{
        position: 'relative',
        minWidth: mini ? '34px' : '150px',
        width: mini ? '34px' : '150px',
        height: '34px',
        padding: 0
      }}
    >
      <Input
        type='color'
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{
          position: 'absolute',
          width: mini ? '34px' : '150px',
          height: '34px',
          opacity: 0,
          cursor: 'pointer',
          zIndex: 2
        }}
      />
      <Box
        style={{
          width: '100%',
          height: '100%',
          borderRadius: '4px',
          border: `1px solid ${value}`,
          backgroundColor: '#333',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          zIndex: 1
        }}
      >
        <svg
          width='20'
          height='20'
          viewBox='0 0 20 20'
          fill='none'
          xmlns='http://www.w3.org/2000/svg'
        >
          <path
            d='M8.08922 2.68493L2.19672 8.57743C1.88427 8.88997 1.70874 9.31382 1.70874 9.75576C1.70874 10.1977 1.88427 10.6215 2.19672 10.9341L6.91005 15.6483C7.06484 15.8032 7.24865 15.9262 7.45098 16.01C7.65331 16.0939 7.87019 16.1371 8.08922 16.1371C8.30824 16.1371 8.52512 16.0939 8.72745 16.01C8.92978 15.9262 9.1136 15.8032 9.26838 15.6483L15.1601 9.75576L8.08922 2.68493ZM8.08922 2.68493L6.91088 1.50659'
            stroke={value}
            strokeWidth='1.5'
            strokeLinecap='round'
            strokeLinejoin='round'
          />
          <path
            d='M16.6667 12.5C16.6667 12.5 19.1667 14.9942 19.1667 16.5725C19.1667 17.9517 18.0459 19.0725 16.6667 19.0725C15.2867 19.0725 14.1767 17.9517 14.1667 16.5725C14.1751 14.9933 16.6667 12.5 16.6667 12.5Z'
            stroke={value}
            strokeWidth='1.5'
            strokeMiterlimit='1.5'
            strokeLinecap='round'
            strokeLinejoin='round'
          />
        </svg>
      </Box>
    </Box>
  );
};

export default ColorElement;
