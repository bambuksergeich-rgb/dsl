// helpers/index.ts
import { GridTrackGroup } from '../types';

export const truncateText = (text: string, maxLength: number): string => {
  if (!text) return '';
  return text.length > maxLength ? `${text.slice(0, maxLength)}...` : text;
};

export const splitSafe = (str: string): string[] => {
  const result: string[] = [];
  let current = '';
  let depth = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    if (char === '(') depth++;
    if (char === ')') depth--;
    if (char === ' ' && depth === 0) {
      if (current) result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  if (current) result.push(current);
  return result;
};

export const parseUnitValue = (val: string) => {
  // Добавляем поддержку ключевых слов как юнитов
  if (val === 'auto-fit' || val === 'auto-fill') {
    return { val: '', unit: val };
  }

  const match = val.match(/^(-?\d*\.?\d*)(\D+)?$/);
  const v = match?.[1] === '' || !match?.[1] ? '' : match[1];
  const u = match?.[2] || val;
  if (
    !match?.[1] &&
    (u === 'auto' || u === 'min-content' || u === 'max-content')
  ) {
    return { val: '', unit: u };
  }
  return { val: v, unit: u || 'fr' };
};

export const parseValueToGroups = (cssValue: string): GridTrackGroup[] => {
  if (!cssValue)
    return [{ value: '1', unit: 'fr', count: '1', id: Date.now().toString() }];

  const items = splitSafe(cssValue);
  const groups: GridTrackGroup[] = [];

  let currentVal = '';
  let currentUnit = '';
  let currentMin = '';
  let currentMinUnit = 'px';
  let currentMax = '';
  let currentMaxUnit = 'fr';
  let currentCount = 0;

  const processItem = (item: string) => {
    // Обработка repeat(auto-fit/fill, ...)
    if (item.startsWith('repeat(')) {
      const match = item.match(
        /^repeat\(\s*(auto-fit|auto-fill)\s*,\s*(.+)\)$/
      );
      if (match) {
        const type = match[1]; // auto-fit или auto-fill
        const content = match[2]; // например, minmax(100px, 1fr)

        // Парсим внутренности (обычно это minmax)
        if (content.startsWith('minmax(') && content.endsWith(')')) {
          const innerContent = content.slice(7, -1);
          const parts = innerContent.split(',').map((s) => s.trim());
          const minPart = parts[0] || '100px';
          const maxPart = parts[1] || '1fr';
          const pMin = parseUnitValue(minPart);
          const pMax = parseUnitValue(maxPart);

          return {
            val: '',
            unit: type, // 'auto-fit' или 'auto-fill'
            min: pMin.val,
            minUnit: pMin.unit,
            max: pMax.val,
            maxUnit: pMax.unit
          };
        }

        // Если внутри не minmax, а просто значение (редко, но возможно)
        const p = parseUnitValue(content);
        return {
          val: p.val, // Используем как min или value, но для редактора лучше minmax
          unit: type,
          min: p.val,
          minUnit: p.unit,
          max: '1',
          maxUnit: 'fr'
        };
      }
    }

    if (item.startsWith('calc(') && item.endsWith(')')) {
      const val = item.slice(5, -1);
      return { val, unit: 'calc' };
    }

    if (item.startsWith('minmax(') && item.endsWith(')')) {
      const content = item.slice(7, -1);
      const parts = content.split(',').map((s) => s.trim());
      const minPart = parts[0] || '100px';
      const maxPart = parts[1] || '1fr';
      const pMin = parseUnitValue(minPart);
      const pMax = parseUnitValue(maxPart);
      return {
        val: '',
        unit: 'minmax',
        min: pMin.val,
        minUnit: pMin.unit,
        max: pMax.val,
        maxUnit: pMax.unit
      };
    }

    const p = parseUnitValue(item);
    return { val: p.val, unit: p.unit };
  };

  items.forEach((item, index) => {
    const parsed = processItem(item);
    const { val, unit } = parsed;
    const min = parsed.min;
    const minUnit = parsed.minUnit;
    const max = parsed.max;
    const maxUnit = parsed.maxUnit;

    if (index === 0) {
      currentVal = val;
      currentUnit = unit;
      // Инициализируем min/max для сложных типов
      if (unit === 'minmax' || unit === 'auto-fit' || unit === 'auto-fill') {
        currentMin = min || '100';
        currentMinUnit = minUnit || 'px';
        currentMax = max || '1';
        currentMaxUnit = maxUnit || 'fr';
      }
      currentCount = 1;
    } else {
      const isSameSimple =
        unit !== 'minmax' &&
        unit !== 'auto-fit' &&
        unit !== 'auto-fill' &&
        val === currentVal &&
        unit === currentUnit;

      const isSameComplex =
        (unit === 'minmax' || unit === 'auto-fit' || unit === 'auto-fill') &&
        unit === currentUnit &&
        min === currentMin &&
        minUnit === currentMinUnit &&
        max === currentMax &&
        maxUnit === currentMaxUnit;

      if (isSameSimple || isSameComplex) {
        currentCount++;
      } else {
        groups.push({
          value: currentVal,
          unit: currentUnit,
          count: String(currentCount),
          min: currentMin,
          minUnit: currentMinUnit,
          max: currentMax,
          maxUnit: currentMaxUnit,
          id: `${Date.now()}-${index}`
        });
        currentVal = val;
        currentUnit = unit;
        if (unit === 'minmax' || unit === 'auto-fit' || unit === 'auto-fill') {
          currentMin = min || '100';
          currentMinUnit = minUnit || 'px';
          currentMax = max || '1';
          currentMaxUnit = maxUnit || 'fr';
        }
        currentCount = 1;
      }
    }
  });

  groups.push({
    value: currentVal,
    unit: currentUnit,
    count: String(currentCount),
    min: currentMin,
    minUnit: currentMinUnit,
    max: currentMax,
    maxUnit: currentMaxUnit,
    id: `${Date.now()}-last`
  });
  return groups;
};

export const formatVal = (v: string, u: string) => {
  if (
    u === 'auto' ||
    u === 'min-content' ||
    u === 'max-content' ||
    u === 'auto-fit' ||
    u === 'auto-fill'
  )
    return u;
  return (v || '0') + u;
};

export const groupsToCss = (currentGroups: GridTrackGroup[]) => {
  return currentGroups
    .map((g) => {
      // Для auto-fit/fill мы игнорируем count, так как сам механизм подразумевает повторение
      if (g.unit === 'auto-fit' || g.unit === 'auto-fill') {
        return `repeat(${g.unit}, minmax(${formatVal(g.min!, g.minUnit!)}, ${formatVal(g.max!, g.maxUnit!)}))`;
      }

      const count = parseInt(g.count) || 1;
      let valStr = '';
      if (g.unit === 'calc') {
        valStr = `calc(${g.value})`;
      } else if (g.unit === 'minmax') {
        valStr = `minmax(${formatVal(g.min!, g.minUnit!)}, ${formatVal(
          g.max!,
          g.maxUnit!
        )})`;
      } else {
        if (
          g.unit === 'auto' ||
          g.unit === 'min-content' ||
          g.unit === 'max-content'
        )
          valStr = g.unit;
        else valStr = g.value + g.unit;
      }
      return Array(count).fill(valStr).join(' ');
    })
    .join(' ');
};

// --- Математические хелперы для стрелок ---

export const cycleValue = (valStr: string, direction: 'up' | 'down') => {
  let val = parseFloat(valStr) || 0;
  val = direction === 'up' ? val + 1 : val - 1;
  return String(val);
};

export const cycleCount = (countStr: string, direction: 'up' | 'down') => {
  let val = parseInt(countStr) || 0;
  if (direction === 'up') val += 1;
  else val = val > 1 ? val - 1 : 1;
  return String(val);
};
