'use client';

import * as React from 'react';
import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  IconButton,
  TableContainer,
  TableBody,
  TableHead,
  Box,
  CircularProgress
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { PlusIcon } from '@/public/icons/Plus.icon';
import { store } from '@/src/store/store';
import { getDashboards } from '@/src/store/actions/getDashboards';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { Dashboard } from '@/src/store/counter/dashboardsSlice';
import { useRouter } from 'next/navigation';
import { sanitizePath } from '@/src/helpers/basePrefix';
import { dashboardActions } from '@/src/store/slices/dashboard.slice';
import {
  TypographyMontserrat500,
  TableStyled,
  TableRowStyled,
  TableCellStyled,
  TableCellLeft
} from '@/src/styles/muiStyledGlobal';
import { formatedDate } from '@/src/helpers/formatedDate';
import { Pagination } from '@/src/components/Pagination/Pagination';

interface DashboardsListModalProps {
  open: boolean;
  onClose: () => void;
  departmentId: string;
  onSaveAndNavigate: (dashboardId: string) => Promise<void>;
}

export default function DashboardsListModal({
  open,
  onClose,
  departmentId,
  onSaveAndNavigate
}: DashboardsListModalProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [selectedDashboard, setSelectedDashboard] = useState<string | null>(
    null
  );
  const [currentPage, setCurrentPage] = useState(1);

  const dashboards = useSelector((state: State) => state.dashboards);

  useEffect(() => {
    if (open && departmentId) {
      setLoading(true);
      store.dispatch(
        getDashboards(currentPage, departmentId, '', undefined, setLoading)
      );
    }
  }, [open, departmentId, currentPage]);

  const handleDashboardClick = async (dashboard: Dashboard) => {
    setSelectedDashboard(dashboard.id);
    try {
      await onSaveAndNavigate(dashboard.id);
      onClose();
    } catch (error) {
      console.error('Failed to save and navigate:', error);
      setSelectedDashboard(null);
    }
  };

  const handleCreateNewDashboard = () => {
    store.dispatch(dashboardActions.clearTempDashboard());
    router.push(
      sanitizePath(`/dashboards/create?departmentId=${departmentId}`)
    );
    onClose();
  };

  const handlePageChange = (
    event: React.ChangeEvent<unknown>,
    value: number
  ) => {
    setCurrentPage(value);
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth='md'
      fullWidth
      PaperProps={{
        sx: {
          background:
            'linear-gradient(90deg, rgba(10, 15, 24, 1) 0%, rgba(55, 59, 68, 1) 100%)',
          color: '#fff',
          borderRadius: '8px',
          minHeight: '80vh',
          maxHeight: '90vh',
          padding: '0 24px'
        }
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '24px 0px',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
          background: 'transparent'
        }}
      >
        <TypographyMontserrat500
          sx={{
            fontSize: '16px',
            fontWeight: 500
          }}
        >
          List of Dashboards
        </TypographyMontserrat500>

        <Box sx={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
          <IconButton
            onClick={handleCreateNewDashboard}
            disableTouchRipple={true}
            sx={{
              width: '44px',
              height: '44px',
              justifyContent: 'center',
              alignItems: 'center',
              borderRadius: '4px',
              backgroundColor: '#3D3AB8',
              '&:hover': {
                backgroundColor: '#4441CC'
              },
              '&:active': {
                backgroundColor: '#504DE3'
              }
            }}
          >
            <PlusIcon />
          </IconButton>

          <IconButton
            onClick={onClose}
            disableTouchRipple={true}
            sx={{
              width: '24px',
              height: '24px',
              justifyContent: 'center',
              alignItems: 'center',
              borderRadius: '4px',
              backgroundColor: '#3D3AB8',
              '&:hover': {
                backgroundColor: '#4441CC'
              },
              '&:active': {
                backgroundColor: '#504DE3'
              }
            }}
          >
            <CloseIcon sx={{ color: '#fff', width: '24px', height: '24px' }} />
          </IconButton>
        </Box>
      </Box>

      <DialogContent
        sx={{
          padding: '0',
          background: 'transparent',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {loading ? (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              minHeight: '400px'
            }}
          >
            <CircularProgress sx={{ color: '#4170FF' }} />
          </Box>
        ) : dashboards?.content?.length > 0 ? (
          <>
            <TableContainer sx={{ width: '100%' }}>
              <TableStyled
                sx={{ borderSpacing: '0', background: 'transparent' }}
              >
                <TableHead>
                  <TableRowStyled sx={{ height: '44px' }}>
                    <TableCellLeft sx={{ width: '40%', paddingLeft: '32px' }}>
                      <TypographyMontserrat500
                        sx={{ fontSize: '16px', color: '#D3D6E7' }}
                      >
                        Name
                      </TypographyMontserrat500>
                    </TableCellLeft>
                    <TableCellStyled
                      align='center'
                      sx={{ width: '30%' }}
                    >
                      <TypographyMontserrat500
                        sx={{ fontSize: '16px', color: '#D3D6E7' }}
                      >
                        Created date
                      </TypographyMontserrat500>
                    </TableCellStyled>
                    <TableCellStyled
                      align='center'
                      sx={{ width: '30%' }}
                    >
                      <TypographyMontserrat500
                        sx={{ fontSize: '16px', color: '#D3D6E7' }}
                      >
                        Group
                      </TypographyMontserrat500>
                    </TableCellStyled>
                  </TableRowStyled>
                </TableHead>
              </TableStyled>
            </TableContainer>

            <TableContainer
              sx={{
                flex: 1,
                overflow: 'auto',
                maxHeight: 'calc(80vh - 200px)',
                '&::-webkit-scrollbar': {
                  width: '4px'
                },
                '&::-webkit-scrollbar-track': {
                  background: 'transparent'
                },
                '&::-webkit-scrollbar-thumb': {
                  backgroundColor: '#D9D9D9',
                  borderRadius: '8px'
                },
                scrollbarWidth: 'thin',
                scrollbarColor: 'rgba(0,0,0,.1) transparent'
              }}
            >
              <TableStyled sx={{ background: 'transparent' }}>
                <TableBody>
                  {dashboards.content.map((row: Dashboard) => (
                    <TableRowStyled
                      key={row.id}
                      sx={{
                        height: '64px',
                        cursor: 'pointer',
                        opacity: selectedDashboard === row.id ? 0.6 : 1,
                        '&:hover': {
                          backgroundColor: 'rgba(65, 112, 255, 0.05)'
                        }
                      }}
                      onClick={() => handleDashboardClick(row)}
                    >
                      <TableCellStyled
                        sx={{ width: '40%', paddingLeft: '32px' }}
                      >
                        <TypographyMontserrat500
                          sx={{
                            fontSize: '16px',
                            width: '100%',
                            color: '#4170FF'
                          }}
                          noWrap
                        >
                          {row.name}
                        </TypographyMontserrat500>
                      </TableCellStyled>

                      <TableCellStyled
                        align='center'
                        sx={{ width: '30%' }}
                      >
                        <TypographyMontserrat500
                          sx={{ fontSize: '16px', color: '#D3D6E7' }}
                        >
                          {formatedDate(row.createdTimestamp, 'DD/MM/YYYY')}
                        </TypographyMontserrat500>
                      </TableCellStyled>

                      <TableCellStyled
                        align='center'
                        sx={{ width: '30%' }}
                      >
                        <TypographyMontserrat500
                          sx={{ fontSize: '16px', color: '#D3D6E7' }}
                        >
                          {row.groupName}
                        </TypographyMontserrat500>
                      </TableCellStyled>
                    </TableRowStyled>
                  ))}
                </TableBody>
              </TableStyled>
            </TableContainer>

            <Box
              sx={{
                padding: '16px 32px',
                borderTop: '1px solid rgba(255, 255, 255, 0.1)'
              }}
            >
              <Pagination
                totalElements={dashboards.totalElements}
                handleChange={handlePageChange}
              />
            </Box>
          </>
        ) : (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              minHeight: '400px',
              color: 'rgba(255, 255, 255, 0.6)',
              fontSize: '14px'
            }}
          >
            No dashboards found
          </Box>
        )}
      </DialogContent>
    </Dialog>
  );
}
