import React, { useState, useEffect } from 'react';
import { useEditorMaybe } from '@grapesjs/react';
import CloseIcon from '@mui/icons-material/Close';
import { Box, IconButton, Tooltip } from '@mui/material';
import { Stack } from '@mui/system';

import { cx } from './common';
import { getComponentDisplayName } from '@/src/editor/componentPresentation';
import { EDITOR_SIDEBAR_BG } from '@/src/styles/editorSidebarTokens';
import { clearEditorSelection } from '@/src/editor/editorRegistry';

interface CustomComponentHeaderProps {
  className?: string;
}

export default function CustomComponentHeader({
  className
}: CustomComponentHeaderProps) {
  const editor = useEditorMaybe();
  const [selectedComponent, setSelectedComponent] = useState<any>(null);

  useEffect(() => {
    if (!editor) return;

    const updateSelected = () => setSelectedComponent(editor.getSelected());

    editor.on('component:selected', updateSelected);
    editor.on('component:deselected', updateSelected);
    updateSelected();

    return () => {
      editor.off('component:selected', updateSelected);
      editor.off('component:deselected', updateSelected);
    };
  }, [editor]);

  if (!editor || !selectedComponent) return null;

  const blocks = editor.Blocks.getAll();
  const componentType = selectedComponent.get('type');
  const isDownload = componentType === 'mui-download';
  const isUpload = componentType === 'mui-upload';
  const typeDef = editor.Components.getType(componentType);

  const possibleBlockIds = [
    selectedComponent.get('blockId'),
    selectedComponent.getAttributes()['data-block'],
    componentType
  ].filter(Boolean);

  let matchedBlock: any = null;
  for (const id of possibleBlockIds) {
    matchedBlock = blocks.find((block: any) => block.getId() === id);
    if (matchedBlock) break;
  }

  let blockMedia =
    '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="3" stroke="white" fill="none"/></svg>';

  if (selectedComponent.get('icon')) {
    blockMedia = selectedComponent.get('icon');
  } else if (matchedBlock?.getMedia?.()) {
    blockMedia = matchedBlock.getMedia() || blockMedia;
  } else if (typeDef?.model?.prototype?.defaults?.icon) {
    blockMedia = typeDef.model.prototype.defaults.icon;
  } else if ((typeDef as any)?.icon) {
    blockMedia = String((typeDef as any).icon);
  }

  let blockLabel = 'Unknown Component';
  const customName = selectedComponent.label;
  const defaultName = typeDef
    ? typeDef.model.prototype.defaults.label || (typeDef as any).label || ''
    : '';

  if (
    customName &&
    customName !== defaultName &&
    customName !== componentType
  ) {
    blockLabel = customName;
  } else if (matchedBlock?.getLabel?.()) {
    blockLabel = matchedBlock.getLabel();
  } else if (defaultName) {
    blockLabel = defaultName;
  } else {
    blockLabel = componentType || selectedComponent.get('tagName');
  }

  blockLabel = getComponentDisplayName(componentType, blockLabel);

  const closeSettings = () => {
    clearEditorSelection(editor);
  };

  return (
    <Box
      className={cx('flex items-center p-4', className)}
      sx={{
        minHeight: 52,
        boxSizing: 'border-box',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '12px',
        background: EDITOR_SIDEBAR_BG,
        color: 'white',
        position: 'sticky',
        top: 0,
        zIndex: 10
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          minWidth: 0
        }}
      >
        <Stack
          sx={{
            width: 24,
            height: 24,
            flexShrink: 0,
            alignItems: 'center',
            justifyContent: 'center',
            '& svg': {
              width: '24px',
              height: '24px',
              display: 'block'
            }
          }}
          dangerouslySetInnerHTML={{ __html: blockMedia }}
        />
        <span
          className='truncate font-medium'
          style={{ fontFamily: 'Montserrat, sans-serif', fontSize: '16px' }}
        >
          <Tooltip title={blockLabel} placement='top'>
            <span>{blockLabel}</span>
          </Tooltip>
        </span>
      </Box>

      <IconButton
        aria-label='Close settings'
        onClick={closeSettings}
        sx={{
          width: 22,
          height: 22,
          flexShrink: 0,
          p: 0,
          color: '#FFFFFF',
          border: '1px solid rgba(255,255,255,.8)',
          borderRadius: '3px',
          '&:hover': { background: 'rgba(255,255,255,.08)' }
        }}
      >
        <CloseIcon sx={{ fontSize: 15 }} />
      </IconButton>
    </Box>
  );
}
