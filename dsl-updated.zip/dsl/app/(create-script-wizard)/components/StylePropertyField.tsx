import { useEditor } from '@grapesjs/react';
import {
  mdiArrowDownDropCircle,
  mdiArrowUpDropCircle,
  mdiPlus,
  mdiClose
} from '@mdi/js';
import Icon from '@mdi/react';
import FormControlLabel from '@mui/material/FormControlLabel';
import IconButton from '@mui/material/IconButton';
import InputAdornment from '@mui/material/InputAdornment';
import MenuItem from '@mui/material/MenuItem';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import Slider from '@mui/material/Slider';
import TextField from '@mui/material/TextField';
import { Box, Select } from '@mui/material';
import type { SelectChangeEvent } from '@mui/material/Select';
import type {
  Property,
  PropertyComposite,
  PropertyRadio,
  PropertySelect,
  PropertySlider,
  PropertyStack
} from 'grapesjs';
import { useEffect, useRef, useState } from 'react';

import { FlexStyleField } from './FlexStyleField';
import { GridStyleField } from './GridStyleField';
import { PositionStyleField } from './PositionStyleField';
import ColorElement from './ColorElement';
import { OptionType } from './types';
import { CustomSelect } from './Select';

import { MAIN_TXT_COLOR, ROUND_BORDER_COLOR, cx } from './common';

interface StylePropertyFieldProps extends React.HTMLProps<HTMLDivElement> {
  prop: Property;
}

export default function StylePropertyField({
  prop,
  ...rest
}: StylePropertyFieldProps) {
  const editor = useEditor();

  const handleChange = (value: string | number) => {
    const next = value.toString();
    const attrs = (prop as any).attributes || (prop as any).props?.() || {};
    const changeFn = attrs.change || (prop as any).get?.("change");
    if (typeof changeFn === "function") {
      changeFn({ value: next });
      return;
    }
    prop.upValue(next);
  };

  const onChange = (
    ev:
      | React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
      | number
      | string
  ) => {
    let value: string | number;
    if (typeof ev === 'string' || typeof ev === 'number') {
      value = ev;
    } else {
      value = ev.target.value;
    }
    handleChange(value);
  };

  const openAssets = () => {
    const { Assets } = editor;
    Assets.open({
      select: (asset, complete) => {
        prop.upValue(asset.getSrc(), { partial: !complete });
        complete && Assets.close();
      },
      types: ['image'],
      accept: 'image/*'
    });
  };

  const type = prop.getType();
  const defValue = prop.getDefaultValue();
  const hasValue = prop.hasValue();
  const value = prop.getValue() as string;
  const valueString = hasValue ? value : '';
  const propId = prop.getId();

  //@ts-ignore
  const units = prop.getUnits?.() || [];
  const extendedUnits = [...units, '-'];
  const hasUnits = extendedUnits.length > 1;

  const extractValueAndUnit = (val: unknown) => {
    const str = String(val ?? '');

    if (str.toLowerCase() === 'auto' || str === '') {
      return { value: '', unit: '-' };
    }

    const match = str.match(/^(-?\d*\.?\d+)(.*)$/);

    if (match) {
      const numValue = match[1];
      const unitValue = match[2] || units[0] || '-';
      return { value: numValue, unit: unitValue };
    }

    return { value: str, unit: '-' };
  };

  const { value: extractedValue, unit: selectedUnit } =
    extractValueAndUnit(valueString);
  const [currentValue, setCurrentValue] = useState<string>(extractedValue);
  const [currentUnit, setCurrentUnit] = useState<string>(selectedUnit);
  const isTyping = useRef(false);

  useEffect(() => {
    if (!isTyping.current) {
      const { value, unit } = extractValueAndUnit(valueString);
      setCurrentValue(value);
      setCurrentUnit(unit);
    }
  }, [valueString]);

  const handleNumberChange = (ev: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = ev.target.value;

    if (currentUnit === '-') return;

    isTyping.current = true;
    setCurrentValue(newValue);

    if (newValue === '') {
      handleChange('auto');
    } else {
      handleChange(newValue + currentUnit);
    }

    setTimeout(() => {
      isTyping.current = false;
    }, 10);
  };

  const handleUnitChange = (ev: SelectChangeEvent<string>) => {
    const newUnit = ev.target.value;
    setCurrentUnit(newUnit);
    isTyping.current = false;

    if (newUnit === '-') {
      setCurrentValue('');
      handleChange('auto');
    } else {
      const val = currentValue && currentValue !== 'auto' ? currentValue : '0';
      setCurrentValue(val);
      handleChange(val + newUnit);
    }
  };
  const handleUnitCycle = (direction: 'up' | 'down') => {
    const step = 1;
    let newValue = parseFloat(currentValue) || 0;
    if (direction === 'up') newValue += step;
    else newValue -= step;

    setCurrentValue(newValue.toString());
    if (currentUnit === '-') handleChange('auto');
    else handleChange(newValue + currentUnit);
  };

  let inputToRender: React.ReactNode = null;

  const isCustomFlexField = [
    'flex-order-type',
    'flex-grow-shrink-group'
  ].includes(propId);
  const isGridField = [
    'justify-self',
    'justify-items',
    'align-items',
    'justify-content',
    'align-self',
    'grid-template-columns',
    'grid-template-rows'
  ].includes(propId);
  const isPositionField = ['text-align', 'align'].includes(propId);
  if (isPositionField) {
    inputToRender = (
      <PositionStyleField
        prop={prop}
        onChange={onChange}
        value={value}
      />
    );
  } else if (isCustomFlexField) {
    inputToRender = (
      <FlexStyleField
        prop={prop}
        onChange={onChange}
        value={value}
      />
    );
  } else if (isGridField) {
    inputToRender = (
      <GridStyleField
        prop={prop}
        onChange={onChange}
        value={value}
      />
    );
  } else {
    inputToRender = (
      <TextField
        placeholder={defValue}
        value={valueString}
        onChange={(e) => onChange(e.target.value)}
        size='small'
        fullWidth
        sx={{
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          borderRadius: '6px',
          '& .MuiOutlinedInput-root': {
            '& fieldset': { border: 'none' },
            '&:hover fieldset': { border: 'none' },
            '&.Mui-focused fieldset': { border: 'none' },

            height: '34px',
            fontFamily: 'Montserrat',
            '& input': {
              border: 'none',
              padding: '0 14px',
              height: '34px',
              fontFamily: 'Montserrat',
              color: 'white'
            }
          }
        }}
      />
    );

    switch (type) {
      case 'radio': {
        const radioProp = prop as PropertyRadio;
        inputToRender = (
          <RadioGroup
            value={value}
            onChange={(e) => onChange(e)}
            row
            sx={{
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              padding: '8px',
              borderRadius: '6px',
              border: 'none',
              fontFamily: 'Montserrat'
            }}
          >
            {radioProp.getOptions().map((option) => (
              <FormControlLabel
                key={radioProp.getOptionId(option)}
                value={radioProp.getOptionId(option)}
                label={radioProp.getOptionLabel(option)}
                control={<Radio size='small' />}
              />
            ))}
          </RadioGroup>
        );
        break;
      }
      case 'select': {
        const selectProp = prop as PropertySelect;
        const options = selectProp.getOptions().map((option) => ({
          value: selectProp.getOptionId(option),
          label: selectProp.getOptionLabel(option)
        }));

        inputToRender = (
          <CustomSelect
            maxWidth='156px'
            options={options}
            activeOption={
              options.find((opt) => opt.value === value) ?? undefined
            }
            onChange={(selectedOption: OptionType) =>
              onChange(selectedOption.value)
            }
            color='rgba(255, 255, 255, 0.1)'
            size='sm'
            placeholder={defValue || 'Select option...'}
            disabled={false}
            mainStyles={{
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              maxWidth: '156px',
              width: '100%',
              height: '34px',
              borderRadius: '6px',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              fontFamily: 'Montserrat'
            }}
            truncateLength={20}
          />
        );
        break;
      }
      case 'color': {
        inputToRender = (
          <div>
            <ColorElement
              value={valueString}
              onChange={onChange}
            />
          </div>
        );
        break;
      }
      case 'slider': {
        const sliderProp = prop as PropertySlider;
        inputToRender = (
          <div
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              padding: '8px',
              borderRadius: '6px',
              fontFamily: 'Montserrat'
            }}
          >
            <Slider
              size='small'
              value={parseFloat(value) || sliderProp.getMin()}
              min={sliderProp.getMin()}
              max={sliderProp.getMax()}
              step={sliderProp.getStep()}
              onChange={(_, newValue) => onChange(newValue as number)}
              valueLabelDisplay='auto'
            />
          </div>
        );
        break;
      }
      case 'file': {
        inputToRender = (
          <div
            className='w-full mb-2'
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              padding: '8px',
              borderRadius: '6px',
              fontFamily: 'Montserrat'
            }}
          >
            <label
              className={cx('block capitalize mb-1 text-sm', MAIN_TXT_COLOR)}
              style={{ fontFamily: 'Montserrat' }}
            >
              {prop.getLabel()}
            </label>
            <div
              className='flex flex-col items-start gap-3'
              style={{ fontFamily: 'Montserrat' }}
            >
              {value && value !== defValue && (
                <div className='flex items-center gap-3 w-full'>
                  <div
                    className='w-[50px] h-[50px] rounded inline-block bg-cover bg-center cursor-pointer border'
                    style={{
                      backgroundImage: `url("${value}")`,
                      borderColor: 'rgba(65, 112, 255, 1)'
                    }}
                    onClick={() => handleChange('')}
                  />
                  <IconButton
                    onClick={() => handleChange('')}
                    size='small'
                    sx={{
                      color: '#f44336',
                      '&:hover': { backgroundColor: 'rgba(244, 67, 54, 0.1)' }
                    }}
                  >
                    <Icon
                      path={mdiClose}
                      size={0.7}
                    />
                  </IconButton>
                </div>
              )}
              <label
                className={cx(
                  'inline-flex items-center justify-center gap-2',
                  'px-4 py-2 rounded border cursor-pointer',
                  'hover:bg-opacity-30 transition-colors'
                )}
                style={{
                  backgroundColor: 'rgba(65, 112, 255, 0.2)',
                  borderColor: 'rgba(65, 112, 255, 1)',
                  color: '#fff'
                }}
                onClick={openAssets}
              >
                <svg
                  width='18'
                  height='22'
                  viewBox='0 0 18 22'
                  fill='none'
                  xmlns='http://www.w3.org/2000/svg'
                  style={{ display: 'inline-block' }}
                >
                  <path
                    d='M2.48585 0.714233C1.94027 0.714233 1.41702 0.930968 1.03123 1.31676C0.645445 1.70255 0.428711 2.22579 0.428711 2.77138V19.2285C0.428711 19.7741 0.645445 20.2973 1.03123 20.6831C1.41702 21.0689 1.94027 21.2857 2.48585 21.2857H15.5144C16.06 21.2857 16.5833 21.0689 16.969 20.6831C17.3548 20.2973 17.5716 19.7741 17.5716 19.2285V8.92395C17.5716 8.29909 17.323 7.69995 16.8816 7.25766L10.9407 1.3168C10.5549 0.93101 10.0317 0.714259 9.48614 0.714233H2.48585ZM1.71443 2.77138C1.71443 2.56678 1.7957 2.37056 1.94037 2.22589C2.08504 2.08122 2.28126 1.99995 2.48585 1.99995H9.00014V7.57138C9.00014 8.02603 9.18075 8.46207 9.50224 8.78356C9.82373 9.10505 10.2598 9.28566 10.7144 9.28566H16.2859V19.2285C16.2859 19.4331 16.2046 19.6293 16.0599 19.774C15.9152 19.9187 15.719 19.9999 15.5144 19.9999H2.48585C2.28126 19.9999 2.08504 19.9187 1.94037 19.774C1.7957 19.6293 1.71443 19.4331 1.71443 19.2285V2.77138ZM15.8059 7.99995H10.7144C10.6008 7.99995 10.4918 7.9548 10.4114 7.87442C10.331 7.79405 10.2859 7.68504 10.2859 7.57138V2.47995L15.8059 7.99995Z'
                    fill='currentColor'
                  />
                </svg>
                <span>Choose file</span>
              </label>
            </div>
          </div>
        );
        break;
      }
      case 'composite': {
        const compositeProp = prop as PropertyComposite;
        inputToRender = (
          <div
            className={cx('flex flex-wrap p-2', ROUND_BORDER_COLOR)}
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              borderRadius: '6px',
              fontFamily: 'Montserrat'
            }}
          >
            {compositeProp.getProperties().map((prop) => (
              <StylePropertyField
                key={prop.getId()}
                prop={prop}
              />
            ))}
          </div>
        );
        break;
      }
      case 'stack': {
        const stackProp = prop as PropertyStack;
        const layers = stackProp.getLayers();
        const isTextShadow = stackProp.getName() === 'text-shadow';
        inputToRender = (
          <div
            className={cx(
              'flex flex-col p-2 gap-2 min-h-[54px]',
              ROUND_BORDER_COLOR
            )}
            style={{
              backgroundColor: 'rgba(51, 51, 51, 0.5)',
              borderRadius: '6px',
              fontFamily: 'Montserrat'
            }}
          >
            {layers.map((layer) => (
              <div
                key={layer.getId()}
                className={ROUND_BORDER_COLOR}
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.1)',
                  fontFamily: 'Montserrat'
                }}
              >
                <div className='flex gap-1 bg-slate-800 px-2 py-1 items-center'>
                  <IconButton
                    size='small'
                    onClick={() => layer.move(layer.getIndex() - 1)}
                  >
                    <Icon
                      size={0.7}
                      path={mdiArrowUpDropCircle}
                    />
                  </IconButton>
                  <IconButton
                    size='small'
                    onClick={() => layer.move(layer.getIndex() + 1)}
                  >
                    <Icon
                      size={0.7}
                      path={mdiArrowDownDropCircle}
                    />
                  </IconButton>
                  <button
                    className='flex-grow'
                    onClick={() => layer.select()}
                  >
                    {layer.getLabel()}
                  </button>
                  <div
                    className={cx(
                      'bg-white min-w-[17px] min-h-[17px] text-black text-sm flex justify-center',
                      ROUND_BORDER_COLOR
                    )}
                    style={layer.getStylePreview({
                      number: { min: -3, max: 3 },
                      camelCase: true
                    })}
                  >
                    {isTextShadow && 'T'}
                  </div>
                  <IconButton
                    size='small'
                    onClick={() => layer.remove()}
                  ></IconButton>
                </div>
                {layer.isSelected() && (
                  <div
                    className='p-2 flex flex-wrap'
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.1)',
                      fontFamily: 'Montserrat'
                    }}
                  >
                    {stackProp.getProperties().map((prop) => (
                      <StylePropertyField
                        key={prop.getId()}
                        prop={prop}
                      />
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        );
        break;
      }
    }
  }

  const isSimpleInput =
    (type === 'number' || type === 'integer' || type === 'text') &&
    !isCustomFlexField;

  if (hasUnits && isSimpleInput) {
    inputToRender = (
      <TextField
        type={currentUnit === '-' ? 'text' : 'number'}
        value={currentUnit === '-' ? 'auto' : currentValue}
        onChange={handleNumberChange}
        style={{
          background: 'rgba(255, 255, 255, 0.1)',
          borderRadius: '6px',
          border: 'none',
          fontFamily: 'Montserrat'
        }}
        size='small'
        fullWidth
        sx={{
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          borderRadius: '6px',
          '& .MuiOutlinedInput-root': {
            '& fieldset': { border: 'none' },
            '&:hover fieldset': { border: 'none' },
            '&.Mui-focused fieldset': { border: 'none' },

            height: '34px',
            fontFamily: 'Montserrat',
            '& input': {
              border: 'none',
              padding: '0 14px',
              height: '34px',
              fontFamily: 'Montserrat',
              color: 'white'
            }
          }
        }}
        InputProps={{
          readOnly: currentUnit === '-',
          endAdornment: (
            <InputAdornment
              position='end'
              sx={{
                display: 'flex',
                alignItems: 'center',
                textAlign: 'center',
                fontFamily: 'Montserrat'
              }}
            >
              <Select
                value={currentUnit}
                //@ts-ignore
                onChange={handleUnitChange}
                variant='outlined'
                disableUnderline
                sx={{
                  '& .MuiSelect-select': {
                    fontSize: '10px',
                    border: '1px solid rgba(255, 255, 255, 0.15)',
                    borderRadius: '6px',
                    width: '24px',
                    height: '24px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center !important',
                    padding: '0 !important',
                    margin: '0 !important',
                    boxSizing: 'border-box',
                    textAlign: 'center !important',
                    lineHeight: '24px',
                    overflow: 'hidden',
                    fontFamily: 'Montserrat'
                  },
                  '& .MuiSelect-select.Mui-focused': {
                    border: '1px solid rgba(255, 255, 255, 0.15)',
                    borderRadius: '6px',
                    width: '24px',
                    height: '24px',
                    padding: '0 !important',
                    margin: '0 !important',
                    lineHeight: '24px',
                    fontFamily: 'Montserrat'
                  },
                  '& .MuiSelect-icon': {
                    display: 'none',
                    fontFamily: 'Montserrat'
                  },
                  width: '24px',
                  height: '24px',
                  minWidth: '24px',
                  fontFamily: 'Montserrat'
                }}
                MenuProps={{
                  PaperProps: {
                    sx: {
                      backgroundColor: 'black',
                      border: '1px solid #2D3748',
                      borderRadius: '0 0 6px 6px',
                      boxShadow: 'none',
                      marginTop: '4px',
                      '& .MuiMenuItem-root': {
                        padding: '8px 20px',
                        margin: '0',
                        textIndent: '0',
                        textAlign: 'left',
                        transform: 'none',
                        transition: 'background-color 0.2s, color 0.2s',
                        boxSizing: 'border-box',
                        width: '100%',
                        fontSize: '14px',
                        color: 'white',
                        fontFamily: 'Montserrat',
                        '&:hover': {
                          backgroundColor: 'rgba(42, 43, 107)',
                          color: 'white'
                        }
                      }
                    }
                  }
                }}
              >
                {extendedUnits.map((unit: string) => (
                  <MenuItem
                    key={unit}
                    value={unit}
                    sx={{
                      padding: '8px 20px',
                      margin: '0',
                      textIndent: '0',
                      textAlign: 'left',
                      transform: 'none',
                      transition: 'background-color 0.2s, color 0.2s',
                      boxSizing: 'border-box',
                      width: '100%',
                      fontSize: '14px',
                      color: 'white',
                      fontFamily: 'Montserrat',
                      '&:hover': {
                        backgroundColor: 'rgba(42, 43, 107)',
                        color: 'white'
                      }
                    }}
                  >
                    {unit}
                  </MenuItem>
                ))}
              </Select>
              <Box sx={{ display: 'flex', flexDirection: 'column', ml: '4px' }}>
                <svg
                  width='12'
                  height='12'
                  viewBox='0 0 12 12'
                  fill='none'
                  xmlns='http://www.w3.org/2000/svg'
                  style={{ cursor: 'pointer' }}
                  onClick={() => handleUnitCycle('up')}
                >
                  <path
                    d='M8.5 7L6 4.5L3.5 7'
                    stroke='rgba(255, 255, 255, 0.5)'
                    strokeWidth='2'
                    strokeLinecap='round'
                    strokeLinejoin='round'
                  />
                </svg>
                <svg
                  width='12'
                  height='12'
                  viewBox='0 0 12 12'
                  fill='none'
                  xmlns='http://www.w3.org/2000/svg'
                  style={{ cursor: 'pointer' }}
                  onClick={() => handleUnitCycle('down')}
                >
                  <path
                    d='M3.5 5L6 7.5L8.5 5'
                    stroke='rgba(255, 255, 255, 0.5)'
                    strokeWidth='2'
                    strokeLinecap='round'
                    strokeLinejoin='round'
                  />
                </svg>
              </Box>
            </InputAdornment>
          )
        }}
      />
    );
  }

  const isFlexSubProp = ['flex-shrink', 'flex-grow', 'flex-basis'].includes(
    propId
  );

  if (isFlexSubProp) {
    return <>{inputToRender}</>;
  }

  const isFullWidth =
    prop.isFull() ||
    ['grid-template-columns', 'grid-template-rows'].includes(propId);

  return (
    <div
      {...rest}
      className={cx('px-1 mb-6 last:mb-0', isFullWidth ? 'w-full' : 'w-1/2')}
      style={{ marginBottom: '24px', ...rest.style }}
    >
      <div className={cx('flex mb-[14px] items-center')}>
        <Box
          className='flex-grow capitalize'
          sx={{ fontSize: '14px', fontWeight: 500, fontFamily: 'Montserrat' }}
        >
          {prop.getLabel()}
        </Box>
        {type === 'stack' && (
          <IconButton
            size='small'
            className='!ml-2'
            onClick={() => (prop as PropertyStack).addLayer({}, { at: 0 })}
          >
            <Icon
              size={1}
              path={mdiPlus}
            />
          </IconButton>
        )}
      </div>
      {inputToRender}
    </div>
  );
}
