import * as React from 'react';
import { LayersResultProps, useEditor } from '@grapesjs/react';
import type { Component, Editor } from 'grapesjs';
import { useRef, useState, useEffect } from 'react';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';
import Box from '@mui/material/Box';

import { DragRect } from './types';
import { cx } from './common';
import LayerItem from './LayerItem';

const LAYER_PAD = 5;

const getDragTarget = (ev: React.PointerEvent) => {
  const el = document.elementFromPoint(ev.clientX, ev.clientY) as HTMLElement;
  const elLayer = el?.closest('[data-layer-item]') as HTMLElement;
  return {
    el: elLayer,
    cmp: (elLayer as any)?.__cmp as Component
  };
};

type CanMoveResult = ReturnType<Editor['Components']['canMove']>;

interface CanMove extends Partial<Omit<CanMoveResult, 'source'>> {
  canMoveInside?: CanMoveResult;
  source?: Component | null;
  index?: number;
}

export default function CustomLayerManager({
  root
}: Omit<LayersResultProps, 'Container'>) {
  const editor = useEditor();
  const [pointerDown, setPointerDown] = useState(false);
  const [canMoveRes, setCanMoveRes] = useState<CanMove>({});
  const [cmpPointerOver, setCmpPointerOver] = useState<Component>();
  const [dragging, setDragging] = useState<Component>();
  const [dragParent, setDragParent] = useState<Component>();
  const [dragRect, setDragRect] = useState<DragRect>();
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredComponents, setFilteredComponents] = useState<Component[]>([]);
  const indicatorRef = useRef<HTMLDivElement>(null);
  const { Components } = editor;

  const collectMatchingComponents = (
    component: Component,
    query: string,
    results: Component[] = []
  ) => {
    if (!component || !query) return results;

    try {
      const name = component.getName?.()?.toLowerCase() || '';
      if (name.includes(query.toLowerCase())) {
        results.push(component);
      }

      const components = component.components?.() || [];
      components.forEach((child: Component) => {
        collectMatchingComponents(child, query, results);
      });
    } catch (error) {
      console.error('Error processing component:', error);
    }

    return results;
  };

  useEffect(() => {
    if (!root) return;

    if (!searchQuery.trim()) {
      setFilteredComponents([]);
      return;
    }

    const matches = collectMatchingComponents(root, searchQuery);
    setFilteredComponents(matches);
  }, [searchQuery, root]);

  const onDragStart = (ev: React.PointerEvent) => {
    ev.stopPropagation();
    const { cmp } = getDragTarget(ev);
    if (!cmp || cmp === root) return;
    setPointerDown(true);
  };

  const onDragMove = (ev: React.PointerEvent) => {
    ev.stopPropagation();
    if (!pointerDown) return;
    const { cmp, el: elLayer } = getDragTarget(ev);
    if (!elLayer || !cmp) return;
    const layerRect = elLayer.getBoundingClientRect();
    const layerH = elLayer.offsetHeight;
    const layerY = elLayer.offsetTop;
    const pointerY = ev.clientY;
    const isBefore = pointerY < layerRect.y + layerH / 2;
    const cmpSource = !dragging ? cmp : dragging;
    const cmpTarget = cmp.parent();
    const cmpIndex = cmp.index() + (isBefore ? 0 : 1);
    !dragging && setDragging(cmp);
    setCmpPointerOver(cmp);
    const canMove = Components.canMove(cmpTarget!, cmpSource, cmpIndex);
    const canMoveInside = Components.canMove(cmp, cmpSource);
    const canMoveRes: CanMove = {
      ...canMove,
      canMoveInside,
      index: cmpIndex
    };
    let pointerInside = false;
    if (
      canMoveInside.result &&
      pointerY > layerRect.y + LAYER_PAD &&
      pointerY < layerRect.y + layerH - LAYER_PAD
    ) {
      pointerInside = true;
      canMoveRes.target = cmp;
      delete canMoveRes.index;
    }
    setDragParent(pointerInside ? cmp : undefined);
    setCanMoveRes(canMoveRes);
    setDragRect({
      pointerInside,
      y: layerY + (isBefore ? 0 : layerH),
      h: layerH
    });
  };

  const onDragEnd = (ev: React.PointerEvent) => {
    ev.stopPropagation();
    canMoveRes?.result &&
      canMoveRes.source?.move(canMoveRes.target!, { at: canMoveRes.index });
    setCanMoveRes({});
    setPointerDown(false);
    setDragging(undefined);
    setCmpPointerOver(undefined);
    setDragParent(undefined);
    setDragRect(undefined);
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(event.target.value);
  };

  const dragLevel = (cmpPointerOver ? cmpPointerOver.parents() : []).length;
  const showIndicator = !!(
    dragging &&
    dragRect &&
    canMoveRes?.result &&
    !dragRect.pointerInside
  );
  const indicatorStyle = showIndicator
    ? { top: dragRect.y, left: 0, marginLeft: dragLevel * 10 + 20 }
    : {};

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        overflow: 'hidden',
        position: 'relative'
      }}
    >
      <TextField
        placeholder='Search'
        value={searchQuery}
        onChange={handleSearchChange}
        sx={{
          mb: 1,
          height: '44px',
          '& .MuiOutlinedInput-root': {
            borderRadius: '5px',
            backgroundColor: 'rgba(255, 255, 255, 0.1)',
            height: '44px',

            '& .MuiOutlinedInput-notchedOutline': {
              border: 'none'
            },
            '&:hover .MuiOutlinedInput-notchedOutline': {
              border: 'none'
            },
            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
              border: 'none'
            }
          }
        }}
        InputProps={{
          endAdornment: (
            <InputAdornment position='start'>
              <SearchIcon fontSize='small' />
            </InputAdornment>
          )
        }}
      />
      <div
        className='gjs-custom-layer-manager flex-1 overflow-y-auto overflow-x-hidden text-sm text-left select-none relative'
        style={{
          scrollbarWidth: 'none', // ✅ Firefox
          msOverflowStyle: 'none' // ✅ IE and Edge
        }}
        onPointerDown={(ev) => onDragStart(ev)}
        onPointerMove={(ev) => onDragMove(ev)}
        onPointerUp={(ev) => onDragEnd(ev)}
      >
        {searchQuery ? (
          filteredComponents.length > 0 ? (
            filteredComponents.map((component) => (
              <LayerItem
                key={component.getId()}
                component={component}
                level={component.parents().length - 1}
                draggingCmp={dragging}
                dragParent={dragParent}
              />
            ))
          ) : (
            <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
              No layers found matching {searchQuery}
            </Box>
          )
        ) : (
          root && (
            <LayerItem
              component={root}
              level={0}
              draggingCmp={dragging}
              dragParent={dragParent}
            />
          )
        )}
        {showIndicator && (
          <div
            ref={indicatorRef}
            className={cx('absolute w-full h-0.5')}
            style={indicatorStyle}
          ></div>
        )}
      </div>

      {/* ✅ Добавляем глобальный стиль для скрытия webkit scrollbar */}
      <style jsx>{`
        .gjs-custom-layer-manager::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </Box>
  );
}
