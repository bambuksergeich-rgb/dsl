import * as React from 'react';
import { useEditor } from '@grapesjs/react';
import { MouseEvent, useEffect, useMemo, useRef, useState } from 'react';
import TextField from '@mui/material/TextField';
import { Component } from 'grapesjs';

import { LayerItemProps } from './types';

import { cx } from './common';

export default function LayerItem({
  component,
  draggingCmp,
  dragParent,
  ...props
}: LayerItemProps) {
  const editor = useEditor();
  const { Layers } = editor;
  const layerRef = useRef<HTMLDivElement>(null);
  const [layerData, setLayerData] = useState(Layers.getLayerData(component));
  const { open, selected, hovered, components, visible, name } = layerData;
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(
    name || `Layer ${component.getId()}`
  );
  const inputRef = useRef<HTMLInputElement>(null);
  const componentsIds = components.map((cmp) => cmp.getId());
  const isDragging = draggingCmp === component;
  const cmpHash = componentsIds.join('-');
  const level = props.level;
  const isHovered = hovered || dragParent === component;

  const getInheritedIcon = (cmp: Component): string => {
    let currentIcon = cmp.getIcon();
    let parent = cmp.parent();
    while (!currentIcon && parent) {
      currentIcon = parent.getIcon();
      parent = parent.parent();
    }
    return (
      currentIcon ||
      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg>`
    );
  };

  const icon = getInheritedIcon(component);
  const isSvg = icon.trim().startsWith('<');

  const selectedLevel = useMemo(() => {
    if (props.level === -1) return null;
    const findSelected = (
      cmp: Component,
      currentLevel: number
    ): number | null => {
      if (Layers.getLayerData(cmp).selected) {
        return currentLevel;
      }
      for (const child of cmp.components().models) {
        const result = findSelected(child, currentLevel + 1);
        if (result !== null) {
          return result;
        }
      }
      return null;
    };
    const root = editor.getWrapper();
    return root ? findSelected(root, 0) : null;
  }, [editor, Layers, layerData.selected]);

  const isDescendantOfSelected = useMemo(() => {
    if (selected || selectedLevel === null) return false;
    const checkParentSelected = (cmp: Component): boolean => {
      const parent = cmp.parent();
      if (!parent) return false;
      if (Layers.getLayerData(parent).selected) return true;
      return checkParentSelected(parent);
    };
    return checkParentSelected(component);
  }, [component, selected, selectedLevel]);

  useEffect(() => {
    const up = (cmp: Component) => {
      if (cmp === component) {
        setLayerData(Layers.getLayerData(cmp));
        setEditName(Layers.getLayerData(cmp).name || `Layer ${cmp.getId()}`);
      }
    };
    const ev = Layers.events.component;
    editor.on(ev, up);
    return () => {
      editor.off(ev, up);
    };
  }, [editor, Layers, component]);

  useEffect(() => {
    if (layerRef.current) {
      (layerRef.current as any).__cmp = component;
    }
  }, [component]);

  const handleDoubleClick = (ev: MouseEvent) => {
    ev.stopPropagation();
    if (draggingCmp) return;
    setIsEditing(true);
    setTimeout(() => inputRef.current?.focus(), 0);
  };

  const handleNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEditName(event.target.value);
  };

  const handleNameSubmit = () => {
    if (editName.trim()) {
      Layers.setLayerData(component, { name: editName.trim() });
    } else {
      setEditName(name || `Layer ${component.getId()}`);
    }
    setIsEditing(false);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      handleNameSubmit();
    } else if (event.key === 'Escape') {
      setEditName(name || `Layer ${component.getId()}`);
      setIsEditing(false);
    }
  };

  const cmpToRender = useMemo(() => {
    return components.map((cmp) => (
      <LayerItem
        key={cmp.getId()}
        component={cmp}
        level={level + 1}
        draggingCmp={draggingCmp}
        dragParent={dragParent}
      />
    ));
  }, [cmpHash, draggingCmp, dragParent]);

  const toggleOpen = (ev: MouseEvent) => {
    ev.stopPropagation();
    Layers.setLayerData(component, { open: !open });
  };

  const toggleVisibility = (ev: MouseEvent) => {
    ev.stopPropagation();
    Layers.setLayerData(component, { visible: !visible });
  };

  const select = (event: MouseEvent) => {
    event.stopPropagation();
    event.preventDefault();
    Layers.setLayerData(component, { selected: true }, { event });
  };

  const hover = (hovered: boolean) => {
    if (!hovered || !draggingCmp) {
      Layers.setLayerData(component, { hovered });
    }
  };

  const wrapperCls = cx(
    selected &&
      'bg-[rgba(42,43,107,1)] border border-[rgba(65,112,255,1)] box-sizing-border-box',
    !selected && isDescendantOfSelected && 'bg-[rgba(42,43,107,0.3)] border-0',
    !selected && !isDescendantOfSelected && 'bg-transparent border-0',
    (!visible || isDragging) && 'opacity-50',
    selected && `data-level="${level}" data-selected`,
    isDescendantOfSelected && `data-level="${level}" data-is-descendant`,
    open && `data-open`,
    'cursor-pointer'
  );

  return (
    <div className='layer-item flex flex-col'>
      <div
        onClick={select}
        onMouseEnter={() => hover(true)}
        onMouseLeave={() => hover(false)}
        className='group max-w-full'
        data-layer-item
        ref={layerRef}
      >
        <div
          className={cx(
            wrapperCls,
            'flex items-center px-[16px] gap-1 h-[48px]',
            isHovered &&
              !selected &&
              !isDescendantOfSelected &&
              'bg-[rgba(42,43,107,0.5)]'
          )}
        >
          <div
            style={{
              marginLeft: `${level * 10}px`
            }}
            className={cx(
              'cursor-pointer flex-shrink-0 mr-1',
              !components.length && 'opacity-0'
            )}
            onClick={toggleOpen}
          >
            {open ? (
              <svg
                width='18'
                height='18'
                viewBox='0 0 18 18'
                fill='none'
                className='text-white'
              >
                <path
                  d='M5.25 7.5L9 11.25L12.75 7.5'
                  stroke='currentColor'
                  strokeWidth='2'
                  strokeLinecap='round'
                  strokeLinejoin='round'
                />
              </svg>
            ) : (
              <svg
                width='18'
                height='18'
                viewBox='0 0 18 18'
                fill='none'
                className='text-white'
              >
                <path
                  d='M7.5 12.75L11.25 9L7.5 5.25'
                  stroke='currentColor'
                  strokeWidth='2'
                  strokeLinecap='round'
                  strokeLinejoin='round'
                />
              </svg>
            )}
          </div>
          <div
            className='flex-shrink-0 flex items-center justify-center mr-2'
            style={{
              width: '20px',
              height: '20px',
              color: 'rgba(255, 255, 255, 0.7)'
            }}
          >
            {isSvg ? (
              <div
                className='w-full h-full flex items-center justify-center [&>svg]:w-full [&>svg]:h-full'
                dangerouslySetInnerHTML={{ __html: icon }}
              />
            ) : (
              <i className={cx(icon, 'text-sm')} />
            )}
          </div>

          <div
            className='truncate flex-grow'
            style={{ maxWidth: '100%' }}
            onDoubleClick={handleDoubleClick}
          >
            {isEditing ? (
              <TextField
                inputRef={inputRef}
                value={editName}
                onChange={handleNameChange}
                onBlur={handleNameSubmit}
                onKeyDown={handleKeyDown}
                size='small'
                fullWidth
                sx={{
                  '& .MuiInputBase-input': {
                    padding: '4px 8px',
                    fontSize: '14px',
                    color: 'white',
                    backgroundColor: 'rgba(255, 255, 255, 0.1)'
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    border: 'none'
                  }
                }}
              />
            ) : (
              name
            )}
          </div>

          {/* ВИДИМОСТЬ */}
          <div
            className={cx(
              'group-hover:opacity-100 cursor-pointer flex-shrink-0',
              visible ? 'opacity-0' : 'opacity-100'
            )}
            onClick={toggleVisibility}
          >
            <svg
              width='18'
              height='18'
              viewBox='0 0 24 24'
              fill='none'
              className='text-white'
            >
              <path
                d='M11.9999 9.00462C14.209 9.00462 15.9999 10.7955 15.9999 13.0046C15.9999 15.2138 14.209 17.0046 11.9999 17.0046C9.79073 17.0046 7.99987 15.2138 7.99987 13.0046C7.99987 10.7955 9.79073 9.00462 11.9999 9.00462ZM11.9999 10.5046C10.6192 10.5046 9.49987 11.6239 9.49987 13.0046C9.49987 14.3853 10.6192 15.5046 11.9999 15.5046C13.3806 15.5046 14.4999 14.3853 14.4999 13.0046C14.4999 11.6239 13.3806 10.5046 11.9999 10.5046ZM11.9999 5.5C16.6134 5.5 20.596 8.65001 21.701 13.0644C21.8016 13.4662 21.5574 13.8735 21.1556 13.9741C20.7537 14.0746 20.3465 13.8305 20.2459 13.4286C19.307 9.67796 15.9212 7 11.9999 7C8.07681 7 4.68997 9.68026 3.75273 13.4332C3.65237 13.835 3.24523 14.0794 2.84336 13.9791C2.44149 13.8787 2.19707 13.4716 2.29743 13.0697C3.40052 8.65272 7.38436 5.5 11.9999 5.5Z'
                fill='currentColor'
              />
              {!visible && (
                <line
                  x1='4'
                  y1='20'
                  x2='20'
                  y2='4'
                  stroke='currentColor'
                  strokeWidth='2'
                />
              )}
            </svg>
          </div>
        </div>
      </div>
      {!!(open && components.length) && (
        <div className={cx('max-w-full', !open && 'hidden')}>{cmpToRender}</div>
      )}
    </div>
  );
}
