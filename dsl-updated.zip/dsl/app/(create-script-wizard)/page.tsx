'use client';

import { useState, useEffect } from 'react';
import { store } from '@/src/store/store';
import { getCompany } from '@/src/store/actions/getCompany';
import { getUser } from '@/src/store/actions/getUser';
import { getActivities } from '@/src/store/actions/getActivities';
import { ActivitieData } from '@/src/store/counter/activitiesSlice';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { Loading } from '@/src/components/Loading/Loading';
import { getActivityMetadataAction } from '@/src/store/actions/getActivityMetadataAction';
import { getUsers } from '@/src/store/actions/getUsers';
import { useSearchParams } from 'next/navigation';

import dynamic from 'next/dynamic';

const Editor = dynamic(() => import('./editor/page'), {
  ssr: false,
  loading: () => <Loading />
});

export default function EditorLayout() {
  const [page, setPage] = useState<number>(1);
  const [filter, setFilter] = useState<string>('ALL');
  const [departmentId, setDepartmentId] = useState<string>('');
  const [action, setAction] = useState<string>('ALL');
  const [employeeId, setEmployeeId] = useState<string>('ALL');
  const [fromDate, setFromDate] = useState<string>('');
  const [toDate, setToDate] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const role = useSelector((state: State) => state.userRole);

  const searchParams = useSearchParams();
  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getUsers(departmentId));
    }
  }, [departmentId]);

  useEffect(() => {
    store.dispatch(getCompany(false));
    store.dispatch(getUser());
  }, []);

  useEffect(() => {
    if (role) {
      store.dispatch(getActivityMetadataAction(role.name === 'Administrator'));
    }
  }, [role]);

  useEffect(() => {
    if (role) {
      store.dispatch(
        getActivities(
          1,
          role.name === 'Administrator',
          filter,
          action,
          employeeId,
          fromDate,
          toDate,
          setPage,
          setLoading
        )
      );
    }
  }, [role]);

  const activities: ActivitieData = useSelector(
    (state: State) => state.activities
  );

  if (!activities) {
    return <Loading />;
  }

  return <Editor />;
}
