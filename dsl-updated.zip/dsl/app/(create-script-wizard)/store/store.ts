import { configureStore } from '@reduxjs/toolkit';
import widgetEditorSlice from './slices/widgetEditor.slice';

const store = configureStore({
  reducer: {
    widgetEditor: widgetEditorSlice
  }
});

export default store;

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
