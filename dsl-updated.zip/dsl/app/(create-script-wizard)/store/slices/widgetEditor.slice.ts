import { deviceFormats, IDeviceFormat } from '../../utils/WidgetEditor/devceFormat';
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const getEmptyPagesList = () => {
  return [
    {
      number: 1,
      deviceFormat: deviceFormats[0]
    },
    {
      number: 2,
      deviceFormat: deviceFormats[0]
    }
  ];
};

export interface IWidgetEditorPage {
  number: number;
  deviceFormat: IDeviceFormat;
}

export interface IWidgetProject {
  title: string;
  description: string;
  selectedPage: number;
  pages: IWidgetEditorPage[];
}

const initialState: IWidgetProject = {
  title: 'New widget',
  description: 'Some description',
  selectedPage: 1,
  pages: getEmptyPagesList()
};

export const widgetEditorSlice = createSlice({
  name: 'widgetEditor',
  initialState,
  reducers: {
    changeWidgetProjectPage(state, pageNumber: PayloadAction<number>) {
      state.selectedPage = pageNumber.payload;
    },
    changeFormatDevice(state, format: PayloadAction<IDeviceFormat>) {
      const currentPage = state.pages.find(page => page.number === state.selectedPage);
      currentPage!.deviceFormat = format.payload;
    },
  }
});

export const {
  changeWidgetProjectPage,
  changeFormatDevice,
} = widgetEditorSlice.actions;
export default widgetEditorSlice.reducer;
