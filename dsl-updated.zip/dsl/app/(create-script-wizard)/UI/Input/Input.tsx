import React from 'react';
import classNames from 'classnames';

type InputProps = {
  label?: string;
  error?: string;
} & React.InputHTMLAttributes<HTMLInputElement>;

export const Input: React.FC<InputProps> = ({ label, error, ...props }) => {
  return (
    <div className={classNames({ 'opacity-50 pointer-events-none': props.disabled }, 'flex flex-col gap-1.5')}>
      {label ? <div className="text-sm font-medium">{label}</div> : null}
      <input
        {...props}
        className={classNames(
          { 'border-red-600': error, 'active:border-dsl-purple-700 hover:border-dsl-purple-700': !error },
          'border border-transparent px-4 py-2 bg-white bg-opacity-10 rounded-md p-2 text-custom-gray-100 text-xs font-medium outline-none'
        )}
      />
      {error ? <div className="text-xs text-red-600">{error}</div> : null}
    </div>
  );
};
