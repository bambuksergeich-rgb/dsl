import React, { useMemo } from 'react';
import classNames from 'classnames';
import SquareButton from '../SquareButton/SquareButton';
import { ArrowRightIcon } from '../../icons/ArrowRight.icon';

interface IListSelectorProps {
  selectedItem: number;
  allItemsCount: number;
  onLeftClick: () => void;
  onRightClick: () => void;
  size?: 'sm' | 'md';
}

const ListSelector = ({
  selectedItem,
  allItemsCount,
  onLeftClick,
  onRightClick,
  size
}: IListSelectorProps) => {
  const isLeftNotActive = useMemo(() => {
    return selectedItem === 1;
  }, [selectedItem]);

  const isRightNotActive = useMemo(() => {
    return selectedItem === allItemsCount;
  }, [selectedItem, allItemsCount]);

  return (
    <div className='flex gap-widget-header'>
      <SquareButton
        size={size}
        onClick={isLeftNotActive ? () => {} : onLeftClick}
      >
        <div
          className={classNames(
            {
              'opacity-30': isLeftNotActive,
              'opacity-100 cursor-pointer': !isLeftNotActive
            },
            'rotate-180'
          )}
        >
          <ArrowRightIcon />
        </div>
      </SquareButton>
      <SquareButton size={size}>
        {`${selectedItem} / ${allItemsCount}`}
      </SquareButton>
      <SquareButton
        size={size}
        onClick={isRightNotActive ? () => {} : onRightClick}
      >
        <div
          className={classNames({
            'opacity-30': isRightNotActive,
            'opacity-100 cursor-pointer': !isRightNotActive
          })}
        >
          <ArrowRightIcon />
        </div>
      </SquareButton>
    </div>
  );
};

export default ListSelector;
