import React from 'react';
import classNames from 'classnames';

type TextareaProps = {
  label?: string;
} & React.TextareaHTMLAttributes<HTMLTextAreaElement>;

export const Textarea: React.FC<TextareaProps> = ({ label, ...props }) => {
  return (
    <div className={classNames({ 'opacity-50 pointer-events-none': props.disabled }, 'flex flex-col gap-1.5')}>
      {label ? <div className="text-sm font-medium">{label}</div> : null}
      <textarea
        {...props}
        className="text-xs min-h-28 max-h-40 border border-transparent active:border-dsl-purple-700 hover:border-dsl-purple-700 px-4 py-2 bg-white bg-opacity-10 rounded-md p-2 text-custom-gray-100 font-medium outline-none"
      ></textarea>
    </div>
  );
};
