import React, { useEffect } from 'react';
import classNames from 'classnames';
import { Button } from '../Button/Button';
import clsx from 'clsx';
import { AddCircleOutlineIcon, ShevronDownIcon } from '@/assets/icons';

export interface OptionType {
  value: string;
  label: string;
}

export interface ExtendableType {
  label: string;
  onClick: () => void;
}

interface SelectProps {
  options: OptionType[];
  onChange?: (option: OptionType) => void;
  activeOption?: OptionType;
  disabled?: boolean;
  size?: 'sm' | 'md';
  label?: string;
  placeholder?: string;
  extendable?: ExtendableType;
  className?: string;
  color?: 'primary' | 'secondary';
  onOpen?: () => void;
  onClose?: () => void;
  mainStyles?: React.CSSProperties;
}

export const Select: React.FC<SelectProps> = ({
  options,
  activeOption,
  onChange = () => {},
  disabled,
  size = 'md',
  className,
  label,
  placeholder,
  extendable,
  color = 'secondary',
  onOpen,
  onClose,
  mainStyles
}: SelectProps) => {
  const isSmall = size === 'sm';
  const isMedium = size === 'md';

  const [open, setOpen] = React.useState<boolean>(false);

  const primaryStyles = 'bg-dsl-purple-700';
  const secondaryStyles = 'bg-white bg-opacity-10';

  const onCloseSelect = () => setOpen(false);
  const onChangeSelectOption = (option: OptionType) => {
    onChange(option);
    setOpen(false);
  };
  const onBodyOpenToggle = () => {
    setOpen((prev) => !prev);
  };

  useEffect(() => {
    if (open && onOpen) {
      onOpen();
    } else if (!open && onClose) {
      onClose();
    }
  }, [open]);

  return (
    <div
      className={clsx('flex flex-col gap-1.5', className)}
      style={mainStyles}
    >
      {label ? <div className='text-sm font-medium '>{label}</div> : null}
      <div
        className={classNames(
          { 'opacity-50 pointer-events-none': disabled },
          'relative z-30'
        )}
      >
        <button
          className={classNames(
            {
              'rounded-b-md': !open,
              'h-[44px] py-3 text-sm': isMedium,
              'h-[36px] py-1.5 text-xs': isSmall,
              [primaryStyles]: color === 'primary',
              [secondaryStyles]: color === 'secondary'
            },
            'flex items-center justify-between  gap-4 px-4  w-full rounded-t-md leading-none '
          )}
          type='button'
          onClick={onBodyOpenToggle}
        >
          <div
            className={classNames(
              {
                'h-[36px]': isSmall,
                'h-[44px]': isMedium
              },
              'absolute top-0 left-0 text-left pl-2 overflow-hidden whitespace-nowrap text-ellipsis'
            )}
            style={{ width: `calc(100% - ${isSmall ? 36 : 44}px)` }}
          >
            <span
              className={classNames({
                'leading-[36px]': isSmall,
                'leading-[44px]': isMedium
              })}
            >
              {activeOption
                ? // @ts-ignore

                  (activeOption?.name ?? activeOption.label)
                : placeholder
                  ? placeholder
                  : 'Select option...'}
            </span>
          </div>
          <div
            className={classNames(
              {
                'h-[36px] w-[36px]': isSmall,
                'h-[44px] w-[44px]': isMedium
              },
              'absolute top-0 right-0 flex justify-center items-center'
            )}
          >
            <ShevronDownIcon stroke='white' />
          </div>
        </button>
        {open ? (
          <div className='border border-dsl-gray-800 absolute left-0 top-full flex flex-col pt-1 pb-2 bg-black selector-scroll-drop-down-list rounded-b-md overflow-hidden'>
            {options.map((option) => {
              return (
                <button
                  className={classNames(
                    {
                      'py-2': isSmall,
                      'py-3': isMedium
                    },
                    'active-option flex !px-5 text-sm'
                  )}
                  type='button'
                  key={option.value + option.label}
                  onClick={() => {
                    onChangeSelectOption(option);
                  }}
                >
                  {option.label}
                </button>
              );
            })}
            {extendable ? (
              <div className='px-4 mt-2'>
                <Button
                  type='button'
                  icon={AddCircleOutlineIcon}
                  size='sm'
                  onClick={extendable.onClick}
                >
                  {extendable.label}
                </Button>
              </div>
            ) : null}
          </div>
        ) : null}
      </div>
      {open ? (
        <div
          className='fixed left-0 top-0 w-screen h-screen z-20'
          onClick={onCloseSelect}
        ></div>
      ) : null}
    </div>
  );
};
