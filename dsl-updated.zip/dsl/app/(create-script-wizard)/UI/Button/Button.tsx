import React, {ReactNode} from 'react';
import classNames from 'classnames';
import {IconType, ImgType} from "../../utils/WidgetEditor/IWidgetTemplate";

export type ButtonProps = {
    icon?: IconType | ImgType;
    children?: string | ReactNode;
    url?: string;
    color?: 'primary' | 'secondary' | 'dark';
    disabled?: boolean;
    active?: boolean;
    size?: 'sm' | 'md';
    align?: 'left' | 'center' | 'right';
    fitContent?: boolean;
    fontWeight?: 'normal' | 'semibold' | 'bold';
} & React.ButtonHTMLAttributes<HTMLButtonElement>;

export const Button: React.FC<ButtonProps> = ({
                                                  icon,
                                                  children,
                                                  disabled,
                                                  color = 'primary',
                                                  size = 'md',
                                                  active = false,
                                                  url,
                                                  align = 'center',
                                                  fitContent = false,
                                                  fontWeight = 'normal',
                                                  ...props
                                              }) => {
    const isPrimary = color === 'primary';
    const isSecondary = color === 'secondary';
    const isDark = color === 'dark';
    const isSmall = size === 'sm';
    const isMedium = size === 'md';
    const isNormal = fontWeight === 'normal';
    const isSemibold = fontWeight === 'semibold';
    const isBold = fontWeight === 'bold';

    if (!children && icon) {
        fitContent = true;
    }

    const Icon = icon;

    return (
        <button
            {...props}
            className={classNames(
                {
                    'justify-start text-left': align === 'left',
                    'justify-center text-center': align === 'center',
                    'justify-end text-right': align === 'right',
                    'min-w-32 w-full': !fitContent,
                    'p-1 text-sm': isSmall || (isMedium && !children),
                    'p-2.5': isMedium && children,
                    'font-normal': isNormal,
                    'font-semibold': isSemibold,
                    'font-bold': isBold,
                    'bg-dsl-purple-700 hover:bg-dsl-purple-600 active:bg-dsl-purple-500': isPrimary,
                    'bg-dsl-gray-600 hover:bg-dsl-gray-500 active:bg-dsl-gray-400': isSecondary,
                    'text-dsl-gray-100 bg-black hover:bg-dsl-purple-600 active:bg-dsl-purple-500': isDark,
                    '!bg-dsl-purple-600': active,
                    'opacity-50 pointer-events-none': disabled,
                    '!min-w-fit': url,
                },
                `flex items-center gap-2 rounded-md ${props?.className || ''}`
            )}
        >
            {url ? <img className="text-white h-[32px] w-[32px]" src={url} alt="icon"
                        width={size === 'md' ? `32px` : `24px`} height={size === 'md' ? `32px` : `24px`}/> : null}
            {Icon ?
                <Icon className="text-white" width={size === 'md' ? 32 : 24} height={size === 'md' ? 32 : 24}/> : null}
            {children}
        </button>
    );
};
