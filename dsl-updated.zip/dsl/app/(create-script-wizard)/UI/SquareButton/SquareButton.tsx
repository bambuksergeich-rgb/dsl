import React, { ReactNode, useMemo } from 'react';

interface ISquareButtonProps {
  size?: 'sm' | 'md' | 'lg';
  isActive?: boolean;
  isBlue?: boolean;
  children?: ReactNode;
  onClick?: () => void;
  isCursorCounter?: boolean;
}

const SquareButton = ({ size, isActive, isBlue, children, onClick, isCursorCounter }: ISquareButtonProps) => {
  const buttonSize = useMemo(() => {
    switch (size) {
      case 'sm':
        return 36;
      case 'md':
        return 44;
      case 'lg':
        return 52;
    }
    return 36;
  }, [size]);

  const getBackgroundColor = () => {
    if (isActive) {
      return '#2A2B6B';
    } else if (isBlue) {
      return '#4441CC';
    } else {
      return 'rgba(255, 255, 255, .1)';
    }
  };

  const getBorder = () => {
    if (isActive) {
      return '1px solid #4170FF';
    } else {
      return 'none';
    }
  };

  const buttonStyle = {
    height: `${buttonSize}px`,
    width: `${buttonSize}px`,
    borderRadius: '5px',
    backgroundColor: getBackgroundColor(),
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    cursor: isCursorCounter ? 'pointer' : 'default',
    border: getBorder(),
  };

  return (
    <div className="flex gap-widget-header">
      <div style={buttonStyle} onClick={onClick}>
        {children}
      </div>
    </div>
  );
};

export default SquareButton;
