import CssIcon from '@/public/icons/widgetEditor/Css.icon';
import HtmlIcon from '@/public/icons/widgetEditor/Html.icon';
import JavascriptIcon from '@/public/icons/widgetEditor/Javascript.icon';
import { INode } from '@/src/components';
import CodeMirrorComponent from '@/src/components/CodeMirror/CodeMirrorComponent';
import { SideBarRedactor } from '@/src/components/SideBarRedactor/SideBarRedactor';
import { WidgetTemplateDraft } from '@/src/store/counter/widgetTemplateDraftSlice';
import {
  addWidgetTemplateFiles,
  removeWidgetTemplateFiles,
  setWidgetTemplateFiles,
  WidgetTemplateFile
} from '@/src/store/counter/widgetTemplateFilesSlice';
import { store } from '@/src/store/store';
import { TabMUIButton } from '@/src/styles/muiButtonStyles';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { EAssetResourceType } from '@/types/apiTypes';
import { Grid } from '@mui/material';
import { WIDGET_EDITOR_DESIGN } from '@/src/components/WidgetSettingsBuilder/widgetEditorDesignTokens';
import { Box, Stack } from '@mui/system';
import {
  Dispatch,
  SetStateAction,
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState
} from 'react';

const D = WIDGET_EDITOR_DESIGN;

export const OneEditorWindow = ({
  setEditorMode,
  editorMode,
  widgetTemplateFiles,
  widgetTemplateDraft,
  setEditorType,
  editorType,
  filesContent,
  setFilesContent,
  previewUrl,
  onOpenVisualization,
  isPreviewSaving = false,
  widgetTemplateId,
  onFileSaved,
  figmaWidgetLayout = false
}: {
  setEditorMode: Dispatch<SetStateAction<string>>;
  editorMode: string;
  widgetTemplateFiles: WidgetTemplateFile[];
  widgetTemplateDraft: WidgetTemplateDraft;
  setEditorType: Dispatch<SetStateAction<string>>;
  editorType: string;
  filesContent: Record<string, string>;
  setFilesContent: Dispatch<SetStateAction<Record<string, string>>>;
  previewUrl?: string;
  onOpenVisualization?: () => Promise<void> | void;
  isPreviewSaving?: boolean;
  widgetTemplateId?: string;
  onFileSaved?: () => void;
  figmaWidgetLayout?: boolean;
}) => {
  const currentFileId = editorMode !== 'Visualization' ? editorMode : null;
  const editorRootRef = useRef<HTMLDivElement | null>(null);
  const editorDocumentTopRef = useRef<number | null>(null);
  const [availableHeight, setAvailableHeight] = useState<number | null>(null);

  const updateAvailableHeight = useCallback((remeasureTop = false) => {
    const root = editorRootRef.current;
    if (!root || typeof window === 'undefined') return;

    if (remeasureTop || editorDocumentTopRef.current == null) {
      editorDocumentTopRef.current = Math.max(
        0,
        root.getBoundingClientRect().top + window.scrollY
      );
    }

    const viewportHeight = window.visualViewport?.height ?? window.innerHeight;
    const documentTop = editorDocumentTopRef.current ?? 0;
    const bottomGap = 40;
    const minHeight = 320;
    const nextHeight = Math.max(
      minHeight,
      Math.floor(viewportHeight - documentTop - bottomGap)
    );

    setAvailableHeight((current) =>
      current === nextHeight ? current : nextHeight
    );
  }, []);

  useLayoutEffect(() => {
    updateAvailableHeight(true);
  }, [updateAvailableHeight, widgetTemplateDraft.draftId]);

  useEffect(() => {
    let frame = 0;
    const scheduleMeasure = () => {
      window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(() => updateAvailableHeight());
    };

    window.addEventListener('resize', scheduleMeasure);
    window.visualViewport?.addEventListener('resize', scheduleMeasure);

    return () => {
      window.cancelAnimationFrame(frame);
      window.removeEventListener('resize', scheduleMeasure);
      window.visualViewport?.removeEventListener('resize', scheduleMeasure);
    };
  }, [updateAvailableHeight]);

  useEffect(() => {
    const root = editorRootRef.current;
    if (!root || typeof ResizeObserver === 'undefined') return;

    const blockAbove = root.previousElementSibling;
    if (!(blockAbove instanceof HTMLElement)) return;

    let frame = 0;
    const observer = new ResizeObserver(() => {
      window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(() => updateAvailableHeight(true));
    });

    observer.observe(blockAbove);

    return () => {
      window.cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, [updateAvailableHeight]);

  const handleSelectFile = (id: string) => {
    setEditorMode(id);
    const file = widgetTemplateFiles.find((f) => f.id === id);
    if (file) setEditorType(file.contentType);
  };

  const codeInFile = currentFileId ? (filesContent[currentFileId] ?? '') : '';

  const updateCurrentFile = (value: string) => {
    if (!currentFileId) return;
    setFilesContent((prev) => ({ ...prev, [currentFileId]: value }));
  };

  return (
    <Box
      ref={editorRootRef}
      sx={{
        display: 'flex',
        margin: figmaWidgetLayout ? `0 ${D.gutter}px ${D.gutter}px ${D.gutter}px` : '0 40px 40px 40px',
        backgroundColor: '#10161C80',
        borderRadius: figmaWidgetLayout ? '2px' : '6px',
        width: figmaWidgetLayout ? `calc(100% - ${D.gutter * 2}px)` : 'calc(100% - 80px)',
        height: availableHeight ? `${availableHeight}px` : 'calc(100dvh - 320px)',
        minHeight: '320px',
        maxHeight: 'calc(100dvh - 40px)',
        overflow: 'hidden'
      }}
    >
      <Grid
        sx={{
          display: 'inline-grid',
          width: '100%',
          height: '100%',
          minHeight: 0,
          gridTemplateColumns: figmaWidgetLayout ? `${D.code.sidebarWidth}px minmax(0, 1fr)` : '1fr 5fr'
        }}
      >
        <Box sx={{ position: 'relative', minHeight: 0, overflow: 'hidden' }}>
          <SideBarRedactor
            setCurrentId={handleSelectFile}
            currentId={editorMode}
                        assetList={(widgetTemplateFiles as INode[]) || []}
            instanceInfo={{
              draftId: widgetTemplateDraft.draftId,
              sourceId: widgetTemplateDraft.sourceId,
              type: EAssetResourceType.WIDGET_TEMPLATE
            }}
            addItemToList={(item) =>
              store.dispatch(addWidgetTemplateFiles(item))
            }
            removeItemsFromList={(itemsIds) =>
              store.dispatch(removeWidgetTemplateFiles(itemsIds))
            }
            figmaWidgetLayout={figmaWidgetLayout}
            setAssetList={(newList) =>
              store.dispatch(setWidgetTemplateFiles(newList))
            }
          />
        </Box>
        <Box sx={{ height: '100%', minHeight: 0, overflow: 'hidden' }}>
          <Grid
            sx={{
              height: '100%',
              minHeight: 0,
              gridTemplateRows: figmaWidgetLayout
                ? '38px minmax(0, 1fr)'
                : '52px 38px minmax(0, 1fr)',
              display: 'grid'
            }}
          >
            {!figmaWidgetLayout && (
              <Stack
                flexDirection='row'
                sx={{ padding: '0 12px', alignItems: 'center' }}
              >
                <TypographyMontserrat500 fontSize='16px'>
                  Widget code
                </TypographyMontserrat500>
              </Stack>
            )}

            {/* TABS WITH SCROLL */}
            <Stack
              flexDirection='row'
              sx={{
                height: '40px',
                padding: '4px 4px 4px 4px',
                gap: '4px',
                width: '100%',
                overflowX: 'auto',
                whiteSpace: 'nowrap',
                '&::-webkit-scrollbar': { height: '4px' },
                '&::-webkit-scrollbar-track': {
                  background: 'transparent'
                },
                '&::-webkit-scrollbar-thumb': {
                  background: '#444',
                  borderRadius: '4px'
                },
                '&::-webkit-scrollbar-thumb:hover': { background: '#666' }
              }}
            >
              {widgetTemplateFiles?.map((file) => (
                <Box
                  key={file.id}
                  sx={{ flexShrink: 0 }}
                >
                  <TabMUIButton
                    selected={editorMode === file.id}
                    sx={figmaWidgetLayout ? { minWidth: `${D.tab.width}px`, width: `${D.tab.width}px`, height: `${D.tab.height}px`, borderRadius: '2px 2px 0 0' } : undefined}
                    onClick={() => {
                      setEditorMode(file.id);
                      setEditorType(file.contentType);
                    }}
                  >
                    {file.contentType === 'text/html' && <HtmlIcon />}
                    {file.contentType === 'text/javascript' && (
                      <JavascriptIcon />
                    )}
                    {file.contentType === 'text/css' && <CssIcon />}
                    <TypographyMontserrat500
                      sx={{ fontSize: figmaWidgetLayout ? `${D.tab.fontSize}px` : '14px', whiteSpace: 'nowrap' }}
                    >
                      {figmaWidgetLayout
                        ? file.contentType === 'text/html'
                          ? 'HTML'
                          : file.contentType === 'text/javascript'
                            ? 'Java Script'
                            : file.contentType === 'text/css'
                              ? 'CSS'
                              : file.name
                        : file.name}
                    </TypographyMontserrat500>
                  </TabMUIButton>
                </Box>
              ))}

              <Box
                sx={{
                  flexShrink: 0,
                  position: 'sticky',
                  right: 0,
                  zIndex: 2,
                  backgroundColor: '#10161C',
                  borderLeft: '1px solid #FFFFFF26'
                }}
              >
                <TabMUIButton
                  selected={editorMode === 'Visualization'}
                  sx={figmaWidgetLayout ? { minWidth: `${D.tab.width}px`, width: `${D.tab.width}px`, height: `${D.tab.height}px`, borderRadius: '2px 2px 0 0' } : undefined}
                  onClick={async () => {
                    setEditorMode('Visualization');
                    setEditorType('Visualization');
                    await onOpenVisualization?.();
                  }}
                >
                  <TypographyMontserrat500 sx={{ fontSize: figmaWidgetLayout ? `${D.tab.fontSize}px` : '14px' }}>
                    Visualization
                  </TypographyMontserrat500>
                </TabMUIButton>
              </Box>
            </Stack>

            <Stack
              sx={{
                borderTop: '1px solid #FFFFFF26',
                width: '100%',
                minHeight: 0,
                overflow: 'hidden',
                padding: figmaWidgetLayout ? '12px 12px 0 12px' : '20px 20px 0 20px',
                boxSizing: 'border-box'
              }}
            >
              <Box
                sx={{
                  width: '100%',
                  height: '100%',
                  minHeight: 0,
                  overflow: 'hidden',
                  backgroundColor: '#10161C',
                  borderRadius: '6px'
                }}
              >
                {editorMode === 'Visualization' ? (
                  <Box
                    sx={{
                      width: '100%',
                      height: '100%',
                      backgroundColor: '#10161C',
                      borderRadius: '6px'
                    }}
                  >
                    {isPreviewSaving ? (
                      <Stack
                        alignItems='center'
                        justifyContent='center'
                        sx={{ width: '100%', height: '100%' }}
                      >
                        <TypographyMontserrat500 sx={{ fontSize: '14px' }}>
                          Saving preview...
                        </TypographyMontserrat500>
                      </Stack>
                    ) : previewUrl ? (
                      <iframe
                        height='100%'
                        width='100%'
                        src={previewUrl}
                        style={{ border: 'none' }}
                        title='Widget Preview'
                      />
                    ) : null}
                  </Box>
                ) : currentFileId ? (
                  <CodeMirrorComponent
                    key={currentFileId}
                    fileId={currentFileId}
                    visualistation={previewUrl || ''}
                    language={editorType}
                    editorType={editorType}
                    tiled={false}
                    fixedHeight='100%'
                    codeInFile={codeInFile}
                    setHtmlContent={(v) => updateCurrentFile(v as string)}
                    setCssContent={(v) => updateCurrentFile(v as string)}
                    setJsContent={(v) => updateCurrentFile(v as string)}
                    widgetTemplateId={widgetTemplateId}
                    widgetTemplateDraft={widgetTemplateDraft}
                    widgetTemplateFiles={widgetTemplateFiles}
                    filesContent={filesContent}
                    setFilesContent={setFilesContent}
                    onFileSaved={onFileSaved}
                  />
                ) : null}
              </Box>
            </Stack>
          </Grid>
        </Box>
      </Grid>
    </Box>
  );
};
