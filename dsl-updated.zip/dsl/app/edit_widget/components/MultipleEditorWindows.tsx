'use client';

import CssIcon from '@/public/icons/widgetEditor/Css.icon';
import HtmlIcon from '@/public/icons/widgetEditor/Html.icon';
import JavascriptIcon from '@/public/icons/widgetEditor/Javascript.icon';
import TabSign from '@/src/components/CodeEditorLayout/TabSign';
import CodeMirrorComponentTiled from '@/src/components/CodeMirror/CodeMirrorComponentTiled';
import { WidgetTemplateDraft } from '@/src/store/counter/widgetTemplateDraftSlice';
import { WidgetTemplateFile } from '@/src/store/counter/widgetTemplateFilesSlice';
import { TabMUIButton } from '@/src/styles/muiButtonStyles';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { Grid, Stack, Box } from '@mui/material';
import { Dispatch, SetStateAction } from 'react';
import { WIDGET_EDITOR_DESIGN as D } from '@/src/components/WidgetSettingsBuilder/widgetEditorDesignTokens';

export const MultipleEditorWindows = ({
  widgetTemplateFiles,
  filesContent,
  setFilesContent,
  activeHtmlId,
  activeCssId,
  activeJsId,
  setActiveHtmlId,
  setActiveCssId,
  setActiveJsId,
  previewUrl,
  widgetTemplateId,
  widgetTemplateDraft,
  onFileSaved,
  figmaWidgetLayout = false
}: {
  widgetTemplateFiles: WidgetTemplateFile[];
  filesContent: Record<string, string>;
  setFilesContent: Dispatch<SetStateAction<Record<string, string>>>;
  activeHtmlId: string | null;
  activeCssId: string | null;
  activeJsId: string | null;
  setActiveHtmlId: Dispatch<SetStateAction<string | null>>;
  setActiveCssId: Dispatch<SetStateAction<string | null>>;
  setActiveJsId: Dispatch<SetStateAction<string | null>>;
  previewUrl: string;
  widgetTemplateId?: string;
  widgetTemplateDraft?: WidgetTemplateDraft;
  onFileSaved?: () => void;
  figmaWidgetLayout?: boolean;
}) => {
  const updateFile = (id: string, value: string) =>
    setFilesContent((prev) => ({ ...prev, [id]: value }));

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'left',
        margin: figmaWidgetLayout ? `0 ${D.gutter}px ${D.gutter}px` : '0 40px 40px 40px',
        width: figmaWidgetLayout ? `calc(100% - ${D.gutter * 2}px)` : 'calc(100% - 80px)',
        minHeight: 0,
        height: '100%',
        overflow: 'hidden'
      }}
    >
      <Grid
        sx={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          width: '100%',
          gap: '14px'
        }}
      >
        <Grid sx={{ display: 'grid', gridTemplateRows: '1fr 1fr' }}>
          <Grid
            sx={{
              display: 'grid',
              gridTemplateRows: '34px 1fr',
              width: '100%',
              height: '96.5%',
              gap: '4px'
            }}
          >
            <Stack
              flexDirection='row'
              gap='2px'
            >
              {widgetTemplateFiles
                .filter((f) => f.contentType === 'text/html')
                .map((f) => (
                  <TabMUIButton
                    key={f.id}
                    selected={activeHtmlId === f.id}
                    onClick={() => setActiveHtmlId(f.id)}
                  >
                    <HtmlIcon />
                    <TypographyMontserrat500 sx={{ fontSize: '14px' }}>
                      {f.name}
                    </TypographyMontserrat500>
                  </TabMUIButton>
                ))}
            </Stack>
            <CodeMirrorComponentTiled
              fileId={activeHtmlId ?? ''}
              language='HTML'
              visualistation={previewUrl}
              editorType='text/html'
              codeInFile={filesContent[activeHtmlId ?? ''] || ''}
              setHtmlContent={(v) => updateFile(activeHtmlId!, v as string)}
              setCssContent={() => {}}
              setJsContent={() => {}}
              widgetTemplateId={widgetTemplateId}
              widgetTemplateDraft={widgetTemplateDraft}
              widgetTemplateFiles={widgetTemplateFiles}
              filesContent={filesContent}
              setFilesContent={setFilesContent}
              onFileSaved={onFileSaved}
            />
          </Grid>
          <Grid
            sx={{
              display: 'grid',
              gridTemplateRows: '34px 1fr',
              width: '100%',
              height: '96.5%',
              gap: '4px'
            }}
          >
            <Stack
              flexDirection='row'
              gap='2px'
            >
              {widgetTemplateFiles
                .filter((f) => f.contentType === 'text/css')
                .map((f) => (
                  <TabMUIButton
                    key={f.id}
                    selected={activeCssId === f.id}
                    onClick={() => setActiveCssId(f.id)}
                  >
                    <CssIcon />
                    <TypographyMontserrat500 sx={{ fontSize: '14px' }}>
                      {f.name}
                    </TypographyMontserrat500>
                  </TabMUIButton>
                ))}
            </Stack>
            <CodeMirrorComponentTiled
              fileId={activeCssId ?? ''}
              language='CSS'
              visualistation={previewUrl}
              editorType='text/css'
              codeInFile={filesContent[activeCssId ?? ''] || ''}
              setCssContent={(v) => updateFile(activeCssId!, v as string)}
              setHtmlContent={() => {}}
              setJsContent={() => {}}
              widgetTemplateId={widgetTemplateId}
              widgetTemplateDraft={widgetTemplateDraft}
              widgetTemplateFiles={widgetTemplateFiles}
              filesContent={filesContent}
              setFilesContent={setFilesContent}
              onFileSaved={onFileSaved}
            />
          </Grid>
        </Grid>
        <Grid sx={{ display: 'grid', gridTemplateRows: '1fr 1fr' }}>
          <Grid
            sx={{
              display: 'grid',
              gridTemplateRows: '34px 1fr',
              width: '100%',
              height: '96.5%',
              gap: '4px'
            }}
          >
            <Stack
              flexDirection='row'
              gap='2px'
            >
              {widgetTemplateFiles
                .filter((f) => f.contentType === 'text/javascript')
                .map((f) => (
                  <TabMUIButton
                    key={f.id}
                    selected={activeJsId === f.id}
                    onClick={() => setActiveJsId(f.id)}
                  >
                    <JavascriptIcon />
                    <TypographyMontserrat500 sx={{ fontSize: '14px' }}>
                      {f.name}
                    </TypographyMontserrat500>
                  </TabMUIButton>
                ))}
            </Stack>
            <CodeMirrorComponentTiled
              fileId={activeJsId ?? ''}
              language='JavaScript'
              visualistation={previewUrl}
              editorType='text/javascript'
              codeInFile={filesContent[activeJsId ?? ''] || ''}
              setJsContent={(v) => updateFile(activeJsId!, v as string)}
              setHtmlContent={() => {}}
              setCssContent={() => {}}
              widgetTemplateId={widgetTemplateId}
              widgetTemplateDraft={widgetTemplateDraft}
              widgetTemplateFiles={widgetTemplateFiles}
              filesContent={filesContent}
              setFilesContent={setFilesContent}
              onFileSaved={onFileSaved}
            />
          </Grid>
          <Grid
            sx={{
              display: 'grid',
              gridTemplateRows: '34px 1fr',
              width: '100%',
              height: '96.5%',
              gap: '4px'
            }}
          >
            <Stack flexDirection='row'>
              <TabSign
                TabName='Visualization'
                useInTile
              />
            </Stack>
            <Stack
              flexDirection='row'
              sx={{
                backgroundColor: '#10161C80',
                borderRadius: '6px',
                overflow: 'hidden'
              }}
            >
              <iframe
                height='100%'
                width='100%'
                src={previewUrl}
                style={{ border: 'none' }}
              />
            </Stack>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
};
