import React from 'react';
import { Box, Button, Checkbox, Typography } from '@mui/material';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { CloseIcon } from '@/assets/icons';
import { useFieldArray, useFormContext } from 'react-hook-form';
import { PlusIcon } from '@/public/icons/Plus.icon';
import { v4 as uuidv4 } from 'uuid';
import classNames from 'classnames';

const MappingEditor = ({ close }: { close: () => void }) => {
  const { control, register } = useFormContext();

  const { fields, append, remove } = useFieldArray({ name: 'items', control });

  const onAddItem = () => {
    append({
      id: uuidv4(),
      name: '',
      key: `Value ${fields.length + 1}`,
      multiple: false
    });
  };

  return (
    <Box
      className='flex flex-col relative'
      sx={{
        backgroundColor: '#10161C80',
        margin: '0 40px 40px 40px',
        width: 'calc(100% - 80px)',
        height: '50%',
        overflow: 'hidden',
        padding: '12px 12px 12px 12px'
      }}
    >
      <button
        onClick={close}
        className='absolute top-4 right-4 '
      >
        <CloseIcon className='w-4 h-4' />
      </button>
      <TypographyMontserrat500 fontSize={'14px'}>
        Mapping parameters
      </TypographyMontserrat500>
      <div className='flex flex-col gap-4 overflow-y-auto'>
        {!fields.length ? (
          <Typography
            className='text-white'
            fontSize={'14px'}
          >
            No parameters
          </Typography>
        ) : (
          fields.map((row, index) => {
            return (
              <div
                key={row.id}
                className='flex mt-4 min-h-[80px] justify-between flex items-center  bg-[#3D3AB8] mr-4 px-5'
              >
                <div className='flex gap-5'>
                  <input
                    {...register(`items.${index}.key`)}
                    className={classNames(
                      {
                        'active:border-dsl-purple-700 hover:border-dsl-purple-700':
                          true
                      },
                      'border bg-white/20 border-transparent px-4 py-2 bg-white bg-opacity-10 rounded-md p-2 text-custom-gray-100 text-xs font-medium outline-none'
                    )}
                  />
                  <input
                    {...register(`items.${index}.name`)}
                    placeholder='Enter parameter key'
                    className={classNames(
                      {
                        'active:border-dsl-purple-700 hover:border-dsl-purple-700':
                          true
                      },
                      'border bg-white/20 border-transparent px-4 py-2 bg-white bg-opacity-10 rounded-md p-2 text-custom-gray-100 text-xs font-medium outline-none'
                    )}
                  />
                </div>
                <div className='gap-10 flex  items-center'>
                  <div className='flex items-center gap-2.5'>
                    <Checkbox
                      sx={{ color: 'rgba(255, 255, 255, 0.15)' }}
                      size='medium'
                      className='h-6 w-6'
                      disableTouchRipple={true}
                    />
                    <Typography
                      sx={{
                        color: '#FFFFFF',
                        fontFamily: 'Montserrat',
                        fontSize: '16px',
                        fontStyle: 'normal',
                        fontWeight: '500'
                      }}
                    >
                      Required Field
                    </Typography>
                  </div>
                  <div className='flex items-center gap-2.5'>
                    <Checkbox
                      {...register(`items.${index}.multiple`, {})}
                      sx={{ color: 'rgba(255, 255, 255, 0.15)' }}
                      size='medium'
                      className='h-6 w-6'
                      disableTouchRipple={true}
                    />
                    <Typography
                      sx={{
                        color: '#FFFFFF',
                        fontFamily: 'Montserrat',
                        fontSize: '16px',
                        fontStyle: 'normal',
                        fontWeight: '500'
                      }}
                    >
                      Multiple
                    </Typography>
                  </div>
                  <div className='flex items-center gap-[25px]'>
                    <Button
                      sx={{
                        width: '137px',
                        height: '34px',
                        borderRadius: '6px',
                        backgroundColor: '#4170FF',
                        textTransform: 'initial'
                      }}
                    >
                      <TypographyMontserrat500 sx={{ fontSize: '16px' }}>
                        ADD CSS UI
                      </TypographyMontserrat500>
                    </Button>
                    <Button
                      onClick={() => remove(index)}
                      sx={{
                        width: '137px',
                        height: '34px',
                        borderRadius: '6px',
                        backgroundColor: '#4170FF',
                        textTransform: 'initial'
                      }}
                    >
                      <TypographyMontserrat500 sx={{ fontSize: '16px' }}>
                        Remove
                      </TypographyMontserrat500>
                    </Button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
      <div className='flex py-5 mt-auto justify-center '>
        <button
          onClick={onAddItem}
          className='bg-[#3D3AB8] h-11 w-[596px] rounded flex items-center justify-center'
        >
          <PlusIcon />
        </button>
      </div>
    </Box>
  );
};

export default MappingEditor;
