'use client';

import WidgetEditorSubHeader from '@/src/components/AllSubHeaders/WidgetEditorSubHeader/WidgetEditorSubHeader';
import WidgetEditorDesignTabs from '@/src/components/WidgetSettingsBuilder/WidgetEditorDesignTabs';
import { useWidgetTemplateDraftPreview } from '@/src/hooks/useWidgetTemplateDraftPreview';
import { getCodeFromWidgetTemplateFile } from '@/src/requests/getCodeFromWidgetTemplateFile';
import { ensureWidgetTemplateDraft } from '@/src/store/actions/createWidgetTemplateDraft';
import { getGroupsAction } from '@/src/store/actions/getGroupsAction';
import { getWidgetTemplateFiles } from '@/src/store/actions/getWidgetTemplateFiles';
import { widgetTemplateFilesGet } from '@/src/store/counter/widgetTemplateFilesSlice';
import { State } from '@/src/store/initialState';
import { store } from '@/src/store/store';
import { Box } from '@mui/system';
import { resolveFileContentType } from '@/src/helpers/resolveFileContentType';
import { useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { getWidgetTemplateDraftMappingsAction } from '@/src/store/actions/getWidgetTemplateDraftMappingsAction';
import { getWidgetTemplateConfigurationsAction } from '@/src/store/actions/WidgetTemplateConfigurations/getWidgetTemplateConfigurationsAction';
import { OneEditorWindow } from './components/OneEditorWindow';
import { persistWidgetTemplateDraftIdInCurrentUrl } from '@/src/utils/widgetTemplateDraftUrl';
import { MultipleEditorWindows } from './components/MultipleEditorWindows';

export default function EditWidget() {
  const dispatch = useDispatch();
  const searchParams = useSearchParams();

  const [displaysOption, setDisplaysOption] = useState(false);
  const [editorMode, setEditorMode] = useState('');
  const [editorType, setEditorType] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const [widgetTemplateId, setWidgetTemplateId] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [openInfoModal, setOpenInfoModal] = useState(false);

  const [filesContent, setFilesContent] = useState<Record<string, string>>({});
  const [savedContent, setSavedContent] = useState<Record<string, string>>({});

  const markFilesSaved = useCallback((uploaded: Record<string, string>) => {
    setSavedContent((prev) => ({ ...prev, ...uploaded }));
  }, []);

  const [activeHtmlId, setActiveHtmlId] = useState<string | null>(null);
  const [activeCssId, setActiveCssId] = useState<string | null>(null);
  const [activeJsId, setActiveJsId] = useState<string | null>(null);

  const methods = useForm({ defaultValues: { items: [] } });

  const rawWidgetTemplateFiles = useSelector(
    (state: State) => state.widgetTemplateFiles
  );
  const widgetTemplateFiles = useMemo(
    () =>
      rawWidgetTemplateFiles.map((file) => ({
        ...file,
        contentType: resolveFileContentType(file.name, file.contentType)
      })),
    [rawWidgetTemplateFiles]
  );
  const widgetTemplateDraft = useSelector(
    (state: State) => state.widgetTemplateDraft
  );
  useEffect(() => {
    if (searchParams.get('openInfo') === '1') {
      setOpenInfoModal(true);
    }
  }, [searchParams]);

  useEffect(() => {
    const widgetId = searchParams.get('widgetTemplateId');
    const depId = searchParams.get('departmentId');
    if (widgetId) setWidgetTemplateId(widgetId);
    if (depId) setDepartmentId(depId);
  }, [searchParams]);

  useEffect(() => {
    if (!widgetTemplateId) return;
    setFilesContent({});
    setSavedContent({});
    setActiveHtmlId(null);
    setActiveCssId(null);
    setActiveJsId(null);
    setEditorMode('');
    setEditorType('');
    dispatch(widgetTemplateFilesGet([]));
  }, [widgetTemplateId, dispatch]);

  useEffect(() => {
    const requestedDraftId =
      searchParams.get('widgetTemplateDraftId') || undefined;
    if (!departmentId || (!widgetTemplateId && !requestedDraftId)) return;

    void store
      .dispatch(
        ensureWidgetTemplateDraft(
          departmentId,
          widgetTemplateId || undefined,
          requestedDraftId
        ) as any
      )
      .then((draft: any) => {
        if (draft?.draftId) {
          persistWidgetTemplateDraftIdInCurrentUrl(draft.draftId);
        }
        const restoredSourceId = String(draft?.sourceId || '').trim();
        if (!widgetTemplateId && restoredSourceId) {
          setWidgetTemplateId(restoredSourceId);
        }
      })
      .catch((error: unknown) => {
        console.error('[EditWidget] Unable to initialize widget draft', error);
      });
  }, [departmentId, widgetTemplateId, searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getGroupsAction(departmentId, 'WIDGET_TEMPLATE'));
    }
  }, [departmentId]);

  useEffect(() => {
    if (!widgetTemplateDraft.draftId) return;

    store.dispatch(
      getWidgetTemplateDraftMappingsAction(
        widgetTemplateDraft.draftId,
        Array.isArray(widgetTemplateDraft.mappings)
          ? widgetTemplateDraft.mappings
          : [],
      ) as any,
    );
  }, [widgetTemplateDraft.draftId, widgetTemplateDraft.mappings]);

  useEffect(() => {
    if (widgetTemplateDraft.name) {
      setName(widgetTemplateDraft.name);
      setDescription(widgetTemplateDraft.description);
    }
  }, [widgetTemplateDraft]);

  useEffect(() => {
    if (widgetTemplateDraft.draftId) {
      store.dispatch(
        getWidgetTemplateFiles(
          widgetTemplateDraft.draftId,
          widgetTemplateDraft.sourceId
        )
      );
    }
  }, [widgetTemplateDraft]);

  // Загрузка контента файлов
  useEffect(() => {
    if (!widgetTemplateFiles?.length) return;

    const TEXT_CONTENT_TYPES = ['text/html', 'text/css', 'text/javascript'];

    widgetTemplateFiles.forEach((file) => {
      if (TEXT_CONTENT_TYPES.includes(file.contentType)) {
        getCodeFromWidgetTemplateFile(file.id, (code) => {
          setFilesContent((prev) =>
            Object.prototype.hasOwnProperty.call(prev, file.id)
              ? prev
              : { ...prev, [file.id]: code as string }
          );
          setSavedContent((prev) =>
            Object.prototype.hasOwnProperty.call(prev, file.id)
              ? prev
              : { ...prev, [file.id]: code as string }
          );
        });
      }

      // Устанавливаем активные файлы по умолчанию
      if (file.contentType === 'text/html' && !activeHtmlId) {
        // Приоритет для index.html
        if (file.name === 'index.html') {
          setActiveHtmlId(file.id);
        } else if (!activeHtmlId) {
          setActiveHtmlId(file.id);
        }
      }
      if (file.contentType === 'text/css' && !activeCssId)
        setActiveCssId(file.id);
      if (file.contentType === 'text/javascript' && !activeJsId)
        setActiveJsId(file.id);
    });

    if (!editorMode) {
      const first = widgetTemplateFiles[0];
      if (first) {
        setEditorMode(first.id);
        setEditorType(first.contentType);
      }
    }
  }, [widgetTemplateFiles]);

  const { isPreviewSaving, previewUrl, saveFilesAndRefreshPreview } =
    useWidgetTemplateDraftPreview({
      widgetTemplateDraft,
      widgetTemplateId,
      widgetTemplateFiles,
      filesContent,
      savedContent,
      onFilesSaved: markFilesSaved
    });

  const refreshDraftFiles = useCallback(() => {
    if (widgetTemplateDraft.draftId) {
      store.dispatch(
        getWidgetTemplateFiles(
          widgetTemplateDraft.draftId,
          widgetTemplateDraft.sourceId
        )
      );
    }
  }, [widgetTemplateDraft.draftId, widgetTemplateDraft.sourceId]);

  useEffect(() => {
    const sourceWidgetTemplateId =
      String(widgetTemplateId || widgetTemplateDraft.sourceId || '').trim();
    if (!sourceWidgetTemplateId) return;
    store.dispatch(
      getWidgetTemplateConfigurationsAction(sourceWidgetTemplateId, 'UI')
    );
  }, [widgetTemplateId, widgetTemplateDraft.sourceId]);

  const effectiveWidgetTemplateId =
    String(widgetTemplateId || widgetTemplateDraft.sourceId || '').trim();

  return (
    <FormProvider {...methods}>
      <Box sx={{ width: '100%', height: '100%', overflowY: 'scroll', overflowX: 'hidden', minWidth: 0 }}>
        <WidgetEditorSubHeader
          openMappingEditor={() => void 0}
          pageName={name || widgetTemplateDraft.name || 'Widgets'}
          name={name}
          setName={setName}
          description={description}
          setDescription={setDescription}
          displaysOption={displaysOption}
          setDisplaysOption={setDisplaysOption}
          widgetTemplateId={effectiveWidgetTemplateId}
          widgetTemplateFiles={widgetTemplateFiles}
          widgetTemplateDraft={widgetTemplateDraft}
          departmentId={departmentId}
          openInfoModal={openInfoModal}
          setOpenInfoModal={setOpenInfoModal}
          isNew={false}
          filesContent={filesContent}
          savedContent={savedContent}
          onFilesSaved={markFilesSaved}
          figmaWidgetLayout
        />

        {widgetTemplateDraft.draftId &&
          (!widgetTemplateId ||
            !widgetTemplateDraft.sourceId ||
            widgetTemplateDraft.sourceId === widgetTemplateId) && (
          <WidgetEditorDesignTabs
            widgetTemplateDraftId={widgetTemplateDraft.draftId}
            widgetTemplateId={effectiveWidgetTemplateId}
            departmentId={departmentId}
          />
        )}

        {displaysOption ? (
          <MultipleEditorWindows
            widgetTemplateFiles={widgetTemplateFiles}
            filesContent={filesContent}
            setFilesContent={setFilesContent}
            activeHtmlId={activeHtmlId}
            activeCssId={activeCssId}
            activeJsId={activeJsId}
            setActiveHtmlId={setActiveHtmlId}
            setActiveCssId={setActiveCssId}
            setActiveJsId={setActiveJsId}
            previewUrl={previewUrl}
            widgetTemplateId={effectiveWidgetTemplateId}
            widgetTemplateDraft={widgetTemplateDraft}
            onFileSaved={refreshDraftFiles}
            figmaWidgetLayout
          />
        ) : (
          <OneEditorWindow
            setEditorMode={setEditorMode}
            editorMode={editorMode}
            widgetTemplateFiles={widgetTemplateFiles}
            widgetTemplateDraft={widgetTemplateDraft}
            setEditorType={setEditorType}
            editorType={editorType}
            filesContent={filesContent}
            setFilesContent={setFilesContent}
            previewUrl={previewUrl}
            onOpenVisualization={saveFilesAndRefreshPreview}
            isPreviewSaving={isPreviewSaving}
            widgetTemplateId={effectiveWidgetTemplateId}
            onFileSaved={refreshDraftFiles}
            figmaWidgetLayout
          />
        )}
      </Box>
    </FormProvider>
  );
}
