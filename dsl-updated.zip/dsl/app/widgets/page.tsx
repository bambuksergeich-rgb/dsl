'use client';

import PageSubHeader from '@/src/components/AllSubHeaders/PageSubHeader/PageSubHeader';
import { useEffect, useState } from 'react';
import { Pagination } from '@/src/components/Pagination/Pagination';
import WidgetsTable from '@/src/components/AllTables/WidgetsTable/WidgetsTable';
import { Loading } from '@/src/components/Loading/Loading';
import { store } from '@/src/store/store';
import { getWidgetTemplates } from '@/src/store/actions/getWidgetTemplates';
import {
  WidgetTemplate,
  WidgetTemplatesData
} from '@/src/store/counter/widgetTemplatesSlice';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { useSearchParams } from 'next/navigation';
import { getGroupsAction } from '@/src/store/actions/getGroupsAction';
import { NoData } from '@/src/components/NoData/NoData';

const Widgets = () => {
  const [filter, setFilter] = useState<string>('');
  const [filteredData, setFilteredData] = useState<WidgetTemplate[] | []>([]);
  const [pageData, setPageData] = useState<WidgetTemplate[] | null>(null);
  const [departmentId, setDepartmentId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  const searchParams = useSearchParams();

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getGroupsAction(departmentId, 'WIDGET_TEMPLATE'));
    }
  }, [departmentId]);

  const groups = useSelector((state: State) => state.groups);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getWidgetTemplates(1, departmentId, filter, setLoading));
    }
  }, [departmentId, filter]);

  const widgetTemplates: WidgetTemplatesData = useSelector(
    (state: State) => state.widgetTemplates
  );

  useEffect(() => {
    setFilteredData(widgetTemplates.content);
  }, [widgetTemplates.content]);

  useEffect(() => {
    setPageData(widgetTemplates.content);
  }, [filteredData]);

  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    if (departmentId) {
      store.dispatch(getWidgetTemplates(value, departmentId, filter));
      setFilteredData(widgetTemplates.content);
    }
  };

  if (!departmentId) {
    return <Loading />;
  }

  return (
    <>
      <PageSubHeader
        pageName='Widgets'
        filter={filter}
        setFilter={setFilter}
        createUrl={`/create_widget?departmentId=${departmentId}`}
        groups={groups}
      />
      {!loading &&
        (widgetTemplates?.content?.length > 0 ? (
          <>
            <WidgetsTable
              pageData={pageData}
              departmentId={departmentId}
            />
            <Pagination
              totalElements={widgetTemplates?.totalElements}
              handleChange={handleChange}
            />
          </>
        ) : (
          <NoData />
        ))}
    </>
  );
};

export default Widgets;
