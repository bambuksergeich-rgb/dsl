'use client';

import React, { useEffect, useRef, useState } from 'react';
import classNames from 'classnames';
import clsx from 'clsx';
import { WidgetView } from '@/src/components/WidgetConfigurationComponents/WidgetView';
import { useRouter, useSearchParams } from 'next/navigation';
import { store } from '@/src/store/store';
import { ensureWidgetTemplateDraft } from '@/src/store/actions/createWidgetTemplateDraft';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { persistWidgetTemplateDraftIdInCurrentUrl } from '@/src/utils/widgetTemplateDraftUrl';
import { getWidgetTemplateDraftConfigurationsAction } from '@/src/store/actions/WidgetTemplateDraftConfigurations/getWidgetTemplateDraftConfigurationsAction';
import { createSectionWidgetTemplateDraftConfigurationsAction } from '@/src/store/actions/WidgetTemplateDraftConfigurations/createSectionWidgetTemplateDraftConfigurationsAction';
import { createTabWidgetTemplateDraftConfigurationsAction } from '@/src/store/actions/WidgetTemplateDraftConfigurations/createTabWidgetTemplateDraftConfigurationsAction';
import { sanitizePath } from '@/src/helpers/basePrefix';

const WidgetConfiguration = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const widgetTemplateId = searchParams.get('widgetTemplateId');
  const departmentId = searchParams.get('departmentId');
  const widgetTemplateMappingId = searchParams.get('widgetTemplateMappingId');
  const focusSectionId = searchParams.get('sectionId') || undefined;
  const requestedDraftId =
    searchParams.get('widgetTemplateDraftId') || undefined;
  const shouldCreateConfiguration = searchParams.get('createConfiguration') === '1';
  const configurationCreateStartedRef = useRef(false);

  const [widgetTemplateMappingDraftId, setWidgetTemplateMappingDraftId] =
    useState<string | undefined>();

  const [name, setName] = useState<string>('');

  useEffect(() => {
    if (!departmentId || (!widgetTemplateId && !requestedDraftId)) return;

    void store
      .dispatch(
        ensureWidgetTemplateDraft(
          departmentId,
          widgetTemplateId || undefined,
          requestedDraftId
        ) as any
      )
      .then((draft: any) => {
        if (draft?.draftId) {
          persistWidgetTemplateDraftIdInCurrentUrl(draft.draftId);
        }
      })
      .catch((error: unknown) => {
        console.error(
          '[WidgetConfiguration] Unable to initialize widget draft',
          error
        );
      });
  }, [departmentId, widgetTemplateId, requestedDraftId]);

  const widgetTemplateDraft = useSelector(
    (state: State) => state.widgetTemplateDraft
  );

  useEffect(() => {
    if (
      !shouldCreateConfiguration ||
      widgetTemplateMappingId ||
      !widgetTemplateDraft?.draftId ||
      configurationCreateStartedRef.current
    ) {
      return;
    }

    configurationCreateStartedRef.current = true;
    let cancelled = false;

    void (async () => {
      try {
        await store.dispatch(
          getWidgetTemplateDraftConfigurationsAction(
            widgetTemplateDraft.draftId,
            'UI'
          ) as any
        );

        const sections =
          store.getState().widgetTemplateDraftConfigurations?.sections ?? [];
        const previousIds = new Set(
          sections.map((section: any) => String(section.draftId || section.id || ''))
        );
        const nextIndex = sections.length
          ? Math.max(...sections.map((section: any) => Number(section.index || 0))) + 1
          : 1;

        await store.dispatch(
          createSectionWidgetTemplateDraftConfigurationsAction(
            widgetTemplateDraft.draftId,
            'UI',
            nextIndex,
            `Configuration ${nextIndex}`,
            2,
            2
          ) as any
        );

        let currentSections =
          store.getState().widgetTemplateDraftConfigurations?.sections ?? [];
        let createdSection = currentSections.find(
          (section: any) =>
            !previousIds.has(String(section.draftId || section.id || ''))
        );

        if (!createdSection) {
          await store.dispatch(
            getWidgetTemplateDraftConfigurationsAction(
              widgetTemplateDraft.draftId,
              'UI'
            ) as any
          );
          currentSections =
            store.getState().widgetTemplateDraftConfigurations?.sections ?? [];
          createdSection = [...currentSections]
            .sort((a: any, b: any) => Number(b.index || 0) - Number(a.index || 0))[0];
        }

        const createdId = String(createdSection?.draftId || createdSection?.id || '');
        if (!createdId || cancelled) return;

        if (!(createdSection?.tabs?.length > 0)) {
          await store.dispatch(
            createTabWidgetTemplateDraftConfigurationsAction(
              widgetTemplateDraft.draftId,
              createdId,
              'New Tab',
              1
            ) as any
          );
        }

        if (cancelled) return;
        const params = new URLSearchParams({
          departmentId: departmentId || '',
          widgetTemplateDraftId: widgetTemplateDraft.draftId,
          sectionId: createdId,
        });
        const effectiveSourceId = String(
          widgetTemplateDraft.sourceId || widgetTemplateId || '',
        ).trim();
        if (effectiveSourceId) {
          params.set('widgetTemplateId', effectiveSourceId);
        }
        router.replace(sanitizePath(`/widget_configuration?${params.toString()}`));
      } catch (error) {
        configurationCreateStartedRef.current = false;
        console.error('[WidgetConfiguration] Unable to create configuration', error);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [
    shouldCreateConfiguration,
    widgetTemplateMappingId,
    widgetTemplateDraft?.draftId,
    departmentId,
    widgetTemplateId,
    router,
  ]);

  useEffect(() => {
    if (!widgetTemplateDraft?.draftId) {
      return;
    }

    if (widgetTemplateMappingId) {
      const mapping = widgetTemplateDraft.mappings?.find(
        (item) =>
          item.sourceId === widgetTemplateMappingId ||
          item.draftId === widgetTemplateMappingId
      );

      if (mapping) {
        setName(mapping.name || widgetTemplateDraft.name || '');
        setWidgetTemplateMappingDraftId(mapping.draftId);

        return;
      }

      console.warn('[WidgetConfiguration] Mapping not found', {
        widgetTemplateMappingId,
        mappings: widgetTemplateDraft.mappings
      });
    }

    setName(widgetTemplateDraft.name ?? '');
    setWidgetTemplateMappingDraftId(undefined);
  }, [widgetTemplateDraft, widgetTemplateMappingId]);

  return (
    <DndProvider backend={HTML5Backend}>
      <div
        className={clsx(
          'w-full flex h-full min-h-0 bg-custom-linear-gradient overflow-hidden'
        )}
      >
        <div
          className={classNames(
            { 'pb-8': false },
            'flex min-h-0 flex-col flex-grow w-full'
          )}
        >
          <div className='min-h-0 flex-grow'>
            {widgetTemplateDraft.draftId &&
              (!widgetTemplateId ||
                !widgetTemplateDraft.sourceId ||
                widgetTemplateDraft.sourceId === widgetTemplateId) && (
                <WidgetView
                  name={name}
                  widgetTemplateDraft={widgetTemplateDraft}
                  widgetTemplateMappingDraftId={widgetTemplateMappingDraftId}
                  focusSectionId={focusSectionId}
                />
              )}
          </div>
        </div>
      </div>
    </DndProvider>
  );
};

export default WidgetConfiguration;
