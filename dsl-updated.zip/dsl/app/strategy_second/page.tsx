'use client';
import ScriptEditor from '@/src/components/ScriptEditor/ScriptEditor';
export default function StrategyWizardPage() {
  return <ScriptEditor variant='strategy' initialBlockType='SCRIPT_GENERATOR' />;
}
