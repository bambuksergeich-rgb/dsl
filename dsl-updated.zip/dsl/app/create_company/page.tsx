'use client';

import { CreateCompanyModal } from '@/src/components/AllModals/CreateCompanyModal/CreateCompanyModal';
import { createCompanyDraft } from '@/src/requests/createCompanyDraft';
import { SimpleMUIButton } from '@/src/styles/muiButtonStyles';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { Stack } from '@mui/material';
import { useState } from 'react';

export default function CreateCompany(): JSX.Element {
  const [openModal, setOpenModal] = useState<boolean>(false);

  return (
    <Stack
      direction={'row'}
      sx={{
        width: '100vw',
        height: '100vh',
        justifyContent: 'center',
        alignItems: 'center'
      }}
    >
      <SimpleMUIButton
        sx={{ width: '300px', height: '44px', textTransform: 'initial' }}
        onClick={async () => {
          await createCompanyDraft(setOpenModal);
        }}
      >
        <TypographyMontserrat500 sx={{ fontSize: '16px' }}>
          Create a draft company
        </TypographyMontserrat500>
      </SimpleMUIButton>
      <CreateCompanyModal
        title='Create a new company'
        openModal={openModal}
        singlePage
      />
    </Stack>
  );
}
