'use client';

import { FullScreenGreyIcon } from '@/public/icons/FullScreenGrey.icon';
import { ViewingDashboard } from '@/src/components/ViewingDashboard/ViewingDashboard';
import { sanitizePath } from '@/src/helpers/basePrefix';
import { WhiteIconButton } from '@/src/styles/muiStyledGlobal';

import { Box, Stack } from '@mui/material';
import { useRouter } from 'next/navigation';

export default function FullViewindDashboard(): JSX.Element {
  const router = useRouter();

  return (
    <Stack
      direction={'row'}
      sx={{
        height: '100%',
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center'
      }}
    >
      <WhiteIconButton
        sx={{
          position: 'fixed',
          top: '930px',
          left: '50px'
        }}
        disableTouchRipple={true}
        onClick={() => {
          router.push(sanitizePath('/viewing_dashboard/1'));
        }}
      >
        <FullScreenGreyIcon />
      </WhiteIconButton>
      <Box
        sx={{
          width: 'calc(100% - 80px)',
          height: 'calc(100% - 80px)',
          backgroundColor: '#10161C80',
          borderRadius: '40px',
          boxSizing: 'border-box',
          padding: '40px 40px 10px 40px'
        }}
      >
        <ViewingDashboard />
      </Box>
    </Stack>
  );
}
