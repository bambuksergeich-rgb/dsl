'use client';

import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { sanitizePath } from '@/src/helpers/basePrefix';
import { useSession } from 'next-auth/react';

export default function Home() {
  const router = useRouter();

  const { data: session, status } = useSession();

  useEffect(() => {
    if (status === 'authenticated') {
      router.push(sanitizePath('/general'));
    }
  }, [status]);
  return <></>;
}
