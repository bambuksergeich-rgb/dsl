'use client';
import ScriptEditor from '@/src/components/ScriptEditor/ScriptEditor';
export default function EditScriptPage() { return <ScriptEditor />; }
