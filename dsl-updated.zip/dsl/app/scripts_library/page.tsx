'use client';

import ScriptsLibrarySubHeader from '@/src/components/AllSubHeaders/ScriptsLibrarySubHeader/ScriptsLibrarySubHeader';
import { Box, Grid, Stack } from '@mui/material';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import LibrarySidebar from '@/src/components/LibrarySidebar/LibrarySidebar';
import TabSign from '@/src/components/CodeEditorLayout/TabSign';

const ScriptsLibrary = () => {
  return (
    <>
      <ScriptsLibrarySubHeader pageName={'Scripts Library'} />
      <Stack
        flexDirection={'column'}
        sx={{
          padding: '0 40px 40px 40px',
          height: '100%'
        }}
      >
        <Grid
          sx={{
            display: 'grid',
            gridTemplateRows: 'auto 1fr',
            height: '100%',
            backgroundColor: '#10161C80',
            borderRadius: '6px',
            overflow: 'hidden'
          }}
        >
          <Stack
            flexDirection={'column'}
            sx={{ padding: '30px' }}
            gap={'8px'}
          >
            <TypographyMontserrat500 fontSize={'14'}>
              {
                'Library contains all common processing logic, uswd from individual processing scripts. All changes here will require to restart each depen processing to get modified logic.'
              }
            </TypographyMontserrat500>
            <TypographyMontserrat500 fontSize={'14'}>
              {'Last updated at 06/11/21 15:29 by admin'}
            </TypographyMontserrat500>
          </Stack>
          <Stack
            flexDirection={'row'}
            sx={{ height: '100%' }}
          >
            <Grid
              sx={{
                display: 'grid',
                gridTemplateColumns: '2fr 5fr',
                width: '100%'
              }}
            >
              <Box>
                <LibrarySidebar />
              </Box>
              <Grid
                sx={{
                  gridTemplateRows: '52px 34px 1fr',
                  display: 'grid',
                  height: '100%'
                }}
              >
                <Stack
                  flexDirection={'row'}
                  sx={{ alignItems: 'center' }}
                >
                  <TypographyMontserrat500 fontSize={'16px'}>
                    Script source code
                  </TypographyMontserrat500>
                </Stack>
                <Stack
                  flexDirection={'row'}
                  sx={{ margin: '4px 4px 0 4px' }}
                >
                  <TabSign
                    TabName='Common Parsing'
                    IconName='file'
                    width='200px'
                    useInTile
                  />
                </Stack>
                <Stack
                  flexDirection={'row'}
                  sx={{
                    padding: '20px',
                    borderTop: '1px solid #FFFFFF26',
                    height: 'calc(100% - 40px)',
                    width: 'calc(100% - 40px)'
                  }}
                >
                  <Box
                    sx={{
                      height: '100%',
                      width: '100%',
                      backgroundColor: '#10161C',
                      borderRadius: '6px'
                    }}
                  ></Box>
                </Stack>
              </Grid>
            </Grid>
          </Stack>
        </Grid>
      </Stack>
    </>
  );
};

export default ScriptsLibrary;
