import { YellowFolderIcon } from '@/public/icons/YellowFolder.ion';
import PythonFileIcon from '@/public/icons/scriptsLibrary/PythonFile.icon';

export interface LibraryFakeInterface {
  icon: JSX.Element;
  title: string;
  children: LibraryFakeInterface[];
}

export const scriptsLibrary: LibraryFakeInterface[] = [
  {
    icon: <PythonFileIcon />,
    title: 'New Script',
    children: []
  },
  {
    icon: <YellowFolderIcon />,
    title: 'New Folder',
    children: [
      {
        icon: <PythonFileIcon />,
        title: 'New Script11111',
        children: []
      },
      {
        icon: <PythonFileIcon />,
        title: 'Outdated Script',
        children: []
      }
    ]
  },
  {
    icon: <PythonFileIcon />,
    title: 'Resource Providers',
    children: []
  },
  {
    icon: <YellowFolderIcon />,
    title: 'New Folder',
    children: [
      {
        icon: <PythonFileIcon />,
        title: 'ghgt',
        children: []
      },
      {
        icon: <YellowFolderIcon />,
        title: 'fnfn',
        children: [
          {
            icon: <YellowFolderIcon />,
            title: 'folder',
            children: [
              {
                icon: <YellowFolderIcon />,
                title: 'folder',
                children: [
                  {
                    icon: <PythonFileIcon />,
                    title: 'file',
                    children: []
                  },
                  {
                    icon: <PythonFileIcon />,
                    title: 'file1',
                    children: []
                  },
                  {
                    icon: <PythonFileIcon />,
                    title: 'file2',
                    children: []
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
];
