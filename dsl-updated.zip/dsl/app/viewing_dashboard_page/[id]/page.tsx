'use client';

import { ViewingDashboardSubHeader } from '@/src/components/AllSubHeaders/ViewingDashboardSubHeader/ViewingDashboardSubHeader';
import { ChartPie } from '@/src/components/Statistics/Chart/ChartPie';
import { StatisticsChartLine } from '@/src/components/Statistics/StatisticChartLine';
import { StatisticStepper } from '@/src/components/Statistics/StatisticStepper';
import { FileList } from '@/src/components/VieWingDashboardFull/FileList/FileList';
import { Timer } from '@/src/components/VieWingDashboardFull/Timer/Timer';
import { Box, Stack } from '@mui/material';

export default function ViewingDashboardPage(): JSX.Element {
  return (
    <>
      <ViewingDashboardSubHeader pageName='Dashboard' />
      <Stack
        direction={'column'}
        gap={'40px'}
        sx={{
          height: '100%',
          overflowY: 'scroll',
          '&::-webkit-scrollbar': {
            display: 'none'
          },
          mb: '20px',
          padding: '0px 82px 82px 40px'
        }}
      >
        <Stack
          direction={'row'}
          justifyContent={'space-between'}
          sx={{
            width: '100%'
          }}
        >
          <Box sx={{ width: '68%', minHeight: '464px' }}>
            <StatisticsChartLine />
          </Box>
          <Box sx={{ width: '30%', minHeight: '464px' }}>
            <ChartPie small />
          </Box>
        </Stack>

        <Stack
          direction={'row'}
          sx={{
            width: '100%',
            height: '50%',
            gap: '37px'
          }}
        >
          <Stack
            sx={{
              width: '50%',
              height: '100%'
            }}
          >
            <Timer />
            <StatisticStepper />
          </Stack>
          <Stack
            sx={{
              width: '50%',
              height: '100%'
            }}
          >
            <FileList />
          </Stack>
        </Stack>
      </Stack>
    </>
  );
}
