'use client';
import PageTransitionEffect
  from '@/src/components/Dashboards/Dashboard/components/PageTransitionEffect/PageTransitionEffect';
import { Dashboard } from '@/src/components/Dashboards/Dashboard/Dashboard';
import {
  buildDashboardFilters,
  type DashboardStorageFilter
} from '@/src/components/Dashboards/Dashboard/utils/buildDashboardFilters';
import { Loading } from '@/src/components/Loading/Loading';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { getDashboardParameters } from '@/src/requests/Dashboard/getDashboardParameters';
import { useParams, useSearchParams } from 'next/navigation';
import React, { useCallback, useEffect, useState } from 'react';

type DashboardLinkComponent = { widgetId: string; componentId: string };

export default function PureDashboardPage() {
  const params = useParams<{ id: string }>();
  const searchParams = useSearchParams();
  const dashboardId = params?.id as string;
  const { dashboard } = useAppSelector((state) => state.dashboard);
  const departmentId = searchParams.get('departmentId')!;
  const filterParam = searchParams.get('filter');
  const [isParamsLoading, setIsParamsLoading] = useState(true);

  const [filters, setFilters] = useState<Record<string, string> | undefined>(
    undefined
  );
  useEffect(() => {
    let isCancelled = false;

    const loadFilters = async () => {
      if (!filterParam) {
        setFilters(undefined);
        setIsParamsLoading(false);
        return;
      }

      setIsParamsLoading(true);

      const parametersResponse = await getDashboardParameters(dashboardId);
      const parameterNames =
        parametersResponse?.content?.map((p: { name: string }) => p.name) ??
        [];
      const parsedFilters: DashboardStorageFilter[] = JSON.parse(filterParam);

      if (isCancelled) return;

      setFilters(buildDashboardFilters(parsedFilters, parameterNames));
      setIsParamsLoading(false);
    };

    loadFilters();

    return () => {
      isCancelled = true;
    };
  }, [dashboardId, filterParam]);

  useEffect(() => {
    window.parent!.postMessage(
      { dashboardInfo: dashboard },
      {
        targetOrigin: '*'
      }
    );
  }, [dashboard]);

  const onAllWidgetsLoaded = useCallback(() => {
    const isIframe = window.parent !== window;
    if (isIframe) {
      window.parent?.postMessage(
        { dashboardWidgetsDownloaded: true },
        { targetOrigin: '*' }
      );
    }
  }, []);

  const [linkComponents, setLinkComponents] = useState<DashboardLinkComponent[]>(
    []
  );

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const config = event.data?.dashboardLinksConfig;
      if (!config) return;
      if (config.dashboardId !== dashboardId) return;
      setLinkComponents(Array.isArray(config.components) ? config.components : []);
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [dashboardId]);

  const onComponentClick = useCallback(
    (widgetId: string, componentId: string) => {
      window.parent?.postMessage(
        { dashboardComponentClick: { dashboardId, widgetId, componentId } },
        { targetOrigin: '*' }
      );
    },
    [dashboardId]
  );

  const [dashboardWidth, setDashboardWidth] = useState<number>(0);
  const [dashboardHeight, setDashboardHeight] = useState<number>(0);
  return (
    <PageTransitionEffect dashboard={undefined}>
      {filterParam && isParamsLoading ? (
        <Loading />
      ) : (
        <Dashboard
          create={false}
          dashboardWidth={dashboardWidth}
          dashboardHeight={dashboardHeight}
          setDashboardWidth={setDashboardWidth}
          setDashboardHeight={setDashboardHeight}
          setDashboardRect={() => {}}
          canToggleViewMode={false}
          filters={filters}
          departmentId={departmentId}
          viewMode={true}
          onAllWidgetsLoaded={onAllWidgetsLoaded}
          componentLinks={linkComponents}
          onComponentClick={onComponentClick}
          dashboardId={dashboardId}
        />
      )}
    </PageTransitionEffect>
  );
}
