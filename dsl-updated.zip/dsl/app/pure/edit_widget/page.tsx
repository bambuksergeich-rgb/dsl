'use client';

import WidgetEditorSubHeader from '@/src/components/AllSubHeaders/WidgetEditorSubHeader/WidgetEditorSubHeader';
import WidgetEditorDesignTabs from '@/src/components/WidgetSettingsBuilder/WidgetEditorDesignTabs';
import { useWidgetTemplateDraftPreview } from '@/src/hooks/useWidgetTemplateDraftPreview';
import { getCodeFromWidgetTemplateFile } from '@/src/requests/getCodeFromWidgetTemplateFile';
import { ensureWidgetTemplateDraft } from '@/src/store/actions/createWidgetTemplateDraft';
import { getGroupsAction } from '@/src/store/actions/getGroupsAction';
import { getWidgetTemplateFiles } from '@/src/store/actions/getWidgetTemplateFiles';
import { State } from '@/src/store/initialState';
import { store } from '@/src/store/store';
import { Box } from '@mui/system';
import { resolveFileContentType } from '@/src/helpers/resolveFileContentType';
import { useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { getWidgetTemplateDraftMappingsAction } from '@/src/store/actions/getWidgetTemplateDraftMappingsAction';
import { getWidgetTemplateConfigurationsAction } from '@/src/store/actions/WidgetTemplateConfigurations/getWidgetTemplateConfigurationsAction';
import { MultipleEditorWindows } from '@/app/edit_widget/components/MultipleEditorWindows';
import { OneEditorWindow } from '@/app/edit_widget/components/OneEditorWindow';
import { persistWidgetTemplateDraftIdInCurrentUrl } from '@/src/utils/widgetTemplateDraftUrl';

export default function EditWidget() {
  const dispatch = useDispatch();
  const searchParams = useSearchParams();

  const [displaysOption, setDisplaysOption] = useState(false);
  const [editorMode, setEditorMode] = useState('');
  const [editorType, setEditorType] = useState('');

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const [widgetTemplateId, setWidgetTemplateId] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [openInfoModal, setOpenInfoModal] = useState(false);

  const [filesContent, setFilesContent] = useState<Record<string, string>>({});
  const [savedContent, setSavedContent] = useState<Record<string, string>>({});

  const markFilesSaved = useCallback((uploaded: Record<string, string>) => {
    setSavedContent((prev) => ({ ...prev, ...uploaded }));
  }, []);

  const [activeHtmlId, setActiveHtmlId] = useState<string | null>(null);
  const [activeCssId, setActiveCssId] = useState<string | null>(null);
  const [activeJsId, setActiveJsId] = useState<string | null>(null);

  const methods = useForm({ defaultValues: { items: [] } });

  const rawWidgetTemplateFiles = useSelector(
    (state: State) => state.widgetTemplateFiles
  );
  const widgetTemplateFiles = useMemo(
    () =>
      rawWidgetTemplateFiles.map((file) => ({
        ...file,
        contentType: resolveFileContentType(file.name, file.contentType)
      })),
    [rawWidgetTemplateFiles]
  );
  const widgetTemplateDraft = useSelector(
    (state: State) => state.widgetTemplateDraft
  );

  useEffect(() => {
    const widgetId = searchParams.get('widgetTemplateId');
    const depId = searchParams.get('departmentId');
    if (widgetId) setWidgetTemplateId(widgetId);
    if (depId) setDepartmentId(depId);
  }, [searchParams]);

  useEffect(() => {
    if (!departmentId || !widgetTemplateId) return;

    const requestedDraftId =
      searchParams.get('widgetTemplateDraftId') || undefined;

    void store
      .dispatch(
        ensureWidgetTemplateDraft(
          departmentId,
          widgetTemplateId,
          requestedDraftId
        ) as any
      )
      .then((draft: any) => {
        if (draft?.draftId) {
          persistWidgetTemplateDraftIdInCurrentUrl(draft.draftId);
        }
      })
      .catch((error: unknown) => {
        console.error(
          '[PureEditWidget] Unable to initialize widget draft',
          error
        );
      });
  }, [departmentId, widgetTemplateId, searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getGroupsAction(departmentId, 'WIDGET_TEMPLATE'));
    }
  }, [departmentId]);

  useEffect(() => {
    if (widgetTemplateDraft.draftId) {
      store.dispatch(
        getWidgetTemplateDraftMappingsAction(widgetTemplateDraft.draftId)
      );
    }
  }, [widgetTemplateDraft.draftId]);

  useEffect(() => {
    if (widgetTemplateDraft.name) {
      setName(widgetTemplateDraft.name);
      setDescription(widgetTemplateDraft.description);
    }
  }, [widgetTemplateDraft]);

  useEffect(() => {
    if (widgetTemplateDraft.draftId) {
      store.dispatch(
        getWidgetTemplateFiles(
          widgetTemplateDraft.draftId,
          widgetTemplateDraft.sourceId
        )
      );
    }
  }, [widgetTemplateDraft]);

  useEffect(() => {
    if (!widgetTemplateFiles?.length) return;

    const TEXT_CONTENT_TYPES = ['text/html', 'text/css', 'text/javascript'];

    widgetTemplateFiles.forEach((file) => {
      if (TEXT_CONTENT_TYPES.includes(file.contentType)) {
        getCodeFromWidgetTemplateFile(file.id, (code) => {
          setFilesContent((prev) =>
            Object.prototype.hasOwnProperty.call(prev, file.id)
              ? prev
              : { ...prev, [file.id]: code as string }
          );
          setSavedContent((prev) =>
            Object.prototype.hasOwnProperty.call(prev, file.id)
              ? prev
              : { ...prev, [file.id]: code as string }
          );
        });
      }

      if (file.contentType === 'text/html' && !activeHtmlId)
        setActiveHtmlId(file.id);
      if (file.contentType === 'text/css' && !activeCssId)
        setActiveCssId(file.id);
      if (file.contentType === 'text/javascript' && !activeJsId)
        setActiveJsId(file.id);
    });

    if (!editorMode) {
      const first = widgetTemplateFiles[0];
      if (first) {
        setEditorMode(first.id);
        setEditorType(first.contentType);
      }
    }
  }, [widgetTemplateFiles]);

  const { isPreviewSaving, previewUrl, saveFilesAndRefreshPreview } =
    useWidgetTemplateDraftPreview({
      widgetTemplateDraft,
      widgetTemplateId,
      widgetTemplateFiles,
      filesContent,
      savedContent,
      onFilesSaved: markFilesSaved
    });

  useEffect(() => {
    store.dispatch(
      getWidgetTemplateConfigurationsAction(widgetTemplateId, 'UI')
    );
  }, [widgetTemplateId, widgetTemplateDraft.draftId]);

  return (
    <FormProvider {...methods}>
      <Box sx={{ width: '100%', height: '100%', overflowY: 'scroll', overflowX: 'hidden', minWidth: 0 }}>
        <WidgetEditorSubHeader
          openMappingEditor={() => void 0}
          pageName='Widgets'
          name={name}
          setName={setName}
          description={description}
          setDescription={setDescription}
          displaysOption={displaysOption}
          setDisplaysOption={setDisplaysOption}
          widgetTemplateId={widgetTemplateId}
          widgetTemplateFiles={widgetTemplateFiles}
          widgetTemplateDraft={widgetTemplateDraft}
          departmentId={departmentId}
          openInfoModal={openInfoModal}
          setOpenInfoModal={setOpenInfoModal}
          isNew={false}
          filesContent={filesContent}
          savedContent={savedContent}
          onFilesSaved={markFilesSaved}
          figmaWidgetLayout
        />

        {widgetTemplateDraft.draftId &&
          widgetTemplateDraft.sourceId === widgetTemplateId && (
          <WidgetEditorDesignTabs
            widgetTemplateDraftId={widgetTemplateDraft.draftId}
            widgetTemplateId={widgetTemplateId}
            departmentId={departmentId}
          />
        )}

        {displaysOption ? (
          <MultipleEditorWindows
            widgetTemplateFiles={widgetTemplateFiles}
            filesContent={filesContent}
            setFilesContent={setFilesContent}
            activeHtmlId={activeHtmlId}
            activeCssId={activeCssId}
            activeJsId={activeJsId}
            setActiveHtmlId={setActiveHtmlId}
            setActiveCssId={setActiveCssId}
            setActiveJsId={setActiveJsId}
            previewUrl={previewUrl}
          />
        ) : (
          <OneEditorWindow
            setEditorMode={setEditorMode}
            editorMode={editorMode}
            widgetTemplateFiles={widgetTemplateFiles}
            widgetTemplateDraft={widgetTemplateDraft}
            setEditorType={setEditorType}
            editorType={editorType}
            filesContent={filesContent}
            setFilesContent={setFilesContent}
            previewUrl={previewUrl}
            onOpenVisualization={saveFilesAndRefreshPreview}
            isPreviewSaving={isPreviewSaving}
            figmaWidgetLayout
          />
        )}
      </Box>
    </FormProvider>
  );
}
