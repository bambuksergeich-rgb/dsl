'use client';

import { IInput } from '@/src/components/EditStrategyComponentsSecond/EditStrategyScriptWizard/EditStrategyScriptWizard';
import { ScriptWizardInner } from '@/src/components/EditStrategyComponentsSecond/EditStrategyScriptWizard/ScriptWizardInner';
import { Box } from '@mui/system';
import React from 'react';

export default function ScriptWizardPage() {
  const inputs: IInput[] = [
    {
      color: 'rgba(255, 204, 77, 1)',
      name: '1'
    },
    {
      color: 'rgba(138, 10, 244, 1)',
      name: '2'
    },
    {
      color: 'rgba(255, 0, 199, 1)',
      name: '3'
    }
  ];

  return (
    <Box
      sx={{
        width: '100%',
        height: '100%',
        overflowY: 'auto',
        overflowX: 'hidden'
      }}
    >
      <ScriptWizardInner inputs={inputs} />
    </Box>
  );
}
