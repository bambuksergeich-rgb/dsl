'use client';
import { TabScriptItem } from '@/app/create_script/interfaces';
import { CloseCrossIcon } from '@/public/icons';
import ScriptEditorSubHeader from '@/src/components/AllSubHeaders/ScriptEditorSubHeader/ScriptEditorSubHeader';
import CodeMirrorScriptComponent from '@/src/components/CodeMirror/CodeMirrorScriptComponent';
import { SideBarRedactorScript } from '@/src/components/SideBarRedactor/SideBarRedactorScript';
import { getCurrentScript } from '@/src/requests/getCurrentScript';
import { createScriptDraftById } from '@/src/store/actions/createScriptDraftById';
import { getGroupsAction } from '@/src/store/actions/getGroupsAction';
import { getScriptListCurrentVersion } from '@/src/store/actions/getScriptListCurrentVersion';
import { getScriptOne } from '@/src/store/actions/getScriptOne';
import { ScriptOne, scriptOneReset } from '@/src/store/counter/scriptOneSlice';
import { State } from '@/src/store/initialState';
import { store } from '@/src/store/store';
import { TabMUIButton } from '@/src/styles/muiButtonStyles';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { Box, Grid, Stack } from '@mui/material';
import { useSearchParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { useSelector } from 'react-redux';

export default function PureEditScript() {
  const [jsContent, setJsContent] = useState<string>('');
  const fileBuffersRef = useRef<Record<string, string>>({});
  const searchParams = useSearchParams();
  const scriptId = searchParams.get('scriptId');
  const [departmentId, setDepartmentId] = useState<string>('');
  const [currentId, setCurrentId] = useState('');
  const scriptDraft = useSelector((state: State) => state.scriptDraft);
  const scriptData: ScriptOne = useSelector((state: State) => state.scriptOne);
  const [openScripts, setOpenScript] = useState<TabScriptItem[]>([]);
  const [openInfoModal, setOpenInfoModal] = useState<boolean>(false);
  useEffect(() => {
    if (departmentId) {
      store.dispatch(getGroupsAction(departmentId, 'SCRIPT'));
    }
  }, [departmentId]);
  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);
  useEffect(() => {
    if (scriptId) {
      store.dispatch(getScriptOne(scriptId));
    }
  }, [scriptId]);

  const getScript = async () => {
    const scriptExist = openScripts.find((item) => item.id === currentId);
    const findScriptByPath = openScripts.find(
      (item) => scriptInfo && item.path === scriptInfo?.path + scriptInfo?.name
    );
    if (!scriptExist && scriptInfo) {
      setOpenScript((prev) => [
        ...prev,
        {
          id: scriptInfo.id,
          name: scriptInfo.name,
          path: scriptInfo.path + scriptInfo.name
        }
      ]);
    }
    if (findScriptByPath && scriptInfo) {
      const newScriptList = openScripts.map((item) => {
        if (item.path === scriptInfo.path + scriptInfo.name) {
          return {
            ...item,
            id: scriptInfo.id
          };
        }
        return item;
      });
      setOpenScript(newScriptList);
    }

    if (fileBuffersRef.current[currentId] !== undefined) {
      setJsContent(fileBuffersRef.current[currentId]);
      return;
    }

    if (
      scriptInfo &&
      scriptInfo.contentType.includes('image') &&
      !scriptInfo.contentType.includes('svg')
    ) {
      setJsContent('This type of file cannot be edited');
      return;
    }

    const data = await getCurrentScript(currentId);
    if (data === null || data === undefined) {
      setJsContent('');
      return;
    }
    setJsContent(data);
    fileBuffersRef.current[currentId] = data;
  };
  // const handleFileInputChange = async (
  //   event: ChangeEvent<HTMLInputElement>
  // ) => {
  //   let fileContent: string | ArrayBuffer | null = '';
  //   if (event.target.files) {
  //     const file = event.target.files[0];
  //     const reader = new FileReader();
  //     reader.onload = (e) => {
  //       if (!e.target) return;
  //       fileContent = e.target.result;
  //       setJsContent(fileContent as string);
  //     };
  //     reader.readAsText(file);
  //     store.dispatch(
  //       createScriptFile(
  //         file,
  //         scriptDraft.sourceId,
  //         currentPath,
  //         setCurrentId,
  //         setOpenScript,
  //         scriptDraft.draftId
  //       )
  //     );
  //   }
  // };
  useEffect(() => {
    if (!currentId) return;
    getScript();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentId]);

  useEffect(() => {
    if (scriptData.id && scriptData.fileVersion) {
      const fetchData = async () => {
        try {
          store.dispatch(
            createScriptDraftById(scriptData.id, scriptData.groupId)
          );
          store.dispatch(
            getScriptListCurrentVersion(
              scriptData.id,
              setOpenScript,
              setCurrentId,
              openScripts,
              scriptData.fileVersion
            )
          );
        } catch (error) {
          console.error('Error fetching script files:', error);
        }
      };
      fetchData();
    }
  }, [scriptData.fileVersion, scriptData.lastModifiedTimestamp]);

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);
  const scriptList = useSelector((state: State) => state.scriptList);

  const scriptInfo = scriptList.find((item) => item.id === currentId);

  const jsContentChange = (value: string) => {
    setJsContent(value);
    if (currentId) {
      fileBuffersRef.current[currentId] = value;
    }
  };

  useEffect(() => {
    return () => {
      store.dispatch(scriptOneReset());
    };
  }, []);
  return (
    <>
      <ScriptEditorSubHeader
        scriptName={scriptData.name}
        pageName={`Edit script "${scriptData.name}"`}
        groupDraftId={''}
        content={jsContent}
        openInfoModal={openInfoModal}
        setOpenInfoModal={setOpenInfoModal}
        isNew={false}
        scriptInfo={scriptInfo}
        scriptDraft={scriptDraft}
      />
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'left',
          // margin: '0 40px 0 40px',
          backgroundColor: '#10161C80',
          borderRadius: '6px',
          width: '100%',
          height: 'calc(100vh - 90px)',
          overflow: 'hidden'
        }}
      >
        <Grid
          sx={{
            display: 'inline-grid',
            width: '100%',
            height: '100%',
            minHeight: 0,
            gridTemplateColumns: '1fr 4fr'
          }}
        >
          <SideBarRedactorScript
            setCurrentId={setCurrentId}
            currentId={currentId}
                      />
          <Box
            sx={{
              height: '100%',
              minHeight: 0,
              width: '100%'
            }}
          >
            <Grid
              sx={{
                width: '100%',
                height: '100%',
                minHeight: 0,
                gridTemplateRows: '52px 38px minmax(0, 1fr)',
                display: 'grid'
              }}
            >
              <Stack
                flexDirection={'row'}
                sx={{
                  alignItems: 'center'
                }}
              >
                <TypographyMontserrat500 fontSize={'16px'}>
                  Script source code
                </TypographyMontserrat500>
              </Stack>
              <Stack
                flexDirection={'row'}
                sx={{
                  height: '34px',
                  padding: '4px 4px 0px 4px',
                  gap: '4px',
                  overflowX: 'auto',
                  overflowY: 'hidden',
                  '&::-webkit-scrollbar': {
                    height: '4px'
                  },
                  '&::-webkit-scrollbar-track': {
                    background: 'transparent'
                  },
                  '&::-webkit-scrollbar-thumb': {
                    backgroundColor: '#D9D9D9',
                    borderRadius: '8px'
                  },
                  scrollbarWidth: 'thin',
                  scrollbarColor: 'rgba(0,0,0,.1) transparent'
                }}
              >
                {openScripts.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      position: 'relative',
                      width: 'fit-content'
                    }}
                  >
                    <TabMUIButton
                      sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        gap: '10px'
                      }}
                      selected={currentId === item.id}
                      onClick={() => setCurrentId(item.id)}
                    >
                      <div />
                      <TypographyMontserrat500
                        sx={{ fontSize: '14px' }}
                        noWrap
                      >
                        {item.name}
                      </TypographyMontserrat500>
                      <div
                        onClick={(e) => {
                          e.stopPropagation();
                          const remaining = openScripts.filter(
                            (s) => s.id !== item.id
                          );
                          delete fileBuffersRef.current[item.id];
                          setOpenScript(remaining);
                          if (currentId === item.id) {
                            const next = remaining[remaining.length - 1];
                            if (next) {
                              setCurrentId(next.id);
                            } else {
                              setCurrentId('');
                              setJsContent('');
                            }
                          }
                        }}
                      >
                        <CloseCrossIcon />
                      </div>
                    </TabMUIButton>
                  </div>
                ))}
              </Stack>
              <Stack
                sx={{
                  borderTop: '1px solid #FFFFFF26',
                  width: '100%',
                  height: '100%',
                  minHeight: 0,
                  boxSizing: 'border-box',
                  padding: '20px',
                  overflow: 'hidden'
                }}
              >
                <Box
                  sx={{
                    width: '100%',
                    height: '100%',
                    minHeight: 0,
                    backgroundColor: '#10161C',
                    borderRadius: '6px',
                    '.cm-theme': {
                      height: '100%'
                    }
                  }}
                >
                  <CodeMirrorScriptComponent
                    key={currentId}
                    jsContent={jsContent}
                    setJsContent={jsContentChange}
                    fillParent
                    readOnly={
                      scriptInfo &&
                      scriptInfo.contentType.includes('image') &&
                      !scriptInfo.contentType.includes('svg')
                    }
                  />
                </Box>
              </Stack>
            </Grid>
          </Box>
        </Grid>
      </Box>
    </>
  );
}
