'use client';

import ScriptLogsSubHeader from '@/src/components/AllSubHeaders/ScriptLogsSubHeader/ScriptLogsSubHeader';
import InstanceSettings from '@/src/components/AllTables/InstanceSettings/InstanceSettings';
import { Loading } from '@/src/components/Loading/Loading';
import ScriptLogsBody from '@/src/components/ScriptLogsBody/ScriptLogsBody';
import { sanitizePath } from '@/src/helpers/basePrefix';
import { useWebSocket } from '@/src/hooks/useWebSockets';
import { useActiveStatusPoll } from '@/src/hooks/useActiveStatusPoll';
import { fetchApiKey } from '@/src/requests/getApiKey';
import {
  getScriptInstanceOneRequest,
  ScriptInstanceSchedule
} from '@/src/requests/Script/getScriptInstanceOneRequest';
import {
  getScriptInstanceRunBlockRequest,
  ScriptRunBlockIo
} from '@/src/requests/Script/getScriptInstanceRunBlockRequest';
import { getScriptLogs } from '@/src/store/actions/getScriptLogs';
import { getScriptOne } from '@/src/store/actions/getScriptOne';
import { getScripts } from '@/src/store/actions/getScripts';
import { Instance } from '@/src/store/counter/instancesSlise';
import { LogsData, scriptLogsGet } from '@/src/store/counter/scriptLogsSlice';
import { ScriptOne } from '@/src/store/counter/scriptOneSlice';
import { ScriptsData } from '@/src/store/counter/scriptsSlice';
import { State } from '@/src/store/initialState';
import { store } from '@/src/store/store';
import { Box } from '@mui/system';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

const PureScriptLogs = () => {
  const router = useRouter();
  const scriptLogs: LogsData = useSelector((state: State) => state.scriptLogs);
  const scriptData: ScriptOne = useSelector((state: State) => state.scriptOne);
  const scripts: ScriptsData = useSelector((state: State) => state.scripts);
  const searchParams = useSearchParams();
  const [scriptId, setScriptId] = useState<string>('');
  const [departmentId, setDepartmentId] = useState<string>('');
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [instances, setInstances] = useState<Instance[] | null>(null);
  const [selectedInstance, setSelectedInstance] = useState<string>('');
  const [instanceSchedule, setInstanceSchedule] =
    useState<ScriptInstanceSchedule | null>(null);
  const [runBlockIo, setRunBlockIo] = useState<
    ScriptRunBlockIo[] | null | undefined
  >(undefined);
  const [canStart, setCanStart] = useState(false);

  // Fetch scripts only if scriptId and departmentId change, or scripts.content is empty
  useEffect(() => {
    const fetchScripts = () => {
      store.dispatch(getScripts(1, departmentId, scriptData.groupId));
    };

    if (scriptData.id && departmentId) {
      fetchScripts();
    }
  }, [departmentId, scriptData.id, scriptData.groupId]);

  useEffect(() => {
    if (scripts.content && scriptId) {
      const currentScript = scripts.content.find(
        (script: any) => script.id === scriptId
      );
      if (currentScript) {
        setInstances(currentScript.instances || []);
      }
    }
  }, [scripts.content, scriptId]);
  useEffect(() => {
    const department = searchParams.get('departmentId');
    const scriptId = searchParams.get('scriptId');
    if (department && scriptId) {
      setDepartmentId(department);
      setScriptId(scriptId);
    }
    if (searchParams.get('canStart')) {
      setCanStart(true);
    }
  }, [searchParams]);

  useEffect(() => {
    if (scriptId) {
      store.dispatch(getScriptOne(scriptId));
      const fetchApiKeyAsync = async () => {
        const fetchedApiKey = await fetchApiKey();
        setApiKey(fetchedApiKey);
      };

      fetchApiKeyAsync();
    }
  }, [scriptId]);

  useEffect(() => {
    if (!scriptId) return;
    store.dispatch(scriptLogsGet({ content: [], totalElements: 0 }));
    if (selectedInstance) {
      store.dispatch(getScriptLogs(scriptId, selectedInstance));
    }
  }, [scriptId, selectedInstance]);

  useEffect(() => {
    if (!scriptId || !instances) return;

    if (
      selectedInstance &&
      instances.some((instance) => instance.id === selectedInstance)
    ) {
      return;
    }

    const saved = sessionStorage.getItem(`dsl:runInstance:${scriptId}`);
    if (saved && instances.some((instance) => instance.id === saved)) {
      setSelectedInstance(saved);
      return;
    }

    if (saved) {
      sessionStorage.removeItem(`dsl:runInstance:${scriptId}`);
    }

    const activeInstanceId = scriptData.instanceId;
    if (
      activeInstanceId &&
      instances.some((instance) => instance.id === activeInstanceId)
    ) {
      setSelectedInstance(activeInstanceId);
      return;
    }

    setSelectedInstance(instances[0]?.id ?? '');
  }, [scriptId, instances, selectedInstance, scriptData.instanceId]);

  useEffect(() => {
    if (scriptId && selectedInstance) {
      sessionStorage.setItem(`dsl:runInstance:${scriptId}`, selectedInstance);
    }
  }, [scriptId, selectedInstance]);

  useEffect(() => {
    if (!scriptId || !selectedInstance) {
      setInstanceSchedule(null);
      return;
    }
    let active = true;
    getScriptInstanceOneRequest(scriptId, selectedInstance).then((data) => {
      if (active) {
        setInstanceSchedule(data);
      }
    });
    return () => {
      active = false;
    };
  }, [scriptId, selectedInstance, scriptData.containerStatus]);

  useEffect(() => {
    if (!scriptId || !selectedInstance) {
      setRunBlockIo(undefined);
      return;
    }
    let active = true;
    getScriptInstanceRunBlockRequest(scriptId, selectedInstance).then(
      (data) => {
        if (active) {
          setRunBlockIo(data?.io ?? null);
        }
      }
    );
    return () => {
      active = false;
    };
  }, [scriptId, selectedInstance]);

  useWebSocket(scriptId, selectedInstance, apiKey);
  useActiveStatusPoll(
    scriptId,
    selectedInstance || null,
    scriptData?.containerStatus,
  );

  if (!scriptLogs || !scriptData) {
    return <Loading />;
  }

  return (
    <>
      <Box
        sx={{
          paddingLeft: '30px',
          paddingRight: '30px',
          overflowY: 'auto'
        }}
      >
        <ScriptLogsSubHeader
          scriptId={scriptId}
          departmentId={departmentId}
          pageName='Script'
          scriptData={scriptData}
          selectedInstance={selectedInstance}
          instances={instances}
          onSelectInstance={setSelectedInstance}
          onBack={() => {
            router.push(sanitizePath(`/scripts?departmentId=${departmentId}`));
          }}
          onEdit={() => {
            router.push(
              sanitizePath(
                `/pure/scripts/edit?scriptId=${scriptId}&departmentId=${departmentId}`
              )
            );
          }}
          apiKey={apiKey}
          showActionButton={canStart}
        />
        <Box sx={{ marginTop: '8px', width: '100%' }}>
          <InstanceSettings
            selectedInstance={selectedInstance}
            instance={
              instances
                ? instances.find((inst) => inst.id === selectedInstance) || null
                : null
            }
            schedule={instanceSchedule}
            blockIo={runBlockIo}
            latestExecutionId={instanceSchedule?.latestExecutionId ?? null}
          />
        </Box>

        <ScriptLogsBody
          scriptData={scriptData}
          scriptLogs={scriptLogs.content}
        />
      </Box>
    </>
  );
};

export default PureScriptLogs;
