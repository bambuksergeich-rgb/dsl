import { AuthOptions } from 'next-auth';
import KeycloakProvider from 'next-auth/providers/keycloak';

import { JWT } from 'next-auth/jwt';

function getAllowedExternalCallbackOrigins() {
  const configuredOrigins =
    process.env.NEXTAUTH_ALLOWED_CALLBACK_ORIGINS?.split(',')
      .map((origin) => origin.trim())
      .filter(Boolean) ?? [];

  if (process.env.NODE_ENV === 'development') {
    configuredOrigins.push('http://localhost:3000');
  }

  return new Set(configuredOrigins);
}

async function refreshAccessToken(token: JWT) {
  const resp = await fetch(`${process.env.REFRESH_TOKEN_URL}`, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: `${process.env.DEMO_FRONTEND_CLIENT_ID}`,
      client_secret: `${process.env.DEMO_FRONTEND_CLIENT_SECRET}`,
      grant_type: 'refresh_token',
      refresh_token: token.refresh_token as string
    }),
    method: 'POST'
  });

  const refreshToken = await resp.json();
  console.log('refreshToken')
  if (!resp.ok) throw refreshToken;
  return {
    ...token,
    access_token: refreshToken.access_token,
    id_token: refreshToken.id_token,
    expires_at: Math.floor(Date.now() / 1000) + refreshToken.expires_in,
    refresh_token: refreshToken.refresh_token
  };
}

export const authOptions: AuthOptions = {secret:`${process.env.NEXTAUTH_SECRET}`,
  providers: [
    KeycloakProvider({
      clientId: `${process.env.DEMO_FRONTEND_CLIENT_ID}`,
      clientSecret: `${process.env.DEMO_FRONTEND_CLIENT_SECRET}`,
      issuer: process.env.AUTH_ISSUER,
    })
  ],
  callbacks: {
    async redirect({ url, baseUrl }) {
      if (url.startsWith('/')) {
        return `${baseUrl}${url}`;
      }

      try {
        const callbackUrl = new URL(url);

        if (callbackUrl.origin === baseUrl) {
          return url;
        }

        if (getAllowedExternalCallbackOrigins().has(callbackUrl.origin)) {
          return url;
        }
      } catch {
        return baseUrl;
      }

      return baseUrl;
    },

    async jwt({ token, user, account, profile, isNewUser }) {
   
      const nowTimeStamp = Math.floor(Date.now() / 1000);
      if (account && typeof account.refresh_expires_in === 'number') {
        token.expires_at = account.expires_at;
        token.access_token = account.access_token;
        token.refresh_token = account.refresh_token;
        token.refresh_expires_in = nowTimeStamp + account.refresh_expires_in;
        return token;
      } else if (
        typeof token.expires_at === 'number' &&
        nowTimeStamp < token.expires_at
      ) {
        return token;
      } else {
        console.log('Token has expired. Will refresh...');
        try {
          const refreshedToken = await refreshAccessToken(token);
          console.log('Token is refreshed.');
          return refreshedToken;
        } catch (error) {
          console.error('Error refreshing access token', error);
          return { ...token, error: 'RefreshAccessTokenError' };
        }
      } 
    },
    async session({ session, token, user }) {

      if (
        session.user &&
        typeof token.access_token === 'string' &&
        typeof token.sub === 'string'
      ) {
        session.user.access_token = token.access_token;
        session.user.userId = token.sub;
      }

      if (
        typeof token.error === 'string' 
        
      ) {
      session.user.error = token.error;  
      }
      
      return session;

    }
  }
};
