'use client';

import React, { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { store } from '@/src/store/store';
import { getScriptDraftById } from '@/src/store/actions/getScriptDraftById';
import { getScriptBlockDraftAction } from '@/src/store/actions/ScriptBlockDraft/getScriptBlockDraftAction';
import { createBlockDraftAction } from '@/src/store/actions/ScriptBlockDraft/createBlockDraftAction';
import { scriptDraftCreate } from '@/src/store/counter/scriptDraft';
import ScriptWizardView from '@/src/components/ScriptWizard/ScriptWizardView';

type LoadResult = { error: string | null };

export default function ScriptWizardPage() {
  const searchParams = useSearchParams();

  const scriptDraftId = searchParams.get('scriptDraftId');
  const blockMode = searchParams.get('block');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // React StrictMode re-runs effects in development. Reuse the same request for
  // the same route key so create mode cannot accidentally create two blocks.
  const inFlightRef = useRef<{ key: string; promise: Promise<LoadResult> } | null>(
    null,
  );
  const activeKeyRef = useRef('');

  useEffect(() => {
    const key = `${scriptDraftId ?? ''}|${blockMode ?? ''}`;
    activeKeyRef.current = key;
    let active = true;

    setLoading(true);
    setError(null);

    const createLoadPromise = async (): Promise<LoadResult> => {
      if (!scriptDraftId) {
        return { error: 'Отсутствует scriptDraftId' };
      }

      if (blockMode !== 'create' && blockMode !== 'edit') {
        return {
          error: 'Неверный параметр block. Используйте "create" или "edit".',
        };
      }

      try {
        const scriptDraft = await getScriptDraftById(scriptDraftId);
        if (!scriptDraft || activeKeyRef.current !== key) {
          return {
            error: scriptDraft ? null : 'Не удалось загрузить Script Draft',
          };
        }

        store.dispatch(scriptDraftCreate(scriptDraft));

        // Constructor may be opened repeatedly before the script itself is
        // published. Reuse the block already linked to the draft instead of
        // creating a fresh empty SCRIPT_GENERATOR on every visit.
        if (scriptDraft.scriptBlockDraftId) {
          const existingBlock = await store.dispatch(
            getScriptBlockDraftAction(scriptDraft.scriptBlockDraftId, {
              retries: 1,
            }),
          );
          return {
            error: existingBlock ? null : 'Не удалось загрузить блок конструктора',
          };
        }

        if (blockMode === 'edit') {
          return { error: 'У Script Draft отсутствует блок для редактирования' };
        }

        const createdBlock = await store.dispatch(
          createBlockDraftAction(scriptDraftId, 'SCRIPT_GENERATOR'),
        );

        return {
          error: createdBlock ? null : 'Не удалось создать блок конструктора',
        };
      } catch (err) {
        console.error(err);
        return { error: 'Не удалось загрузить или создать блок' };
      }
    };

    const promise =
      inFlightRef.current?.key === key
        ? inFlightRef.current.promise
        : createLoadPromise();

    if (inFlightRef.current?.key !== key) {
      inFlightRef.current = { key, promise };
    }

    void promise.then((result) => {
      if (!active || activeKeyRef.current !== key) return;
      setError(result.error);
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, [scriptDraftId, blockMode]);

  if (loading) {
    return (
      <div
        className="h-screen w-full overflow-hidden"
        style={{ background: "#1D222A" }}
        aria-label="Loading constructor"
      >
        <div className="h-[150px] border-b border-white/5 bg-[#1D222A]" />
        <div className="flex h-[calc(100vh-150px)]">
          <div className="flex flex-1 items-start justify-center pt-14">
            <div className="h-[430px] w-[704px] max-w-[calc(100%-48px)] border border-[#4745C7]/60 bg-[#353484] opacity-60" />
          </div>
          <div className="w-[350px] border-l border-white/5 bg-[#10161C]/50" />
        </div>
      </div>
    );
  }
  if (error) {
    return (
      <div className="h-screen w-full bg-[#1D222A] p-10 text-red-400">
        Ошибка: {error}
      </div>
    );
  }

  return <ScriptWizardView />;
}
