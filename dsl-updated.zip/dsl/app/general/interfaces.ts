export interface GeneralPageRowInterface {
  language: string;
  country: string;
  jan: string;
  feb: string;
  mar: string;
}
