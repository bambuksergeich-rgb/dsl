'use client';

import { GeneralSubHeader } from '@/src/components/GeneralPageComponents/GeneralSubHeader/GeneralSubHeader';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { Grid, Stack } from '@mui/material';
import { useEffect } from 'react';
import GeneralPageTable from '@/src/components/GeneralPageComponents/GeneralPageTable/GeneralPageTable';
import { generalTableData } from './const';

import GeneralPagePieChart from '@/src/components/GeneralPageComponents/GeneralPagePieChart/GeneralPagePieChart';
import GeneralPageBarChart from '@/src/components/GeneralPageComponents/GeneralPageBarChart/GeneralPageBarChart';
import { store } from '@/src/store/store';
import { getCompany } from '@/src/store/actions/getCompany';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { getUser } from '@/src/store/actions/getUser';
import { User } from '@/src/store/counter/userSlice';

export default function GeneralPage(): JSX.Element {
  const tileHeight: string = 'calc((100vh - 300px) / 2)';

  useEffect(() => {
    store.dispatch(getUser());
    store.dispatch(getCompany(false));
  }, []);

  const user: User = useSelector((state: State) => state.user);
  const company = useSelector((state: State) => state.company);

  return (
    <>
      <Grid
        display={'grid'}
        gridTemplateRows={'auto 1fr'}
        sx={{
          width: '100%',
          height: '100%'
        }}
      >
        <GeneralSubHeader
          name={user.firstName}
          company={company}
          subHeaderPadding='42px 40px 43px 40px'
        />
        <Grid
          gridTemplateRows={`${tileHeight} ${tileHeight}`}
          sx={{
            display: 'grid',
            width: 'calc(100% - 80px)',
            height: 'calc(100% - 45px)',
            margin: '0 40px 40px 40px',
            gap: '7px',
            border: '3px solid #3D3AB8'
          }}
        >
          <Grid
            display={'grid'}
            gridTemplateColumns={'1fr 1fr'}
            gap={'7px'}
            sx={{
              width: '100%',
              height: '100%'
            }}
          >
            <Stack
              sx={{
                height: '100%',
                width: '100%',
                backgroundColor: '#10161C80',
                borderRadius: '14px',
                overflow: 'hidden'
              }}
            >
              <Grid
                display={'grid'}
                gridTemplateRows={'44px 1fr'}
                sx={{
                  overflow: 'hidden'
                }}
              >
                <Stack
                  flexDirection={'row'}
                  sx={{
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <TypographyMontserrat500 fontSize={'20px'}>
                    {'Chart'}
                  </TypographyMontserrat500>
                </Stack>
                <GeneralPagePieChart height={`calc(${tileHeight} - 44px)`} />
              </Grid>
            </Stack>
            <Stack
              sx={{
                height: '100%',
                width: '100%',
                backgroundColor: '#10161C80',
                borderRadius: '14px',
                overflow: 'hidden'
              }}
            >
              <Grid
                display={'grid'}
                gridTemplateRows={'44px 1fr'}
                sx={{
                  overflow: 'hidden'
                }}
              >
                <Stack
                  flexDirection={'row'}
                  sx={{
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <TypographyMontserrat500 fontSize={'20px'}>
                    {'Chart'}
                  </TypographyMontserrat500>
                </Stack>
                <GeneralPageBarChart height={`calc(${tileHeight} - 44px)`} />
              </Grid>
            </Stack>
          </Grid>
          <Grid
            display={'grid'}
            gridTemplateColumns={'1fr 1fr'}
            gap={'7px'}
            sx={{
              width: '100%',
              height: '100%'
            }}
          >
            <GeneralPageTable generalTableData={generalTableData} />
            <Stack
              sx={{
                height: '100%',
                width: '100%'
              }}
            ></Stack>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
}
