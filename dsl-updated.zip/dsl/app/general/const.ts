import { GeneralPageRowInterface } from './interfaces';

export const generalTableData: GeneralPageRowInterface[] = [
  {
    language: 'English',
    country: 'Ireland',
    jan: '$362,392',
    feb: '$362,392',
    mar: '$362,392'
  },
  {
    language: 'English',
    country: 'Ireland',
    jan: '$362,392',
    feb: '$362,392',
    mar: '$362,392'
  },
  {
    language: 'English',
    country: 'Ireland',
    jan: '$362,392',
    feb: '$362,392',
    mar: '$362,392'
  },
  {
    language: 'English',
    country: 'Ireland',
    jan: '$362,392',
    feb: '$362,392',
    mar: '$362,392'
  },
  {
    language: 'English',
    country: 'Ireland',
    jan: '$362,392',
    feb: '$362,392',
    mar: '$362,392'
  },
  {
    language: 'English',
    country: 'Ireland',
    jan: '$362,392',
    feb: '$362,392',
    mar: '$362,392'
  },
  {
    language: 'English',
    country: 'Ireland',
    jan: '$362,392',
    feb: '$362,392',
    mar: '$362,392'
  },
  {
    language: 'English',
    country: 'Ireland',
    jan: '$362,392',
    feb: '$362,392',
    mar: '$362,392'
  }
];
