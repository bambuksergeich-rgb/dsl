import { TableCell, styled } from '@mui/material';

export const Cell = styled(TableCell)(({}) => ({
  paddingTop: '7px',
  paddingBottom: '7px',
  border: '1px solid rgba(255, 255, 255, 0.15)'
}));
