import { DataTable } from './interface';

export const dataTable: DataTable[] = [
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Widget33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  }
];
