export interface DataTable {
  name: string;
  date: string;
  action: string;
  blueAction?: string;
  path: string;
  employee?: string
}
