'use client';

import React from 'react';
import { Header } from '@/app/dashboards/create/components/Header/Header';
import { Dashboard } from '@/app/dashboards/create/components/Dashboard/Dashboard';
import { EditWidgetData } from '@/app/dashboards/create/components/EditWidgetData/ViewWidgetData';
import { Sidebar } from '@/app/dashboards/create/components/Sidebar/Sidebar';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';

export const DashboardView: React.FC = () => {
  const { isFullscreenMode } = useAppSelector((state) => state.common);
  const { view } = useAppSelector((state) => state.dashboard);

  return (
    <div className='flex h-full gap-2'>
      <div className='flex flex-col w-full shrink'>
        {isFullscreenMode ? null : <Header />}
        <div className='grow h-full'>
          {view === 'DASHBOARD' ? <Dashboard /> : null}
          {view === 'EDIT_WIDGET_DATA' ? (
            <EditWidgetData widgetName='Widget name' />
          ) : null}
        </div>
      </div>
      {isFullscreenMode ? null : <Sidebar />}
    </div>
  );
};
