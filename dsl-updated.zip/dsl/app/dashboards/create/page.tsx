'use client';

import React from 'react';
import classNames from 'classnames';
import clsx from 'clsx';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { DashboardView } from '@/app/dashboards/[id]/dashboard.view';

export default function Page() {
  const { isFullscreenMode } = useAppSelector((state) => state.common);

  return (
    <div
      className={clsx(
        'w-full flex h-screen bg-custom-linear-gradient overflow-hidden',
        isFullscreenMode && 'absolute left-0 top-0',
        isFullscreenMode &&
          'top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2'
      )}
      style={{}}
    >
      <div
        className={classNames(
          { 'pb-8': false },
          'flex flex-col flex-grow w-full'
        )}
      >
        <div className='flex-grow'>
          <DashboardView create />
        </div>
      </div>
    </div>
  );
}
