import React from 'react';
import { ItalicFontIcon, UnderlineFontIcon } from '@/assets/icons';
import {
  backgroundFillTypeOptions,
  fontOptions
} from '@/app/dashboards/[id]/components/Sidebar/components/Settings/const';
import { CssAccordion } from '@/app/dashboards/[id]/components/Sidebar/components/Settings/components/CssAccordion';
import { Select } from '@/src/components/UI/Select/Select';
import { NumberInput } from '@/src/components/UI/NumberInput/NumberInput';
import { ColorPicker } from '@/src/components/UI/ColorPicker/ColorPicker';

export const CssSection: React.FC = () => {
  const [font, setFont] = React.useState<any>(fontOptions[0]);
  const [frontColor, setFrontColor] = React.useState<string>('#000000');
  const [frontSize, setFrontSize] = React.useState<number>(14);
  const [backgroundFillType, setBackgroundFillType] = React.useState<any>(
    backgroundFillTypeOptions[0]
  );
  const [backgroundFillTypeColor, setBackgroundFillTypeColor] =
    React.useState<string>('#000000');

  const onFontChange = (option: any) => {
    setFont(option);
  };

  const onFrontColorChange = (value: string) => {
    setFrontColor(value);
  };

  const onFrontSizeChange = (value: number) => {
    setFrontSize(value);
  };
  const onFrontSizeIncrease = () => {
    setFrontSize((prev) => prev + 1);
  };
  const onFrontSizeDecrease = () => {
    setFrontSize((prev) => prev - 1);
  };

  const onBackgroundFillTypeChange = (option: any) => {
    setBackgroundFillType(option);
  };

  const onBackgroundFillTypeColorChange = (value: string) => {
    setBackgroundFillTypeColor(value);
  };

  return (
    <div className='flex flex-col gap-6'>
      <CssAccordion
        label='Font'
        initialOpen
      >
        <div className='flex flex-col gap-3.5'>
          <div className='flex justify-between items-center'>
            <div className='text-sm font-medium'>Font</div>
            <div className='font-semibold text-dsl-purple-700 text-sm cursor-pointer'>
              SourceSansPro
            </div>
          </div>
          <div>
            <div className='text-sm font-medium mb-1.5'>Style</div>
            <div className='flex items-center gap-1'>
              <div className='flex-grow'>
                <Select
                  onChange={onFontChange}
                  size='sm'
                  options={fontOptions}
                  activeOption={font}
                  placeholder='Font'
                ></Select>
              </div>
              <button
                className='p-2 bg-white bg-opacity-15 rounded'
                color='secondary'
              >
                <ItalicFontIcon
                  width={20}
                  height={20}
                  color='white'
                />
              </button>
              <button className='p-2 bg-white bg-opacity-15 rounded'>
                <UnderlineFontIcon
                  width={20}
                  height={20}
                  color='white'
                />
              </button>
            </div>
          </div>
          <div className='flex gap-3'>
            <div>
              <div className='text-sm mb-1.5 font-medium'>Front size:</div>
              <NumberInput
                onDecreaseClick={onFrontSizeDecrease}
                onIncreaseClick={onFrontSizeIncrease}
                value={frontSize}
                onChange={(e) =>
                  onFrontSizeChange(parseInt(e.currentTarget.value))
                }
                type='number'
              />
            </div>
            <div className='flex flex-col items-start pr-6'>
              <div className='text-sm mb-1.5 font-medium'>Front color:</div>
              <ColorPicker
                position='bottom-right'
                value={frontColor}
                onChange={onFrontColorChange}
              />
            </div>
          </div>
        </div>
      </CssAccordion>
      <CssAccordion
        label='Background'
        initialOpen
      >
        <div className='flex flex-col gap-3.5'>
          <Select
            label='Fill type'
            onChange={onBackgroundFillTypeChange}
            options={backgroundFillTypeOptions}
            activeOption={backgroundFillType}
            size='sm'
          />
          <div>
            <div className='text-sm font-medium mb-1.5'>Fill Type Color:</div>
            <ColorPicker
              position='bottom-left'
              value={backgroundFillTypeColor}
              onChange={onBackgroundFillTypeColorChange}
            />
          </div>
        </div>
      </CssAccordion>
    </div>
  );
};
