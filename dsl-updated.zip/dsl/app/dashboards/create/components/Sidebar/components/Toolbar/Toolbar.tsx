// import React from 'react';
// import classNames from 'classnames';
// import { WidgetsSection } from '@/app/dashboards/[id]/components/Sidebar/components/Toolbar/Sections/WidgetsSection';
// import { DataSection } from '@/app/dashboards/[id]/components/Sidebar/components/Toolbar/Sections/DataSection';
// import { ElementsSection } from '@/app/dashboards/[id]/components/Sidebar/components/Toolbar/Sections/ElementsSection';
// import { useAppSelector } from '@/src/hooks/typedAsyncThunk';

// interface ToolbarProps {
//   height: number;
// }

// export const Toolbar: React.FC<ToolbarProps> = ({ height }) => {
//   const { toolbar } = useAppSelector((state) => state.common);
//   const { view } = useAppSelector((state) => state.dashboard);
//   const isOrderGrid = toolbar.order === 'grid';
//   const isOrderList = toolbar.order === 'list';

//   return (
//     <div
//       className={classNames(
//         {
//           'px-4': isOrderGrid,
//           'pl-1 pr-3.5': isOrderList,
//           'blur-sm pointer-events-none': view === 'EDIT_WIDGET_DATA'
//         },
//         'overflow-y-auto w-full z-20'
//       )}
//       style={{ height, backgroundColor: '#232831' }}
//     >
//       <WidgetsSection />
//       <DataSection />
//       {/* <ElementsSection /> */}
//     </div>
//   );
// };
