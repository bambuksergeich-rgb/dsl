// import React from 'react';
// import { GridIcon, ListIcon } from '@/assets/icons';
// import { useDispatch } from 'react-redux';
// import classNames from 'classnames';
// import 'react-tooltip/dist/react-tooltip.css';
// import { Tooltip } from 'react-tooltip';
// import { IWidgetTemplate, widgets } from '@/app/dashboards/[id]/components/Sidebar/components/Toolbar/Sections/const';
// import {useAppSelector} from "@/src/hooks/typedAsyncThunk";
// import {departmentsAPI} from "@/src/store/api/departmentsAPI";
// import {widgetsAPI} from "@/src/store/api/widgetsAPI";
// import {appActions} from "@/src/store/slices/app.slice";
// import {dashboardActions} from "@/src/store/slices/dashboard.slice";
// import { Button } from '@/src/components/UI/Button/Button';
// import { Group } from '@/src/components/Group/Group';

// export const WidgetsSection: React.FC = () => {
//   const dispatch = useDispatch();
//   const { order } = useAppSelector((state) => state.common.toolbar);
//   const { data: departments } = departmentsAPI.useGetAllQuery();
//   const { data: widgetTemplates } = widgetsAPI.useGetWidgetTemplatesQuery(
//       { departmentId: departments?.content[0].id as string },
//       { skip: !departments }
//   );

//   const { data: widgetsData } = widgetsAPI.useGetWidgetsQuery(
//       { departmentId: departments?.content[0].id as string },
//       { skip: !departments }
//   );

//   const isOrderGrid = order === 'grid';
//   const isOrderList = order === 'list';

//   const onOrderChange = (order: 'grid' | 'list') => {
//     dispatch(appActions.setToolbarOrder(order));
//     if (order === 'grid') {
//       dispatch(appActions.closeToolbarSettings());
//     }
//   };

//   const onWidgetClick = () => {
//     dispatch(appActions.openToolbarSettings());
//     dispatch(appActions.setToolbarOrder('list'));
//   };

//   const onDragStart = (widget: Omit<IWidgetTemplate, 'icon'>) => {
//     console.log(widget)
//     dispatch(dashboardActions.setDraggingWidgetTemplate(widget));
//   };
//   const onDragEnd = () => {
//     dispatch(dashboardActions.setDraggingWidgetTemplate(null));
//   };

//   return (
//     <div className={classNames({ 'border-b border-white': isOrderList }, 'flex flex-col gap-6 pt-6 pb-5')}>
//       {isOrderGrid ? <h3 className="text-center font-semibold text-xs">Widgets</h3> : null}
//       <div className={classNames({ 'flex-col items-center': isOrderList }, 'flex gap-1 justify-center')}>
//         <div>
//           <Button
//             onClick={() => onOrderChange('grid')}
//             fitContent
//             size="sm"
//             icon={GridIcon}
//             color={isOrderGrid ? 'primary' : 'dark'}
//           />
//         </div>
//         <div>
//           <Button
//             onClick={() => onOrderChange('list')}
//             fitContent
//             size="sm"
//             icon={ListIcon}
//             color={isOrderList ? 'primary' : 'dark'}
//           />
//         </div>
//       </div>
//       <div className="flex flex-col gap-1">
//         <Group size={isOrderList ? 'sm' : 'md'} isFullWidth={isOrderGrid} label="Group 1">
//           <div className={classNames({ 'flex-col items-center': isOrderList }, 'flex flex-wrap justify-start gap-1')}>
//             {widgets.map(({ icon, ...widget }, i) => (
//               <div key={i} className="basis-8">
//                 <Button
//                   draggable
//                   onDragStart={() => onDragStart(widget)}
//                   onDragEnd={onDragEnd}
//                   onClick={onWidgetClick}
//                   color="dark"
//                   icon={icon}
//                   size="sm"
//                 />
//               </div>
//             ))}
//           </div>
//         </Group>
//         <Group size={isOrderList ? 'sm' : 'md'} isFullWidth={isOrderGrid} label="Group 2">
//           <div className={classNames({ 'flex-col items-center': isOrderList }, 'flex flex-wrap justify-start gap-1')}>
//             {widgets.map((widget, i) => (
//               <div key={i} className="basis-8">
//                 <Button
//                   onClick={onWidgetClick}
//                   data-tooltip-id="my-tooltip"
//                   data-tooltip-place="left-end"
//                   data-tooltip-position-strategy="fixed"
//                   color="dark"
//                   icon={widget.icon}
//                   size="sm"
//                 />
//                 <Tooltip className="!bg-black !rounded-xl !p-4 !z-50" id="my-tooltip">
//                   <div className="bg-black max-w-64">
//                     <h4 className="mb-1 font-semibold">Name</h4>
//                     <p>
//                       Corem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a,
//                       mattis tellus. Sed dignissim, metus nec fringilla accumsan,{' '}
//                     </p>
//                   </div>
//                 </Tooltip>
//               </div>
//             ))}
//           </div>
//         </Group>
//       </div>
//     </div>
//   );
// };
