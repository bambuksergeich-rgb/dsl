import React from 'react';
import { DetailedIcon } from '@/assets/icons';
import { DashboardGridConfigurationModal } from '@/app/dashboards/[id]/components/DashboardGridConfigurationModal/DashboardGridConfigurationModal';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { useAppDispatch } from '@/src/hooks/typedAsyncThunk';
import { dashboardsAPI } from '@/src/store/api/dashboardsAPI';
import { IDashboard } from '@/src/models/IDashboard';
import { appActions } from '@/src/store/slices/app.slice';
import { Button } from '@/src/components/UI/Button/Button';
import { CreateDashboardModal } from '@/src/components/Modal/CreateDashboardModal';
import { DashboardSettingsModal } from '@/src/components/Modal/DashboardSettingsModal/DashboardSettingsModal';
import { sanitizePath } from '@/src/helpers/basePrefix';

export const DetailedDropdown: React.FC = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const [isOpen, setIsOpen] = React.useState<boolean>(false);
  const params = useParams<{ id: string }>();
  const dashboardId = params?.id as string;

  const { data: dashboard } = dashboardsAPI.useGetDashboardByIdQuery({
    id: dashboardId
  });
  const [createDraftFromDashboard] =
    dashboardsAPI.useCreateDraftFromDashboardMutation();
  const [updateDraft] = dashboardsAPI.useUpdateDraftMutation();
  const [publish] = dashboardsAPI.usePublishDraftMutation();
  const [deleteDashboard] = dashboardsAPI.useDeleteDashboardByIdMutation();
  const searchParams = useSearchParams();

  const onUpdateDashboardSubmit = async (values: IDashboard) => {
    if (!dashboard) return;

    try {
      const createRes = await createDraftFromDashboard({
        sourceId: dashboard.id
      }).unwrap();

      const updateRes = await updateDraft({
        draftId: createRes.draftId,
        name: values.name,
        description: values.description,
        columns: values.columns,
        rows: values.rows
      }).unwrap();

      await publish({
        draftId: updateRes.draftId,
        name: updateRes.name,
        description: updateRes.description,
        columns: updateRes.columns,
        rows: updateRes.rows
      }).unwrap();
    } catch (e) {}
  };

  const onDescriptionModalOpen = () => {
    if (!dashboard) return;

    dispatch(
      appActions.setModalContent(
        <DashboardSettingsModal
          initialValues={dashboard ?? undefined}
          onSubmit={(values) =>
            onUpdateDashboardSubmit({
              ...dashboard,
              name: values.name,
              description: values.description
            })
          }
        />
      )
    );
  };

  const onScaleConfigurationModalOpen = () => {
    if (!dashboard) return;

    dispatch(
      appActions.setModalContent(
        <DashboardGridConfigurationModal
          initialValues={
            dashboard
              ? { columns: dashboard.columns, rows: dashboard.rows }
              : undefined
          }
          onSubmit={(values) =>
            onUpdateDashboardSubmit({
              ...dashboard,
              columns: values.columns,
              rows: values.rows
            })
          }
        />
      )
    );
  };

  const onDeleteClick = async () => {
    const department = searchParams.get('departmentId');
    await deleteDashboard(dashboardId);
    router.push(sanitizePath(`/dashboards?departmentId=${department}`));
  };

  const onMouseEnter = () => {
    setIsOpen(true);
  };
  const onMouseLeave = () => {
    setIsOpen(false);
  };

  return (
    <div className='relative z-50'>
      <div
        className='relative z-10'
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
      >
        <Button icon={DetailedIcon} />
      </div>
      {isOpen ? (
        <div
          onMouseEnter={onMouseEnter}
          onMouseLeave={onMouseLeave}
          className='absolute left-0 top-full px-1.5 py-3 bg-black rounded-lg border border-white border-opacity-10 text-sm min-w-56'
        >
          <button
            className='py-3 !px-4 active-option w-full text-left'
            onClick={onDescriptionModalOpen}
          >
            Description
          </button>
          <button
            className='py-3 !px-4 active-option w-full text-left'
            onClick={onScaleConfigurationModalOpen}
          >
            Scale Configuration
          </button>
          <button
            className='py-3 !px-4 active-option w-full text-left'
            onClick={onDeleteClick}
          >
            Remove
          </button>
        </div>
      ) : null}
    </div>
  );
};
