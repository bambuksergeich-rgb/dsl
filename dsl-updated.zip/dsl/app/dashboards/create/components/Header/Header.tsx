import React from 'react';
import Link from 'next/link';
import { useParams, useSearchParams } from 'next/navigation';
import 'react-loading-skeleton/dist/skeleton.css';
import { useAppDispatch, useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { dashboardActions } from '@/src/store/slices/dashboard.slice';
import { Button } from '@/src/components/UI/Button/Button';
import { appActions } from '@/src/store/slices/app.slice';
import { CreateDashboardModal } from '@/src/components/Modal/CreateDashboardModal';

export const Header: React.FC = () => {
  const dispatch = useAppDispatch();
  const searchParams = useSearchParams();
  const { currentStorage } = useAppSelector((state) => state.dashboard);
  const params = useParams<{ id: string }>();
  const department = searchParams.get('departmentId');

  const onDashboardSaveClick = () => {
    dispatch(
      appActions.setModalContent(
        <CreateDashboardModal departmentId={department as string} />
      )
    );
  };

  const onWidgetDataSaveClick = () => {
    dispatch(dashboardActions.setCurrentStorage(null));
  };

  const onBackClick = () => {
    dispatch(dashboardActions.setCurrentStorage(null));
  };

  return (
    <div className='flex justify-between items-center w-full p-10'>
      <div className='flex gap-10 items-center'>
        <h1 className='font-medium text-3xl '>{'New Dashboard'}</h1>
      </div>
      <div className='flex gap-3'>
        <Link
          href={`/dashboards?departmentId=${department}`}
          onClick={onBackClick}
        >
          <Button color='secondary'>Back</Button>
        </Link>
        <Button
          onClick={
            currentStorage ? onWidgetDataSaveClick : onDashboardSaveClick
          }
        >
          Save
        </Button>
      </div>
    </div>
  );
};
