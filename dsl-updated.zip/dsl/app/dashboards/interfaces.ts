interface Grid {
  x: number;
  y: number;
}

export interface DashboardRowInterface {
  name: string;
  description: string;
  createdDate: string;
  modifiedDate: string;
  modifiedBy: string;
  group: string;
  grid: Grid;
  numberOfWidgets: number;
}
