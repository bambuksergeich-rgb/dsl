import {
  BASE_GRID_ORDER_TOOLBAR_WIDTH,
  LIST_TOOLBAR_WIDTH,
  MAX_RESIZED_TOOLBAR_WIDTH,
  SETTINGS_TOOLBAR_WIDTH,
  TOOLBAR_TRANSITION_MS
} from '@/app/dashboards/[id]/const';

export const getDefaultToolbarStyles = (
  isOrderGrid: boolean,
  isToolbarExtended: boolean
) => ({
  transition: `all ${TOOLBAR_TRANSITION_MS}ms ease-in`,
  flexBasis: isOrderGrid
    ? isToolbarExtended
      ? MAX_RESIZED_TOOLBAR_WIDTH
      : BASE_GRID_ORDER_TOOLBAR_WIDTH
    : LIST_TOOLBAR_WIDTH,
  width: isOrderGrid
    ? isToolbarExtended
      ? MAX_RESIZED_TOOLBAR_WIDTH
      : BASE_GRID_ORDER_TOOLBAR_WIDTH
    : LIST_TOOLBAR_WIDTH,
  flexShrink: 0
});

export const getTransitionToolbarStyles = (
  isOrderGrid: boolean,
  isToolbarExtended: boolean
) => ({
  entering: {
    flexBasis: isOrderGrid
      ? isToolbarExtended
        ? MAX_RESIZED_TOOLBAR_WIDTH
        : BASE_GRID_ORDER_TOOLBAR_WIDTH
      : LIST_TOOLBAR_WIDTH,
    width: isOrderGrid
      ? isToolbarExtended
        ? MAX_RESIZED_TOOLBAR_WIDTH
        : BASE_GRID_ORDER_TOOLBAR_WIDTH
      : LIST_TOOLBAR_WIDTH
  },
  entered: {
    flexBasis: SETTINGS_TOOLBAR_WIDTH + LIST_TOOLBAR_WIDTH,
    width: SETTINGS_TOOLBAR_WIDTH + LIST_TOOLBAR_WIDTH
  },
  exiting: {
    flexBasis: SETTINGS_TOOLBAR_WIDTH + LIST_TOOLBAR_WIDTH,
    width: SETTINGS_TOOLBAR_WIDTH + LIST_TOOLBAR_WIDTH
  },
  exited: {
    flexBasis: isOrderGrid
      ? isToolbarExtended
        ? MAX_RESIZED_TOOLBAR_WIDTH
        : BASE_GRID_ORDER_TOOLBAR_WIDTH
      : LIST_TOOLBAR_WIDTH,
    width: isOrderGrid
      ? isToolbarExtended
        ? MAX_RESIZED_TOOLBAR_WIDTH
        : BASE_GRID_ORDER_TOOLBAR_WIDTH
      : LIST_TOOLBAR_WIDTH
  },
  unmounted: {}
});

export const getDefaultSettingsStyle = () => ({
  transition: `all ${TOOLBAR_TRANSITION_MS}ms ease-in`,
  flexBasis: 0,
  width: 0,
  flexShrink: 0
});

export const getTransitionSettingsStyles = () => ({
  entering: { flexBasis: 0, width: 0 },
  entered: { flexBasis: SETTINGS_TOOLBAR_WIDTH, width: SETTINGS_TOOLBAR_WIDTH },
  exiting: { flexBasis: SETTINGS_TOOLBAR_WIDTH, width: SETTINGS_TOOLBAR_WIDTH },
  exited: { flexBasis: 0, width: 0 },
  unmounted: {}
});
