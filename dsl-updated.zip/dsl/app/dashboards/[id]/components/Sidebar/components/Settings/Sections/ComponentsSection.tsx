import React from 'react';
import { CalendarIcon, DetailedIcon, ShevronDownIcon } from '@/assets/icons';
import { Formik } from 'formik';
import classNames from 'classnames';
import { componentsOptions } from '@/app/dashboards/[id]/components/Sidebar/components/Settings/const';
import { Select } from '@/src/components/UI/Select/Select';
import { Button } from '@/src/components/UI/Button/Button';
import { Input } from '@/src/components/UI/Input/Input';
import { Textarea } from '@/src/components/UI/Textarea/Textarea';

export const ComponentsSection: React.FC = () => {
  const [activeOption, setActiveOption] = React.useState(componentsOptions[0]);
  const [isDataOpen, setIsDataOpen] = React.useState(true);

  const onOptionChange = (option: any) => setActiveOption(option);

  const onDataToggle = () => setIsDataOpen((prev) => !prev);

  return (
    <div>
      <div className='flex justify-between items-center mb-4'>
        <Select
          color='primary'
          size='sm'
          options={componentsOptions}
          activeOption={activeOption}
          onChange={onOptionChange}
        ></Select>
        <div>
          <Button
            icon={DetailedIcon}
            size='sm'
          />
        </div>
      </div>
      <Formik
        initialValues={{}}
        onSubmit={() => {}}
      >
        {({ handleSubmit }) => (
          <form onSubmit={handleSubmit}>
            <div className='flex flex-col gap-3 mb-6'>
              <Input
                label='Name'
                placeholder='Enter name'
              />
              <div>
                <div
                  className='flex justify-between items-center gap-2 cursor-pointer mb-1'
                  onClick={onDataToggle}
                >
                  <div className='flex  items-center gap-1 '>
                    <div>Data</div>
                    <CalendarIcon
                      width={19}
                      height={18}
                    />
                  </div>
                  <div className={classNames({ '-rotate-90': !isDataOpen })}>
                    <ShevronDownIcon
                      width={18}
                      height={18}
                      color='white'
                    />
                  </div>
                </div>
                {isDataOpen ? <Textarea placeholder='Enter data' /> : null}
              </div>
              <Input
                label='Selector'
                placeholder='Enter selector'
              />
            </div>
            <div className='flex justify-end'>
              <div>
                <Button type='submit'>Save</Button>
              </div>
            </div>
          </form>
        )}
      </Formik>
    </div>
  );
};
