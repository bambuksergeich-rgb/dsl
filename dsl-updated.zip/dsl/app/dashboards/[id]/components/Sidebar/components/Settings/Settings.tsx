import React from 'react';
import { MenuOpenIcon } from '@/assets/icons';
import { useDispatch } from 'react-redux';
import {
  nameToSectionMap,
  sectionOptions
} from '@/app/dashboards/[id]/components/Sidebar/components/Settings/const';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { appActions } from '@/src/store/slices/app.slice';
import { Select } from '@/src/components/UI/Select/Select';

export const Settings: React.FC = () => {
  const dispatch = useDispatch();
  const { settings } = useAppSelector((state) => state.common.toolbar);

  if (!settings) return null;

  const onCloseClick = () => {
    dispatch(appActions.closeToolbarSettings());
  };

  const onOptionChange = (option: any) => {
    if (option.value === 'components') {
      dispatch(appActions.setToolbarSettingsSection('components'));
    } else if (option.value === 'css') {
      dispatch(appActions.setToolbarSettingsSection('css'));
    } else if (option.value === 'filter') {
      dispatch(appActions.setToolbarSettingsSection('filter'));
    }
  };

  const Section = nameToSectionMap[settings.section];

  return (
    <div
      className='p-4 bg-black bg-opacity-50 h-full'
      style={{ backgroundColor: 'rgb(35, 40, 49)' }}
    >
      <div className='flex gap-2 mb-6'>
        <button
          className='flex-shrink'
          onClick={onCloseClick}
        >
          <MenuOpenIcon />
        </button>
        <div className='flex-grow text-center pr-8'>Widgets</div>
      </div>
      <div className='relative z-40 mb-3'>
        <Select
          onChange={onOptionChange}
          options={sectionOptions}
          activeOption={sectionOptions.find(
            (s) => s.value === settings.section
          )}
        />
      </div>
      <Section />
    </div>
  );
};
