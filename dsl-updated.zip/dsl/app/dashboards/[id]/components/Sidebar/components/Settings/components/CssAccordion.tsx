import React from 'react';
import { ShevronDownIcon } from '@/assets/icons';
import classNames from 'classnames';

interface CssAccordionProps {
  label: string;
  children: React.ReactNode;
  initialOpen?: boolean;
}

export const CssAccordion: React.FC<CssAccordionProps> = ({
  label,
  children,
  initialOpen = false
}) => {
  const [isOpen, setIsOpen] = React.useState(initialOpen);

  const onLabelClick = () => {
    setIsOpen((prev) => !prev);
  };

  return (
    <div className='w-full'>
      <div
        className='flex items-center justify-between pb-1 border-b border-white border-opacity-10 cursor-pointer font-medium'
        onClick={onLabelClick}
      >
        {label}
        <div className={classNames({ '-rotate-90': !isOpen })}>
          <ShevronDownIcon
            width={24}
            height={24}
            color='white'
          />
        </div>
      </div>
      {isOpen ? <div className='mt-3.5'>{children}</div> : null}
    </div>
  );
};
