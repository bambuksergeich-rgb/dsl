import React from 'react';
import classNames from 'classnames';
import { elements } from '@/app/dashboards/[id]/components/Sidebar/components/Toolbar/Sections/const';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { Button } from '@/src/components/UI/Button/Button';

export const ElementsSection: React.FC = () => {
  const { order } = useAppSelector((state) => state.common.toolbar);

  const isOrderGrid = order === 'grid';
  const isOrderList = order === 'list';

  return (
    <div className='flex flex-col gap-6 pt-6 pb-5'>
      {isOrderGrid ? (
        <h3 className='text-center font-semibold text-xs'>Elements</h3>
      ) : null}
      <div
        className={classNames(
          { 'items-center': isOrderList },
          'flex flex-col gap-1'
        )}
      >
        {elements.map((element) => (
          <Button
            key={element.label}
            fitContent
            size='sm'
            align='left'
            color='dark'
            icon={element.icon}
          >
            {isOrderGrid ? element.label : undefined}
          </Button>
        ))}
      </div>
    </div>
  );
};
