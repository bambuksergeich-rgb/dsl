import React from 'react';
import { IconType, ShevronDownIcon } from '@/assets/icons';
import classNames from 'classnames';

interface FilterAccordionProps {
  label: string;
  children: React.ReactNode;
  icon?: IconType;
  initialOpen?: boolean;
}

export const FilterAccordion: React.FC<FilterAccordionProps> = ({
  label,
  children,
  icon,
  initialOpen = false
}) => {
  const [isOpen, setIsOpen] = React.useState(initialOpen);

  const onLabelClick = () => {
    setIsOpen((prev) => !prev);
  };

  const Icon = icon;

  return (
    <div className='flex flex-col'>
      <div
        className='active-option flex cursor-pointer !px-8'
        onClick={onLabelClick}
      >
        <div className='flex items-center gap-3 py-2.5'>
          {Icon ? (
            <Icon
              width={24}
              height={24}
            />
          ) : null}
          <div className='flex  gap-1'>
            {label}
            <div className={classNames({ '-rotate-90': !isOpen })}>
              <ShevronDownIcon
                width={24}
                height={24}
                color='white'
              />
            </div>
          </div>
        </div>
      </div>
      {isOpen ? <div className='mt-3.5 pb-3.5'>{children}</div> : null}
    </div>
  );
};
