import React from 'react';
import { LineChartOutlineIcon } from '@/assets/icons';
import { FilterAccordion } from '@/app/dashboards/[id]/components/Sidebar/components/Settings/components/FilterAccordion';

export const FilterSection: React.FC = () => {
  const componentsStyles = 'w-full px-6 py-1.5 border border-white rounded-full text-sm font-medium';

  return (
    <div>
      <FilterAccordion label="Select" icon={LineChartOutlineIcon} initialOpen>
        <div className="flex flex-wrap pl-8 gap-2.5">
          <div className="shrink-0">
            <div className={componentsStyles}>Button 1</div>
          </div>
          <div className="shrink-0">
            <div className={componentsStyles}>Buttonbutton1</div>
          </div>
          <div className="shrink-0">
            <div className={componentsStyles}>Button 1</div>
          </div>

          <div className="shrink-0">
            <div className={componentsStyles}>Buttonbutton1</div>
          </div>
          <div className="shrink-0">
            <div className={componentsStyles}>Buttonbutton1</div>
          </div>
          <div className="shrink-0">
            <div className={componentsStyles}>Button 1</div>
          </div>
        </div>
      </FilterAccordion>
      <FilterAccordion label="Select" icon={LineChartOutlineIcon} initialOpen>
        <div className="flex flex-wrap pl-8 gap-2.5">
          <div className="shrink-0">
            <div className={componentsStyles}>Button 1</div>
          </div>
          <div className="shrink-0">
            <div className={componentsStyles}>Buttonbutton1</div>
          </div>
          <div className="shrink-0">
            <div className={componentsStyles}>Button 1</div>
          </div>

          <div className="shrink-0">
            <div className={componentsStyles}>Buttonbutton1</div>
          </div>
          <div className="shrink-0">
            <div className={componentsStyles}>Buttonbutton1</div>
          </div>
          <div className="shrink-0">
            <div className={componentsStyles}>Button 1</div>
          </div>
        </div>
      </FilterAccordion>
    </div>
  );
};
