import React from 'react';
import { DashboardIcon } from '@/assets/icons';
import classNames from 'classnames';
import { transformArray } from '@/app/dashboards/[id]/components/Sidebar/components/Toolbar/Sections/helpers';
import { useAppDispatch, useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { departmentsAPI } from '@/src/store/api/departmentsAPI';
import { storagesAPI } from '@/src/store/api/storagesAPI';
import { IStorage, IStorageTemp } from '@/src/models/IStorage';
import { dashboardActions } from '@/src/store/slices/dashboard.slice';
import { Group } from '@/src/components/Group/Group';
import { Button } from '@/src/components/UI/Button/Button';

interface DataSectionProps {}

export const DataSection: React.FC<DataSectionProps> = () => {
  const dispatch = useAppDispatch();
  const { order } = useAppSelector((state) => state.common.toolbar);

  const { data: departments } = departmentsAPI.useGetAllQuery();
  const { data: storages } = storagesAPI.useGetAllStoragesQuery(
    { departmentId: departments?.content[0].id as string },
    { skip: !departments }
  );

  const storagesWithGroups = storages?.content.filter(
    (storage: IStorage) => Boolean(storage.groupId)
  );
  const storagesWithoutGroups = storages?.content.filter(
    (storage: IStorage) => !storage.groupId
  );
  const groupedStorages = transformArray(storagesWithGroups ?? []);

  const isOrderGrid = order === 'grid';
  const isOrderList = order === 'list';

  const onDragStart = (storage: IStorage) => {
    const storageType: IStorageTemp['type'] =
      storage.type === 'SQL' || storage.type === 'CARD' ? storage.type : 'DATA';
    dispatch(
      dashboardActions.setDraggingStorage({
        id: storage.id,
        name: storage.name,
        databaseId: storage.databaseId,
        type: storageType,
        bodyValues: []
      })
    );
  };
  const onDragEnd = () => {
    dispatch(dashboardActions.setDraggingStorage(null));
  };

  return (
    <div
      className={classNames(
        { 'border-b border-white': isOrderList },
        'flex flex-col gap-6 pt-6 pb-5'
      )}
    >
      {isOrderGrid ? (
        <h3 className='text-center font-semibold text-xs'>Data</h3>
      ) : null}
      <div className='flex flex-col gap-1'>
        {groupedStorages.map((groupStorage) => (
          <Group
            key={groupStorage.groupId}
            size={isOrderList ? 'sm' : 'md'}
            isFullWidth={isOrderGrid}
            label={groupStorage.groupName}
          >
            <div
              className={classNames(
                { 'items-center': isOrderList },
                'flex flex-col gap-1'
              )}
            >
              {groupStorage.storages.map((storage) => (
                <Button
                  key={storage.id}
                  align='left'
                  fontWeight='semibold'
                  color='dark'
                  icon={DashboardIcon}
                  size='sm'
                  fitContent
                  draggable
                  onDragStart={() => onDragStart(storage)}
                  onDragEnd={onDragEnd}
                >
                  {isOrderGrid ? storage.name : undefined}
                </Button>
              ))}
            </div>
          </Group>
        ))}
        {storagesWithoutGroups?.map((storage: IStorage) => (
          <Button
            key={storage.id}
            align='left'
            fontWeight='semibold'
            color='dark'
            icon={DashboardIcon}
            size='sm'
            fitContent
            draggable
            onDragStart={() => onDragStart(storage)}
            onDragEnd={onDragEnd}
          >
            {isOrderGrid ? storage.name : undefined}
          </Button>
        ))}
      </div>
    </div>
  );
};
