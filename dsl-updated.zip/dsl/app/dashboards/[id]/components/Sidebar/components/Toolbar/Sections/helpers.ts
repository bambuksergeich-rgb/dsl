import { IStorage } from '@/src/models/IStorage';

interface GroupedTable {
  groupId: string;
  groupName: string;
  storages: IStorage[];
}

export const transformArray = (inputArray: IStorage[]): GroupedTable[] => {
  const groupedTables: { [groupId: string]: GroupedTable } = {};

  inputArray.forEach((table) => {
    const { groupId, groupName } = table;
    if (!groupId || !groupName) return;

    if (!groupedTables[groupId]) {
      groupedTables[groupId] = {
        groupId,
        groupName,
        storages: [],
      };
    }

    groupedTables[groupId].storages.push(table);
  });

  return Object.values(groupedTables);
};
