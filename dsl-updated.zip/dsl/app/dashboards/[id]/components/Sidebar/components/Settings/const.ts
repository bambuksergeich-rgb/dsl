import { ComponentsSection } from '@/app/dashboards/[id]/components/Sidebar/components/Settings/Sections/ComponentsSection';
import { CssSection } from '@/app/dashboards/[id]/components/Sidebar/components/Settings/Sections/CssSection';
import { FilterSection } from '@/app/dashboards/[id]/components/Sidebar/components/Settings/Sections/FilterSection';

export const sectionOptions: any[] = [
  {
    value: 'components',
    label: 'Components',
  },
  {
    value: 'css',
    label: 'CSS UI',
  },
  {
    value: 'filter',
    label: 'Filter',
  },
];

export const nameToSectionMap = {
  components: ComponentsSection,
  css: CssSection,
  filter: FilterSection,
};

export const componentsOptions: any[] = [
  {
    label: 'Components#',
    value: '1',
  },
  {
    label: 'Components2',
    value: '2',
  },
  {
    label: 'Components3',
    value: '3',
  },
];

export const fontOptions: any[] = [
  {
    label: 'Normal',
    value: 'normal',
  },
  {
    label: 'Medium',
    value: 'medium',
  },
  {
    label: 'Semibold',
    value: 'semibold',
  },
  {
    label: 'Bold',
    value: 'bold',
  },
];

export const backgroundFillTypeOptions: any[] = [
  {
    label: 'Solid',
    value: 'solid',
  },
  { label: 'Dashed', value: 'dashed' },
  { label: 'Dotted', value: 'dotted' },
  { label: 'Double', value: 'double' },
  { label: 'Groove', value: 'groove' },
  { label: 'Ridge', value: 'ridge' },
  { label: 'Inset', value: 'inset' },
  { label: 'Outset', value: 'outset' },
];
