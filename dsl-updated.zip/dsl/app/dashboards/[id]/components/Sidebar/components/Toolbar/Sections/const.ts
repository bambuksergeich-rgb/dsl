import {
  BarChartOutlineIcon,
  ButtonElementIcon,
  CheckboxElementIcon,
  DashboardIcon,
  IconType,
  ImageElementIcon,
  LineChartOutlineIcon,
  PieChartOutlineIcon,
  RangeElementIcon,
  SelectElementIcon,
  TextElementIcon,
  TimerOutlineIcon,
} from '@/assets/icons';

export type WidgetType = 'PIE_CHART' | 'LINE_CHART' | 'BAR_CHART' | 'TABLE' | 'INFO_BLOCK';

export interface IWidgetTemplate {
  icon: IconType;
  type: WidgetType;
  preferredWidth: number;
  preferredHeight: number;
}

export const widgets: IWidgetTemplate[] = [
  {
    icon: TimerOutlineIcon,
    preferredWidth: 800,
    preferredHeight: 400,
    type: 'PIE_CHART',
  },
  {
    icon: PieChartOutlineIcon,
    preferredWidth: 800,
    preferredHeight: 400,
    type: 'BAR_CHART',
  },
  {
    icon: LineChartOutlineIcon,
    preferredWidth: 800,
    preferredHeight: 400,
    type: 'LINE_CHART',
  },
  {
    icon: DashboardIcon,
    preferredWidth: 800,
    preferredHeight: 400,
    type: 'TABLE',
  },
  {
    icon: BarChartOutlineIcon,
    preferredWidth: 400,
    preferredHeight: 200,
    type: 'INFO_BLOCK',
  },
];

export const elements = [
  {
    label: 'Select',
    icon: SelectElementIcon,
  },
  {
    label: 'Check-box',
    icon: CheckboxElementIcon,
  },
  {
    label: 'Button',
    icon: ButtonElementIcon,
  },
  {
    label: 'Text',
    icon: TextElementIcon,
  },
  {
    label: 'Picture',
    icon: ImageElementIcon,
  },
  {
    label: 'Range',
    icon: RangeElementIcon,
  },
];
