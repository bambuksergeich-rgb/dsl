export const getSidebarWidth = (
  order: 'list' | 'grid',
  isSettingsOpened: boolean,
  currentSidebarWidth: number
): number => {
  const listSidebarWidth = 52;
  const settingsSidebarWidth = 350;

  if (isSettingsOpened) {
    return listSidebarWidth + settingsSidebarWidth;
  }

  if (order === 'list') {
    return listSidebarWidth;
  } else {
    return currentSidebarWidth;
  }
};
