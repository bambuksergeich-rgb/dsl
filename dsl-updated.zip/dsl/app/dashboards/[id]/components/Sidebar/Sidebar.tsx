import React from 'react';
import { ShevronLeftIcon, ShevronRightIcon } from '@/assets/icons';
import { Toolbar } from '@/app/dashboards/[id]/components/Sidebar/components/Toolbar/Toolbar';
import { Settings } from '@/app/dashboards/[id]/components/Sidebar/components/Settings/Settings';
import { Transition } from 'react-transition-group';
import {
  getDefaultSettingsStyle,
  getDefaultToolbarStyles,
  getTransitionSettingsStyles,
  getTransitionToolbarStyles,
} from '@/app/dashboards/[id]/components/Sidebar/helpers';
import {useAppDispatch, useAppSelector} from "@/src/hooks/typedAsyncThunk";
import {appActions} from "@/src/store/slices/app.slice";

export const Sidebar: React.FC = () => {
  const [toolbarHeight, setToolbarHeight] = React.useState<number>(0);
  const transitionRef = React.useRef<HTMLDivElement>(null);
  const toolbarRef = React.useRef<HTMLDivElement>(null);
  const dispatch = useAppDispatch();
  const { toolbar } = useAppSelector((state) => state.common);

  const isOrderGrid = toolbar.order === 'grid';

  const defaultToolbarStyles = getDefaultToolbarStyles(isOrderGrid, toolbar.extended);
  const transitionToolbarStyles = getTransitionToolbarStyles(isOrderGrid, toolbar.extended);
  const defaultSettingsStyle = getDefaultSettingsStyle();
  const transitionSettingsStyles = getTransitionSettingsStyles();

  const onExtendedToolbar = React.useCallback(() => {
    dispatch(appActions.setToolbarExtended(!toolbar.extended));
  }, [dispatch, toolbar.extended]);

  React.useEffect(() => {
    setToolbarHeight(toolbarRef.current?.clientHeight || 0);
  }, [toolbarRef]);

  return (
    <Transition in={Boolean(toolbar.settings)} nodeRef={transitionRef} timeout={0}>
      {(state) => (
        <div
          className="flex relative max-h-full h-full shrink-0 z-30"
          style={{
            ...defaultToolbarStyles,
            ...transitionToolbarStyles[state],
          }}
          ref={toolbarRef}
        >
          {isOrderGrid ? (
            <button
              className="absolute -left-2.5 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center  rounded-full z-30 bg-black"
              onClick={onExtendedToolbar}
            >
              {toolbar.extended ? (
                <ShevronRightIcon width={18} height={18} />
              ) : (
                <ShevronLeftIcon width={18} height={18} />
              )}
            </button>
          ) : null}
          <Toolbar height={toolbarHeight} />
          <div
            ref={transitionRef}
            className="h-full transition-all"
            style={{
              ...defaultSettingsStyle,
              ...transitionSettingsStyles[state],
            }}
          >
            <Settings />
          </div>
        </div>
      )}
    </Transition>
  );
};
