import React from 'react';
import { StorageTable } from '@/app/dashboards/[id]/components/StorageTable/StorageTable';
import {databaseAPI} from "@/src/store/api/databaseAPI";
import {useAppSelector} from "@/src/hooks/typedAsyncThunk";

interface EditWidgetDataProps {
  widgetName: string;
}

export const EditWidgetData: React.FC<EditWidgetDataProps> = ({ widgetName }) => {
  const { currentStorage } = useAppSelector((state) => state.dashboard);

  const { data: dbStructure } = databaseAPI.useGetDatabaseQuery(
    {
      databaseId: currentStorage?.databaseId as string,
      storageId: currentStorage?.id as string,
    },
    {
      skip: !currentStorage,
    }
  );
  const { data: tableData } = databaseAPI.useGetTableDataQuery(
    { databaseId: currentStorage?.databaseId as string, storageId: currentStorage?.id as string },
    {
      skip: !currentStorage,
    }
  );

  if (!currentStorage || !dbStructure?.tables.length) return;

  const [, , ...headerColumns] = dbStructure.tables[0].columns;

  return (
    <div className="flex h-full gap-1">
      <div className="basis-1/2 relative flex items-center justify-center p-3 h-full bg-black bg-opacity-50">
        <div className="absolute left-3 top-3">
          <h2 className="text-base font-medium mb-0.5">{currentStorage.name}</h2>
          <p className="text-xs font-medium">Storage section</p>
        </div>
        <StorageTable
          headerValues={headerColumns.map((col: any) => col.name)}
          bodyValues={
            tableData?.content.map((row: any) => {
              const [, , ...rest] = row;

              return rest.map((cell: any) => cell.toString());
            }) ?? []
          }
        />
      </div>
      <div className="basis-1/2 relative flex items-center justify-center p-3 h-full bg-black bg-opacity-50">
        <div className="absolute left-3 top-3">
          <h2 className="text-base font-medium mb-0.5">{widgetName}</h2>
          <p className="text-xs font-medium">Widget section</p>
        </div>
      </div>
    </div>
  );
};
