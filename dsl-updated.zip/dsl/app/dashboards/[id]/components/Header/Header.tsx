import React, { useState } from 'react';
import Link from 'next/link';
import { DetailedDropdown } from '@/app/dashboards/[id]/components/Header/components/DetailedDropdown/DetailedDropdown';
import { useParams, useSearchParams } from 'next/navigation';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';
import { useAppDispatch, useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { dashboardsAPI } from '@/src/store/api/dashboardsAPI';
import { dashboardActions } from '@/src/store/slices/dashboard.slice';
import { Button } from '@/src/components/UI/Button/Button';
import { DashboardActivies } from '@/src/components/AllModals/ActiviesModal/DashboardActivies';
import ActiviesModal from '@/src/components/AllModals/ActiviesModal/ActiviesModal';

export const Header: React.FC = () => {
  const dispatch = useAppDispatch();
  const searchParams = useSearchParams();
  const { currentStorage } = useAppSelector((state) => state.dashboard);
  const params = useParams<{ id: string }>();
  const { data } = dashboardsAPI.useGetDashboardByIdQuery({
    id: params?.id as string
  });
  const department = searchParams.get('departmentId');
  const [openActivities, setOpenActivities] = useState<boolean>(false);

  const onDashboardSaveClick = () => {};

  const handleCloseModal = () => {
    setOpenActivities(false);
  };

  const onVisibleActivity = () => {
    setOpenActivities(true);
  };

  const onWidgetDataSaveClick = () => {
    dispatch(dashboardActions.setCurrentStorage(null));
  };

  const onBackClick = () => {
    dispatch(dashboardActions.setCurrentStorage(null));
  };

  return (
    <div className='flex justify-between items-center w-full p-10'>
      <div className='flex gap-10 items-center'>
        <h1 className='font-medium text-3xl w-52'>
          {data ? (
            data.name
          ) : (
            <Skeleton
              width={200}
              height={40}
              baseColor='#161C23'
              highlightColor='#2e3033'
            />
          )}
        </h1>
        <div>
          <DetailedDropdown />
        </div>
      </div>
      <div className='flex gap-3'>
        <Button onClick={onVisibleActivity}>Activities</Button>
        <Link
          href={`/dashboards?departmentId=${department}`}
          onClick={onBackClick}
        >
          <Button color='secondary'>Back</Button>
        </Link>
        <Button
          onClick={
            currentStorage ? onWidgetDataSaveClick : onDashboardSaveClick
          }
        >
          Save
        </Button>
      </div>
      <ActiviesModal
        openModal={openActivities}
        handleCloseModal={handleCloseModal}
      />
    </div>
  );
};
