import React from 'react';

interface StorageTableProps {
  headerValues: string[];
  bodyValues: string[][];
}

export const StorageTable: React.FC<StorageTableProps> = ({ headerValues, bodyValues }) => {
  return (
    <div className="p-3 border border-white border-opacity-15 bg-custom-linear-gradient rounded-xl max-w-xl w-full">
      <div className="flex gap-1 mb-1">
        {headerValues.map((value, i) => (
          <div
            key={i}
            className="grow shrink flex justify-center items-center text-center p-6 bg-black rounded"
            style={{ flexBasis: `${(100 / headerValues.length).toFixed(2)}%` }}
          >
            {value}
          </div>
        ))}
      </div>
      <div className="flex flex-col gap-1">
        {bodyValues.map((row, i) => (
          <div key={i} className="flex gap-1">
            {row.map((value, j) => (
              <div
                key={j}
                className="grow flex justify-center items-center text-center p-6 bg-black rounded"
                style={{ flexBasis: `${(100 / row.length).toFixed(2)}%` }}
              >
                {value}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
