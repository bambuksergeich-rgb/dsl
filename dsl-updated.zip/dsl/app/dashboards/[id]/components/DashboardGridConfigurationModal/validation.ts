import { number, object } from 'yup';

export const updateDashboardScaleConfigurationSchema = object().shape({
  columns: number().min(1).max(50).required('Number of columns is required'),
  rows: number().min(1).max(100).required('Number of rows is required'),
});
