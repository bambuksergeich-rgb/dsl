import React from 'react';
import { CrossIcon } from '@/assets/icons';
import { Formik } from 'formik';
import { useDispatch } from 'react-redux';
import { updateDashboardScaleConfigurationSchema } from '@/app/dashboards/[id]/components/DashboardGridConfigurationModal/validation';
import { appActions } from '@/src/store/slices/app.slice';
import { Input } from '@/src/components/UI/Input/Input';
import { Button } from '@/src/components/UI/Button/Button';

interface FormValues {
  rows: number;
  columns: number;
}

interface DashboardGridConfigurationModalProps {
  initialValues?: FormValues;
  onSubmit?: (values: FormValues) => void;
}

export const DashboardGridConfigurationModal: React.FC<
  DashboardGridConfigurationModalProps
> = ({ initialValues = {} as FormValues, onSubmit }) => {
  const dispatch = useDispatch();
  const close = () => {
    dispatch(appActions.clearModalContent());
  };

  const onSubmitForm = (values: FormValues) => {
    if (onSubmit) {
      onSubmit(values);
    }
    close();
  };

  return (
    <div className='relative z-10 bg-custom-linear-gradient mx-auto p-6 rounded-xl border border-dsl-gray-800 max-w-lg w-full'>
      <Formik
        initialValues={initialValues}
        onSubmit={onSubmitForm}
        validationSchema={updateDashboardScaleConfigurationSchema}
      >
        {({ values, setFieldValue, handleSubmit, errors, isValid }) => (
          <form onSubmit={handleSubmit}>
            <div className='flex justify-between items-center mb-6'>
              <div className='font-medium'>Configuration grid</div>
              <div>
                <Button
                  onClick={close}
                  size='sm'
                  icon={CrossIcon}
                />
              </div>
            </div>
            <div className='flex flex-col gap-6 mb-6'>
              <Input
                name='rows'
                label='Number of rows'
                value={values.rows}
                onInput={(e) => setFieldValue('rows', e.currentTarget.value)}
                placeholder='Enter number of rows'
                type='number'
                error={errors.rows}
              />
              <Input
                name='columns'
                label='Number of Columns'
                value={values.columns}
                onInput={(e) => setFieldValue('columns', e.currentTarget.value)}
                placeholder='Enter number of Columns'
                type='number'
                error={errors.columns}
              />
            </div>
            <div className='flex justify-end gap-1'>
              <div>
                <Button
                  disabled={!isValid}
                  type='submit'
                >
                  Save
                </Button>
              </div>
            </div>
          </form>
        )}
      </Formik>
    </div>
  );
};
