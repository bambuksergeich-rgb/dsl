import React from 'react';
import { MemoGrid } from '@/app/dashboards/[id]/components/Dashboard/components/Grid/Grid';
import { SyncLoader } from 'react-spinners';
import { useAppDispatch, useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { appActions } from '@/src/store/slices/app.slice';
import { FullScreenIcon } from '@/assets/icons';

export const Dashboard: React.FC = () => {
  const dispatch = useAppDispatch();
  const { isFullscreenMode, toolbar, isSidebarFullOpened } = useAppSelector(
    (state) => state.common
  );
  const gridWrapperRef = React.useRef<HTMLDivElement>(null);
  const [gridWidth, setGridWidth] = React.useState<number>(0);
  const [gridHeight, setGridHeight] = React.useState<number>(0);
  const [isLoaded, setIsLoaded] = React.useState<boolean>(false);

  const onToggleFullscreenMode = () => {
    dispatch(appActions.setFullscreenMode(!isFullscreenMode));
  };

  React.useEffect(() => {
    setTimeout(() => setIsLoaded(true), 10);
  }, []);

  React.useEffect(() => {
    if (!gridWrapperRef.current) return;
    setGridWidth(gridWrapperRef.current.clientWidth);
    setGridHeight(gridWrapperRef.current.clientHeight);
  }, [
    isFullscreenMode,
    gridWrapperRef.current?.clientHeight,
    gridWrapperRef.current?.clientWidth,
    isSidebarFullOpened
  ]);

  React.useEffect(() => {
    setTimeout(() => {
      if (!gridWrapperRef.current) return;
      setGridWidth(gridWrapperRef.current.clientWidth);
      setGridHeight(gridWrapperRef.current.clientHeight);
    }, 180);
  }, [toolbar.settings, toolbar.order, toolbar.extended]);

  return (
    <div className='relative h-full bg-black bg-opacity-50'>
      <div
        className='absolute left-0 top-0 w-full h-full'
        ref={gridWrapperRef}
      >
        {isLoaded ? (
          <MemoGrid
            width={gridWidth as number}
            height={gridHeight as number}
          />
        ) : (
          <SyncLoader />
        )}
      </div>
      <div className='absolute left-6 bottom-8 z-30'>
        <button
          className='p-2.5 bg-dsl-gray-100 rounded-md text-dsl-gray-600'
          onClick={onToggleFullscreenMode}
        >
          <FullScreenIcon
            width={20}
            height={20}
          />
        </button>
      </div>
    </div>
  );
};
