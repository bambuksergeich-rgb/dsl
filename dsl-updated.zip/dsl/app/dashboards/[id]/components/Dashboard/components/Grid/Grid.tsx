'use client';
import React, { useEffect, useRef } from 'react';
import { useParams } from 'next/navigation';
import {
  GridClass,
  IObjectCords
} from '@/app/dashboards/[id]/components/Dashboard/components/Grid/GridClass';
import classNames from 'classnames';
import { dashboardActions } from '@/src/store/slices/dashboard.slice';
import { dashboardsAPI } from '@/src/store/api/dashboardsAPI';
import { useAppDispatch, useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { IStorageTemp } from '@/src/models/IStorage';
import { createWidgetDraftRequest } from '@/src/requests/Mapping/createWidgetDraftRequest';

interface ICanvasGridProps {
  width: number;
  height: number;
}

export const Grid: React.FC<ICanvasGridProps> = ({ width, height }) => {
  width -= 15;
  height -= 15;
  const params = useParams<{ id: string }>();
  const [gridClass, setGridClass] = React.useState<GridClass | null>(null);
  const [firstInit, setFirstInit] = React.useState<boolean>(false);
  const [cellSize, setCellSize] = React.useState<number>(0);
  const draggingWidgetRef = useRef<any | null>(null);
  const draggingStorageRef = useRef<IStorageTemp | null>(null);

  const dispatch = useAppDispatch();
  const { isFullscreenMode } = useAppSelector((state) => state.common);
  const { draggingWidgetTemplate, widgets, draggingStorage, tempDashboard } =
    useAppSelector((state) => state.dashboard);

  useEffect(() => {
    if (tempDashboard) {
      localStorage.setItem('dashboardDraftId', tempDashboard.draftId);
    }
  }, [tempDashboard]);

  const { data } = dashboardsAPI.useGetDashboardByIdQuery({
    id: params?.id as string
  });

  const onAddWidgetHandle = async (
    id: string,
    x: number,
    y: number,
    w: number,
    h: number
  ) => {
    if (!draggingWidgetRef.current) return;
    const dashboardDraftId = localStorage.getItem('dashboardDraftId') || '';
    const content = await createWidgetDraftRequest(
      dashboardDraftId,
      draggingWidgetRef.current.widgetTemplateId,
      draggingWidgetRef.current.name,
      x,
      y,
      width,
      height,
      draggingWidgetRef.current.cssClass,
      draggingWidgetRef.current.data
    );

    const widget = {
      id,
      type: content.type,
      preferredWidth: content.preferredWidth,
      preferredHeight: content.preferredHeight,
      name: content.name,
      widgetTemplateId: content.widgetTemplateId ?? '',
      widgetId: content.widgetId ?? '',
      sourceId: content.draftId,
      x,
      y,
      w,
      h
    };
    dispatch(dashboardActions.addWidget(widget));
  };
  const onUpdateWidgetHandle = React.useCallback(
    (id: string, data: IObjectCords) => {
      dispatch(
        dashboardActions.updateWidget({
          id,
          ...data
        })
      );
    },
    [dispatch]
  );

  const onSetStorage = React.useCallback(() => {
    if (!draggingStorageRef.current) return;
    dispatch(dashboardActions.setCurrentStorage(draggingStorageRef.current));
    dispatch(dashboardActions.setView('EDIT_WIDGET_DATA'));
  }, [dispatch]);

  React.useEffect(() => {
    draggingWidgetRef.current = draggingWidgetTemplate;
  }, [draggingWidgetTemplate]);

  React.useEffect(() => {
    draggingStorageRef.current = draggingStorage;
  }, [draggingStorage]);

  React.useEffect(() => {
    if (!data) return;
    const { rows, columns } = data;

    // if (!firstInit) {
    //   const cellSize = width / columns;
    //   const canvasHeight = rows * cellSize;
    //   const canvas = new fabric.Canvas('grid', { width, height: canvasHeight });
    //   const grid = new GridClass(canvas, draggingWidgetRef);
    //   canvas.selection = false;
    //   grid.onAddHandler = onAddWidgetHandle;
    //   grid.onUpdateWidgetHandle = onUpdateWidgetHandle;
    //   grid.onSetStorage = onSetStorage;
    //   grid.widgets = widgets;
    //   grid.init(width, columns, rows);
    //   setCellSize(grid.cellSize);
    //   setGridClass(grid);
    //   setFirstInit(true);
    //   return;
    // }

    if (!gridClass) return;

    gridClass.widgets = widgets;
    gridClass.viewOnly = isFullscreenMode;
    gridClass.init(width, columns, rows);
    setCellSize(gridClass.cellSize);
  }, [
    widgets,
    width,
    data?.columns,
    data?.rows,
    data,
    gridClass,
    firstInit,
    onAddWidgetHandle,
    onUpdateWidgetHandle,
    onSetStorage,
    isFullscreenMode
  ]);

  return (
    <div
      className='relative overflow-y-auto'
      style={{ maxHeight: height + 15, width: width + 15 }}
    >
      <canvas
        className='relative border-r-dsl-gray-900 z-10'
        id='grid'
      ></canvas>
      {gridClass?.cellSize
        ? widgets.map((widget: any) => (
            <iframe
              key={widget.id}
              className={classNames({ 'z-30': isFullscreenMode }, 'absolute')}
              src='http://en.wikipedia.org/w/index.php?title=Gamergate_controversy&diff=650003294&oldid=649972067'
              style={{
                left: widget.x * cellSize,
                top: widget.y * cellSize,
                width: widget.w * cellSize,
                height: widget.h * cellSize
              }}
            ></iframe>
          ))
        : null}
    </div>
  );
};

export const MemoGrid = React.memo(Grid);
