import { fabric } from 'fabric';
import {
  IWidgetTemplate,
  WidgetType
} from '@/app/dashboards/[id]/components/Sidebar/components/Toolbar/Sections/const';
import React from 'react';
import toast from 'react-hot-toast';
import { IEvent, Object as FabricObject } from 'fabric/fabric-impl';
import { DashboardWidget } from '@/src/store/slices/dashboard.slice';

type Obj = {
  left: number;
  top: number;
  width: number;
  height: number;
};

interface IObjectData {
  id: string;
  objectType: 'widget' | 'hover';
  widgetType: WidgetType;
  preferredWidth: number;
  preferredHeight: number;
  prevState: {
    width: number;
    height: number;
    left: number;
    top: number;
  };
}

export interface IDraggingWidgetCords {
  x: number;
  y: number;
}

export interface IObjectCords {
  x: number;
  y: number;
  w: number;
  h: number;
}

export class GridClass {
  private readonly _canvas: fabric.Canvas;
  private _canvasWidth: number = 300;
  private _canvasHeight: number = 202;
  private _columns: number = 2;
  private _rows: number = 2;
  private _draggingWidgetCords: IDraggingWidgetCords;

  constructor(
    canvas: fabric.Canvas,
    draggingWidgetRef: React.MutableRefObject<Omit<
      IWidgetTemplate,
      'icon'
    > | null>
  ) {
    this._canvas = canvas;
    this._draggingWidgetCords = {
      x: 0,
      y: 0
    };

    this._canvas.on('dragover', (e) =>
      this.onDragOverHandle(e, draggingWidgetRef)
    );
    this._canvas.on('drop', () => this.onDropHandle(draggingWidgetRef));
    this._canvas.on('object:moving', (e) =>
      e.target ? this.onObjectMovingHandle(e.target) : {}
    );
    this._canvas.on('object:modified', (e) =>
      e.target ? this.onObjectModifiedHandle(e.target) : {}
    );
    this._canvas.on('dragleave', () => this.onDragLeaveHandle());
  }

  private _cellSize: number = 10;
  get cellSize(): number {
    return this._cellSize;
  }

  private _widgets: DashboardWidget[] = [];
  set widgets(value: DashboardWidget[]) {
    this._widgets = value;
  }

  private _viewOnly?: boolean = false;
  set viewOnly(value: boolean) {
    this._viewOnly = value;
  }

  private _onAddHandler?: (
    id: string,
    x: number,
    y: number,
    w: number,
    h: number
  ) => void;
  set onAddHandler(
    value: (id: string, x: number, y: number, w: number, h: number) => void
  ) {
    this._onAddHandler = value;
  }

  private _onUpdateWidgetHandle?: (id: string, data: IObjectCords) => void;
  set onUpdateWidgetHandle(value: (id: string, data: IObjectCords) => void) {
    this._onUpdateWidgetHandle = value;
  }

  private _onSetStorage?: () => void;
  set onSetStorage(value: () => void) {
    this._onSetStorage = value;
  }

  init(width: number, columns: number, rows: number) {
    this._cellSize = width / columns;
    this._canvasWidth = width;
    this._canvasHeight = rows * this._cellSize;
    this._columns = columns;
    this._rows = rows;

    this._canvas.setDimensions({
      width: this._canvasWidth,
      height: this._canvasHeight
    });

    // this.renderGrid();
    this.renderWidgets();
  }

  private onDragOverHandle(
    e: IEvent<globalThis.MouseEvent>,
    draggingWidgetRef: React.MutableRefObject<Omit<
      IWidgetTemplate,
      'icon'
    > | null>
  ) {
    if (!draggingWidgetRef.current) return;
    this.removeHoverObjects();

    this._draggingWidgetCords.x = Math.floor(e.e.offsetX / this._cellSize);
    this._draggingWidgetCords.y = Math.floor(e.e.offsetY / this._cellSize);

    const left = this.snapToGridFloor(e.e.offsetX);
    const top = this.snapToGridFloor(e.e.offsetY);
    const { width, height } = this.calculateWidgetSize(
      draggingWidgetRef.current.preferredWidth,
      draggingWidgetRef.current.preferredHeight,
      this._cellSize,
      true
    );
    const endX = left + width;
    const endY = top + height;
    const fill =
      endX > (this._canvas.width as number) ||
      endY > (this._canvas.height as number)
        ? '#f34c4c'
        : '#959595';

    const hoverRect = new fabric.Rect({
      left,
      top,
      width,
      height,
      type: 'rectangle',
      fill,
      data: { objectType: 'hover' } as IObjectData
    });
    this._canvas.add(hoverRect);
  }

  private onObjectMovingHandle(obj: FabricObject) {
    if (!obj.top || !obj.left || !obj.width || !obj.height) return;

    let left = this.snapToGridRound(obj.left);
    let top = this.snapToGridRound(obj.top);
    const width = obj.width;
    const height = obj.height;
    const endX = left + width;
    const endY = top + height;

    if (endX > this._canvasWidth && endY > this._canvasHeight) {
      left = this._canvasWidth - width;
      top = this._canvasHeight - height;
    } else if (endX > this._canvasWidth) left = this._canvasWidth - width;
    else if (endY > this._canvasHeight) top = this._canvasHeight - height;
    else if (left < 0 && top < 0) {
      left = 0;
      top = 0;
    } else if (left < 0) left = 0;
    else if (top < 0) top = 0;

    obj.set({
      left,
      top,
      data: { ...obj.data, left, top }
    });
  }

  private onObjectModifiedHandle(obj: FabricObject) {
    if (
      !obj ||
      !obj.width ||
      !obj.height ||
      !obj.scaleX ||
      !obj.scaleY ||
      obj.left === undefined ||
      obj.top === undefined
    )
      return;

    const left = this.snapToGridRound(obj.left);
    const top = this.snapToGridRound(obj.top);
    const width = this.snapToGridRound(obj.width * obj.scaleX);
    const height = this.snapToGridRound(obj.height * obj.scaleY);

    const newObj: Partial<fabric.Object> = {
      left,
      top,
      width,
      height,
      scaleX: 1,
      scaleY: 1,
      data: { ...obj.data }
    };

    let resetToPrevState = false;
    if (width < obj.data.preferredWidth) {
      resetToPrevState = true;
      newObj.width = this.snapToGridCeil(obj.data.preferredWidth);
      newObj.left = obj.data.prevState.left;
      toast.error('Widget is smaller than recommended width');
    }
    if (height < obj.data.preferredHeight) {
      resetToPrevState = true;
      newObj.height = this.snapToGridCeil(obj.data.preferredHeight);
      newObj.top = obj.data.prevState.top;
      toast.error('Widget is smaller than recommended height');
    }

    if (
      left + (newObj.width as number) > (this._canvas.width as number) ||
      top + (newObj.height as number) > (this._canvas.height as number)
    ) {
      resetToPrevState = true;
      newObj.width = obj.width as number;
      newObj.height = obj.height as number;
      toast.error('Widget is out of bounds');
    }

    if (left < 0 || top < 0) {
      resetToPrevState = true;
      newObj.left = obj.data.prevState.left;
      newObj.top = obj.data.prevState.top;
      newObj.width = obj.width;
      newObj.height = obj.height;
      toast.error('Widget is out of bounds');
    }
    const anotherWidgets = this._canvas
      .getObjects()
      .filter(
        (o) =>
          o.type === 'rectangle' &&
          o.data.objectType === 'widget' &&
          o.data.id !== newObj.data.id
      );
    const isIntersectsWithAnotherWidgets = anotherWidgets.some(
      (anotherWidget) =>
        this.isObjectsIntersects(newObj as Obj, anotherWidget as Obj)
    );
    if (isIntersectsWithAnotherWidgets) {
      resetToPrevState = true;
      newObj.left = obj.data.prevState.left;
      newObj.top = obj.data.prevState.top;
      newObj.width = obj.width;
      newObj.height = obj.height;
      toast.error('Widget intersects with another widgets');
    }
    if (!resetToPrevState) {
      newObj.data.prevState.left = left;
      newObj.data.prevState.top = top;
      newObj.data.prevState.width = newObj.width as number;
      newObj.data.prevState.height = newObj.height as number;
    }

    const leftInCells = (newObj.left as number) / this._cellSize;
    const topInCells = (newObj.top as number) / this._cellSize;
    const widthInCells = (newObj.width as number) / this._cellSize;
    const heightInCells = (newObj.height as number) / this._cellSize;

    obj.set(newObj);
    if (this._onUpdateWidgetHandle) {
      this._onUpdateWidgetHandle(newObj.data.id, {
        x: leftInCells,
        y: topInCells,
        w: widthInCells,
        h: heightInCells
      });
    }
  }

  private onDropHandle(
    draggingWidgetRef: React.MutableRefObject<Omit<
      IWidgetTemplate,
      'icon'
    > | null>
  ) {
    this.removeHoverObjects();
    if (this._onSetStorage) this._onSetStorage();

    if (!draggingWidgetRef.current) return;

    const left = this._draggingWidgetCords.x * this._cellSize;
    const top = this._draggingWidgetCords.y * this._cellSize;
    const { width, height } = this.calculateWidgetSize(
      draggingWidgetRef.current.preferredWidth,
      draggingWidgetRef.current.preferredHeight,
      this._cellSize,
      true
    );
    const endX = left + width;
    const endY = top + height;
    const widthInCells = Math.ceil(
      draggingWidgetRef.current.preferredWidth / this._cellSize
    );
    const heightInCells = Math.ceil(
      draggingWidgetRef.current.preferredHeight / this._cellSize
    );

    if (
      endX > (this._canvas.width as number) ||
      endY > (this._canvas.height as number)
    ) {
      toast.error('Widget is out of bounds');
      return;
    }

    const id = this.generateObjectId().toString();
    const data: IObjectData = {
      id,
      widgetType: draggingWidgetRef.current.type,
      objectType: 'widget',
      preferredWidth: draggingWidgetRef.current.preferredWidth,
      preferredHeight: draggingWidgetRef.current.preferredHeight,
      prevState: {
        left,
        top,
        width,
        height
      }
    };

    const rect = new fabric.Rect({
      left,
      top,
      width,
      height,
      type: 'rectangle',
      fill: 'transparent',
      data,
      lockSkewingX: true,
      lockSkewingY: true
    });
    rect.controls = {
      ...fabric.Rect.prototype.controls,
      mtr: new fabric.Control({ visible: false })
    };
    const rects = this._canvas
      .getObjects()
      .filter((o) => o.type === 'rectangle');
    const isIntersectsWithAnotherWidgets = rects.some((r) =>
      this.isObjectsIntersects(rect as Obj, r as Obj)
    );
    if (isIntersectsWithAnotherWidgets) {
      toast.error('Widget intersects with another widgets');
      return;
    }

    this._canvas.add(rect);
    if (this._onAddHandler)
      this._onAddHandler(
        id,
        this._draggingWidgetCords.x,
        this._draggingWidgetCords.y,
        widthInCells,
        heightInCells
      );
  }

  private onDragLeaveHandle() {
    this.removeHoverObjects();
  }

  private renderGrid() {
    this.removeGrid();

    for (let i = 0; i < this._columns; i++) {
      const line = new fabric.Line(
        [
          i * this._cellSize,
          0,
          i * this._cellSize,
          this._canvasHeight as number
        ],
        {
          type: 'line',
          stroke: '#2e3033',
          selectable: false
        }
      );
      this._canvas.add(line);
    }
    for (let i = 0; i < this._rows; i++) {
      this._canvas.add(
        new fabric.Line(
          [
            0,
            i * this._cellSize,
            this._canvas.width as number,
            i * this._cellSize
          ],
          {
            type: 'line',
            stroke: '#2e3033',
            selectable: false
          }
        )
      );
    }
  }

  private renderWidgets() {
    this.removeWidgets();

    this._widgets.forEach((widget) => {
      if (widget.x === null || widget.y === null) return;

      const left = widget.x * this._cellSize;
      const top = widget.y * this._cellSize;
      const width = widget.w * this._cellSize;
      const height = widget.h * this._cellSize;

      const data: IObjectData = {
        id: widget.id,
        widgetType: widget.type,
        objectType: 'widget',
        preferredWidth: widget.preferredWidth,
        preferredHeight: widget.preferredHeight,
        prevState: {
          left,
          top,
          width,
          height
        }
      };
      const rect = new fabric.Rect({
        left,
        top,
        width,
        height,
        type: 'rectangle',
        fill: 'transparent',
        data,
        lockSkewingX: true,
        lockSkewingY: true
      });
      rect.controls = {
        ...fabric.Rect.prototype.controls,
        mtr: new fabric.Control({ visible: false })
      };
      if (this._viewOnly) {
        rect.selectable = false;
        rect.lockMovementX = true;
        rect.lockMovementY = true;
        rect.hoverCursor = 'default';
      }

      this._canvas.add(rect);
    });
  }

  private removeGrid() {
    this._canvas.remove(...this._canvas.getObjects('line'));
  }

  private removeWidgets() {
    this._canvas.remove(
      ...this._canvas
        .getObjects('rectangle')
        .filter((o) => o.data.objectType === 'widget')
    );
  }

  private removeHoverObjects() {
    this._canvas.remove(
      ...this._canvas
        .getObjects('rectangle')
        .filter((o) => o.data.objectType === 'hover')
    );
  }

  private generateObjectId() {
    const min = 99;
    const max = 9999999;
    const random = Math.floor(Math.random() * (max - min + 1)) + min;
    return new Date().getTime() + random;
  }

  private snapToGridRound(cord: number) {
    return Math.round(cord / this._cellSize) * this._cellSize;
  }

  private snapToGridCeil(cord: number) {
    return Math.ceil(cord / this._cellSize) * this._cellSize;
  }

  private snapToGridFloor(cord: number) {
    return Math.floor(cord / this._cellSize) * this._cellSize;
  }

  private calculateWidgetSize(
    widthInCells: number,
    heightInCells: number,
    cellSize: number,
    isMinWidth = false
  ) {
    if (isMinWidth) {
      return {
        width: this.snapToGridCeil(widthInCells),
        height: this.snapToGridCeil(heightInCells)
      };
    } else {
      return {
        width: this.snapToGridRound(widthInCells),
        height: this.snapToGridRound(heightInCells)
      };
    }
  }

  private isObjectsIntersects(obj1: Obj, obj2: Obj) {
    return (
      obj1.left < obj2.left + obj2.width &&
      obj1.left + obj1.width > obj2.left &&
      obj1.top < obj2.top + obj2.height &&
      obj1.top + obj1.height > obj2.top
    );
  }
}
