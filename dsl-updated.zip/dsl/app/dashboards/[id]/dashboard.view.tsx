'use client';

import React, { useEffect, useState } from 'react';
import { Header } from '@/src/components/Dashboards/Header/Header';
import { Dashboard } from '@/src/components/Dashboards/Dashboard/Dashboard';
import { EditWidgetData } from '@/src/components/Dashboards/EditWidgetData/ViewWidgetData';
import { Sidebar } from '@/src/components/Dashboards/Sidebar/Sidebar';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { dashboardActions } from '@/src/store/slices/dashboard.slice';
import { useDispatch } from 'react-redux';
import { Settings } from '@/src/components/Dashboards/Sidebar/components/Settings/Settings';
import { getTransitionParameters } from '@/src/components/Dashboards/Dashboard/utils/dashboardTransition';
import { useParams, useSearchParams } from 'next/navigation';
import { appActions } from '@/src/store/slices/app.slice';

export const DashboardView = ({ create }: { create?: boolean }) => {
  const { toolbar } = useAppSelector((state) => state.common);
  const view = useAppSelector((state) => state.dashboard.view);
  const dispatch = useDispatch();
  const searchParams = useSearchParams();
  const viewMode = searchParams.get('viewMode') === 'true';
  const departmentId = searchParams.get('departmentId') ?? '';
  const params = useParams<{ id: string }>();
  const dashboardId = params?.id ?? '';
  const transitionParameters = getTransitionParameters(searchParams);
  const [dashboardRect, setDashboardRect] = useState<DOMRect | null>(null);
  const [dashboardWidth, setDashboardWidth] = useState<number>(0);
  const [dashboardHeight, setDashboardHeight] = useState<number>(0);

  useEffect(() => {
    if (create) {
      dispatch(dashboardActions.clearWidgets());
      dispatch(dashboardActions.setCreatedDashboard(null));
    }
  }, [create]);

  useEffect(() => {
    return () => {
      dispatch(dashboardActions.clearWidgets());
      dispatch(dashboardActions.setTempDashboard(null));
      dispatch(dashboardActions.setDashboard(null));
      dispatch(dashboardActions.setCreatedDashboard(null));
      dispatch(
        dashboardActions.linkStorageToWidget({
          widgetId: null,
          storageId: null
        })
      );
      dispatch(dashboardActions.setView('DASHBOARD'));
      dispatch(appActions.closeToolbarSettings());
      dispatch(appActions.setToolbarIsOpen(true));
      dispatch(dashboardActions.setContextMenuCoords(null));
      dispatch(appActions.openTransition(false));
      dispatch(appActions.openTransitionToPageOrModal(false));
    };
  }, []);

  return (
    <div className='flex h-full gap-2'>
      <div className='flex flex-col w-full shrink min-w-0'>
        {!viewMode && (
          <Header
            create={create || false}
            dashboardWidth={dashboardWidth}
            dashboardHeight={dashboardHeight}
            setDashboardWidth={setDashboardWidth}
            setDashboardHeight={setDashboardHeight}
            dashboardRect={dashboardRect}
          />
        )}
        <div
          className='grow h-full'
          style={{ position: 'relative' }}
        >
          <Dashboard
            create={create}
            dashboardWidth={dashboardWidth}
            dashboardHeight={dashboardHeight}
            setDashboardWidth={setDashboardWidth}
            setDashboardHeight={setDashboardHeight}
            setDashboardRect={setDashboardRect}
            canToggleViewMode={true}
            viewMode={viewMode}
            filters={transitionParameters}
            departmentId={departmentId}
            dashboardId={dashboardId}
          />
          {view === 'EDIT_WIDGET_DATA' && <EditWidgetData />}
        </div>
      </div>
      {!viewMode && (toolbar.isOpen ? <Sidebar /> : <Settings />)}
    </div>
  );
};
