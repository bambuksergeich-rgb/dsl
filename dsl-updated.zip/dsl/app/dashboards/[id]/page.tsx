'use client';

import React, { use, useEffect } from 'react';
import { DashboardView } from '@/app/dashboards/[id]/dashboard.view';
import classNames from 'classnames';
import { useParams, useSearchParams } from 'next/navigation';
import { dashboardsAPI } from '@/src/store/api/dashboardsAPI';
import PageTransitionEffect from '@/src/components/Dashboards/Dashboard/components/PageTransitionEffect/PageTransitionEffect';

export default function Page() {
  const searchParams = useSearchParams();
  const params = useParams<{ id: string }>();

  const dashboardId = params?.id as string;

  const transitionParameters = Object.fromEntries(
    Array.from(searchParams.entries()).filter(
      ([key, value]) => key !== 'viewMode' && key !== 'departmentId'
    )
  );

  const { data: dashboard } = dashboardsAPI.useGetDashboardByIdQuery({
    id: dashboardId,
    params: transitionParameters
  });

  return (
    <PageTransitionEffect
      start={false}
      dashboard={dashboard}
    >
      <div
        className={classNames(
          { 'pb-8': false },
          'flex flex-col flex-grow w-full'
        )}
      >
        <div className='flex-grow'>
          <DashboardView />
        </div>
      </div>
    </PageTransitionEffect>
  );
}
