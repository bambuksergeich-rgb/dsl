'use client';

import { useEffect, useState } from 'react';

import PageSubHeader from '@/src/components/AllSubHeaders/PageSubHeader/PageSubHeader';
import { Pagination } from '@/src/components/Pagination/Pagination';
import { DashboardsTable } from '@/src/components/AllTables/DashboardsTable/DashboardsTable';
import { store } from '@/src/store/store';
import { getDashboards } from '@/src/store/actions/getDashboards';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { Dashboard, DashboardsData } from '@/src/store/counter/dashboardsSlice';
import { Loading } from '@/src/components/Loading/Loading';
import { useSearchParams } from 'next/navigation';
import { getGroupsAction } from '@/src/store/actions/getGroupsAction';
import { NoData } from '@/src/components/NoData/NoData';

export default function ListOfDashboards(): JSX.Element {
  const [filter, setFilter] = useState<string>('');
  const [dataPage, setDataPage] = useState<Dashboard[] | null>(null);
  const [filteredData, setFilteredData] = useState<any[] | []>([]);
  const [departmentId, setDepartmentId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  const searchParams = useSearchParams();

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getGroupsAction(departmentId, 'DASHBOARD'));
    }
  }, [departmentId]);

  const groups = useSelector((state: State) => state.groups);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(
        getDashboards(1, departmentId, filter, undefined, setLoading)
      );
    }
  }, [departmentId, filter]);

  const dashboards: DashboardsData = useSelector(
    (state: State) => state.dashboards
  );
  useEffect(() => {
    setFilteredData(dashboards.content);
  }, [dashboards.content]);

  useEffect(() => {
    setDataPage(dashboards.content);
  }, [filteredData]);

  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    if (departmentId) {
      store.dispatch(getDashboards(value, departmentId, filter));
      setFilteredData(dashboards.content);
    }
  };

  if (!departmentId) {
    return <Loading />;
  }

  return (
    <>
      <PageSubHeader
        pageName='Dashboards'
        filter={filter}
        createUrl={`/dashboards/create?departmentId=${departmentId}`}
        setFilter={setFilter}
        groups={groups}
      />
      {!loading ? (
        dashboards?.content?.length > 0 ? (
          <>
            <DashboardsTable
              dataPage={dataPage}
              departmentId={departmentId}
            />
            <Pagination
              totalElements={dashboards.totalElements}
              handleChange={handleChange}
            />
          </>
        ) : (
          <NoData />
        )
      ) : null}
    </>
  );
}
