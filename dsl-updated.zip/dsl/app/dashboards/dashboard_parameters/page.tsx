'use client';

import { useEffect, useState } from 'react';
import SubHeader from './components/SubHeader';
import { useSearchParams } from 'next/navigation';
import { dashboardsAPI } from '@/src/store/api/dashboardsAPI';
import { store } from '@/src/store/store';
import { dashboardActions } from '@/src/store/slices/dashboard.slice';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { Stack } from '@mui/system';
import { IconButton } from '@mui/material';
import { PlusIcon } from '@/public/icons/Plus.icon';
import CreateModal from './components/CreateModal';

const DashboardParameters = () => {
  const [dashboardId, setDashboardId] = useState<string>('');
  const [departmentId, setDepartmentId] = useState<string>('');
  const [openModal, setOpenModal] = useState<boolean>(false);

  const [createDraftFromDashboard] =
    dashboardsAPI.useCreateDraftFromDashboardMutation();

  const searchParams = useSearchParams();

  useEffect(() => {
    const dashboard = searchParams.get('dashboardId');
    const department = searchParams.get('departmentId');

    if (dashboard) {
      setDashboardId(dashboard);
    }
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (dashboardId && departmentId) {
      createDraftFromDashboard({
        sourceId: dashboardId,
        departmentId: departmentId
      })
        .unwrap()
        .then((res) => {
          store.dispatch(dashboardActions.setTempDashboard(res));
        });
    }
  }, [dashboardId, departmentId]);

  const { tempDashboard } = useAppSelector((state) => state.dashboard);
  return (
    tempDashboard && (
      <>
        <SubHeader />
        <Stack
          direction='row'
          justifyContent='end'
          padding='0 40px 43px 40px'
          alignItems='center'
        >
          <IconButton
            onClick={() => {
              setOpenModal(true);
            }}
            disableTouchRipple={true}
            sx={{
              width: '44px',
              height: '44px',
              justifyContent: 'content',
              alignItems: 'center',
              borderRadius: '4px',

              backgroundColor: '#3D3AB8',
              '&:hover': {
                backgroundColor: '#4441CC'
              },
              '&:active': {
                backgroundColor: '#504DE3'
              }
            }}
          >
            <PlusIcon />
          </IconButton>
        </Stack>
        <CreateModal
          openModal={openModal}
          handleCloseModal={() => setOpenModal(false)}
        />
      </>
    )
  );
};

export default DashboardParameters;
