'use client';

import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { dashboardsAPI } from '@/src/store/api/dashboardsAPI';
import {
  BigGreyButton,
  BigLightBlueButton,
  TypographyMontserrat500
} from '@/src/styles/muiStyledGlobal';
import { Stack } from '@mui/system';
import { useRouter } from 'next/navigation';
import React from 'react';

const SubHeader = () => {
  const router = useRouter();
  const [publish] = dashboardsAPI.usePublishDraftMutation();
  const { tempDashboard } = useAppSelector((state) => state.dashboard);

  const save = async () => {
    if (tempDashboard) {
      await publish({
        draftId: tempDashboard.draftId,
        name: tempDashboard.name,
        groupId: tempDashboard.groupId,
        description: tempDashboard.description,
        columns: tempDashboard.columns,
        rows: tempDashboard.rows
      }).unwrap();
    }
  };

  return (
    <Stack
      flexDirection={'row'}
      sx={{
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '42px 40px 24px 40px'
      }}
    >
      <TypographyMontserrat500
        sx={{
          fontSize: '32px'
        }}
      >
        Dashboard Parameters
      </TypographyMontserrat500>
      <Stack
        flexDirection={'row'}
        sx={{
          justifyContent: 'center',
          alignItems: 'center',
          gap: '14px'
        }}
      >
        <BigGreyButton onClick={() => router.back()}>Back</BigGreyButton>
        <BigLightBlueButton onClick={save}>Save</BigLightBlueButton>
      </Stack>
    </Stack>
  );
};

export default SubHeader;
