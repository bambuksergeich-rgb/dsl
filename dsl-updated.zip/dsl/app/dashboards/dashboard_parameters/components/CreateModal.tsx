import { CrossIcon } from '@/public/icons/Cross.icon';
import { StyledBackdrop } from '@/public/style';
import { OptionType, Select } from '@/src/components/UI/Select/Select';
import {
  BigGreyButton,
  BigLightBlueButton,
  BlueButton,
  TypographyMontserrat600
} from '@/src/styles/muiStyledGlobal';
import { Modal } from '@mui/material';
import { Stack } from '@mui/system';
import React, { useEffect, useState } from 'react';
import StyledTextField from './StyledTextField';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { dashboardsAPI } from '@/src/store/api/dashboardsAPI';
import { getMappingsWidgetDraft } from '@/src/requests/Mapping/getMappingsWidgetDraft';
import { getMetaDescriptionBdRequest } from '@/src/requests/Mapping/getMetaDescriptionBdRequest';
import { useSearchParams } from 'next/navigation';
import { store } from '@/src/store/store';
import { getDashboards } from '@/src/store/actions/getDashboards';
import { createDashboardDraftParametersAction } from '@/src/store/actions/createDashboardDraftParametersAction';

const CreateModal = ({
  openModal,
  handleCloseModal
}: {
  openModal: boolean;
  handleCloseModal: () => void;
}) => {
  const [parameterName, setParameterName] = useState<string>('');
  const [getWidgetDraft] = dashboardsAPI.useGetWidgetDraftMutation();
  const [selectWidgets, setSelectWidgets] = useState<OptionType[]>([]);
  const [activeWidget, setActiveWidget] = useState<OptionType>();
  const [selectTables, setSelectTables] = useState<OptionType[]>([]);
  const [activeTable, setActiveTable] = useState<OptionType>();
  const [selectColumns, setSelectColumns] = useState<OptionType[]>([]);
  const [activeColumn, setActiveColumn] = useState<OptionType>();
  const [db, setDb] = useState<any>();
  const [departmentId, setDepartmentId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  const searchParams = useSearchParams();

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  const onParameterNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setParameterName(e.target.value);
  };

  const onWidgetChange = (option: OptionType) => {
    setActiveWidget(option);
  };

  const onTableChange = (option: OptionType) => {
    setActiveTable(option);
  };

  const onColumnChange = (option: OptionType) => {
    setActiveColumn(option);
  };

  const { tempDashboard, dashboardDraftParameters } = useAppSelector(
    (state) => state.dashboard
  );

  useEffect(() => {
    const func = async () => {
      if (tempDashboard) {
        const { content } = await getWidgetDraft({
          dashboardId: tempDashboard.draftId
        }).unwrap();

        const formattedContent = content.map((widget) => ({
          label: widget.name,
          value: widget.draftId
        }));
        setSelectWidgets(formattedContent);
      }
    };
    func();
  }, [tempDashboard]);

  useEffect(() => {
    const func = async () => {
      if (activeWidget) {
        const mappings = await getMappingsWidgetDraft(activeWidget.value);
        if (mappings) {
          const db = await getMetaDescriptionBdRequest(
            mappings.mappings[0].storageId,
            mappings.mappings[0].databaseId
          );
          setDb(db);
          const formattedTables = db.tables.map((table: any) => ({
            label: table.name,
            value: table.name
          }));
          setSelectTables(formattedTables);
        }
      }
    };
    func();
  }, [activeWidget]);

  useEffect(() => {
    if (activeTable && db) {
      const filteredDb = db.tables.filter(
        (table: any) => table.name === activeTable.value
      );
      const formattedDb = filteredDb[0].columns
        .filter((column: any) => column.nullable === true)
        .map((i: any) => ({ label: i.name, value: i.name }));
      setSelectColumns(formattedDb);
    }
  }, [activeTable, db]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(
        getDashboards(1, departmentId, undefined, 100, setLoading)
      );
    }
  }, [departmentId]);

  const parametersForRequest = dashboardDraftParameters?.content.map(
    (param) => ({
      dashboardParameterId: param.draftId,
      columnName: param.name
    })
  );

  const saveParameters = async () => {
    if (tempDashboard && parameterName) {
      store.dispatch(
        createDashboardDraftParametersAction(
          tempDashboard?.draftId,
          parameterName
        )
      );
    }
    // if (activeWidget && parametersForRequest && )
    // await updatingTransmittedParametersRequest(
    //   activeWidget.value,
    //   activeComponent?.componentId,
    //   activePageId,
    //   isTransition,
    //   parametersForRequest
    // );
  };

  return (
    <Modal
      open={openModal}
      onClose={handleCloseModal}
      BackdropComponent={StyledBackdrop}
    >
      <Stack
        alignItems={'flex-start'}
        sx={{
          position: 'absolute' as 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          padding: '24px',
          border: '1px solid rgba(255, 255, 255, 0.15)',
          background: 'linear-gradient(72deg, #0A0F18 0%, #373B44 100%)',
          borderRadius: '12px',
          // height: '137px',
          width: '506px',
          gap: '24px'
        }}
      >
        <Stack
          direction={'row'}
          sx={{
            justifyContent: 'space-between',
            alignItems: 'center',
            width: '100%'
          }}
        >
          <TypographyMontserrat600
            sx={{
              fontSize: '16px'
            }}
          >
            Create Parameter
          </TypographyMontserrat600>
          <BlueButton
            disableTouchRipple={true}
            onClick={handleCloseModal}
          >
            <CrossIcon />
          </BlueButton>
        </Stack>
        <Stack
          flexDirection='column'
          alignItems='start'
          justifyContent='start'
          gap='24px'
          padding='0 21px 53px 55px'
          width='100%'
        >
          <Stack
            flexDirection='row'
            justifyContent='space-between'
            alignItems='center'
            width='100%'
          >
            <TypographyMontserrat600 fontSize='14'>
              Parameter name
            </TypographyMontserrat600>
            <StyledTextField
              title=''
              value={parameterName}
              onChange={onParameterNameChange}
              error={false}
              placeholder='Parameter name'
            />
          </Stack>
          <Stack
            flexDirection='row'
            justifyContent='space-between'
            alignItems='center'
            width='100%'
          >
            <TypographyMontserrat600 fontSize='14'>
              Widget name
            </TypographyMontserrat600>
            <Select
              placeholder='Widget name'
              options={selectWidgets}
              onChange={onWidgetChange}
              activeOption={activeWidget}
            />
          </Stack>
          <Stack
            flexDirection='row'
            justifyContent='space-between'
            alignItems='center'
            width='100%'
          >
            <TypographyMontserrat600 fontSize='14'>
              Table name
            </TypographyMontserrat600>
            <Select
              placeholder='Table name'
              options={selectTables}
              onChange={onTableChange}
              activeOption={activeTable}
            />
          </Stack>
          <Stack
            flexDirection='row'
            justifyContent='space-between'
            alignItems='center'
            width='100%'
          >
            <TypographyMontserrat600 fontSize='14'>
              Column name
            </TypographyMontserrat600>
            <Select
              placeholder='Column name'
              options={selectColumns}
              activeOption={activeColumn}
              onChange={onColumnChange}
            />
          </Stack>
        </Stack>
        <Stack
          flexDirection='row'
          justifyContent='end'
          alignItems='center'
          gap='14px'
          sx={{
            width: '100%'
          }}
        >
          <BigGreyButton onClick={handleCloseModal}>Back</BigGreyButton>
          <BigLightBlueButton onClick={saveParameters}>Save</BigLightBlueButton>
        </Stack>
      </Stack>
    </Modal>
  );
};

export default CreateModal;
