import { TextField, TextFieldProps } from '@mui/material';
import { styled } from '@mui/system';

const StyledTextField = styled((props: TextFieldProps) => (
  <TextField
    {...props}
    variant='outlined'
    InputProps={{
      ...props.InputProps,
      classes: { input: 'custom-input' }
    }}
  />
))(() => ({
  '& .MuiOutlinedInput-root': {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    color: 'white',
    borderRadius: '6px',
    paddingLeft: '16px',
    paddingRight: '16px',
    height: '44px',
    width: '180px',

    '& fieldset': {
      border: 'none'
    },
    '&:hover fieldset': {
      borderColor: '#ffffff30'
    },
    '&.Mui-focused fieldset': {
      borderColor: '#ffffff50'
    }
  },

  '& .custom-input::placeholder': {
    color: 'white',
    opacity: 1
  },

  '& .MuiInputBase-input': {
    padding: 0,
    height: '40px',
    display: 'flex',
    alignItems: 'center',
    color: 'white'
  },

  '& .MuiInputLabel-root': {
    color: 'white'
  },
  '& label.Mui-focused': {
    color: 'white'
  }
}));

export default StyledTextField;
