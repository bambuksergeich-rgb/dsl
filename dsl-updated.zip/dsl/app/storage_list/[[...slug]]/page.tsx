'use client';

import { PureDashboardModal } from '@/src/components/Dashboards/Dashboard/PureDashboardForModal';
import { usePathname, useSearchParams } from 'next/navigation';
import React, {
  MutableRefObject,
  useCallback,
  useEffect,
  useRef,
  useState
} from 'react';

function useListener<T extends keyof WindowEventMap>(
  event: T,
  callback: (e: WindowEventMap[T]) => void
) {
  const callbackRef = useRef<typeof callback>(() => callback);

  callbackRef.current = callback;

  useEffect(() => {
    window.addEventListener(event, callbackRef.current);

    return () => window.removeEventListener(event, callbackRef.current);
  }, []);
}

export default function StorageList(): JSX.Element {
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const [departmentId, setDepartmentId] = useState<string>(
    searchParams.get('departmentId') || ''
  );
  const iframeRef = useRef<HTMLIFrameElement>(
    null
  ) as MutableRefObject<HTMLIFrameElement | null>;
  const [isDashboardModalOpen, setIsDashboardModalOpen] =
    useState<boolean>(false);
  const [dashboardId, setDashboardId] = useState<string>('');
  const searchParamsRef = useRef(searchParams);
  searchParamsRef.current = searchParams;
  const [dashboardFilters, setDashboardFilters] = useState<
    { columnName: string; value: string }[]
  >([]);
  const [linkComponents, setLinkComponents] = useState<
    { widgetId: string; componentId: string }[]
  >([]);

  const onComponentClick = useCallback(
    (widgetId: string, componentId: string) => {
      iframeRef.current?.contentWindow?.postMessage(
        { dashboardComponentClick: { dashboardId, widgetId, componentId } },
        { targetOrigin: '*' }
      );
      setIsDashboardModalOpen(false);
      setDashboardId('');
    },
    [dashboardId]
  );

  const setVariablesFromMessage = (e: MessageEvent) => {
    if (e.data === 'tokens_request' && iframeRef.current) {
      const token = sessionStorage.getItem('accessToken');
      iframeRef.current!.contentWindow!.postMessage(
        {
          authToken: `Bearer ${token}`,
          departmentId: departmentId
        },
        {
          targetOrigin: '*'
        }
      );
    }
    if (e.data?.openDashboardModal && e.data?.dashboardId) {
      setDashboardId(e.data.dashboardId);
      setDashboardFilters(e.data.filters);
      setLinkComponents(
        Array.isArray(e.data.linksConfig?.components)
          ? e.data.linksConfig.components
          : []
      );
      setIsDashboardModalOpen(true);
      return;
    }

    const clearStateFromNextTrash = (state: any) => {
      const clearState = {} as any;

      for (let stateKey in state) {
        if (!stateKey.startsWith('_')) {
          clearState[stateKey] = state[stateKey];
        }
      }

      return clearState;
    };

    const historyStateLifetimeEnd = (nextPath: string) => {
      if (!history.state?.lifetime) {
        return true;
      }

      return !history.state.lifetime.some((l: string) => nextPath.includes(l));
    };

    const getState = (nextPath: string) =>
      clearStateFromNextTrash({
        ...(historyStateLifetimeEnd(nextPath) ? null : history.state),
        ...e.data?.state
      });

    if (e.data?.get_path) {
      iframeRef.current?.contentWindow?.postMessage(
        {
          get_path_result: pathname,
          state: history.state
        },
        { targetOrigin: '*' }
      );
    }

    if (e.data?.init_path) {
      notifyPathChanged();
    }

    if (e.data?.back_path) {
      window.history.back();
      // setTimeout(() => {
      //   window.history.replaceState(e.data.state, '');
      // }, 100);
    }

    if (e.data?.forward_path) {
      window.history.forward();
    }

    if (e.data?.go) {
      window.history.go(e.data.go);

      iframeRef.current?.contentWindow?.postMessage(
        {
          get_path_result: pathname,
          state: history.state
        },
        { targetOrigin: '*' }
      );
    }

    if (e.data?.push_path) {
      const pushPath = e.data?.push_path;
      window.history.pushState(
        getState(pushPath),
        '',
        `${pushPath}?${searchParamsRef.current}`
      );
    }
    if (e.data?.push_state) {
      const path =
        window.location.pathname +
        window.location.search +
        window.location.hash;
      window.history.pushState(
        getState(path.replace('/storage_list', '')),
        '',
        `${path}`
      );
    }

    if (e.data?.replace_path) {
      const replacePath = e.data?.replace_path;
      window.history.replaceState(
        getState(replacePath),
        '',
        replacePath ? `${replacePath}?${searchParamsRef.current}` : undefined
      );
    }

    if (e.data?.replace_state) {
      window.history.replaceState(
        clearStateFromNextTrash({
          ...history.state,
          ...e.data?.state
        }),
        ''
      );

      iframeRef.current?.contentWindow?.postMessage(
        {
          get_path_result: pathname,
          state: history.state
        },
        { targetOrigin: '*' }
      );
    }
  };

  useEffect(() => {
    const newDepartmentId = searchParams.get('departmentId');
    if (newDepartmentId) {
      setDepartmentId(newDepartmentId);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId.length) {
      const token = sessionStorage.getItem('accessToken');

      iframeRef.current!.contentWindow!.postMessage(
        {
          authToken: `Bearer ${token}`,
          departmentId: departmentId
        },
        {
          targetOrigin: '*'
        }
      );
    }
  }, [departmentId]);

  useListener('message', setVariablesFromMessage);
  useListener('popstate', () => {
    iframeRef.current?.contentWindow?.postMessage(
      {
        get_path_result: pathname,
        state: history.state
      },
      { targetOrigin: '*' }
    );
  });

  const notifyPathChanged = () => {
    iframeRef.current?.contentWindow?.postMessage(
      {
        current_path: pathname,
        state: history.state
      },
      { targetOrigin: '*' }
    );
  };

  useEffect(() => {
    notifyPathChanged();
  }, [pathname]);

  return (
    <React.Fragment>
      <iframe
        src='https://app.wizquant.com/storage'
        // src='http://localhost:3000/storage'
        allow='*'
        height='100%'
        width='100%'
        ref={(r) => {
          iframeRef.current = r;
        }}
        sandbox='allow-same-origin allow-scripts allow-popups allow-forms allow-top-navigation'
      >
        <span>not iframe</span>
      </iframe>

      <PureDashboardModal
        dashboardId={dashboardId}
        isOpen={!!dashboardId && isDashboardModalOpen}
        onClose={() => {
          setIsDashboardModalOpen(false);
          setDashboardId('');
        }}
        filters={dashboardFilters}
        departmentId={departmentId}
        components={linkComponents}
        onComponentClick={onComponentClick}
      />
    </React.Fragment>
  );
}
