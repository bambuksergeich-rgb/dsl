import './globals.css';
import '../src/styles/global.css';
import { MainLayoutWithAuth } from '@/src/components/MainLayout/MainLayoutWithAuth';
import { ReduxProvider } from '@/src/components/Providers/ReduxProvider';
import { SessionProviderWrapper } from '@/src/components/Providers/SessionProviderWrapper';
import { AppScrollbarBridge } from '@/src/components/AppScrollbarBridge/AppScrollbarBridge';
import { AppThemeProvider } from '@/src/components/Providers/AppThemeProvider';

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang='en'>
      <head>
        <title>DSL</title>
        <meta
          name='viewport'
          content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'
        />
      </head>
      <body suppressHydrationWarning={true}>
        <AppScrollbarBridge />
        <AppThemeProvider><ReduxProvider>
          <SessionProviderWrapper>
            <MainLayoutWithAuth>{children}</MainLayoutWithAuth>
          </SessionProviderWrapper>
        </ReduxProvider></AppThemeProvider>
      </body>
    </html>
  );
}
