import { Definitions } from './interfaces';

export const definitions: Definitions[] = [
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'JavaScript',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  },
  {
    name: 'ticker',
    type: 'function',
    language: 'Python',
    createdDate: '12/09/2023',
    modifiedDate: '17/09/2023',
    modifiedBy: 'John Smith'
  }
];
