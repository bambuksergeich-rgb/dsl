export interface Definitions {
  name: string;
  type: string;
  language: string;
  createdDate: string;
  modifiedDate: string;
  modifiedBy: string;
}
