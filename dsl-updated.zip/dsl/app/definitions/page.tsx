'use client';

import { DefinitionsTable } from '@/src/components/AllTables/DefinitionsTable/DefinitionsTable';
import { useEffect, useState } from 'react';
import { Definitions } from './interfaces';
import { definitions } from './constants';
import { Pagination } from '@/src/components/Pagination/Pagination';
import { DefinitionsModal } from '@/src/components/AllModals/DefinitionsModal/DefinitionsModal';
import PageSubHeader from '@/src/components/AllSubHeaders/PageSubHeader/PageSubHeader';

export default function DefinitionsPage(): JSX.Element {
  const [page, setPage] = useState<number>(1);
  const [openModal, setOpenModal] = useState<boolean>(false);
  const [filter, setFilter] = useState<string>('Deals');
  const [dataPage, setDataPage] = useState<Definitions[]>(definitions);
  const [filteredData, setFilteredData] = useState<any[] | []>([]);

  useEffect(() => {
    setFilteredData(definitions);
  }, [filter]);

  useEffect(() => {
    setDataPage(
      page === 1
        ? filteredData.slice(page - 1, page + 9)
        : filteredData.slice((page - 1) * 10, page + 9)
    );
  }, [filteredData]);

  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
    setDataPage(
      value === 1
        ? filteredData.slice(value - 1, value + 9)
        : filteredData.slice((value - 1) * 10, value * 10)
    );
  };

  const handleCloseModal = () => {
    setOpenModal(false);
  };

  return (
    <>
      {/* <DefinitionsModal
        open={openModal}
        closeModal={handleCloseModal}
      />

      <PageSubHeader
        pageName='Definitions'
        filter={filter}
        setFilter={setFilter}
      />
      <DefinitionsTable dataPage={dataPage} />
      <Pagination
        totalElements={definitions.length}
        handleChange={handleChange}
      /> */}
    </>
  );
}
