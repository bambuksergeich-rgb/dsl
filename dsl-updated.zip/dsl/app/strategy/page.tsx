'use client';
import ScriptEditor from '@/src/components/ScriptEditor/ScriptEditor';
export default function StrategyPage() { return <ScriptEditor variant='strategy' />; }
