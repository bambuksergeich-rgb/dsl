'use client';

import { AccessSettingsSubHeader } from '@/src/components/AllSubHeaders/AccessSettingsSubHeader/AccessSettingsSubHeader';
import { IconButton, Stack } from '@mui/material';
import { useEffect, useState } from 'react';
import { PlusIcon } from '@/public/icons/Plus.icon';
import { DataAccessTable } from '@/src/components/AllTables/DataAccessTable/DataAccessTable';
import { ComponentAccessTable } from '@/src/components/AllTables/ComponentAccessTable/ComponentAccessTable';
import { AccessSettingsTable } from '@/src/components/AllTables/AccessSettingsTable/AccessSettingsTable';
import { store } from '@/src/store/store';
import { getCompany } from '@/src/store/actions/getCompany';
import { Company } from '@/src/store/counter/companySlice';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { useSearchParams } from 'next/navigation';
import { getRoles } from '@/src/store/actions/getRoles';
import { RolesData } from '@/src/store/counter/rolesSlice';
import { Loading } from '@/src/components/Loading/Loading';
import { getRoleAction } from '@/src/store/actions/getRoleAction';
import { Access } from './interfaces';
import { CreateRoleModal } from '@/src/components/AllModals/CreateRoleModal/CreateRoleModal';
import { AccessSettingsTabs } from '@/src/components/AccessSettings/AccessSettingsTabs';

export default function AccessSettings(): JSX.Element {
  const [createRole, setCreateRole] = useState<boolean>(false);
  const [activeButton, setActiveButton] = useState<string>('');
  const [departmentId, setDepartmentId] = useState<string>('');

  const searchParams = useSearchParams();

  useEffect(() => {
    store.dispatch(getCompany(false));
  }, []);

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getRoles(departmentId));
    }
  }, [departmentId]);

  const company: Company = useSelector((state: State) => state.company);
  const roles: RolesData = useSelector((state: State) => state.roles);

  useEffect(() => {
    if (roles.content) {
      if (!activeButton) {
        setActiveButton(roles.content[0].id);
      }
      store.dispatch(getRoleAction(roles.content[0].id));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roles.content]);

  const activeRole = useSelector((state: State) => state.role);
  const departments = useSelector((state: State) => state.departments);

  const [departmentAccess, setDepartmentAccess] = useState<boolean>(false);
  const [dashboardAccess, setDashboardAccess] = useState<boolean>(false);
  const [departmentDataAccess, setDepartmentDataAccess] = useState<
    Access[] | null
  >(null);
  const [dashboardDataAccess, setDashboardDataAccess] = useState<
    Access[] | null
  >(null);
  const [widgetDataAccess, setWidgetDataAccess] = useState<Access[] | null>(
    null
  );

  const handleCloseCreateRoleModal = () => {
    setCreateRole(false);
  };

  useEffect(() => {
    setDepartmentAccess(activeRole.departmentAccess);
    setDashboardAccess(activeRole.dashboardAccess);
    setDepartmentDataAccess(activeRole.departmentDataAccess);
    setDashboardDataAccess(activeRole.dashboardDataAccess);
    setWidgetDataAccess(activeRole.widgetDataAccess);
  }, [activeRole]);

  const updatedRole = {
    name: activeRole.name,
    departmentAccess: departmentAccess,
    dashboardAccess: dashboardAccess,
    departmentDataAccess: departmentDataAccess,
    dashboardDataAccess: dashboardDataAccess,
    widgetDataAccess: widgetDataAccess
  };

  if (!roles) {
    return <Loading />;
  }

  return (
    <div style={{ overflowY: 'scroll', marginBottom: '40px' }}>
      <CreateRoleModal
        open={createRole}
        handleClose={handleCloseCreateRoleModal}
      />
      <AccessSettingsSubHeader
        activeRole={activeRole}
        updatedRole={updatedRole}
      />
      <Stack
        direction={'column'}
        sx={{
          justifyContent: 'start',
          gap: '24px',
          padding: '0 40px',
          minHeight: 'calc(100% - 161px)'
        }}
      >
        <Stack
          direction={'row'}
          sx={{
            paddingBottom: '4px',
            borderBottom: '1px solid #596471'
          }}
        >
          <Stack
            direction={'row'}
            sx={{
              height: '34px',

              gap: '4px',
              overflowX: 'auto',
              overflowY: 'hidden',
              '&::-webkit-scrollbar': {
                height: '4px'
              },
              '&::-webkit-scrollbar-track': {
                background: 'transparent'
              },
              '&::-webkit-scrollbar-thumb': {
                backgroundColor: '#D9D9D9',
                borderRadius: '8px'
              },
              scrollbarWidth: 'thin',
              scrollbarColor: 'rgba(0,0,0,.1) transparent'
            }}
          >
            {roles.content?.map((item) => (
              <AccessSettingsTabs
                item={item}
                key={item.id}
                setActiveButton={setActiveButton}
                activeButton={activeButton}
              />
            ))}
          </Stack>
          <IconButton
            onClick={() => {
              setCreateRole(true);
            }}
            disableTouchRipple={true}
            sx={{
              width: '44px',
              height: '34px',
              borderRadius: '6px 6px 0 0',
              backgroundColor: '#547FFF',
              '&:hover': {
                backgroundColor: '#4170FF'
              },
              '&:active': {
                backgroundColor: '#4170FF'
              }
            }}
          >
            <PlusIcon />
          </IconButton>
        </Stack>

        <Stack
          direction={'column'}
          sx={{
            gap: '24px',
            alignItems: 'start',
            width: '100%',
            overflowY: 'auto',
            overflowX: 'hidden',
            justifyContent: 'start',
            '&::-webkit-scrollbar': {
              display: 'none'
            },
            height: 'calc(100% - 24px)'
          }}
        >
          {/* <Stack
            direction={'row'}
            sx={{
              width: '100%',
              height: 'calc(50% - 12px)',
              gap: '12px'
            }}
          >
            <DataAccessTable
              departments={departments}
              departmentDataAccess={departmentDataAccess}
              setDepartmentDataAccess={setDepartmentDataAccess}
              dashboardDataAccess={dashboardDataAccess}
              setDashboardDataAccess={setDashboardDataAccess}
              widgetDataAccess={widgetDataAccess}
              setWidgetDataAccess={setWidgetDataAccess}
            />
            <ComponentAccessTable
              departmentAccess={departmentAccess}
              setDepartmentAccess={setDepartmentAccess}
              dashboardAccess={dashboardAccess}
              setDashboardAccess={setDashboardAccess}
            />
          </Stack> */}
          <Stack
            flexDirection={'row'}
            sx={{
              width: '100%',
              minHeight: 'calc(50% - 12px)'
            }}
          >
            <AccessSettingsTable />
          </Stack>
        </Stack>
      </Stack>
    </div>
  );
}
