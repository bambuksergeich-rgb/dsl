export interface Access {
  id: string;
  access: string;
}
