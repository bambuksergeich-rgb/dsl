'use client';

import { FullScreenGreyIcon } from '@/public/icons/FullScreenGrey.icon';
import { DashboardSubHeader } from '@/src/components/AllSubHeaders/DashboardSubHeader/DashboardSubHeader';
import { sanitizePath } from '@/src/helpers/basePrefix';
import { WhiteIconButton } from '@/src/styles/muiStyledGlobal';
import { Stack } from '@mui/material';
import { useRouter } from 'next/navigation';

export default function ViewingDashboard(): JSX.Element {
  const router = useRouter();

  return (
    <>
      <DashboardSubHeader />
      <Stack
        direction={'row'}
        sx={{
          width: '100%',
          height: '100%',
          backgroundColor: '#10161C80',
          padding: '26px',
          justifyContent: 'start',
          alignItems: 'end'
        }}
      >
        <WhiteIconButton
          disableTouchRipple={true}
          onClick={() => {
            router.push(sanitizePath('/viewing_dashboard_full/1'));
          }}
        >
          <FullScreenGreyIcon />
        </WhiteIconButton>
      </Stack>
    </>
  );
}
