import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const accessToken = req.headers.get('Authorization');
  const body = await req.json();

  const response = await fetch(
    `${process.env.NEXT_AI_CHAT_BASE_URL}/chat/new`,
    {
      method: 'POST',
      headers: {
        ...(accessToken ? { Authorization: accessToken } : {}),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    }
  );

  const data = await response.json();
  return NextResponse.json(data, { status: response.status });
}
