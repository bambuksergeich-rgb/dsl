import { NextRequest, NextResponse } from 'next/server';

export async function PATCH(
  req: NextRequest,
  { params }: { params: { chatId: string } }
) {
  const accessToken = req.headers.get('Authorization');
  const { chatId } = params;
  const body = await req.json();

  const response = await fetch(
    `${process.env.NEXT_AI_CHAT_BASE_URL}/chat/${chatId}`,
    {
      method: 'PATCH',
      headers: {
        ...(accessToken ? { Authorization: accessToken } : {}),
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    }
  );

  const data = await response.json();
  return NextResponse.json(data, { status: response.status });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { chatId: string } }
) {
  const accessToken = req.headers.get('Authorization');
  const { chatId } = params;

  const response = await fetch(
    `${process.env.NEXT_AI_CHAT_BASE_URL}/chat/${chatId}`,
    {
      method: 'DELETE',
      headers: {
        ...(accessToken ? { Authorization: accessToken } : {}),
      },
    }
  );

  if (response.status === 204 || response.headers.get('content-length') === '0') {
    return new NextResponse(null, { status: 204 });
  }

  const data = await response.json();
  return NextResponse.json(data, { status: response.status });
}
