import { NextRequest, NextResponse } from 'next/server';

export async function POST(
  req: NextRequest,
  { params }: { params: { chatId: string } }
) {
  const accessToken = req.headers.get('Authorization');
  const { chatId } = params;
  const formData = await req.formData();

  const response = await fetch(
    `${process.env.NEXT_AI_CHAT_BASE_URL}/chat/${chatId}/send`,
    {
      method: 'POST',
      headers: {
        'X-LLM-Model': 'DEEPSEEK',
        ...(accessToken ? { Authorization: accessToken } : {})
      },
      body: formData
    }
  );

  const contentType = response.headers.get('Content-Type') ?? '';

  // SSE stream — pass through as-is
  if (contentType.includes('text/event-stream')) {
    const headers = new Headers();
    headers.set('Content-Type', 'text/event-stream');
    headers.set('Cache-Control', 'no-cache');
    headers.set('Connection', 'keep-alive');

    return new Response(response.body, {
      status: response.status,
      headers
    });
  }

  // Non-streaming JSON response
  const data = await response.json();
  return NextResponse.json(data, { status: response.status });
}
