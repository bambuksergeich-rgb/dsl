import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const accessToken = req.headers.get('Authorization');

  try {
    const response = await fetch(
      `${process.env.NEXT_AI_CHAT_BASE_URL}/chat/list`,
      {
        method: 'GET',
        headers: {
          ...(accessToken ? { Authorization: accessToken } : {})
        }
      }
    );

    const data = await response.json();
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    console.error('AI chat list error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch chat list' },
      { status: 500 }
    );
  }
}
