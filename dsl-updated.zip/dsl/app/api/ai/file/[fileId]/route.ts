import { NextRequest, NextResponse } from 'next/server';

export async function GET(
  req: NextRequest,
  { params }: { params: { fileId: string } }
) {
  const accessToken = req.headers.get('Authorization');
  const { fileId } = params;

  const response = await fetch(
    `${process.env.NEXT_AI_CHAT_BASE_URL}/file/${fileId}`,
    {
      method: 'GET',
      headers: {
        ...(accessToken ? { Authorization: accessToken } : {}),
      },
    }
  );

  if (!response.ok) {
    return NextResponse.json(
      { error: 'Failed to fetch file' },
      { status: response.status }
    );
  }

  // Blob в NextResponse в некоторых рантаймах Next даёт пустое тело — шлём сырые байты.
  const buffer = await response.arrayBuffer();
  const headers = new Headers();
  const contentType = response.headers.get('Content-Type');
  const contentDisposition = response.headers.get('Content-Disposition');

  if (contentType) headers.set('Content-Type', contentType);
  if (contentDisposition) headers.set('Content-Disposition', contentDisposition);
  headers.set('Content-Length', String(buffer.byteLength));

  return new NextResponse(buffer, { status: 200, headers });
}
