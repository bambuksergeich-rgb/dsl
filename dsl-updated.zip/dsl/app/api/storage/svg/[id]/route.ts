import { NextRequest, NextResponse } from "next/server";

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } },
) {
  const accessToken = req.headers.get("Authorization");

  try {
    const url = `${process.env.NEXT_EDM_BASE_URL}/svg/${params.id}`;
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "API-key": accessToken?.split(" ")[1] || "",
      },
    });

    const data = await response.json();
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    console.error("EDM svg by id error:", error);
    return NextResponse.json(
      { error: "Failed to fetch svg" },
      { status: 500 },
    );
  }
}
