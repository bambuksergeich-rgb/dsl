import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const accessToken = req.headers.get('Authorization');
  const { searchParams } = new URL(req.url);
  const qs = searchParams.toString();

  try {
    const url = `${process.env.NEXT_EDM_BASE_URL}/svg${qs ? `?${qs}` : ''}`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'API-key': accessToken?.split(' ')[1] || ''
      }
    });

    const data = await response.json();
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    console.error('EDM svg list error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch svg list' },
      { status: 500 }
    );
  }
}
