'use client';

import WidgetEditorSubHeader from '@/src/components/AllSubHeaders/WidgetEditorSubHeader/WidgetEditorSubHeader';
import WidgetSettingsBuilder from '@/src/components/WidgetSettingsBuilder/WidgetSettingsBuilder';
import { useWidgetTemplateDraftPreview } from '@/src/hooks/useWidgetTemplateDraftPreview';
import { getCodeFromWidgetTemplateFile } from '@/src/requests/getCodeFromWidgetTemplateFile';
import { createWidgetTemplateDraft } from '@/src/store/actions/createWidgetTemplateDraft';
import { getGroupsAction } from '@/src/store/actions/getGroupsAction';
import { getWidgetTemplateFiles } from '@/src/store/actions/getWidgetTemplateFiles';
import { State } from '@/src/store/initialState';
import { store } from '@/src/store/store';
import { Box } from '@mui/system';
import { resolveFileContentType } from '@/src/helpers/resolveFileContentType';
import { useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useSelector } from 'react-redux';
import { widgetTemplateDraftReset } from '@/src/store/counter/widgetTemplateDraftSlice';
import { widgetTemplateFilesGet } from '@/src/store/counter/widgetTemplateFilesSlice';
import { componentListGet } from '@/src/store/counter/componentListSlice';
import { getWidgetTemplateDraftConfigurations } from '@/src/store/counter/widgetTemplateDraftConfigurationSlice';
import { widgetTemplateDraftMappingsActions } from '@/src/store/counter/widgetTemplateDraftMappingsSlice';
import { getWidgetTemplateDraftMappingConfigurations } from '@/src/store/counter/widgetTemplateDraftMappingConfigurationsSlice';
import { MultipleEditorWindows } from '../edit_widget/components/MultipleEditorWindows';
import { OneEditorWindow } from '../edit_widget/components/OneEditorWindow';

export default function CreateWidget() {
  const searchParams = useSearchParams();
  const methods = useForm({ defaultValues: { items: [] } });

  const [displaysOption, setDisplaysOption] = useState(false);
  const [editorMode, setEditorMode] = useState('');
  const [editorType, setEditorType] = useState('');

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const [widgetTemplateId, setWidgetTemplateId] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [openInfoModal, setOpenInfoModal] = useState(true);
  const [initializedDraftId, setInitializedDraftId] = useState('');
  const draftInitializationKeyRef = useRef('');

  const [filesContent, setFilesContent] = useState<Record<string, string>>({});
  const [savedContent, setSavedContent] = useState<Record<string, string>>({});

  const markFilesSaved = useCallback((uploaded: Record<string, string>) => {
    setSavedContent((prev) => ({ ...prev, ...uploaded }));
  }, []);

  const [activeHtmlId, setActiveHtmlId] = useState<string | null>(null);
  const [activeCssId, setActiveCssId] = useState<string | null>(null);
  const [activeJsId, setActiveJsId] = useState<string | null>(null);

  const storedWidgetTemplateDraft = useSelector(
    (state: State) => state.widgetTemplateDraft
  );
  const widgetTemplateDraft = useMemo(
    () =>
      storedWidgetTemplateDraft?.draftId &&
      storedWidgetTemplateDraft.draftId === initializedDraftId
        ? storedWidgetTemplateDraft
        : ({} as State['widgetTemplateDraft']),
    [storedWidgetTemplateDraft, initializedDraftId]
  );
  const rawWidgetTemplateFiles = useSelector(
    (state: State) => state.widgetTemplateFiles
  );
  const widgetTemplateFiles = useMemo(
    () =>
      rawWidgetTemplateFiles.map((file) => ({
        ...file,
        contentType: resolveFileContentType(file.name, file.contentType)
      })),
    [rawWidgetTemplateFiles]
  );

  const routeDepartmentId = searchParams.get('departmentId') || '';
  const routeWidgetTemplateId = searchParams.get('widgetTemplateId') || '';

  useEffect(() => {
    setDepartmentId(routeDepartmentId);
    setWidgetTemplateId(routeWidgetTemplateId);
  }, [routeDepartmentId, routeWidgetTemplateId]);

  useEffect(() => {
    if (!routeDepartmentId) return;

    const initializationKey = `${routeDepartmentId}:${routeWidgetTemplateId || '__new__'}`;
    if (draftInitializationKeyRef.current === initializationKey) return;
    draftInitializationKeyRef.current = initializationKey;

    let cancelled = false;
    setInitializedDraftId('');
    setFilesContent({});
    setSavedContent({});
    setActiveHtmlId(null);
    setActiveCssId(null);
    setActiveJsId(null);
    setEditorMode('');
    setEditorType('');

    store.dispatch(widgetTemplateDraftReset());
    store.dispatch(widgetTemplateFilesGet([]));
    store.dispatch(componentListGet([]));
    store.dispatch(getWidgetTemplateDraftConfigurations({ sections: [] }));
    store.dispatch(getWidgetTemplateDraftMappingConfigurations({ sections: [] }));
    store.dispatch(
      widgetTemplateDraftMappingsActions.getWidgetTemplateDraftMappings({
        mappings: [],
      })
    );

    store.dispatch(getGroupsAction(routeDepartmentId, 'WIDGET_TEMPLATE'));

    void store
      .dispatch(
        createWidgetTemplateDraft(
          routeDepartmentId,
          routeWidgetTemplateId || undefined
        ) as any
      )
      .then((draft: any) => {
        if (cancelled || !draft?.draftId) return;
        setInitializedDraftId(String(draft.draftId));
        if (draft.sourceId) {
          setWidgetTemplateId(String(draft.sourceId));
        }
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          draftInitializationKeyRef.current = '';
          console.error('[CreateWidget] Unable to initialize fresh widget draft', error);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [routeDepartmentId, routeWidgetTemplateId]);

  useEffect(() => {
    if (widgetTemplateDraft.draftId) {
      store.dispatch(
        getWidgetTemplateFiles(
          widgetTemplateDraft.draftId,
          widgetTemplateId || widgetTemplateDraft.sourceId || undefined
        )
      );
    }
  }, [widgetTemplateDraft.draftId, widgetTemplateDraft.sourceId, widgetTemplateId]);

  useEffect(() => {
    if (!widgetTemplateFiles?.length) return;

    const TEXT_CONTENT_TYPES = ['text/html', 'text/css', 'text/javascript'];

    widgetTemplateFiles.forEach((file) => {
      if (TEXT_CONTENT_TYPES.includes(file.contentType)) {
        getCodeFromWidgetTemplateFile(file.id, (code) => {
          setFilesContent((prev) =>
            Object.prototype.hasOwnProperty.call(prev, file.id)
              ? prev
              : { ...prev, [file.id]: code as string }
          );
          setSavedContent((prev) =>
            Object.prototype.hasOwnProperty.call(prev, file.id)
              ? prev
              : { ...prev, [file.id]: code as string }
          );
        });
      }

      if (file.contentType === 'text/html' && !activeHtmlId)
        setActiveHtmlId(file.id);
      if (file.contentType === 'text/css' && !activeCssId)
        setActiveCssId(file.id);
      if (file.contentType === 'text/javascript' && !activeJsId)
        setActiveJsId(file.id);
    });

    if (!editorMode && widgetTemplateFiles.length > 0) {
      const first = widgetTemplateFiles[0];
      setEditorMode(first.id);
      setEditorType(first.contentType);
    }
  }, [widgetTemplateFiles]);

  const { isPreviewSaving, previewUrl, saveFilesAndRefreshPreview } =
    useWidgetTemplateDraftPreview({
      widgetTemplateDraft,
      widgetTemplateId,
      widgetTemplateFiles,
      filesContent,
      savedContent,
      onFilesSaved: markFilesSaved
    });

  return (
    <FormProvider {...methods}>
      <Box sx={{ width: '100%', height: '100%', overflowY: 'scroll' }}>
        <WidgetEditorSubHeader
          openMappingEditor={() => {}}
          pageName='Create widget'
          name={name}
          setName={setName}
          description={description}
          setDescription={setDescription}
          displaysOption={displaysOption}
          setDisplaysOption={setDisplaysOption}
          widgetTemplateId={widgetTemplateId}
          widgetTemplateFiles={widgetTemplateFiles}
          widgetTemplateDraft={widgetTemplateDraft}
          departmentId={departmentId}
          openInfoModal={openInfoModal}
          setOpenInfoModal={setOpenInfoModal}
          isNew={true}
          filesContent={filesContent}
          savedContent={savedContent}
          onFilesSaved={markFilesSaved}
        />

        <WidgetSettingsBuilder
          widgetTemplateDraftId={widgetTemplateDraft.draftId}
          widgetTemplateId={widgetTemplateId}
          departmentId={departmentId}
        />

        {displaysOption ? (
          <MultipleEditorWindows
            widgetTemplateFiles={widgetTemplateFiles}
            filesContent={filesContent}
            setFilesContent={setFilesContent}
            activeHtmlId={activeHtmlId}
            activeCssId={activeCssId}
            activeJsId={activeJsId}
            setActiveHtmlId={setActiveHtmlId}
            setActiveCssId={setActiveCssId}
            setActiveJsId={setActiveJsId}
            previewUrl={previewUrl}
          />
        ) : (
          <OneEditorWindow
            setEditorMode={setEditorMode}
            editorMode={editorMode}
            widgetTemplateFiles={widgetTemplateFiles}
            widgetTemplateDraft={widgetTemplateDraft}
            setEditorType={setEditorType}
            editorType={editorType}
            filesContent={filesContent}
            setFilesContent={setFilesContent}
            previewUrl={previewUrl}
            onOpenVisualization={saveFilesAndRefreshPreview}
            isPreviewSaving={isPreviewSaving}
          />
        )}
      </Box>
    </FormProvider>
  );
}
