import { GreenFileIcon } from '@/public/icons/GreenFile.icon';
import { OrangeFileIcon } from '@/public/icons/OrangeFile.icon';
import { RedFileIcon } from '@/public/icons/RedFile.icon';
import { YellowFolderIcon } from '@/public/icons/YellowFolder.ion';
import { LibraryFakeInterface } from '../scripts_library/const';

export const library: LibraryFakeInterface[] = [
  {
    icon: <YellowFolderIcon />,
    title: 'RSS',
    children: [{ icon: <RedFileIcon />, title: 'RSS Defaults', children: [] }]
  },
  {
    icon: <YellowFolderIcon />,
    title: 'Company',
    children: [
      {
        icon: <GreenFileIcon />,
        title: 'Check Add Company',
        children: []
      },
      {
        icon: <OrangeFileIcon />,
        title: 'Documents ID',
        children: []
      }
    ]
  },
  {
    icon: <YellowFolderIcon />,
    title: 'Resource Providers',
    children: [
      {
        icon: <YellowFolderIcon />,
        title: 'PSE',
        children: [
          {
            icon: <OrangeFileIcon />,
            title: 'Form 23C',
            children: []
          },
          {
            icon: <GreenFileIcon />,
            title: 'Form 17C',
            children: []
          }
        ]
      },
      {
        icon: <YellowFolderIcon />,
        title: 'BSE',
        children: [
          {
            icon: <GreenFileIcon />,
            title: 'Annexure 1',
            children: []
          }
        ]
      },
      {
        icon: <YellowFolderIcon />,
        title: 'HKEX',
        children: [
          {
            icon: <RedFileIcon />,
            title: 'library',
            children: []
          }
        ]
      }
    ]
  }
];

export const otherList: LibraryFakeInterface[] = [
  {
    icon: <YellowFolderIcon />,
    title: 'Case 1',
    children: [
      {
        icon: <YellowFolderIcon />,
        title: 'QuerySample',
        children: [
          { icon: <RedFileIcon />, title: 'Main script', children: [] }
        ]
      },
      {
        icon: <YellowFolderIcon />,
        title: 'Save doc test',
        children: [
          { icon: <RedFileIcon />, title: 'Main script', children: [] }
        ]
      },
      {
        icon: <YellowFolderIcon />,
        title: 'DB query1',
        children: [
          { icon: <RedFileIcon />, title: 'Main script', children: [] }
        ]
      },
      {
        icon: <YellowFolderIcon />,
        title: 'dad',
        children: [
          { icon: <RedFileIcon />, title: 'Main script', children: [] }
        ]
      },
      {
        icon: <YellowFolderIcon />,
        title: 'Многомерный массив',
        children: [
          { icon: <RedFileIcon />, title: 'Main script', children: [] }
        ]
      },
      {
        icon: <YellowFolderIcon />,
        title: 'case test',
        children: [
          { icon: <RedFileIcon />, title: 'Main script', children: [] }
        ]
      }
    ]
  }
];
