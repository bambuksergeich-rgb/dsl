'use client';

import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { DashboardView } from '@/src/components/Dashboards/DashboardView/DashboardView';
import { dashboardActions } from '@/src/store/slices/dashboard.slice';

export const Dashboard = () => {
  const dispatch = useDispatch();
  const [dashboardWidth, setDashboardWidth] = useState<number>(0);
  const [dashboardHeight, setDashboardHeight] = useState<number>(0);

  useEffect(() => {
    return () => {
      dispatch(dashboardActions.clearWidgets());
      dispatch(dashboardActions.setDashboard(null));
      dispatch(dashboardActions.setTempDashboard(null));
      dispatch(dashboardActions.clearTempDashboard());
    };
  }, [dispatch]);

  return (
    <div className='flex h-full gap-2'>
      <div className='flex flex-col w-full shrink'>
        <div className='grow h-full'>
          <DashboardView
            dashboardWidth={dashboardWidth}
            dashboardHeight={dashboardHeight}
            setDashboardWidth={setDashboardWidth}
            setDashboardHeight={setDashboardHeight}
          />
        </div>
      </div>
    </div>
  );
};
