'use client';

import React from 'react';
import classNames from 'classnames';
import { useParams, useSearchParams } from 'next/navigation';
import { dashboardsAPI } from '@/src/store/api/dashboardsAPI';
import PageTransitionEffect from '@/src/components/Dashboards/Dashboard/components/PageTransitionEffect/PageTransitionEffect';
import { getTransitionParameters } from '@/src/components/Dashboards/Dashboard/utils/dashboardTransition';
import { Dashboard } from './dashboard';

export default function Page() {
  const searchParams = useSearchParams();
  const params = useParams<{ id: string }>();
  const dashboardId = params?.id as string;

  const transitionParameters = getTransitionParameters(searchParams);

  const { data: dashboard } = dashboardsAPI.useGetDashboardByIdQuery({
    id: dashboardId,
    params: transitionParameters
  });

  return (
    <PageTransitionEffect
      start={false}
      dashboard={dashboard}
    >
      <div
        className={classNames(
          { 'pb-8': false },
          'flex flex-col flex-grow w-full'
        )}
      >
        <div className='flex-grow'>
          <Dashboard />
        </div>
      </div>
    </PageTransitionEffect>
  );
}
