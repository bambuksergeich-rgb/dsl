'use client';

import { MyProfileCard } from '@/src/components/MyProfile/MyProfileCard';
import { MyProfileLogs } from '@/src/components/MyProfile/MyProfileLogs';
import { MyProfileNotification } from '@/src/components/MyProfile/MyProfileNotification';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { Box } from '@mui/system';
import { useEffect, useState } from 'react';
import { store } from '@/src/store/store';
import { getCompany } from '@/src/store/actions/getCompany';
import { Company } from '@/src/store/counter/companySlice';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { getUser } from '@/src/store/actions/getUser';
import { User } from '@/src/store/counter/userSlice';
import { checkRole } from '@/src/requests/checkRole';
import { Stack } from '@mui/material';

export default function MyProfile(): JSX.Element {
  const user: User = useSelector((state: State) => state.user);
  const role = useSelector((state: State) => state.userRole);

  const company: Company = useSelector((state: State) => state.company);

  return (
    <>
      <Box
        sx={{
          height: '90vh',
          overflowY: 'scroll',
          '&::-webkit-scrollbar': {
            display: 'none'
          }
        }}
      >
        <Stack
          sx={{
            flexDirection: 'row',
            justifyContent: 'start',
            alignItems: 'center',
            padding: '42px 40px 43px 40px'
          }}
        >
          <TypographyMontserrat500 sx={{ fontSize: '32px' }}>
            My profile
          </TypographyMontserrat500>
        </Stack>
        <MyProfileCard
          user={user}
          role={role.name}
          companyName={company.name}
        />
        <MyProfileLogs />
        <MyProfileNotification />
      </Box>
    </>
  );
}
