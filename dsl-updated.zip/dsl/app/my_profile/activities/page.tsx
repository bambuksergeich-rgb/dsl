'use client';
import { ActivitiesHeader } from '@/src/components/Activities/ActivitiesHeader';
import { ActivitiesTableAll } from '@/src/components/Activities/common/ActivitiesTableAll';
import { Stack } from '@mui/system';
import { useState, useEffect } from 'react';
import { Pagination } from '@/src/components/Pagination/Pagination';
import { store } from '@/src/store/store';
import { getCompany } from '@/src/store/actions/getCompany';
import { getUser } from '@/src/store/actions/getUser';
import { getActivities } from '@/src/store/actions/getActivities';
import { Activitie, ActivitieData } from '@/src/store/counter/activitiesSlice';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { Loading } from '@/src/components/Loading/Loading';
import { checkRole } from '@/src/requests/checkRole';
import { useSearchParams } from 'next/navigation';
import { getUsers } from '@/src/store/actions/getUsers';
import { getActivityMetadataAction } from '@/src/store/actions/getActivityMetadataAction';
import { NoData } from '@/src/components/NoData/NoData';

const componentList = [
  'ALL',
  'SCRIPT',
  'DOCKER_IMAGE',
  'DOCKER_CONTAINER',
  'COMPANY',
  'DEPARTMENT',
  'USER',
  'USER_INVITATION',
  'ROLE',
  'WIDGET_TEMPLATE',
  'COMPONENT',
  'WIDGET',
  'WIDGET_COMPONENT',
  'DASHBOARD',
  'EVENT',
  'STORAGE'
];

export default function Activities() {
  const [page, setPage] = useState<number>(1);
  const [filter, setFilter] = useState<string>('ALL');
  const [dataPage, setDataPage] = useState<Activitie[]>([]);
  const [filteredData, setFilteredData] = useState<Activitie[]>([]);
  const [departmentId, setDepartmentId] = useState<string>('');
  const [action, setAction] = useState<string>('');
  const [employee, setEmployee] = useState<string>('');
  const [employeeId, setEmployeeId] = useState<string>('');
  const [fromDate, setFromDate] = useState<string>('');
  const [toDate, setToDate] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const role = useSelector((state: State) => state.userRole);

  const searchParams = useSearchParams();

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getUsers(departmentId));
    }
  }, [departmentId]);

  useEffect(() => {
    if (role) {
      store.dispatch(getActivityMetadataAction(role.name === 'Administrator'));
    }
  }, [role]);

  useEffect(() => {
    store.dispatch(
      getActivities(
        1,
        role.name === 'Administrator',
        filter,
        action,
        employeeId,
        fromDate,
        toDate,
        setPage,
        setLoading
      )
    );
  }, [filter]);

  const activities: ActivitieData = useSelector(
    (state: State) => state.activities
  );

  const user = useSelector((state: State) => state.user);

  useEffect(() => {
    setFilteredData(activities.content);
  }, [activities.content]);

  useEffect(() => {
    setDataPage(activities.content);
  }, [filteredData]);

  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
    store.dispatch(
      getActivities(value, true, filter, action, employeeId, fromDate, toDate)
    );
  };

  if (!activities) {
    <Loading />;
  }

  return (
    <>
      <Stack sx={{ p: '40px 40px 24px 40px' }}>
        <ActivitiesHeader
          isAllActivities={false}
          name={`${user.firstName} ${user.lastName}'s`}
          filter={filter}
          setFilter={setFilter}
          componentList={componentList}
          type={filter}
          setType={setFilter}
          action={action}
          setAction={setAction}
          employee={employee}
          setEmployee={setEmployee}
          fromDate={fromDate}
          setFromDate={setFromDate}
          toDate={toDate}
          setToDate={setToDate}
          employeeId={employeeId}
          setEmployeeId={setEmployeeId}
          page={page}
          setPage={setPage}
        />
      </Stack>
      {!loading ? (
        activities?.content?.length > 0 ? (
          <>
            <ActivitiesTableAll
              isAdmin={false}
              dataPage={dataPage}
            />
            <Pagination
              page={page}
              totalElements={activities.totalElements}
              handleChange={handleChange}
            />
          </>
        ) : (
          <NoData />
        )
      ) : null}
    </>
  );
}
