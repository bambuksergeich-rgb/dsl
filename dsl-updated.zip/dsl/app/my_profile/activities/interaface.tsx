export type FakeDataActivities = Record<string, DataTableActivities[]>;

export interface DataTableActivities {
  name: string;
  date: string;
  action?: string;
  blueAction?: string;
  path?: string;
  type?: string;
  employee?: string;
}

export interface DataTablePages {
  name: string;
  date: string;
}
