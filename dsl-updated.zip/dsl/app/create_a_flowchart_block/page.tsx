'use client';

import React, { useEffect, useRef, useState } from 'react';
import classNames from 'classnames';
import clsx from 'clsx';
import { useAppSelector } from '@/src/hooks/typedAsyncThunk';
import { useRouter, useSearchParams } from 'next/navigation';
import { store } from '@/src/store/store';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { CreateFlowchartBlockView } from '@/src/components/CreateFlowchartBlock/CreateFlowchartBlockView';
import { createBlockDraftAction } from '@/src/store/actions/ScriptBlockDraft/createBlockDraftAction';
import { resolveScriptDraftById } from '@/src/helpers/scriptDraftAccess';
import { getScriptBlockDraftAction } from '@/src/store/actions/ScriptBlockDraft/getScriptBlockDraftAction';
import { clearScriptBlockDraft } from '@/src/store/counter/scriptBlockDraftSlice';
import { scriptDraftCreate, setScriptBlockDraftId } from '@/src/store/counter/scriptDraft';
import { createCurrentScriptDraftRequest } from '@/src/requests/createCurrentScriptDraft';
import { Loading } from '@/src/components/Loading/Loading';
import { SimpleMUIButton } from '@/src/styles/muiButtonStyles';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { Box } from '@mui/material';

const FLOWCHART_DRAFT_CACHE_KEY = 'dsl:flowchartDraftMeta';

type FlowchartDraftMeta = {
  draftId: string;
  sourceId: string;
  groupId: string;
  name?: string;
};

const CreateFlowchartBlock = () => {
  const { isFullscreenMode } = useAppSelector((state) => state.common);
  const router = useRouter();
  const routerRef = useRef(router);
  routerRef.current = router;
  const scriptBlockDraft = useSelector(
    (state: State) => state.scriptBlockDraft
  );
  const currentScriptDraft = useSelector(
    (state: State) => state.scriptDraft
  );

  const [name, setName] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const searchParams = useSearchParams();
  const scriptDraftId = searchParams.get('scriptDraftId') || '';

  const readCachedDraftMeta = (): FlowchartDraftMeta | null => {
    if (typeof window === 'undefined') return null;
    try {
      const raw = sessionStorage.getItem(FLOWCHART_DRAFT_CACHE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as Partial<FlowchartDraftMeta>;
      if (!parsed.sourceId || !parsed.groupId) return null;
      return {
        draftId: parsed.draftId || '',
        sourceId: parsed.sourceId,
        groupId: parsed.groupId,
        name: parsed.name,
      };
    } catch {
      return null;
    }
  };

  const writeCachedDraftMeta = (draft: Partial<FlowchartDraftMeta>) => {
    if (typeof window === 'undefined') return;
    if (!draft.sourceId || !draft.groupId) return;
    sessionStorage.setItem(
      FLOWCHART_DRAFT_CACHE_KEY,
      JSON.stringify({
        draftId: draft.draftId || '',
        sourceId: draft.sourceId,
        groupId: draft.groupId,
        name: draft.name || '',
      }),
    );
  };

  useEffect(() => {
    if (!currentScriptDraft?.sourceId || !currentScriptDraft?.groupId) return;
    writeCachedDraftMeta({
      draftId: currentScriptDraft.draftId,
      sourceId: currentScriptDraft.sourceId,
      groupId: currentScriptDraft.groupId,
      name: currentScriptDraft.name,
    });
  }, [
    currentScriptDraft?.draftId,
    currentScriptDraft?.sourceId,
    currentScriptDraft?.groupId,
    currentScriptDraft?.name,
  ]);

  useEffect(() => {
    if (!scriptDraftId) {
      setIsLoading(false);
      setLoadError('Script draft id is missing');
      return;
    }

    let cancelled = false;

    const replaceDraftIdInUrl = (nextDraftId: string) => {
      if (!nextDraftId || nextDraftId === scriptDraftId) return;
      const params = new URLSearchParams(window.location.search);
      params.set('scriptDraftId', nextDraftId);
      routerRef.current.replace(
        `${window.location.pathname}?${params.toString()}`,
      );
    };

    const ensureBlockDraft = async (draft: {
      draftId: string;
      scriptBlockDraftId?: string;
    }) => {
      if (draft.scriptBlockDraftId) {
        store.dispatch(setScriptBlockDraftId(draft.scriptBlockDraftId));
        await store.dispatch(
          getScriptBlockDraftAction(draft.scriptBlockDraftId, {
            silent: true,
            retries: 5,
          }) as any,
        );
        if (cancelled) return false;
        const loaded = store.getState().scriptBlockDraft;
        if (loaded?.draftId === draft.scriptBlockDraftId) return true;
      }

      await store.dispatch(
        createBlockDraftAction(draft.draftId, 'INPUT', { silent: true }) as any,
      );
      if (cancelled) return false;
      return Boolean(store.getState().scriptBlockDraft?.draftId);
    };

    const fetchScriptDraft = async () => {
      const state = store.getState();
      const alreadyLoaded =
        state.scriptDraft?.draftId === scriptDraftId &&
        Boolean(state.scriptBlockDraft?.draftId) &&
        state.scriptDraft?.scriptBlockDraftId ===
          state.scriptBlockDraft?.draftId;

      if (alreadyLoaded && state.scriptBlockDraft?.draftId) {
        const stillValid = await store.dispatch(
          getScriptBlockDraftAction(state.scriptBlockDraft.draftId, {
            silent: true,
            retries: 1,
          }) as any,
        );
        if (cancelled) return;
        if (stillValid) {
          setName(state.scriptDraft?.name || '');
          setLoadError(null);
          setIsLoading(false);
          return;
        }
      }

      setIsLoading(true);
      setLoadError(null);
      store.dispatch(clearScriptBlockDraft());

      const lookup = await resolveScriptDraftById(scriptDraftId, 3);
      if (cancelled) return;
      let draft = lookup.data;

      if (!draft?.draftId) {
        const storeDraft = store.getState().scriptDraft;
        const cached = readCachedDraftMeta();
        const recreateFrom =
          storeDraft?.sourceId && storeDraft?.groupId
            ? {
                sourceId: storeDraft.sourceId,
                groupId: storeDraft.groupId,
                name: storeDraft.name,
              }
            : cached?.sourceId && cached?.groupId
              ? {
                  sourceId: cached.sourceId,
                  groupId: cached.groupId,
                  name: cached.name,
                }
              : null;

        if (recreateFrom) {
          const recreated = await createCurrentScriptDraftRequest(
            recreateFrom.sourceId,
            recreateFrom.groupId,
          );
          if (cancelled) return;
          if (recreated?.draftId) {
            draft = recreated;
            writeCachedDraftMeta({
              draftId: recreated.draftId,
              sourceId: recreated.sourceId || recreateFrom.sourceId,
              groupId: recreated.groupId || recreateFrom.groupId,
              name: recreated.name || recreateFrom.name,
            });
          }
        }
      }

      if (!draft?.draftId) {
        if (!cancelled) {
          setLoadError('Script draft not found');
          setIsLoading(false);
        }
        return;
      }

      store.dispatch(scriptDraftCreate(draft));
      setName(draft.name || '');
      writeCachedDraftMeta({
        draftId: draft.draftId,
        sourceId: draft.sourceId,
        groupId: draft.groupId,
        name: draft.name,
      });

      const blockReady = await ensureBlockDraft(draft);
      if (cancelled) return;

      if (!blockReady) {
        setLoadError('Failed to load flowchart block');
        setIsLoading(false);
        return;
      }

      setLoadError(null);
      setIsLoading(false);
      replaceDraftIdInUrl(draft.draftId);
    };

    fetchScriptDraft();

    return () => {
      cancelled = true;
    };
  }, [scriptDraftId]);

  const canRender = Boolean(scriptBlockDraft?.draftId);
  const activeScriptDraftId = currentScriptDraft?.draftId || scriptDraftId;

  if (isLoading && !canRender) {
    return <Loading />;
  }

  if (!canRender) {
    return (
      <Box
        sx={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '16px',
        }}
      >
        <TypographyMontserrat500 sx={{ fontSize: '16px' }}>
          {loadError || 'Failed to open flowchart'}
        </TypographyMontserrat500>
        <SimpleMUIButton onClick={() => router.back()}>Back</SimpleMUIButton>
      </Box>
    );
  }

  return (
    <div
      className={clsx(
        'w-full flex h-full bg-custom-linear-gradient overflow-hidden',
        isFullscreenMode && 'absolute left-0 top-0',
        isFullscreenMode &&
          'top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2'
      )}
    >
      <div
        className={classNames(
          { 'pb-8': false },
          'flex flex-col flex-grow w-full min-h-0'
        )}
      >
        <div className='flex-grow min-h-0'>
          <CreateFlowchartBlockView
            create
            name={name}
            scriptDraftId={activeScriptDraftId}
            scriptBlockDraft={scriptBlockDraft!}
          />
        </div>
      </div>
    </div>
  );
};

export default CreateFlowchartBlock;
