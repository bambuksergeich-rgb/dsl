import { DataTable } from './interface';

export const dataTable: DataTable[] = [
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard21',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  },
  {
    name: 'Dashboard33',
    date: '12/09/2023 ',
    action: 'change add_row',
    blueAction: '#1414441',
    path: '/404'
  }
];
