'use client';

import { ActionSubHeader } from '@/src/components/AllSubHeaders/ActionSubHeader/ActionSubHeader';
import { useEffect, useState } from 'react';
import { ActionTable } from '@/src/components/AllTables/ActionTable/ActionTable';
import { Pagination } from '@/src/components/Pagination/Pagination';
import { DataTable } from './interface';
import { dataTable } from './constants';

export default function DashboardAction(): JSX.Element {
  const [page, setPage] = useState<number>(1);
  const [filter, setFilter] = useState<string>('Deals');
  const [dataPage, setDataPage] = useState<DataTable[]>(dataTable);
  const [filteredData, setFilteredData] = useState<any[] | []>([]);
  useEffect(() => {
    setFilteredData(dataTable);
  }, [filter]);

  useEffect(() => {
    setDataPage(
      page === 1
        ? filteredData.slice(page - 1, page + 9)
        : filteredData.slice((page - 1) * 10, page + 9)
    );
  }, [filteredData]);

  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
    setDataPage(
      value === 1
        ? filteredData.slice(value - 1, value + 9)
        : filteredData.slice((value - 1) * 10, value * 10)
    );
  };

  return (
    <>
      <ActionSubHeader
        name='Ivan Petrov'
        type='Dashboard'
      />
      <ActionTable dataPage={dataPage} />
      <Pagination
        totalElements={dataTable.length}
        handleChange={handleChange}
      />
    </>
  );
}
