'use client';

import ScriptEditor from '@/src/components/ScriptEditor/ScriptEditor';

export default function CreateScriptPage() {
  return <ScriptEditor createNew />;
}
