export interface TabScriptItem {
  id: string;
  name: string;
  path: string;
}
