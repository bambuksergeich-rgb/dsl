import { Backdrop, styled } from '@mui/material';

export const StyledBackdrop = styled(Backdrop)(({ theme }) => ({
  backgroundColor: 'rgba(30, 30, 30, 0.30)',
  backdropFilter: 'blur(5px)',
  zIndex: -1,
  width: '100vw',
  height: '100vh'
}));
