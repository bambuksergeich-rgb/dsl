export const DropBuildIcon = (): JSX.Element => {
  return (
    <svg
      xmlns='http://www.w3.org/2000/svg'
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
    >
      <path
        d='M6.66667 5H13.3333C14.25 5 15 5.75 15 6.66667V13.3333C15 14.25 14.25 15 13.3333 15H6.66667C5.75 15 5 14.25 5 13.3333V6.66667C5 5.75 5.75 5 6.66667 5Z'
        fill='white'
      />
    </svg>
  );
};
