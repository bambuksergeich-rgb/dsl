import React from 'react';

const ConfigurationIcon: React.FC = (props) => (
  <svg
    width={60}
    height={60}
    viewBox='0 0 60 60'
    fill='none'
    xmlns='http://www.w3.org/2000/svg'
    {...props}
  >
    <g
      id='mnj0rkx2'
      clip-path='url(#clip0_1633_39473)'
    >
      <g id='cogfig'>
        <path
          id='Vector'
          d='M60 0H0V60H60V0Z'
          fill='white'
          fill-opacity='0.01'
        />
        <g id='&#231;&#188;&#150;&#231;&#187;&#132;'>
          <path
            id='Path-15'
            d='M30 5L22.5 12.5H12.5V22.5L5 30L12.5 37.5V47.5H22.5L30 55L37.5 47.5H47.5V37.5L55 30L47.5 22.5V12.5H37.5L30 5Z'
            fill='#2F88FF'
            stroke='black'
            stroke-width='5'
            stroke-linejoin='round'
          />
          <path
            id='Oval-6'
            d='M30 37.5C34.1421 37.5 37.5 34.1421 37.5 30C37.5 25.8579 34.1421 22.5 30 22.5C25.8579 22.5 22.5 25.8579 22.5 30C22.5 34.1421 25.8579 37.5 30 37.5Z'
            fill='#43CCF8'
            stroke='white'
            stroke-width='5'
            stroke-linejoin='round'
          />
        </g>
      </g>
    </g>
    <defs>
      <clipPath id='clip0_1633_39473'>
        <rect
          width='60'
          height='60'
          fill='white'
        />
      </clipPath>
    </defs>
  </svg>
);

export default ConfigurationIcon;
