import React from 'react';

const ConnectionPointTwoIcon: React.FC = (props) => (
  <svg
    width={60}
    height={60}
    viewBox='0 0 60 60'
    fill='none'
    xmlns='http://www.w3.org/2000/svg'
    {...props}
  >
    <g
      id='lxq3fvbg'
      clip-path='url(#clip0_1633_39507)'
    >
      <path
        id='Vector'
        d='M60 0H0V60H60V0Z'
        fill='white'
        fill-opacity='0.01'
      />
      <path
        id='Vector_2'
        d='M45 10H16.25C12.5 10 5 12.5 5 20C5 27.5 12.5 30 16.25 30H43.75C47.5 30 55 32.5 55 40C55 47.5 47.5 50 43.75 50H15'
        stroke='black'
        stroke-width='5'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
      <path
        id='Vector_3'
        d='M50 15C52.7614 15 55 12.7614 55 10C55 7.23857 52.7614 5 50 5C47.2386 5 45 7.23857 45 10C45 12.7614 47.2386 15 50 15Z'
        fill='#2F88FF'
        stroke='black'
        stroke-width='5'
        stroke-linejoin='round'
      />
      <path
        id='Vector_4'
        d='M10 55C12.7614 55 15 52.7614 15 50C15 47.2386 12.7614 45 10 45C7.23857 45 5 47.2386 5 50C5 52.7614 7.23857 55 10 55Z'
        fill='#2F88FF'
        stroke='black'
        stroke-width='5'
        stroke-linejoin='round'
      />
    </g>
    <defs>
      <clipPath id='clip0_1633_39507'>
        <rect
          width='60'
          height='60'
          fill='white'
        />
      </clipPath>
    </defs>
  </svg>
);
export default ConnectionPointTwoIcon;
