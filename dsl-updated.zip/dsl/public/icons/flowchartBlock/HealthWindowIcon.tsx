import React from 'react';

const HealthWindowIcon: React.FC = (props) => (
  <svg
    width={60}
    height={60}
    viewBox='0 0 60 60'
    fill='none'
    xmlns='http://www.w3.org/2000/svg'
    {...props}
  >
    <g id='f30qlkcz'>
      <path
        id='Vector'
        d='M48.75 7.5H11.25C9.17894 7.5 7.5 9.17894 7.5 11.25V48.75C7.5 50.8211 9.17894 52.5 11.25 52.5H48.75C50.8211 52.5 52.5 50.8211 52.5 48.75V11.25C52.5 9.17894 50.8211 7.5 48.75 7.5Z'
        fill='#2F88FF'
        stroke='black'
        stroke-width='5'
      />
      <path
        id='Vector_2'
        d='M34.125 15C31.8469 15 30 16.7934 30 19.0056C30 23.0114 34.875 26.6529 37.5 27.5C40.125 26.6529 45 23.0114 45 19.0056C45 16.7934 43.1531 15 40.875 15C39.4799 15 38.2465 15.6725 37.5 16.702C36.7535 15.6725 35.5201 15 34.125 15Z'
        fill='#43CCF8'
        stroke='white'
        stroke-width='5'
        stroke-linecap='round'
        stroke-linejoin='round'
      />
    </g>
  </svg>
);
export default HealthWindowIcon;
