export const DonutIcon = (): JSX.Element => (
  <svg
    xmlns='http://www.w3.org/2000/svg'
    width='16'
    height='16'
    viewBox='0 0 16 16'
    fill='none'
  >
    <circle
      cx='8'
      cy='8'
      r='8'
      fill='#2A2B6B'
    />
    <circle
      cx='8'
      cy='8'
      r='4'
      fill='#10161C'
      fillOpacity='0.5'
    />
  </svg>
);
