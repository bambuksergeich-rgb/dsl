export const ArrowUpIcon = ({ rotate }: { rotate?: boolean }) => {
  return (
    <svg
      style={{ rotate: rotate ? '-180deg' : '' }}
      width='24'
      fill='none'
      height='24'
      viewBox='0 0 24 24'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        strokeWidth='2'
        stroke='#D3D6E7'
        d='M7 10L12 15L17 10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
};
