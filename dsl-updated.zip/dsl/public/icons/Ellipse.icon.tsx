interface EllipceIconProps {
  color?: string; // Используем перечисление в качестве типа для цвета
}

export const EllipceIcon = ({ color }: EllipceIconProps): JSX.Element => (
  <svg
    xmlns='http://www.w3.org/2000/svg'
    width='24'
    height='24'
    viewBox='0 0 24 24'
    fill='none'
  >
    <circle
      cx='12'
      cy='12'
      r='10.5'
      stroke={color}
      strokeWidth='3'
    />
  </svg>
);
