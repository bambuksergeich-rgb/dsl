export const AgreementIcon = (): JSX.Element => {
  return (
    <svg
      width='24'
      height='24'
      fill='none'
      viewBox='0 0 24 24'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        stroke='#ffffff'
        strokeWidth='1.5'
        strokeLinecap='round'
        strokeLinejoin='round'
        d='M19 2H5C4.44772 2 4 2.44772 4 3V21C4 21.5523 4.44772 22 5 22H19C19.5523 22 20 21.5523 20 21V3C20 2.44772 19.5523 2 19 2Z'
      />
      <path
        stroke='#ffffff'
        strokeWidth='1.5'
        strokeLinecap='round'
        strokeLinejoin='round'
        d='M8 2H12.5V10L10.25 8L8 10V2Z'
      />
      <path
        stroke='#ffffff'
        strokeWidth='1.5'
        d='M8 14H13M8 17H16'
        strokeLinecap='round'
      />
    </svg>
  );
};
