export const LanguageIcon = (): JSX.Element => {
  return (
    <svg
      width='24'
      height='24'
      fill='none'
      viewBox='0 0 24 24'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        stroke='white'
        strokeWidth='1.5'
        strokeLinecap='round'
        strokeLinejoin='round'
        d='M2 12C2 17.523 6.477 22 12 22C17.523 22 22 17.523 22 12C22 6.477 17.523 2 12 2C6.477 2 2 6.477 2 12Z'
      />
      <path
        stroke='white'
        strokeWidth='1.5'
        strokeLinecap='round'
        strokeLinejoin='round'
        d='M13 2.05005C13 2.05005 16 6.00005 16 12C16 18 13 21.9501 13 21.9501M11 21.9501C11 21.9501 8 18 8 12C8 6.00005 11 2.05005 11 2.05005M2.63 15.5H21.37M2.63 8.50005H21.37'
      />
    </svg>
  );
};
