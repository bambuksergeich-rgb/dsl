export const FlowChartIcon = (): JSX.Element => {
  return (
    <svg
      width='24'
      height='24'
      fill='#FFFFFF70'
      viewBox='0 0 24 24'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        stroke='#FFFFFF70'
        d='M16.5 13.5H24V21H16.5V18H11.625L6.75 22.875L1.125 17.25L6 12.375V7.5H3V0H10.5V7.5H7.5V12.375L11.625 16.5H16.5V13.5ZM4.5 1.5V6H9V1.5H4.5ZM6.75 20.625L10.125 17.25L6.75 13.875L3.375 17.25L6.75 20.625ZM22.5 19.5V15H18V19.5H22.5Z'
      />
    </svg>
  );
};
