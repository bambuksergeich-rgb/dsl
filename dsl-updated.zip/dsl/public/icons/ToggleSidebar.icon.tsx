export const ToggleSidebarIcon = () => (
  <svg
    xmlns='http://www.w3.org/2000/svg'
    width='14'
    height='7'
    viewBox='0 0 14 7'
    fill='none'
  >
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M1.99996 4L4.14596 6.146L3.43896 6.854L0.438965 3.854V3.146L3.43896 0.145996L4.14596 0.853996L1.99996 3H12L9.85396 0.853996L10.561 0.145996L13.561 3.146V3.854L10.561 6.854L9.85396 6.147L12 4H1.99996Z'
      fill='white'
    />
  </svg>
);
