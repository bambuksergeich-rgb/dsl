export const DataPlusIcon = (): JSX.Element => {
  return (
    <svg
      width='24'
      height='24'
      fill='none'
      viewBox='0 0 24 24'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        stroke='#ffffff80'
        strokeWidth='2'
        strokeLinecap='round'
        strokeLinejoin='round'
        d='M21 7C21 9.21 16.97 11 12 11C7.03 11 3 9.21 3 7M21 7C21 4.79 16.97 3 12 3C7.03 3 3 4.79 3 7M21 7V12M3 7V12M3 12C3 14.21 7.03 16 12 16M3 12V17C3 19.21 7.03 21 12 21M18 15V18M18 18V21M18 18H21M18 18H15'
      />
    </svg>
  );
};
