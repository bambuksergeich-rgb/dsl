export const TextIcon = (): JSX.Element => {
  return (
    <svg
      width='20'
      height='20'
      fill='none'
      viewBox='0 0 20 20'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        stroke='white'
        strokeWidth='2'
        strokeLinecap='round'
        strokeLinejoin='round'
        d='M4.16666 6.66663H15.8333M4.16666 9.99996H15.8333M4.16666 13.3333H9.16666'
      />
    </svg>
  );
};
