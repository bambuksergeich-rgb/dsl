export const TxtIcon = () => {
  return (
    <svg
      width='14'
      height='21'
      viewBox='0 0 14 21'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M0 0.964285C0 0.431725 0.430627 0 0.961832 0H10.0458L14 3.96429V17.0357C14 17.5683 13.5694 18 13.0382 18H0.961832C0.430627 18 0 17.5683 0 17.0357V0.964285Z'
        fill='url(#paint0_linear_1_140)'
      />
      <path
        d='M10.0458 0L14 3.96429H11.0076C10.4764 3.96429 10.0458 3.53256 10.0458 3V0Z'
        fill='#B0FE9D'
      />
      <path
        d='M2.17756 8.99751V8.36364H5.16406V8.99751H4.05078V12H3.29084V8.99751H2.17756ZM6.37678 8.36364L7.11009 9.60298H7.13849L7.87536 8.36364H8.74361L7.63388 10.1818L8.76847 12H7.88423L7.13849 10.7589H7.11009L6.36435 12H5.48366L6.6218 10.1818L5.50497 8.36364H6.37678ZM9.09162 8.99751V8.36364H12.0781V8.99751H10.9648V12H10.2049V8.99751H9.09162Z'
        fill='white'
      />
      <defs>
        <linearGradient
          id='paint0_linear_1_140'
          x1='7'
          y1='0'
          x2='7'
          y2='18'
          gradientUnits='userSpaceOnUse'
        >
          <stop stopColor='#86FF4D' />
          <stop
            offset='1'
            stopColor='#407200'
          />
        </linearGradient>
      </defs>
    </svg>
  );
};
