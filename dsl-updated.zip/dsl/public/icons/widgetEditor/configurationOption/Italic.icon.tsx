export const ItalicIcon = () => {
  return (
    <svg
      width='20'
      height='20'
      viewBox='0 0 20 20'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        d='M5 19L5.33 17.49L7.5 16.83L10.4 3.17L8.5 2.54L9 1H16L15.29 2.6L13 3.17L10.17 16.83L12.31 17.49L12 19H5Z'
        fill='white'
      />
    </svg>
  );
};
