export const OpChickSmallIcon = () => {
  return (
    <svg
      width='12'
      height='12'
      viewBox='0 0 12 12'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <g id='iconamoon:arrow-up-2-duotone'>
        <path
          id='Vector'
          d='M3.5 5L6 7.5L8.5 5'
          stroke='white'
          strokeWidth='2'
          strokeLinecap='round'
          strokeLinejoin='round'
        />
      </g>
    </svg>
  );
};
