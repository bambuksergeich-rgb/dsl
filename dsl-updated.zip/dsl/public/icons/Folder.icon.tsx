import { SvgIconProps } from '@mui/material';

export const FolderIcon = (props: SvgIconProps): JSX.Element => {
  return (
    <svg
      width='24'
      height='24'
      fill='none'
      viewBox='0 0 24 24'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        fill='white'
        d='M0 4.80002C0 3.48002 1.08 2.40002 2.4 2.40002H10.8L13.2 4.80002H21.6C22.2365 4.80002 22.847 5.05288 23.2971 5.50297C23.7471 5.95306 24 6.56351 24 7.20002V19.2C24 19.8365 23.7471 20.447 23.2971 20.8971C22.847 21.3472 22.2365 21.6 21.6 21.6H2.4C1.76348 21.6 1.15303 21.3472 0.702944 20.8971C0.252856 20.447 0 19.8365 0 19.2V4.80002Z'
      />
    </svg>
  );
};
