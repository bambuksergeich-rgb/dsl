import React from 'react';

export const DashboardGroupIcon = ({
  width = 24,
  height = 24,
  fill = 'white'
}) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox='0 0 24 24'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
    >
      <g clipPath='url(#clip0_5884_33680)'>
        <path
          d='M1 21H23V3H1V21ZM22 4V20H9V4H22ZM2 4H8V8H2V4ZM2 9H8V20H2V9Z'
          fill={fill}
        />
      </g>
      <defs>
        <clipPath id='clip0_5884_33680'>
          <rect
            width='24'
            height='24'
            fill='white'
          />
        </clipPath>
      </defs>
    </svg>
  );
};
