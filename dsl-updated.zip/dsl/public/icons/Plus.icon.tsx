export const PlusIcon = (): JSX.Element => {
  return (
    <svg
      width='24'
      height='24'
      fill='none'
      viewBox='0 0 24 24'
      xmlns='http://www.w3.org/2000/svg'
    >
      <path
        stroke='white'
        strokeWidth='1.5'
        strokeLinecap='round'
        strokeLinejoin='round'
        d='M12 4.5V19.5M19.5 12H4.5'
      />
    </svg>
  );
};
