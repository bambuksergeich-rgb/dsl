import { editor } from 'monaco-editor';

export const themeRedactor: editor.IStandaloneThemeData = {
  base: 'vs-dark',
  inherit: true,
  rules: [
    { token: 'keyword', foreground: '#4170FF' },
    { token: 'string', foreground: '#FF6A3E' },
    { token: 'comment', foreground: '#828282' },
    { token: 'annotation', foreground: '#FF0000' },
    { token: 'number', foreground: '#FABF52' }
  ],
  colors: {
    'editor.background': '#10161C',
    'editor.foreground': '#FFFFFF'
  }
};

export const options: editor.IStandaloneEditorConstructionOptions | undefined =
  {
    contextmenu: false,
    matchBrackets: 'never',
    renderLineHighlight: 'none',
    selectOnLineNumbers: false,
    showFoldingControls: 'never',
    tabSize: 6,
    colorDecorators: true,
    glyphMargin: false,
    minimap: { enabled: false },
    selectionHighlight: false,
    overviewRulerLanes: 0,
    hideCursorInOverviewRuler: true,
    scrollbar: {
      vertical: 'hidden'
    },
    padding: { bottom: 16, top: 16 },
    overviewRulerBorder: false
  };
