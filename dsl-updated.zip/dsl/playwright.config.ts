import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests/e2e',
  timeout: 90000,
  workers: 1,
  use: {
    baseURL: 'http://127.0.0.1:8081',
    viewport: { width: 1920, height: 1080 },
    launchOptions: {
      ...(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}),
      args: ['--no-sandbox'],
    },
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
  webServer: {
    command: 'npx next dev -p 8081 -H 127.0.0.1',
    url: 'http://127.0.0.1:8081',
    reuseExistingServer: false,
    timeout: 120000,
    env: {
      NEXT_DIST_DIR: '.next-e2e',
      NEXT_PUBLIC_API_URL: 'http://127.0.0.1:8081/__test_api',
      // The pre-existing development bypass is used only against browser mocks.
      NEXT_PUBLIC_DEV_TOKEN: 'local-ui-test',
      NEXTAUTH_URL: 'http://localhost:8081',
    },
  },
});
