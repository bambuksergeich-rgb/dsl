/** Reconstructed from the supplied source archive; see README.md. */
const nextConfig = { distDir: process.env.NEXT_DIST_DIR || (process.env.NODE_ENV === "development" ? ".next-dev" : ".next"), experimental: { cpus: 2 }, webpack(config) { config.module.rules.push({ test: /\.svg$/, issuer: /\.[jt]sx?$/, use: ['@svgr/webpack'] }); return config; } };
export default nextConfig;
