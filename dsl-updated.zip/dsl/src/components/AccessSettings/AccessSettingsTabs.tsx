import { ThreeDotsMini } from '@/public/icons/ThreeDotsMini.icon';
import { getRoleAction } from '@/src/store/actions/getRoleAction';
import { Role } from '@/src/store/counter/rolesSlice';
import { store } from '@/src/store/store';
import { TabMUIButton } from '@/src/styles/muiButtonStyles';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { IconButton, Popover } from '@mui/material';
import { Box, Stack } from '@mui/system';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { EditRoleModal } from '../AllModals/EditRoleModal/EditRoleModal';
import { useSearchParams } from 'next/navigation';
import { deleteRole } from '@/src/requests/deleteRole';
import { getRoles } from '@/src/store/actions/getRoles';
import { ModalItemWorking } from '../AllModals/ProfileModal/style';

interface AccessSettingsTabsProps {
  activeButton: string;
  setActiveButton: Dispatch<SetStateAction<string>>;
  item: Role;
}

export const AccessSettingsTabs = (props: AccessSettingsTabsProps) => {
  const { activeButton, setActiveButton, item } = props;
  const [openModal, setOpenModal] = useState(false);
  const [hover, setHover] = useState(false);
  const [departmentId, setDepartmentId] = useState('');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const searchParams = useSearchParams();
  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popper' : undefined;
  const ModalItem = [
    {
      name: 'Edit',
      function: () => setOpenModal((prev) => !prev)
    },
    {
      name: 'Remove',
      function: async () => {
        await deleteRole(item.id);
        store.dispatch(getRoles(departmentId));
      }
    }
  ];
  return (
    <Box
      sx={{ position: 'relative' }}
      key={item.id}
    >
      <TabMUIButton
        selected={activeButton === item.id}
        onClick={() => {
          setActiveButton(item.id);
          store.dispatch(getRoleAction(item.id));
        }}
        sx={{
          padding: '0',
          margin: '0',
          minWidth: '180px',
          p: '0 20px 0 20px',
          height: '100%',
          background: hover ? '#547FFF' : ''
        }}
      >
        <TypographyMontserrat500
          noWrap
          sx={{ fontSize: '14px', marginRight: '15px' }}
        >
          {item.name}
        </TypographyMontserrat500>
      </TabMUIButton>
      <IconButton
        onMouseEnter={() => {
          setHover(true);
        }}
        onMouseLeave={() => {
          setHover(false);
        }}
        sx={{
          padding: '0px',
          height: '100%',
          width: '34px',
          position: 'absolute',
          marginLeft: '5px',
          right: '5px',
          top: '0',
          '&:hover': {
            background: 'transparent'
          }
        }}
        onClick={handleClick}
        disableTouchRipple={true}
      >
        <ThreeDotsMini />
      </IconButton>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left'
        }}
        PaperProps={{
          sx: {
            backgroundColor: 'transparent'
          }
        }}
      >
        <Stack
          flexDirection={'column'}
          sx={{
            width: '150px',
            padding: '12px 0',
            borderRadius: '10px',
            backgroundColor: 'rgba(16, 22, 28)',
            border: '1px solid rgba(255, 255, 255, 0.15)'
          }}
        >
          {ModalItem.map((item, index) => (
            <ModalItemWorking
              selected={false}
              key={index}
              onClick={(e) => {
                item.function();
                handleClick(e);
              }}
              sx={{
                cursor: 'pointer',
                p: '10px 0px 10px 24px',
                textTransform: 'capitalize'
              }}
            >
              <TypographyMontserrat500
                noWrap
                sx={{ fontSize: '14px', lineHeight: 1 }}
              >
                {item.name}
              </TypographyMontserrat500>
            </ModalItemWorking>
          ))}
        </Stack>
      </Popover>
      <EditRoleModal
        value={item.name}
        roleId={item.id}
        open={openModal}
        setOpen={setOpenModal}
      />
    </Box>
  );
};
