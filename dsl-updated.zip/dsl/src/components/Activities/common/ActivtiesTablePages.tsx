import { Activitie } from '@/src/store/counter/activitiesSlice';
import {
  TableWrapperBox,
  TableStyled,
  TableRowStyled,
  TableCellStyled,
  TypographyMontserrat500
} from '@/src/styles/muiStyledGlobal';
import { TableContainer, TableHead, TableBody } from '@mui/material';

export const ActivitiesTablePages = ({
  dataPage
}: {
  dataPage: Activitie[];
}) => {
  return (
    <TableWrapperBox>
      <TableContainer>
        <TableStyled>
          <TableHead>
            <TableRowStyled>
              <TableCellStyled
                sx={{
                  pl: '34px',
                  width: '20%'
                }}
              >
                Name
              </TableCellStyled>
              <TableCellStyled
                sx={{
                  width: '80%'
                }}
                align='center'
              >
                Date
              </TableCellStyled>
            </TableRowStyled>
          </TableHead>
          <TableBody>
            <TypographyMontserrat500>in development</TypographyMontserrat500>
          </TableBody>
        </TableStyled>
      </TableContainer>
    </TableWrapperBox>
  );
};
