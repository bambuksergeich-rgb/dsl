import { formatedDate, formatedTime } from '@/src/helpers/formatedDate';
import { useSearchParams } from 'next/navigation';
import { SxProps } from '@mui/material';
import UniversalTable from "@/src/components/AllTables/UniversalTable";

const columns = [
  { id: 'entityName', label: 'Name', minWidth: 170 },
  { id: 'entity', label: 'Type', minWidth: 100, align: 'center' as const },
  { id: 'createdTimestamp', label: 'Date', minWidth: 170, align: 'center' as const, format: (value: any) => formatedDate(value) },
  { id: 'createdTimestamp', label: 'Time', minWidth: 170, align: 'center' as const, format: (value: any) => formatedTime(value) },
  { id: 'createdByName', label: 'Employee', minWidth: 170, align: 'center' as const },
  { id: 'action', label: 'Action', minWidth: 170, align: 'center' as const },
];

const rows = [
  // Ваши данные здесь
];

export const ActivitiesTableAll = ({ isAdmin, sx, dataPage }: { dataPage: any[]; isAdmin: boolean; sx?: SxProps }) => {
  const depParams = useSearchParams();
  const depId = depParams.get('departmentId');

  const preparedRows = dataPage?.length ? dataPage?.map(item => ({
    ...item,
    depId: depId,
  })) : []

  return (
    <UniversalTable columns={isAdmin ? columns : columns.filter(col => col.id !== 'createdByName')} rows={preparedRows} rowKey="entityId" sx={sx} />
  );
};
