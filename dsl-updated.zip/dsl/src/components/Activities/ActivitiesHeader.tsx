'use client';

import {TypographyMontserrat500} from '@/src/styles/muiStyledGlobal';
import {Popover, IconButton, SxProps} from '@mui/material';
import {Stack} from '@mui/system';
import {useState} from 'react';
import {ActivitiesFilterPopover} from './ActivitiesFilterPopover';
import {ArrowUpIcon} from '@/public/icons/ArrowUp.icon';
import {FilterIcon} from '@/public/icons/Filter.icon';
import {ActivatesButtonList} from './ActivatesButtonList';

interface ActivitiesHeaderProps {
  name: string;
  filter: string;
  isAllActivities: boolean;
  showTitle?: boolean;
  stackSX?: SxProps;
  componentList: string[];
  setFilter: React.Dispatch<React.SetStateAction<string>>;
  type: string;
  setType: React.Dispatch<React.SetStateAction<string>>;
  action: string;
  setAction: React.Dispatch<React.SetStateAction<string>>;
  employee: string;
  setEmployee: React.Dispatch<React.SetStateAction<string>>;
  fromDate: string;
  setFromDate: React.Dispatch<React.SetStateAction<string>>;
  toDate: string;
  setToDate: React.Dispatch<React.SetStateAction<string>>;
  employeeId: string;
  setEmployeeId: React.Dispatch<React.SetStateAction<string>>;
  page: number;
  setPage: React.Dispatch<React.SetStateAction<number>>;
}

export const ActivitiesHeader = ({
                                   isAllActivities,
                                   name,
                                   filter,
                                   setFilter,
                                   componentList,
                                   showTitle = true,
                                   type,
                                   setType,
                                   action,
                                   setAction,
                                   employee,
                                   stackSX,
                                   setEmployee,
                                   fromDate,
                                   setFromDate,
                                   toDate,
                                   setToDate,
                                   employeeId,
                                   setEmployeeId,
                                   page,
                                   setPage
                                 }: ActivitiesHeaderProps) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popper' : undefined;
  return (
    <Stack
      sx={stackSX}
      direction={'row'}
      justifyContent={'space-between'}
    >
      {showTitle ? <Stack>
        <TypographyMontserrat500 sx={{fontSize: '32px'}}>
          {isAllActivities ? 'All Activities' : `${name} Activities`}
        </TypographyMontserrat500>
        <TypographyMontserrat500
          sx={{
            fontSize: '16px',
            color: '#D3D6E7',
            textTransform: 'capitalize'
          }}
        >
          {filter === 'All' || filter === 'pages'
            ? `${filter} `
            : `${filter} Activities`}
        </TypographyMontserrat500>
      </Stack> : null}
      <Stack
        direction={'row'}
        gap={'24px'}
      >
        <IconButton
          onClick={(e) => handleClick(e)}
          disableTouchRipple
          sx={{
            width: '80px',
            height: '44px',
            borderRadius: '4px',
            backgroundColor: '#4170FF',
            '&:hover': {
              backgroundColor: '#547FFF'
            },
            '&:active': {
              backgroundColor: '#6188FF'
            },
            gap: '8px'
          }}
        >
          <FilterIcon/>
          <ArrowUpIcon/>
        </IconButton>
        <Popover
          id={id}
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left'
          }}
          PaperProps={{
            sx: {
              backgroundColor: 'transparent'
            }
          }}
        >
          <ActivitiesFilterPopover
            closePopover={handleClose}
            filter={filter}
            isAllActivities={isAllActivities}
            type={type}
            setType={setType}
            action={action}
            setAction={setAction}
            employee={employee}
            setEmployee={setEmployee}
            fromDate={fromDate}
            setFromDate={setFromDate}
            toDate={toDate}
            setToDate={setToDate}
            employeeId={employeeId}
            setEmployeeId={setEmployeeId}
            page={page}
            setPage={setPage}
            setFilter={setFilter}
          />
        </Popover>
      </Stack>
    </Stack>
  );
};
