'use client';

import { DataCalendar } from '@/public/icons/DataCalendar.icon';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';
import { Button, Popover } from '@mui/material';
import { DateCalendar } from '@mui/x-date-pickers';
import dayjs, { Dayjs } from 'dayjs';
import { useEffect, useState } from 'react';

interface ActivitiesCalendarProps {
  buttonName: string;
  setDate: React.Dispatch<React.SetStateAction<string>>;
  date: string;
}

export const ActivitiesCalendar = ({
  buttonName,
  setDate,
  date
}: ActivitiesCalendarProps) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const currentTime = dayjs();
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popper' : undefined;

  const [value, setValue] = useState<Dayjs | null>(null);
  useEffect(() => {
    if (value) {
      if (buttonName === 'Date to') {
        const newValue = value.hour(23).minute(59).second(59);
        setDate(newValue?.toISOString());
        return;
      }
      setDate(value?.toISOString());
    }
  }, [value]);
  return (
    <>
      <Button
        onClick={handleClick}
        sx={{
          border: '1px solid rgba(255, 255, 255, 0.15)',
          width: '219px',
          height: '36px',
          display: 'flex',
          justifyContent: 'space-between',
          textTransform: 'capitalize',
          background: 'rgba(16, 22, 28, 0.50))'
        }}
      >
        <TypographyMontserrat500 sx={{ fontSize: '12px' }}>
          {date ? dayjs(date).format('DD.MM.YYYY') : buttonName}
        </TypographyMontserrat500>
        <DataCalendar />
      </Button>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left'
        }}
        PaperProps={{
          sx: {
            backgroundColor: 'transparent'
          }
        }}
      >
        <DateCalendar
          sx={{
            color: '#FFF',
            background: 'rgba(16, 22, 28, 1)',
            width: '356px',
            height: '335px',
            '& div': {
              overflow: 'hidden'
            },
            '& button': {
              color: '#FFF'
            },
            '& button:hover, & .Mui-selected': {
              borderRadius: '10px'
            },
            '& MuiPickersDay-today': {
              borderRadius: '0'
            },
            '&.MuiDayCalendar-weekDayLabel ': {
              fontSize: '12px'
            },
            '& .MuiPickersDay-dayWithMargin, & span ': {
              color: '#FFF',
              width: '44px',
              height: '44px'
            },
            '& .MuiPickersDay-dayWithMargin': {
              fontSize: '16px'
            }
          }}
          slotProps={{
            day: () =>
              ({
                disableTouchRipple: true,
                sx: {
                  borderRadius: '10px'
                }
              }) as any,
            calendarHeader: () =>
              ({
                sx: {
                  '& span': {
                    display: 'none'
                  }
                }
              }) as any
          }}
          value={value}
          onChange={(e) => {
            setValue(e);
            handleClose();
          }}
        />
      </Popover>
    </>
  );
};
