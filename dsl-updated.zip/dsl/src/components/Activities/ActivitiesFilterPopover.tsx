'use client';

import { CrossIcon } from '@/public/icons/Cross.icon';
import { SimpleMUIButton } from '@/src/styles/muiButtonStyles';
import { SelectChangeEvent } from '@mui/material';
import { Box, Stack } from '@mui/system';
import { ActivitiesCalendar } from './ActivitiesCalendar';
import { ActivitiesMenu } from './ActivitiesMenu';
import {
  BigLightBlueButton,
  TypographyMontserrat500,
  TypographyMontserrat600
} from '@/src/styles/muiStyledGlobal';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { ActivitiesMenuEmployee } from './ActivitiesMenuEmployee';
import { store } from '@/src/store/store';
import { getActivities } from '@/src/store/actions/getActivities';

export const searchProps = {
  width: '450px',
  height: '34px',
  background: 'rgba(255, 255, 255, 0.15)',
  borderRadius: '5px',
  color: ' #D3D6E7',
  fontFamily: 'Montserrat',
  fontSize: '14px',
  fontStyle: 'normal',
  fontWeight: '500',
  mt: '22px',
  '& input::placeholder': {
    color: ' #D3D6E7',
    fontFamily: 'Montserrat',
    fontSize: '14px',
    fontStyle: 'normal',
    fontWeight: '500',
    lineHeight: '8px'
  },
  '& input': {
    color: '#D3D6E7'
  }
};

interface ActivitiesFilterPopoverProps {
  filter: string;
  isAllActivities: boolean;
  closePopover: () => void;
  type: string;
  setType: React.Dispatch<React.SetStateAction<string>>;
  action: string;
  setAction: React.Dispatch<React.SetStateAction<string>>;
  employee: string;
  setEmployee: React.Dispatch<React.SetStateAction<string>>;
  fromDate: string;
  setFromDate: React.Dispatch<React.SetStateAction<string>>;
  toDate: string;
  setToDate: React.Dispatch<React.SetStateAction<string>>;
  employeeId: string;
  setEmployeeId: React.Dispatch<React.SetStateAction<string>>;
  page: number;
  setPage: React.Dispatch<React.SetStateAction<number>>;
  setFilter: React.Dispatch<React.SetStateAction<string>>;
}

export const ActivitiesFilterPopover = ({
  filter,
  isAllActivities,
  closePopover,
  type,
  setType,
  action,
  setAction,
  employee,
  setEmployee,
  fromDate,
  setFromDate,
  toDate,
  setToDate,
  employeeId,
  setEmployeeId,
  page,
  setPage,
  setFilter
}: ActivitiesFilterPopoverProps) => {
  const activityMetadata = useSelector(
    (state: State) => state.activityMetadata
  );

  const users = useSelector((state: State) => state.users);

  const handleChangeType = (event: SelectChangeEvent) => {
    setType(event.target.value as string);
  };
  const handleChangeAction = (event: SelectChangeEvent) => {
    setAction(event.target.value as string);
  };
  const handleChangeEmployee = (event: SelectChangeEvent) => {
    setEmployee(event.target.value as string);
  };
  return (
    <Stack
      sx={{
        padding: '24px',
        border: '1px solid rgba(255, 255, 255, 0.15)',
        background: 'linear-gradient(72deg, #0A0F18 0%, #373B44 100%)',
        borderRadius: '12px',
        width: '450px'
      }}
      justifyContent={'center'}
      alignItems={'center'}
    >
      <Stack sx={{ width: '100%' }}>
        <Stack
          direction={'row'}
          justifyContent={'space-between'}
        >
          <TypographyMontserrat600>Filter</TypographyMontserrat600>
          <SimpleMUIButton
            isicon
            verysmall
            onClick={closePopover}
          >
            <CrossIcon />
          </SimpleMUIButton>
        </Stack>
        <Stack
          direction={'row'}
          gap={'14px'}
          sx={{ mt: '24px' }}
        >
          <ActivitiesCalendar
            setDate={setFromDate}
            buttonName='Date from'
            date={fromDate}
          />
          <ActivitiesCalendar
            setDate={setToDate}
            buttonName='Date to'
            date={toDate}
          />
        </Stack>
        <Stack
          direction={'row'}
          justifyContent={'space-between'}
          flexWrap={'wrap'}
          gap='10px'
          paddingTop='10px'
        >
          <Box>
            <ActivitiesMenu
              selected={action}
              handleChange={handleChangeAction}
              menuItem={['ALL', ...activityMetadata.actions]}
              label='By action'
            />
          </Box>
          {isAllActivities && (
            <Box>
              <ActivitiesMenuEmployee
                selected={employee}
                handleChange={handleChangeEmployee}
                menuItem={users}
                label='By emplyee'
                setEmployeeId={setEmployeeId}
              />
            </Box>
          )}
          <Box>
            <ActivitiesMenu
              selected={type}
              handleChange={handleChangeType}
              menuItem={['ALL', ...activityMetadata.entityTypes]}
              label='By type'
            />
          </Box>
        </Stack>
        <Stack
          direction={'row'}
          sx={{ width: '100%', paddingTop: '24px', justifyContent: 'end' }}
        >
          <BigLightBlueButton
            disableTouchRipple
            onClick={() => {
              store.dispatch(
                getActivities(
                  page,
                  isAllActivities,
                  type,
                  action,
                  employeeId,
                  fromDate,
                  toDate,
                  setPage
                )
              );
              closePopover();
              setFilter(type);
            }}
          >
            <TypographyMontserrat500 fontSize='16px'>
              Apply
            </TypographyMontserrat500>
          </BigLightBlueButton>
        </Stack>
      </Stack>
    </Stack>
  );
};
