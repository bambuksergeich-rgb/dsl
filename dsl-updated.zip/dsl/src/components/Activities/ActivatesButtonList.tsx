import { Popover, Stack } from '@mui/material';
import { useState } from 'react';
import { SimpleMUIButton } from '@/src/styles/muiButtonStyles';
import { ModalItemWorking } from '../AllModals/ProfileModal/style';
import { ThreeDots } from '@/public/icons/ThreeDots';
import { TypographyMontserrat500 } from '@/src/styles/muiStyledGlobal';

interface ActivatesButtonListProps {
  setFilter: (value: string) => void;
  componentList: string[];
  filter: string;
}

export const ActivatesButtonList = ({
  setFilter,
  componentList,
  filter
}: ActivatesButtonListProps) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popper' : undefined;
  return (
    <>
      <SimpleMUIButton
        isicon
        onClick={handleClick}
      >
        <ThreeDots />
      </SimpleMUIButton>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right'
        }}
        PaperProps={{
          sx: {
            backgroundColor: 'transparent'
          }
        }}
      >
        <Stack
          flexDirection={'column'}
          sx={{
            width: '278px',
            padding: '12px 0',
            borderRadius: '10px',
            backgroundColor: 'rgba(16, 22, 28)',
            border: '1px solid rgba(255, 255, 255, 0.15)'
          }}
        >
          {componentList.map((item, index) => (
            <ModalItemWorking
              selected={filter === item}
              key={index}
              onClick={(e) => {
                setFilter(item);
                handleClick(e);
              }}
              sx={{
                cursor: 'pointer',
                p: '10px 0px 10px 24px',
                textTransform: 'capitalize'
              }}
            >
              <TypographyMontserrat500
                noWrap
                sx={{ fontSize: '14px', lineHeight: 1 }}
              >
                {item}
              </TypographyMontserrat500>
            </ModalItemWorking>
          ))}
        </Stack>
      </Popover>
    </>
  );
};
