import OptionsOpenIcon from '@/public/icons/scriptEditor/OptionsOpen.icon';
import { UsersData } from '@/src/store/counter/usersSlice';
import { TypographyMontserrat600 } from '@/src/styles/muiStyledGlobal';

import {
  FormControl,
  Select,
  MenuItem,
  SelectChangeEvent,
  InputLabel
} from '@mui/material';
import { Box } from '@mui/system';
import { useRef, useState } from 'react';
const MenuProps = {
  PaperProps: {
    style: {
      background: '#393D45'
    }
  }
};

const selectStyle = {
  background: 'rgba(16, 22, 28, 0.40)',
  width: '220px',
  color: '#FFF',
  fontFamily: 'Montserrat',
  fontSize: '14px',
  fontWeight: '500',
  lineHeight: '35px',
  borderRadius: '6px',
  pl: '12px',
  height: '34px'
};

const menuItemStyle = {
  display: 'flex',
  height: '30px',
  padding: '11px 0px 12px 24px',
  fontFamily: 'Montserrat',
  fontSize: '14px',
  fontWeight: '500',
  color: '#FFF',

  lineHeight: '3',
  '&.Mui-selected:hover': {
    background: '#2A2B6B'
  },
  '&:hover, &.Mui-selected': {
    background: '#2A2B6B',
    backdropFilter: 'blur(2px)'
  },
  '&:hover::before, &.Mui-selected::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    width: '8px',
    height: '100%',
    background: '#3D3AB8'
  }
};

interface ActivitiesMenuProps {
  selected: string;
  menuItem: UsersData;
  label: string;
  handleChange: (event: SelectChangeEvent) => void;
  setEmployeeId: React.Dispatch<React.SetStateAction<string>>;
}

export const ActivitiesMenuEmployee = (props: ActivitiesMenuProps) => {
  const { selected, label, menuItem, handleChange, setEmployeeId } = props;
  const selectRef = useRef<HTMLSelectElement>(null);
  const [open, setOpen] = useState(false);
  const handleLabelClick = () => {
    if (selectRef.current) {
      selectRef.current.click();
    }
  };
  const handleClick = (event: any) => {
    if (!event.target.className.includes('MuiModal-backdrop')) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  };
  return (
    <FormControl
      variant='standard'
      fullWidth
      sx={{ position: 'relative' }}
    >
      <Box
        sx={{
          position: 'absolute',
          right: '10px',
          top: '20px',
          zIndex: 10,
          cursor: 'pointer'
        }}
        onClick={handleLabelClick}
      >
        <OptionsOpenIcon />
      </Box>
      <InputLabel
        htmlFor='demo-simple-select'
        sx={{ zIndex: 10, cursor: 'pointer' }}
      >
        <TypographyMontserrat600
          sx={{ fontSize: '12px', ml: '10px', mt: '5px', color: '#FFF' }}
          onClick={handleLabelClick}
        >
          {label}
        </TypographyMontserrat600>
      </InputLabel>

      <Select
        id='demo-simple-select'
        value={selected}
        onChange={(e) => {
          handleChange(e);
          setOpen(false);
        }}
        IconComponent={() => null}
        sx={selectStyle}
        MenuProps={{ ...MenuProps, onClick: () => setOpen(false) }}
        ref={selectRef}
        onClick={handleClick}
        open={open}
        disableUnderline
      >
        {['ALL', ...menuItem.content].map((item, index) => (
          <MenuItem
            value={
              typeof item === 'string'
                ? 'ALL'
                : `${item.firstName} ${item.lastName}`
            }
            key={index}
            sx={menuItemStyle}
            onClick={(e) => {
              if (typeof item === 'string') {
                setEmployeeId('ALL');
                e.stopPropagation();
                return;
              }
              setEmployeeId(item.id);
              e.stopPropagation();
            }}
            disableTouchRipple
          >
            {typeof item === 'string'
              ? 'ALL'
              : `${item.firstName} ${item.lastName}`}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};
