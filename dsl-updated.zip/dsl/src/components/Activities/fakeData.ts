
export const widgetFakeData = [
    {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in ',
        path: '/404'
    },
    {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
   { name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
    {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
    {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
    {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
    {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
    {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
    {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    },
       {name: 'Widget21',
        date: '12/09/2023',
        action: 'create in script',
        blueAction: 'create in script',
        path: '/404'
    }
]


export const storageFakeData = [
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
   { name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'create in script',
        path: '/404'
    }
]

export const scriptFakeData = [
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
   { name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
    {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    },
       {name: 'Table 1',
        date: '12/09/2023',
        action: 'Run',
        path: '/404'
    }
]

export const pagesFakeData = [
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },

    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
    {
        name: 'Dashboard',
        date: '12/09/2023 15:45'
    },
]

export const allFakeData = [{
    name: 'Script 1',
    type: 'Script',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Dashboard 1',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Widget 1',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Widget  2',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Dashboard 2',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Script 3',
    type: 'Component',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Widget 1',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Dashboard 3',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Script 1',
    type: 'Script',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Dashboard 1',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Widget 1',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Widget  2',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Dashboard 2',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Script 3',
    type: 'Component',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Widget 1',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Dashboard 3',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Script 1',
    type: 'Script',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Dashboard 1',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Widget 1',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Widget  2',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Dashboard 2',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Script 3',
    type: 'Component',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Widget 1',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Dashboard 3',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Script 1',
    type: 'Script',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Dashboard 1',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Widget 1',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Widget  2',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Dashboard 2',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Script 3',
    type: 'Component',
    date: '12/09/2023',
    action: 'change add_row',
},
{
    name: 'Widget 1',
    type: 'Widget',
    date: '12/09/2023',
    action: 'change add_row',
},{
    name: 'Dashboard 3',
    type: 'Dashboard',
    date: '12/09/2023',
    action: 'change add_row',
},]