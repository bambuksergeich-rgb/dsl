"use client";

import { StyledBackdrop } from "@/public/style";
import {
  TypographyMontserrat500,
  TypographyMontserrat600,
} from "@/src/styles/muiStyledGlobal";
import { TextFieldConfCustom } from "@/src/styles/muiEditorStyles";
import {
  BigBlueButton,
  BigGreyButton,
  ModaLBox,
} from "@/src/styles/muiStyledGlobal";
import { Box, Modal, Stack } from "@mui/material";
import { ChangeEvent, useEffect, useState } from "react";
import { store } from "@/src/store/store";
import { createRole } from "@/src/store/actions/createRole";
import { useSearchParams } from "next/navigation";

export const CreateRoleModal = ({
  open,
  handleClose,
}: {
  open: boolean;
  handleClose: () => void;
}) => {
  const [roleName, setRoleName] = useState<string>("");
  const [departmentId, setDepartmentId] = useState<string>("");
  const [checkRole, setCheckRole] = useState(false);
  const searchParams = useSearchParams();

  useEffect(() => {
    const department = searchParams.get("departmentId");
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  const handleChangeName = (e: ChangeEvent<HTMLInputElement>) => {
    setRoleName(e.target.value);
  };

  return (
    <Modal open={open} onClose={handleClose} BackdropComponent={StyledBackdrop}>
      <ModaLBox sx={{ width: "500px" }}>
        <Stack
          direction={"row"}
          sx={{
            justifyContent: "start",
            alignItems: "center",
            width: "100%",
          }}
        >
          <TypographyMontserrat600
            sx={{
              fontSize: "16px",
            }}
          >
            Create a new role
          </TypographyMontserrat600>
        </Stack>
        <Stack
          flexDirection={"column"}
          sx={{
            width: "100%",
            borderRadius: "6px",
            gap: "6px",
            margin: "42px 0 40px 0",
          }}
        >
          <TypographyMontserrat500 fontSize={"14px"}>
            Role name
          </TypographyMontserrat500>
          <Box sx={{ position: "relative" }}>
            <TextFieldConfCustom
              placeholder="Enter role name"
              InputLabelProps={{ shrink: false, style: { height: "34px" } }}
              variant="outlined"
              onChange={handleChangeName}
              inputProps={{ style: { height: "34px", padding: "0 14px" } }}
              sx={
                checkRole
                  ? {
                      "& fieldset": {
                        borderColor: "#BB382F !important",
                      },
                      "&:hover fieldset": {
                        borderColor: "#BB382F !important",
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "#BB382F !important",
                      },
                    }
                  : null
              }
            />
            {checkRole && (
              <TypographyMontserrat600
                sx={{
                  fontSize: "12px",
                  color: "#BA584F",
                  position: "absolute",
                  bottom: "-23px",
                  left: 0,
                }}
              >
                Data entered incorrectly
              </TypographyMontserrat600>
            )}
          </Box>
        </Stack>

        <Stack
          direction={"row"}
          sx={{
            justifyContent: "end",
            width: "100%",
            gap: "14px",
          }}
        >
          <BigGreyButton onClick={handleClose} disableTouchRipple={true}>
            Back
          </BigGreyButton>
          <BigBlueButton
            onClick={() => {
              if (roleName.trim().length > 0 && departmentId) {
                store.dispatch(createRole(roleName.trim(), departmentId));
                handleClose();
              }

              if (roleName.trim().length < 2) {
                setCheckRole(true);
              }
            }}
            disableTouchRipple={true}
          >
            Save
          </BigBlueButton>
        </Stack>
      </ModaLBox>
    </Modal>
  );
};
