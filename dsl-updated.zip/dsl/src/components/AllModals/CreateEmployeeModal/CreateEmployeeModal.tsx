'use client';

import { ArrowUpIcon } from '@/public/icons/ArrowUp.icon';
import { StyledBackdrop } from '@/public/style';
import {
  TypographyMontserrat500,
  TypographyMontserrat600
} from '@/src/styles/muiStyledGlobal';

import {
  BigBlueButton,
  BigGreyButton,
  ModaLBox
} from '@/src/styles/muiStyledGlobal';
import { Button, Modal, Popover, Stack } from '@mui/material';
import { useSelector } from 'react-redux';
import { RolesData } from '@/src/store/counter/rolesSlice';
import { State } from '@/src/store/initialState';
import { useState } from 'react';
import { invitationUser } from '@/src/requests/invitationUser';
import { telephoneMask } from '@/src/helpers/telephoneMask';
import { CustomInput } from '../../common/CustomInput/CustomInput';
import { ModalItemWorking } from '../ProfileModal/style';

export const CreateEmployeeModal = ({
  open,
  handleClose
}: {
  open: boolean;
  handleClose: () => void;
}): JSX.Element => {
  const roles: RolesData = useSelector((state: State) => state.roles);

  const [selectRole, setSelectRole] = useState<string>('');
  const [selectRoleId, setSelectRoleId] = useState<string>('');

  const [firstName, setFirstName] = useState<string>('');
  const [lastName, setLastName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');

  const [errorFirstName, setErrorFirstName] = useState(false);
  const [errorLastName, setErrorLastName] = useState(false);
  const [errorEmail, setErrorEmail] = useState(false);
  const [errorPhone, setErrorPhone] = useState(false);
  const [errorRole, setErrorRole] = useState(false);
  const emailRegexp =
    /^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/iu;

  const handleFirstName = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFirstName(e.target.value);
    setErrorFirstName(false);
  };

  const handleLastName = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLastName(e.target.value);
    setErrorLastName(false);
  };

  const handleEmail = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    setErrorEmail(false);
  };

  const handlePhone = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhone(telephoneMask(e));
    setErrorPhone(false);
  };
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };
  const handleClosePopover = () => {
    setAnchorEl(null);
  };

  const openPopover = Boolean(anchorEl);
  const id = open ? 'simple-popper' : undefined;

  return (
    <Modal
      open={open}
      onClose={handleClose}
      BackdropComponent={StyledBackdrop}
    >
      <ModaLBox sx={{ width: '500px' }}>
        <Stack
          direction={'row'}
          sx={{
            justifyContent: 'start',
            alignItems: 'center',
            width: '100%'
          }}
        >
          <TypographyMontserrat600
            sx={{
              fontSize: '16px'
            }}
          >
            Invite a new employee
          </TypographyMontserrat600>
        </Stack>
        <Stack
          direction={'column'}
          sx={{ gap: '24px', width: '100%', margin: '42px 0 40px 0' }}
        >
          <CustomInput
            title={'Name*'}
            placeholder={'Enter name'}
            value={firstName}
            handleChange={handleFirstName}
            error={errorFirstName}
          />
          <CustomInput
            title={'Last name*'}
            placeholder={'Enter last name'}
            value={lastName}
            handleChange={handleLastName}
            error={errorLastName}
          />
          <CustomInput
            title={'Email*'}
            placeholder={'Enter email'}
            value={email}
            handleChange={handleEmail}
            error={errorEmail}
          />
          <CustomInput
            title={'Phone number'}
            placeholder={'Enter phone number'}
            value={phone}
            handleChange={handlePhone}
            error={errorPhone}
          />

          <Stack
            flexDirection={'column'}
            sx={{
              width: '100%',
              borderRadius: '6px',
              gap: '6px',
              position: 'relative'
            }}
          >
            <TypographyMontserrat500 fontSize={'14px'}>
              Role*
            </TypographyMontserrat500>
            <Button
              disableTouchRipple={true}
              sx={{
                flexDirection: 'row',
                width: '100%',
                height: '34px',
                padding: '0 16px',
                boxSizing: 'border-box',
                alignItems: 'center',
                justifyContent: 'space-between',
                borderRadius: '6px',
                border: errorRole ? '1px solid red' : '',
                backgroundColor: '#FFFFFF30',
                textTransform: 'initial',
                '&:active': {
                  backgroundColor: '#FFFFFF30'
                },
                '&:hover': {
                  backgroundColor: '#FFFFFF30'
                },

                borderColor: '#BB382F !important',
                '&:hover fieldset': {
                  borderColor: '#BB382F !important'
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#BB382F !important'
                }
              }}
              onClick={handleClick}
            >
              <TypographyMontserrat500
                sx={{ color: '#FFFFFF70', fontSize: '13px' }}
              >
                {selectRole ? selectRole : 'Choose role'}
              </TypographyMontserrat500>
              <ArrowUpIcon />
            </Button>
            <Popover
              id={id}
              open={openPopover}
              anchorEl={anchorEl}
              onClose={handleClosePopover}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left'
              }}
              PaperProps={{
                sx: {
                  backgroundColor: 'transparent'
                }
              }}
            >
              <Stack
                flexDirection={'column'}
                sx={{
                  width: '500px',
                  height: '250px',
                  padding: '12px 0',
                  borderRadius: '10px',
                  backgroundColor: 'rgba(16, 22, 28)',
                  border: '1px solid rgba(255, 255, 255, 0.15)',
                  overflow: 'auto',

                  '&::-webkit-scrollbar': {
                    width: '4px'
                  },
                  '&::-webkit-scrollbar-track': {
                    background: 'transparent'
                  },
                  '&::-webkit-scrollbar-thumb': {
                    backgroundColor: '#D9D9D9',
                    borderRadius: '8px'
                  },
                  scrollbarWidth: 'thin',
                  scrollbarColor: 'rgba(0,0,0,.1) transparent'
                }}
              >
                {roles.content?.map((role) => (
                  <ModalItemWorking
                    selected={selectRoleId === role.id}
                    key={role.id}
                    onClick={(e) => {
                      setSelectRole(role.name);
                      setSelectRoleId(role.id);
                      setErrorRole(false);
                      handleClick(e);
                    }}
                    sx={{
                      cursor: 'pointer',
                      p: '10px 0px 10px 24px',
                      textTransform: 'capitalize'
                    }}
                  >
                    <TypographyMontserrat500
                      noWrap
                      sx={{ fontSize: '14px', lineHeight: 1 }}
                    >
                      {role.name}
                    </TypographyMontserrat500>
                  </ModalItemWorking>
                ))}
              </Stack>
            </Popover>
            {errorRole && (
              <TypographyMontserrat600
                sx={{
                  fontSize: '12px',
                  color: '#BA584F',
                  position: 'absolute',
                  bottom: '-23px',
                  left: 0
                }}
              >
                Data entered incorrectly
              </TypographyMontserrat600>
            )}
          </Stack>
        </Stack>
        <Stack
          direction={'row'}
          sx={{
            justifyContent: 'end',
            width: '100%',
            gap: '14px'
          }}
        >
          <BigGreyButton
            onClick={handleClose}
            disableTouchRipple={true}
          >
            Back
          </BigGreyButton>
          <BigBlueButton
            onClick={async () => {
              if (
                firstName.length > 2 &&
                lastName.length > 2 &&
                emailRegexp.test(email) &&
                selectRoleId
              ) {
                await invitationUser(
                  firstName,
                  lastName,
                  email,
                  phone,
                  selectRoleId
                );
                setFirstName('');
                setLastName('');
                setEmail('');
                setPhone('');
                handleClose();
              }

              if (firstName.length <= 2) {
                setErrorFirstName(true);
              }
              if (lastName.length <= 2) {
                setErrorLastName(true);
              }
              if (!emailRegexp.test(email)) {
                setErrorEmail(true);
              }
              if (!selectRoleId) {
                setErrorRole(true);
              }
            }}
            disableTouchRipple={true}
          >
            Save
          </BigBlueButton>
        </Stack>
      </ModaLBox>
    </Modal>
  );
};
