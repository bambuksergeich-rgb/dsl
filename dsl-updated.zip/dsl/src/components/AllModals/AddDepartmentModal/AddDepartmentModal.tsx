'use client';

import { CrossIcon } from '@/public/icons/Cross.icon';
import { UploadPhotoIcon } from '@/public/icons/UploadPhoto.icon';
import { StyledBackdrop } from '@/public/style';
import { createDepartment } from '@/src/store/actions/createDepartment';
import { store } from '@/src/store/store';
import { SimpleMUIButton } from '@/src/styles/muiButtonStyles';
import { TextFieldConfCustom } from '@/src/styles/muiEditorStyles';
import {
  GrayButton,
  TypographyMontserrat400,
  TypographyMontserrat500,
  TypographyMontserrat600
} from '@/src/styles/muiStyledGlobal';
import { Box, Button, Modal, Stack } from '@mui/material';
import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import backgroundImage from '../../../../public/images/dashedBorder.png';
import { addDepartmentLogo } from '@/src/requests/addDepartmentLogo';
import { useSelector } from 'react-redux';
import { State } from '@/src/store/initialState';
import { editDepartmentAction } from '@/src/store/actions/editDepartmentAction';
import { SubmitHandler, useForm } from 'react-hook-form';

const AddDepartmentModal = ({
  title,
  openModal,
  handleCloseModal,
  departmnetDraftId,
  departmentId
}: {
  title: string;
  openModal: boolean;
  handleCloseModal: () => void;
  departmnetDraftId: string | null;
  departmentId?: string;
}) => {
  const [name, setName] = useState<string>('');
  const [checkName, setCheckName] = useState<boolean>(false);

  const handleChangeName = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.value.length === 1) {
      setName(e.target.value.trim());
      return;
    }
    setName(e.target.value);
    setCheckName(false);
  };

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [avatar, setAvatar] = useState<File | null>(null);
  const [logoUrl, setLogoUrl] = useState<string>('');

  const imageBackground = useMemo(() => {
    return avatar ? `url(${URL.createObjectURL(avatar)})` : 'none';
  }, [avatar]);

  const handleFileInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const file = event.target.files[0];
      setAvatar(file);
    }
  };

  const departments = useSelector((state: State) => state.departments);

  useEffect(() => {
    if (departments && departmentId) {
      const foundDepartment = departments.find(
        (department) => department.id === departmentId
      );

      if (foundDepartment) {
        setName(foundDepartment.name);
        if (foundDepartment.logoUrl) {
          setLogoUrl(foundDepartment.logoUrl);
        } else {
          setLogoUrl('');
        }
      }
    }
  }, [departments, departmentId]);
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm<{ name: string }>();

  const onSubmit: SubmitHandler<{ name: string }> = (data) => console.log(data);

  return (
    <Modal
      open={openModal}
      onClose={handleCloseModal}
      BackdropComponent={StyledBackdrop}
    >
      <Stack
        alignItems={'center'}
        sx={{
          position: 'absolute' as 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '500px',
          padding: '24px',
          border: '1px solid rgba(255, 255, 255, 0.15)',
          background: 'linear-gradient(72deg, #0A0F18 0%, #373B44 100%)',
          borderRadius: '12px'
        }}
      >
        <Stack
          flexDirection={'column'}
          sx={{ width: '100%' }}
        >
          <Stack
            flexDirection={'row'}
            sx={{
              justifyContent: 'space-between',
              width: '100%',
              marginBottom: '26px'
            }}
          >
            <TypographyMontserrat600>{title}</TypographyMontserrat600>
            <SimpleMUIButton
              isicon
              verysmall
              onClick={() => {
                handleCloseModal();
              }}
            >
              <CrossIcon />
            </SimpleMUIButton>
          </Stack>
          <Stack
            flexDirection={'column'}
            gap={'12px'}
            sx={{
              width: '100%',
              alignItems: 'center',
              marginBottom: '24px'
            }}
          >
            <input
              type='file'
              accept='image/*'
              ref={fileInputRef}
              style={{ display: 'none' }}
              onChange={handleFileInputChange}
            />
            <Button
              disableTouchRipple={true}
              sx={{
                flexDirection: 'column',
                gap: '12px',
                width: '140px',
                height: '146px',
                padding: 0,
                textTransform: 'initial',
                backgroundColor: 'transparent',
                '&:acitve': {
                  backgroundColor: 'transparent'
                },
                '&:hover': {
                  backgroundColor: 'transparent'
                }
              }}
              onClick={() => {
                if (fileInputRef.current) {
                  fileInputRef.current.click();
                }
              }}
            >
              <TypographyMontserrat400 sx={{ fontSize: '14px' }}>
                Upload one file
              </TypographyMontserrat400>

              <Box>
                <Stack
                  flexDirection={'row'}
                  sx={{
                    width: '117px',
                    height: '117px',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundSize: 'cover',
                    backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'center',
                    borderRadius: '10px',
                    backgroundImage:
                      logoUrl && imageBackground === 'none'
                        ? `url(${logoUrl})`
                        : imageBackground !== 'none'
                          ? imageBackground
                          : `url(${backgroundImage.src})`
                  }}
                >
                  {imageBackground === 'none' && !logoUrl && (
                    <UploadPhotoIcon />
                  )}
                </Stack>
              </Box>
            </Button>
          </Stack>
          <Stack
            flexDirection={'column'}
            gap={'6px'}
            marginBottom={'24px'}
            sx={{
              position: 'relative'
            }}
          >
            <TypographyMontserrat500 fontSize={'14px'}>
              {'Department name'}
            </TypographyMontserrat500>
            <TextFieldConfCustom
              onChange={handleChangeName}
              placeholder='Enter department name'
              InputLabelProps={{ shrink: false, style: { height: '34px' } }}
              variant='outlined'
              value={name}
              inputProps={{ style: { height: '34px', padding: '0 14px' } }}
              sx={
                checkName
                  ? {
                      '& fieldset': {
                        borderColor: '#BB382F !important'
                      },
                      '&:hover fieldset': {
                        borderColor: '#BB382F !important'
                      },
                      '&.Mui-focused fieldset': {
                        borderColor: '#BB382F !important'
                      }
                    }
                  : null
              }
            />
            {checkName && (
              <TypographyMontserrat600
                sx={{
                  fontSize: '12px',
                  color: '#BA584F',
                  position: 'absolute',
                  bottom: '-23px',
                  left: 0
                }}
              >
                Data entered incorrectly
              </TypographyMontserrat600>
            )}
          </Stack>
          <Stack
            flexDirection={'row'}
            gap={'14px'}
            sx={{ width: '100%', justifyContent: 'end' }}
          >
            <GrayButton
              onClick={() => {
                handleCloseModal();
              }}
              sx={{ height: '44px', width: '140px', borderRadius: '6px' }}
            >
              <TypographyMontserrat500 fontSize='16px'>
                {'Back'}
              </TypographyMontserrat500>
            </GrayButton>
            <SimpleMUIButton
              sx={{ height: '44px', borderRadius: '6px' }}
              onClick={async () => {
                if (name.length >= 1) {
                  if (avatar && departmnetDraftId) {
                    if (departmentId) {
                      await addDepartmentLogo(
                        avatar,
                        departmnetDraftId,
                        departmentId
                      );
                    } else {
                      await addDepartmentLogo(avatar, departmnetDraftId);
                    }
                  }
                  if (departmentId) {
                    store.dispatch(
                      editDepartmentAction(name.trim(), departmnetDraftId)
                    );
                  } else {
                    store.dispatch(
                      createDepartment(name.trim(), departmnetDraftId)
                    );
                    setName('');
                  }

                  setAvatar(null);
                  handleCloseModal();
                }

                if (name.length < 1) {
                  setCheckName(true);
                }
              }}
            >
              <TypographyMontserrat500 fontSize='16px'>
                {'Save'}
              </TypographyMontserrat500>
            </SimpleMUIButton>
          </Stack>
        </Stack>
      </Stack>
    </Modal>
  );
};

export default AddDepartmentModal;
