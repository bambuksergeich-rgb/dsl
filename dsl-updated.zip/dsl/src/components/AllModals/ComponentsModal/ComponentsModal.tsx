import React, {useCallback, useMemo, useState} from 'react';
import {Component} from '@/src/store/counter/componentSlice';
import {Dashboard as DashboardType} from "@/src/store/counter/dashboardsSlice";
import {openSnackBarAction} from "@/src/store/actions/openSnackBar";
import {SnackType} from "@/src/store/counter/snackBarSlice";
import {dashboardActions, DashboardWidget} from "@/src/store/slices/dashboard.slice";
import {useBoolean, useCounter} from "usehooks-ts";
import {useParams} from "next/navigation";
import {widgetsAPI} from "@/src/store/api/widgetsAPI";
import {useAppDispatch, useAppSelector} from "@/src/hooks/typedAsyncThunk";
import DashboardModal from "@/src/components/AllModals/DashboardModal/DashboardModal";
import WidgetsModal from "@/src/components/AllModals/WidgetsModal/WidgetsModal";
import {TypographyMontserrat500, TypographyMontserrat600} from "@/src/styles/muiStyledGlobal";
import {SimpleMUIButton} from "@/src/styles/muiButtonStyles";
import {CrossIcon} from "@/public/icons/Cross.icon";
import {Stack} from "@mui/material";
import {appActions} from "@/src/store/slices/app.slice";
import UniversalTable from "@/src/components/AllTables/UniversalTable";
import {Button} from '../../UI/Button/Button';

const ComponentsModal = ({activeEl, count, increment}: {
  activeEl: any | null; count: number; increment: () => void
}) => {

  const dispatch = useAppDispatch();
  const {value: isOpenDashboard, toggle: toggleDashboard} = useBoolean(false);
  const {value: isOpenWidget, toggle: toggleWidget} = useBoolean(false);
  const params = useParams<{ id: string }>();
  const dashboardId = params?.id as string;
  const [addWidgetActions] = widgetsAPI.useAddWidgetActionsMutation();
  const [activeComponent, setActiveComponent] = useState<Component | null>(null);
  const {widgets, components} = useAppSelector((state) => state.dashboard);
  const [getWidgetComponents] = widgetsAPI.useGetWidgetComponentsMutation();

  const fetchComponents = async () => {
    setTimeout(async () => {
      getWidgetComponents({
        widgetId: activeEl?.widgetId || activeEl?.id,
        variant: activeEl?.widgetId ? 'widget_templates' : 'widgets',
      }).unwrap()
        .then(({content}) => {
          dispatch(dashboardActions.setComponents(content))
        })
    }, 300)
  }

  const columns = useMemo(() => {

    return [
      {id: 'name', label: 'Name', minWidth: 170},
      {
        id: 'actions', label: '', minWidth: 100, align: 'center' as const, render: (_: any, row: Component) => {

          const find = widgets.find((item) => item.id === row?.targetId)

          const findTarget = find && row?.action === 'POPUP_WIDGET';
          const findDashboard = row?.action === 'OPEN_DASHBOARD';

          if (findTarget) {
            return <div className="flex items-center gap-4 justify-end pr-6">
              <div
                className="border-[#596471] border rounded-[3px] h-[28px] px-1.5 flex items-center gap-2.5">
                <TypographyMontserrat500 fontSize={'16px'} color="white">
                  {find.name}
                </TypographyMontserrat500>
                <button>
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                       xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M3.66421 3.79485L3.72472 3.72475C3.94661 3.50285 4.29383 3.48269 4.53851 3.66423L4.60861 3.72475L10 9.11585L15.3914 3.72475C15.6355 3.48067 16.0312 3.48067 16.2752 3.72475C16.5193 3.96882 16.5193 4.36455 16.2752 4.60863L10.8842 10L16.2752 15.3914C16.4972 15.6133 16.5173 15.9605 16.3357 16.2052L16.2752 16.2753C16.0534 16.4972 15.7062 16.5174 15.4615 16.3358L15.3914 16.2753L10 10.8842L4.60861 16.2753C4.36453 16.5194 3.9688 16.5194 3.72472 16.2753C3.48065 16.0312 3.48065 15.6355 3.72472 15.3914L9.11583 10L3.72472 4.60863C3.50283 4.38674 3.48266 4.03952 3.66421 3.79485Z"
                      fill="white"/>
                  </svg>
                </button>
              </div>
            </div>
          }

          if (findDashboard) {
            return <div className="flex items-center gap-4 justify-end pr-6">
              <div
                className="border-[#596471] border rounded-[3px] h-[28px] px-1.5 flex items-center gap-2.5">
                <TypographyMontserrat500 fontSize={'16px'} color="white">
                  Dashboard
                </TypographyMontserrat500>
                <button>
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                       xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M3.66421 3.79485L3.72472 3.72475C3.94661 3.50285 4.29383 3.48269 4.53851 3.66423L4.60861 3.72475L10 9.11585L15.3914 3.72475C15.6355 3.48067 16.0312 3.48067 16.2752 3.72475C16.5193 3.96882 16.5193 4.36455 16.2752 4.60863L10.8842 10L16.2752 15.3914C16.4972 15.6133 16.5173 15.9605 16.3357 16.2052L16.2752 16.2753C16.0534 16.4972 15.7062 16.5174 15.4615 16.3358L15.3914 16.2753L10 10.8842L4.60861 16.2753C4.36453 16.5194 3.9688 16.5194 3.72472 16.2753C3.48065 16.0312 3.48065 15.6355 3.72472 15.3914L9.11583 10L3.72472 4.60863C3.50283 4.38674 3.48266 4.03952 3.66421 3.79485Z"
                      fill="white"/>
                  </svg>
                </button>
              </div>
            </div>
          }

          return <div className="flex items-center gap-4 justify-end pr-6">
            <Button type="button" onClick={() => onSelect(row, 'dashboard')} className="max-w-[155px] p-1.5">
              <TypographyMontserrat500 fontSize={'16px'} color="white">
                {'Add Dashboard'}
              </TypographyMontserrat500>
            </Button>
            <Button type="button" onClick={() => onSelect(row, 'popup')} className="max-w-[145px] p-1.5">
              <TypographyMontserrat500 fontSize={'16px'} color="white">
                {'Add Pop-Up'}
              </TypographyMontserrat500>
            </Button>
          </div>

        }
      },
    ]

  }, [count, components]);

  const onSelectDashboard = useCallback((dashboard: DashboardType) => {
    if (dashboard.id !== dashboardId && activeEl && activeComponent?.id) {
      addWidgetActions({
        targetId: dashboard.id,
        action: 'OPEN_DASHBOARD',
        widgetId: activeEl.id,
        componentId: activeComponent?.id
      });
      dispatch(openSnackBarAction(SnackType.success, 'Dashboard added to popup', true));
      toggleDashboard()
      fetchComponents()
    }
  }, [activeEl, dashboardId, dispatch, activeComponent, fetchComponents]);

  const onSelectWidget = useCallback((widget: DashboardWidget) => {

    if (activeEl && widget.id && activeComponent?.id) {
      addWidgetActions({
        targetId: widget.id,
        action: 'POPUP_WIDGET',
        widgetId: activeEl.id,
        componentId: activeComponent?.id
      });
      dispatch(openSnackBarAction(SnackType.success, 'Widget added to popup', true));
      fetchComponents()
    }
  }, [addWidgetActions, activeEl, dispatch, activeComponent, fetchComponents]);

  const close = () => {
    dispatch(appActions.clearModalContent());
  };

  const onSelect = (component: Component, type: 'dashboard' | 'popup') => {

    if (type === 'dashboard') {
      toggleDashboard()
    } else {
      toggleWidget()
    }
    setActiveComponent(component)
  }

  return (
    <div
      className="relative z-10 bg-custom-linear-gradient mx-auto p-6 rounded-xl border border-dsl-gray-800 max-w-[827px] w-full flex flex-col gap-[25px]">
      <Stack direction="row" justifyContent="space-between">
        <TypographyMontserrat600 fontSize={'16px'}>
          {'List of Components'}
        </TypographyMontserrat600>

        <SimpleMUIButton
          isicon
          verysmall
          onClick={close}
        >
          <CrossIcon/>
        </SimpleMUIButton>
      </Stack>
      <UniversalTable  columns={columns} rows={components} rowKey="id" sx={{
        pl: 0,
      }}/>
      {isOpenDashboard && (
        <DashboardModal openModal={true} onSelect={onSelectDashboard} handleCloseModal={toggleDashboard}/>
      )}
      {isOpenWidget && (
        <WidgetsModal openModal={true} onSelect={onSelectWidget} handleCloseModal={toggleWidget}/>
      )}
    </div>
  );
};

export default ComponentsModal;
