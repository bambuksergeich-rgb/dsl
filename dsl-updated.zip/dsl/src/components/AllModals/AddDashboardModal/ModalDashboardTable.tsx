'use client';

import { TextIcon } from '@/public/icons/Text.icon';
import {
  BlueLink,
  GridBox,
  IconButtonWithoutBackground,
  NumberBox,
  SmallIconButton,
  TableCellLeft,
  TableCellRight,
  TableCellStyled,
  TableRowStyled,
  TableStyled,
  TableWrapperBox,
  TypographyMontserrat500
} from '@/src/styles/muiStyledGlobal';
import { TableBody, TableContainer, TableHead } from '@mui/material';
import { DescriptionModal } from '../DescriptionModal/DescriptionModal';
import { useState } from 'react';
import WidgetConfigurationModal from '../WidgetConfigurationModal/WidgetConfigurationModal';
import { sanitizePath } from '@/src/helpers/basePrefix';
import { Dashboard } from '@/src/store/counter/dashboardsSlice';
import Link from 'next/link';

export const ModalDashboardTable = ({
  dataPage,
  departmentId
}: {
  departmentId: string;
  dataPage: Dashboard[];
}) => {
  const [openWidgetsModal, setOpenWidgetsModal] = useState<number | null>(null);
  const [openedDescriptionIndex, setOpenedDescriptionIndex] = useState<
    number | null
  >(null);

  const handleDescriptionOpen = (index: number) => {
    setOpenedDescriptionIndex(index);
  };

  const handleDescriptionClose = () => {
    setOpenedDescriptionIndex(null);
  };

  const handleWidgetsModalClose = () => {
    setOpenWidgetsModal(null);
  };

  return (
    <TableWrapperBox>
      <TableContainer>
        <TableStyled>
          <TableHead>
            <TableRowStyled sx={{ height: '44px' }}>
              <TableCellLeft
                align='left'
                sx={{
                  width: '500px',
                  padding: '0 40px'
                }}
              >
                <TypographyMontserrat500
                  sx={{ fontSize: '16px', color: 'white' }}
                >
                  {'Name'}
                </TypographyMontserrat500>
              </TableCellLeft>
              <TableCellStyled
                align='center'
                sx={{}}
              >
                <TypographyMontserrat500
                  sx={{ fontSize: '16px', color: 'white' }}
                >
                  {'Description'}
                </TypographyMontserrat500>
              </TableCellStyled>
              <TableCellRight
                sx={{
                  width: '250px'
                }}
                align='center'
              >
                <TypographyMontserrat500
                  sx={{ fontSize: '16px', color: 'white' }}
                >
                  {'Number of widgets'}
                </TypographyMontserrat500>
              </TableCellRight>
            </TableRowStyled>
          </TableHead>
          <TableBody>
            {dataPage?.map((row, index: number) => (
              <TableRowStyled
                key={index}
                sx={{ height: '64px' }}
              >
                <TableCellStyled
                  align='left'
                  sx={{ padding: '0 40px' }}
                >
                  {/* <BlueLink
                    href={sanitizePath(
                      `/viewing_dashboard_page/1?departmentId=${departmentId}`
                    )}
                  >
                    {row.name}
                  </BlueLink> */}
                  <Link
                    href={sanitizePath('/404')}
                    style={{ textDecoration: 'none' }}
                  >
                    <TypographyMontserrat500
                      sx={{ fontSize: '16px', width: '100%', color: '#4170FF' }}
                      noWrap
                    >
                      {row.name}
                    </TypographyMontserrat500>
                  </Link>
                </TableCellStyled>
                <TableCellStyled align='center'>
                  <SmallIconButton
                    disableTouchRipple={true}
                    onClick={() => {
                      handleDescriptionOpen(index);
                    }}
                  >
                    <TextIcon />
                  </SmallIconButton>
                  {openedDescriptionIndex === index && (
                    <DescriptionModal
                      title={row.description}
                      openDescriptionModal={true}
                      handleDescriptionModal={handleDescriptionClose}
                    />
                  )}
                </TableCellStyled>
                <TableCellStyled
                  align='center'
                  sx={{
                    padding: '0 40px'
                  }}
                >
                  <GridBox>
                    <NumberBox>
                      <IconButtonWithoutBackground
                        disableTouchRipple={true}
                        onClick={() => {
                          setOpenWidgetsModal(index);
                        }}
                      >
                        <TypographyMontserrat500 sx={{ fontSize: '16px' }}>
                          {row.widgetCount}
                        </TypographyMontserrat500>
                      </IconButtonWithoutBackground>
                    </NumberBox>
                  </GridBox>
                </TableCellStyled>
                {openWidgetsModal === index && (
                  <WidgetConfigurationModal
                    openModal={true}
                    handleCloseModal={handleWidgetsModalClose}
                  />
                )}
              </TableRowStyled>
            ))}
          </TableBody>
        </TableStyled>
      </TableContainer>
    </TableWrapperBox>
  );
};
