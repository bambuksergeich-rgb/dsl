'use client';

import { StyledBackdrop } from '@/public/style';
import {
  TypographyMontserrat500,
  TypographyMontserrat600
} from '@/src/styles/muiStyledGlobal';
import { TextFieldConfCustom } from '@/src/styles/muiEditorStyles';
import {
  BigBlueButton,
  BigGreyButton,
  ModaLBox
} from '@/src/styles/muiStyledGlobal';
import { Modal, Stack } from '@mui/material';
import { ChangeEvent, useEffect, useState } from 'react';
import { store } from '@/src/store/store';
import { useSearchParams } from 'next/navigation';
import { createGroupAction } from '@/src/store/actions/createGroupAction';

export const CreateGroupModal = ({
  open,
  groupType,
  handleClose
}: {
  open: boolean;
  groupType: string;
  handleClose: () => void;
}) => {
  const [groupName, setGroupName] = useState<string>('');
  const [departmentId, setDepartmentId] = useState<string>('');

  const searchParams = useSearchParams();

  useEffect(() => {
    const department = searchParams.get('departmentId');
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  const handleChangeName = (e: ChangeEvent<HTMLInputElement>) => {
    setGroupName(e.target.value);
  };

  return (
    <Modal
      open={open}
      onClose={handleClose}
      BackdropComponent={StyledBackdrop}
    >
      <ModaLBox sx={{ width: '500px' }}>
        <Stack
          direction={'row'}
          sx={{
            justifyContent: 'start',
            alignItems: 'center',
            width: '100%'
          }}
        >
          <TypographyMontserrat600
            sx={{
              fontSize: '16px'
            }}
          >
            Create a new group
          </TypographyMontserrat600>
        </Stack>
        <Stack
          flexDirection={'column'}
          sx={{
            width: '100%',
            borderRadius: '6px',
            gap: '6px',
            margin: '42px 0 40px 0'
          }}
        >
          <TypographyMontserrat500 fontSize={'14px'}>
            Group name
          </TypographyMontserrat500>
          <TextFieldConfCustom
            placeholder='Enter group name'
            InputLabelProps={{ shrink: false, style: { height: '34px' } }}
            variant='outlined'
            onChange={handleChangeName}
            inputProps={{ style: { height: '34px', padding: '0 14px' } }}
          />
        </Stack>
        <Stack
          direction={'row'}
          sx={{
            justifyContent: 'end',
            width: '100%',
            gap: '14px'
          }}
        >
          <BigGreyButton
            onClick={handleClose}
            disableTouchRipple={true}
          >
            Back
          </BigGreyButton>
          <BigBlueButton
            onClick={() => {
              if (groupName.length > 0 && departmentId) {
                store.dispatch(
                  createGroupAction(groupName, groupType, departmentId)
                );
              }
              handleClose();
            }}
            disableTouchRipple={true}
          >
            Save
          </BigBlueButton>
        </Stack>
      </ModaLBox>
    </Modal>
  );
};
