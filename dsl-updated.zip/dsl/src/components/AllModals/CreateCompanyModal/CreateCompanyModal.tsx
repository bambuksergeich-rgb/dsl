'use client';

import { EmptyImageIcon } from '@/public/icons/createCompanyPage/EmptyImage.icon';
import { createCompany } from '@/src/store/actions/createCompany';
import { store } from '@/src/store/store';
import { SimpleMUIButton } from '@/src/styles/muiButtonStyles';
import { TextFieldConfCustom } from '@/src/styles/muiEditorStyles';
import {
  BigLightBlueButton,
  IconButtonWithoutBackground,
  TypographyMontserrat500,
  TypographyMontserrat600
} from '@/src/styles/muiStyledGlobal';
import { Modal, Stack } from '@mui/material';
import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import { addCompanyLogo } from '@/src/requests/addCompanyLogo';
import { StyledBackdrop } from '@/public/style';
import { Company } from '@/src/store/counter/companySlice';
import { telephoneMask } from '@/src/helpers/telephoneMask';

export const CreateCompanyModal = ({
  title,
  openModal,
  singlePage,
  handleClose,
  company
}: {
  title: string;
  openModal: boolean;
  singlePage: boolean;
  handleClose?: () => void;
  company?: Company;
}) => {
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [address, setAddress] = useState('');
  const [website, setWebsite] = useState('');
  const [avatar, setAvatar] = useState<File | null>(null);
  const [checkName, setCheckName] = useState<boolean>(false);
  const [checkEmail, setCheckEmail] = useState<boolean>(false);

  useEffect(() => {
    if (company) {
      setName(company.name);
      setEmail(company.email);
      setPhone(company.phone);
      setAddress(company.address);
      setWebsite(company.website);
    }
  }, [company]);

  const handleChangeName = (e: ChangeEvent<HTMLInputElement>) => {
    setName(e.target.value);
    setCheckName(false);
  };

  const handleChangeEmail = (e: ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    setCheckEmail(false);
  };

  const handleChangePhone = (event: ChangeEvent<HTMLInputElement>) => {
    setPhone(telephoneMask(event));
  };

  const handleChangeAddress = (e: ChangeEvent<HTMLInputElement>) => {
    setAddress(e.target.value);
  };

  const handleChangeWebSite = (e: ChangeEvent<HTMLInputElement>) => {
    setWebsite(e.target.value);
  };

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const imageBackground = useMemo(() => {
    return avatar ? `url(${URL.createObjectURL(avatar)})` : 'none';
  }, [avatar]);

  const handleFileInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const file = event.target.files[0];
      setAvatar(file);
    }
  };

  return (
    <Modal
      open={openModal}
      onClose={handleClose ? handleClose : () => {}}
      hideBackdrop={singlePage}
      disableAutoFocus={singlePage}
      BackdropComponent={StyledBackdrop}
    >
      <Stack
        alignItems={'center'}
        sx={{
          position: 'absolute' as 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '500px',
          padding: '24px',
          border: '1px solid rgba(255, 255, 255, 0.15)',
          background: 'linear-gradient(72deg, #0A0F18 0%, #373B44 100%)',
          borderRadius: '12px'
        }}
      >
        <Stack
          flexDirection={'column'}
          gap={'24px'}
          sx={{ width: '100%' }}
        >
          <TypographyMontserrat600 fontSize={'16px'}>
            {title}
          </TypographyMontserrat600>
          <Stack
            flexDirection={'row'}
            sx={{ alignItems: 'center' }}
          >
            <input
              type='file'
              accept='image/*'
              ref={fileInputRef}
              style={{ display: 'none' }}
              onChange={handleFileInputChange}
            />
            <IconButtonWithoutBackground
              disableTouchRipple={true}
              sx={{
                backgroundColor: '#727170',
                width: '100px',
                height: '100px',
                borderRadius: '12px',
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: '24px',
                backgroundImage:
                  company?.logoUrl && imageBackground === 'none'
                    ? `url(${company.logoUrl})`
                    : imageBackground,
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center',
                '&:active': {
                  backgroundColor: '#727170'
                },
                '&:hover': {
                  backgroundColor: '#727170'
                }
              }}
              onClick={() => {
                if (fileInputRef.current) {
                  fileInputRef.current.click();
                }
              }}
            >
              {!company?.logoUrl && !avatar ? <EmptyImageIcon /> : null}
            </IconButtonWithoutBackground>

            <BigLightBlueButton
              sx={{ width: '170px', height: '44px' }}
              disableTouchRipple={true}
              onClick={async () => {
                if (avatar) {
                  await addCompanyLogo(avatar, company?.id);
                }
              }}
            >
              <TypographyMontserrat500
                textTransform={'initial'}
                sx={{ fontSize: '16px' }}
              >
                {'Add an emblem'}
              </TypographyMontserrat500>
            </BigLightBlueButton>
          </Stack>
          <Stack
            flexDirection={'column'}
            sx={{
              width: '100%',
              borderRadius: '6px',
              gap: '6px',
              position: 'relative'
            }}
          >
            <TypographyMontserrat500 fontSize={'14px'}>
              Company name*
            </TypographyMontserrat500>
            <TextFieldConfCustom
              placeholder='Enter company name'
              InputLabelProps={{ shrink: false, style: { height: '34px' } }}
              variant='outlined'
              value={name}
              inputProps={{ style: { height: '34px', padding: '0 14px' } }}
              onChange={handleChangeName}
              sx={
                checkName
                  ? {
                      '& fieldset': {
                        borderColor: '#BB382F !important'
                      },
                      '&:hover fieldset': {
                        borderColor: '#BB382F !important'
                      },
                      '&.Mui-focused fieldset': {
                        borderColor: '#BB382F !important'
                      }
                    }
                  : null
              }
            />
            {checkName && (
              <TypographyMontserrat600
                sx={{
                  fontSize: '12px',
                  color: '#BA584F',
                  position: 'absolute',
                  bottom: '-23px',
                  left: 0
                }}
              >
                Data entered incorrectly
              </TypographyMontserrat600>
            )}
          </Stack>
          <Stack
            flexDirection={'column'}
            sx={{
              width: '100%',
              borderRadius: '6px',
              gap: '6px',
              position: 'relative'
            }}
          >
            <TypographyMontserrat500 fontSize={'14px'}>
              E-mail*
            </TypographyMontserrat500>
            <TextFieldConfCustom
              placeholder='Enter e-mail'
              type='email'
              InputLabelProps={{ shrink: false, style: { height: '34px' } }}
              variant='outlined'
              value={email}
              inputProps={{ style: { height: '34px', padding: '0 14px' } }}
              onChange={handleChangeEmail}
              sx={
                checkEmail
                  ? {
                      '& fieldset': {
                        borderColor: '#BB382F !important'
                      },
                      '&:hover fieldset': {
                        borderColor: '#BB382F !important'
                      },
                      '&.Mui-focused fieldset': {
                        borderColor: '#BB382F !important'
                      }
                    }
                  : null
              }
            />
            {checkEmail && (
              <TypographyMontserrat600
                sx={{
                  fontSize: '12px',
                  color: '#BA584F',
                  position: 'absolute',
                  bottom: '-23px',
                  left: 0
                }}
              >
                Data entered incorrectly
              </TypographyMontserrat600>
            )}
          </Stack>
          <Stack
            flexDirection={'column'}
            sx={{
              width: '100%',
              borderRadius: '6px',
              gap: '6px'
            }}
          >
            <TypographyMontserrat500 fontSize={'14px'}>
              Phone number
            </TypographyMontserrat500>
            <TextFieldConfCustom
              placeholder='Enter phone number'
              InputLabelProps={{ shrink: false, style: { height: '34px' } }}
              variant='outlined'
              value={phone}
              inputProps={{ style: { height: '34px', padding: '0 14px' } }}
              onChange={handleChangePhone}
            />
          </Stack>
          <Stack
            flexDirection={'column'}
            sx={{
              width: '100%',
              borderRadius: '6px',
              gap: '6px'
            }}
          >
            <TypographyMontserrat500 fontSize={'14px'}>
              Address
            </TypographyMontserrat500>
            <TextFieldConfCustom
              placeholder='Enter address'
              InputLabelProps={{ shrink: false, style: { height: '34px' } }}
              variant='outlined'
              value={address}
              inputProps={{ style: { height: '34px', padding: '0 14px' } }}
              onChange={handleChangeAddress}
            />
          </Stack>
          <Stack
            flexDirection={'column'}
            sx={{
              width: '100%',
              borderRadius: '6px',
              gap: '6px'
            }}
          >
            <TypographyMontserrat500 fontSize={'14px'}>
              Site
            </TypographyMontserrat500>
            <TextFieldConfCustom
              placeholder='Enter site'
              InputLabelProps={{ shrink: false, style: { height: '34px' } }}
              variant='outlined'
              value={website}
              inputProps={{ style: { height: '34px', padding: '0 14px' } }}
              onChange={handleChangeWebSite}
            />
          </Stack>
          <SimpleMUIButton
            sx={{ width: '100%', height: '44px' }}
            onClick={async () => {
              if (avatar) {
                await addCompanyLogo(avatar, company?.id);
              }
              if (name.length >= 2 && /\S+@\S+\.\S+/.test(email)) {
                store.dispatch(
                  createCompany(
                    name,
                    email,
                    phone,
                    address,
                    website,
                    singlePage,
                    handleClose
                  )
                );
              }

              if (name.length < 2) {
                setCheckName(true);
              }

              if (!/\S+@\S+\.\S+/.test(email)) {
                setCheckEmail(true);
              }
            }}
          >
            <TypographyMontserrat500 sx={{ fontSize: '16px' }}>
              {'Save'}
            </TypographyMontserrat500>
          </SimpleMUIButton>
        </Stack>
      </Stack>
    </Modal>
  );
};
