"use state";

import { Modal } from "@mui/material";
import { Box } from "@mui/system";
import React, { useState } from "react";
import { StyledBackdrop } from "@/public/style";
import { store } from "@/src/store/store";
import { createComponentDraft } from "@/src/store/actions/createComponentDraft";
import ComponentsForm from "../../Dashboards/Sidebar/components/Settings/components/ComponentsForm";

const CreateComponentDraftModal = ({
  openModal,
  handleCloseModal,
  widgetTemplateDraftId,
}: {
  openModal: boolean;
  handleCloseModal: () => void;
  widgetTemplateDraftId: string;
}) => {
  const [name, setName] = useState<string>("");
  const [data, setData] = useState<string>("");
  const [selector, setSelector] = useState<string>("");

  const handleChangeName = (event: React.ChangeEvent<HTMLInputElement>) => {
    setName(event.target.value);
  };

  const handleChangeData = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setData(event.target.value);
  };

  const handleChangeSelector = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelector(event.target.value);
  };

  const onSaveSetting = () => {
    store.dispatch(
      createComponentDraft(widgetTemplateDraftId, name, data, selector),
    );
    setName("");
    setData("");
    setSelector("");
    handleCloseModal();
  };

  return (
    <Modal
      open={openModal}
      onClose={handleCloseModal}
      BackdropComponent={StyledBackdrop}
    >
      <Box
        sx={{
          position: "absolute" as "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "24px",
          border: "1px solid rgba(255, 255, 255, 0.15)",
          background: "linear-gradient(72deg, #0A0F18 0%, #373B44 100%)",
          borderRadius: "12px",
        }}
      >
        <ComponentsForm
          onSaveSetting={onSaveSetting}
          name={name}
          handleChangeName={handleChangeName}
          data={data}
          handleChangeData={handleChangeData}
          selector={selector}
          handleChangeSelector={handleChangeSelector}
        />
      </Box>
    </Modal>
  );
};

export default CreateComponentDraftModal;
