import { Box, Modal } from "@mui/material";
import { DashboardActivies } from "./DashboardActivies";
import { StyledBackdrop } from "@/public/style";

const ActiviesModal = ({
  openModal,
  handleCloseModal,
}: {
  openModal: boolean;
  handleCloseModal: () => void;
}) => {
  return (
    <Modal
      open={openModal}
      onClose={handleCloseModal}
      BackdropComponent={StyledBackdrop}
    >
      <Box
        sx={{
          position: "absolute" as "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "24px",
          border: "1px solid rgba(255, 255, 255, 0.15)",
          background: "linear-gradient(72deg, #0A0F18 0%, #373B44 100%)",
          borderRadius: "12px",
        }}
      >
        <DashboardActivies handleCloseModal={handleCloseModal} />
      </Box>
    </Modal>
  );
};

export default ActiviesModal;
