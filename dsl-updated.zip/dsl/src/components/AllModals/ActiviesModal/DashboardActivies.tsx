"use client";

import { Stack } from "@mui/material";
import { useEffect, useState } from "react";
import { TypographyMontserrat600 } from "@/src/styles/muiStyledGlobal";
import { SimpleMUIButton } from "@/src/styles/muiButtonStyles";
import { CrossIcon } from "@/public/icons/Cross.icon";
import { store } from "@/src/store/store";
import { useSelector } from "react-redux";
import { State } from "@/src/store/initialState";
import { useSearchParams } from "next/navigation";
import { ActivitiesTableAll } from "@/src/components/Activities/common/ActivitiesTableAll";
import { Pagination } from "@/src/components/Pagination/Pagination";
import { NoData } from "@/src/components/NoData/NoData";
import { Activitie, ActivitieData } from "@/src/store/counter/activitiesSlice";
import { getUsers } from "@/src/store/actions/getUsers";
import { getCompany } from "@/src/store/actions/getCompany";
import { getUser } from "@/src/store/actions/getUser";
import { getActivityMetadataAction } from "@/src/store/actions/getActivityMetadataAction";
import { ActivitiesHeader } from "@/src/components/Activities/ActivitiesHeader";
import { getActivitiesForDashboardAction } from "@/src/store/actions/Dashboard/getActivitiesForDashboardAction";
import { useAppSelector } from "@/src/hooks/typedAsyncThunk";

const componentList = [
  "ALL",
  "SCRIPT",
  "DOCKER_IMAGE",
  "DOCKER_CONTAINER",
  "COMPANY",
  "DEPARTMENT",
  "USER",
  "USER_INVITATION",
  "ROLE",
  "WIDGET_TEMPLATE",
  "COMPONENT",
  "WIDGET",
  "WIDGET_COMPONENT",
  "DASHBOARD",
  "EVENT",
  "STORAGE",
];

export const DashboardActivies = ({
  handleCloseModal,
}: {
  handleCloseModal: () => void;
}) => {
  const [page, setPage] = useState<number>(1);
  const [filter, setFilter] = useState<string>("ALL");
  const [type, setType] = useState<string>("ALL");
  const [dataPage, setDataPage] = useState<Activitie[]>([]);
  const [filteredData, setFilteredData] = useState<Activitie[]>([]);
  const [departmentId, setDepartmentId] = useState<string>("");
  const [action, setAction] = useState<string>("ALL");
  const [employee, setEmployee] = useState<string>("ALL");
  const [employeeId, setEmployeeId] = useState<string>("ALL");
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const role = useSelector((state: State) => state.userRole);

  const { dashboard } = useAppSelector((state) => state.dashboard);

  const searchParams = useSearchParams();
  useEffect(() => {
    const department = searchParams.get("departmentId");
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getUsers(departmentId));
    }
  }, [departmentId]);

  useEffect(() => {
    store.dispatch(getCompany(false));
    store.dispatch(getUser());
  }, []);

  useEffect(() => {
    if (role) {
      store.dispatch(getActivityMetadataAction(role.name === "Administrator"));
    }
  }, [role]);
  useEffect(() => {
    if (departmentId && dashboard?.id) {
      store.dispatch(
        getActivitiesForDashboardAction(
          1,
          departmentId,
          dashboard.id,
          action,
          fromDate,
          toDate,
          setPage,
          setLoading,
        ),
      );
    }
  }, [departmentId, dashboard?.id, action, fromDate, toDate]);

  const activities: ActivitieData = useSelector(
    (state: State) => state.activities,
  );

  const user = useSelector((state: State) => state.user);

  useEffect(() => {
    setFilteredData(activities.content);
  }, [activities.content]);

  useEffect(() => {
    setDataPage(activities.content);
  }, [filteredData]);

  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
    if (activities.totalElements / 10 < page) {
      setPage(1);
    }
    if (departmentId && dashboard?.id) {
      store.dispatch(
        getActivitiesForDashboardAction(
          value,
          departmentId,
          dashboard.id,
          action,
          fromDate,
          toDate,
          setPage,
          setLoading,
        ),
      );
    }
  };

  return (
    <div className="flex flex-col">
      <Stack
        flexDirection={"column"}
        sx={{
          width: "100%",
          justifyContent: "space-between",
          marginBottom: "25px",
        }}
      >
        <Stack direction="row" justifyContent="space-between">
          <TypographyMontserrat600 fontSize={"16px"}>
            {"Number of Scripts Using Storage"}
          </TypographyMontserrat600>

          <SimpleMUIButton
            isicon
            verysmall
            onClick={() => {
              handleCloseModal();
            }}
          >
            <CrossIcon />
          </SimpleMUIButton>
        </Stack>
        <div className="flex flex-col">
          <Stack sx={{ p: "40px 0 0 0" }}>
            <ActivitiesHeader
              showTitle={false}
              stackSX={{
                pb: 4,
                justifyContent: "flex-end",
              }}
              isAllActivities={role.name === "Administrator"}
              name={`${user.firstName} ${user.lastName}'s`}
              filter={filter}
              setFilter={setFilter}
              componentList={componentList}
              type={type}
              setType={setType}
              action={action}
              setAction={setAction}
              employee={employee}
              setEmployee={setEmployee}
              fromDate={fromDate}
              setFromDate={setFromDate}
              toDate={toDate}
              setToDate={setToDate}
              employeeId={employeeId}
              setEmployeeId={setEmployeeId}
              page={page}
              setPage={setPage}
            />
          </Stack>
          {!loading ? (
            activities?.content?.length > 0 ? (
              <>
                <ActivitiesTableAll
                  sx={{
                    p: 0,
                  }}
                  isAdmin={true}
                  dataPage={dataPage}
                />
                <Pagination
                  page={page}
                  totalElements={activities.totalElements}
                  handleChange={handleChange}
                />
              </>
            ) : (
              <NoData />
            )
          ) : null}
        </div>
      </Stack>
      <Stack
        flexDirection={"column"}
        sx={{ width: "calc(100vw - 340px)" }}
      ></Stack>
    </div>
  );
};
