"use client";

import { Stack } from "@mui/material";
import { useEffect, useState } from "react";
import { Pagination } from "../../Pagination/Pagination";
import { ModalDashboardTable } from "./ModalDashboardTable";
import { TypographyMontserrat600 } from "@/src/styles/muiStyledGlobal";
import { SimpleMUIButton } from "@/src/styles/muiButtonStyles";
import { CrossIcon } from "@/public/icons/Cross.icon";
import { Loading } from "../../Loading/Loading";
import { store } from "@/src/store/store";
import { getDashboards } from "@/src/store/actions/getDashboards";
import { Dashboard, DashboardsData } from "@/src/store/counter/dashboardsSlice";
import { useSelector } from "react-redux";
import { State } from "@/src/store/initialState";
import { useSearchParams } from "next/navigation";

export const ModalDashboard = ({
  handleCloseModal,
  onSelect,
}: {
  handleCloseModal: () => void;
  onSelect: (dashboard: Dashboard) => void;
}) => {
  const [dataPage, setDataPage] = useState<Dashboard[] | null>(null);
  const [filteredData, setFilteredData] = useState<any[] | []>([]);

  const [departmentId, setDepartmentId] = useState<string>("");

  const searchParams = useSearchParams();

  useEffect(() => {
    const department = searchParams.get("departmentId");
    if (department) {
      setDepartmentId(department);
    }
  }, [searchParams]);

  useEffect(() => {
    if (departmentId) {
      store.dispatch(getDashboards(1, departmentId));
    }
  }, [departmentId]);

  const dashboards: DashboardsData = useSelector(
    (state: State) => state.dashboards,
  );

  useEffect(() => {
    setFilteredData(dashboards.content);
  }, [dashboards.content]);

  useEffect(() => {
    setDataPage(dashboards.content);
  }, [filteredData]);

  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    store.dispatch(getDashboards(value, departmentId));
    setFilteredData(dashboards.content);
  };

  if (!departmentId) {
    return <Loading />;
  }

  return (
    <Stack>
      <Stack
        flexDirection={"row"}
        sx={{
          width: "100%",
          justifyContent: "space-between",
          marginBottom: "25px",
        }}
      >
        <TypographyMontserrat600 fontSize={"16px"}>
          {"List of Dashboard"}
        </TypographyMontserrat600>
        <SimpleMUIButton
          isicon
          verysmall
          onClick={() => {
            handleCloseModal();
          }}
        >
          <CrossIcon />
        </SimpleMUIButton>
      </Stack>
      <Stack flexDirection={"column"} sx={{ width: "calc(100vw - 340px)" }}>
        {dataPage && (
          <ModalDashboardTable
            dataPage={dataPage}
            onSelect={onSelect}
            departmentId={departmentId}
          />
        )}
        {dataPage && (
          <Pagination
            totalElements={dashboards.totalElements}
            handleChange={handleChange}
          />
        )}
      </Stack>
    </Stack>
  );
};
