import { makeVar, InMemoryCache } from '@apollo/client';

export const createNewFileVar = makeVar(false);

export const createNewFolderVar = makeVar(false);

export const cache = new InMemoryCache({
  typePolicies: {
    Query: {
      fields: {
        createNewFile: {
          read() {
            return createNewFileVar();
          }
        },
        createNewFolder: {
          read() {
            return createNewFolderVar();
          }
        }
      }
    }
  }
});
